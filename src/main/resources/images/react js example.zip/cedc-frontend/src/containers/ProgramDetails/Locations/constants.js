import { pagination } from "../../../utils/constants";

export const ADDRESS_TABS = {
  ADDRESS_VARIATIONS: 0,
  PROVIDER_ASSOCIATIONS: 1,
  LOCATION_HISTORY: 2,
};

export const getAddLocationPopupDefaultValues = (data, ceSelected) => {
  const { ceID, ceName, ceCode } = ceSelected || {};
  return {
    ceid: data.ceid || ceID,
    entityLocationId: data.entityLocationId || 0,
    locationName: data.locationName || "",
    locationHrsaId: data.locationHrsaId || "",
    addressLine1: data.addressLine1 || "",
    addressLine2: data.addressLine2 || "",
    city: data.city || "",
    stateName: data.state || "",
    zipCode: data.zip || "",
    startDate: data.locationStatus === "Terminated" ? "" : data.startDate || "",
    endDate: data.locationStatus === "Terminated" ? "" : data.endDate || "",
    coveredEntityName: data.coveredEntity || ceName || "",
    ceCode: data.ceCode || ceCode || "",
    sourceId: data.sourceId || 1,
  };
};
export const getRegisteredOPATablePayload = (values = {}, ceSelected) => {
  return {
    hrsaid: ceSelected.ceCode || "",
    ceId: ceSelected.ceID || 0,
    city: values.city || "",
    state: values.state || "",
    zip: values.zip || "",
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "",
    sortBy: values.sortBy || "",
    filter: values.filter || [],
    export: values.export || false,
  };
};
export const getAddVariationPopupDefaultValues = (data) => {
  return {
    ceid: data.ceid || "",
    entityLocationId: data.entityLocationId || 0,
    locationName: "",
    locationHrsaId: "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    stateName: "",
    zipCode: "",
    startDate: "",
    endDate: "",
    coveredEntityName: data.coveredEntity || "",
    ceCode: data.ceCode || "",
  };
};
export const getLocationsFiltersObject = (filters = []) => {
  const dateFields = ["lastModifiedDate", "startDate", "endDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const ALL = "all";
export const NEW = "Pending";
export const PARTICIPATING = "Participating";
export const TERMINATED = "Terminated";
export const OPPORTUNITY_ADDRESS = "opportunityAddress";
