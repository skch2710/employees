export const getAddProviderDefaultValues = (data = {}) => {
  const {
    providerNpi,
    firstName,
    lastName,
    providerDea,
    prescriberSpi,
    startDate,
    endDate,
    prescriberPanelTypeId,
    isTerminated,
    lastModifiedDate
  } = data || {};
  return {
    npi: providerNpi || "",
    firstName: firstName || "",
    lastName: lastName || "",
    providerDea: providerDea || "",
    spi: prescriberSpi || "",
    startDate: startDate || "",
    endDate: endDate || "",
    prescriberPanelTypeId: prescriberPanelTypeId || 0,
    providerLocations: [],
    prescriberPanelTypeChanged: "N",
    lastModifiedDate: lastModifiedDate || ""
  };
};

export const addProviderPayload = (data = {}) => {
  const {
    prescriberId,
    providerNpi,
    firstName,
    lastName,
    providerDea,
    prescriberSpi,
    startDate,
    endDate,
    prescriberPanelTypeId,
    prescriberPanelTypeChanged,
    prescriberCeid,
    npi,
    spi,
  } = data || {};
  return {
    npi: providerNpi || npi,
    firstName: firstName,
    lastName: lastName,
    providerDea: providerDea,
    spi: prescriberSpi || spi,
    startDate: startDate,
    endDate: endDate,
    prescriberPanelTypeId: prescriberPanelTypeId || 0,
    providerLocations: [],
    prescriberPanelTypeChanged: prescriberPanelTypeChanged || "N",
    ...(prescriberCeid && {
      providerCeId: prescriberCeid,
      providerId: prescriberId,
    }),
  };
};
