import React, {
  forwardRef,
  memo,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { Button, Grid } from "@material-ui/core";
import _get from "lodash/get";
import { useDispatch, useSelector } from "react-redux";
import { BsChevronLeft, BsChevronRight } from "react-icons/bs";
import RegisteredOPATable from "./RegisteredOPATable";
import ParticipatingOPATable from "./ParticipatingOPATable";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import { useOPALocationsTablesStyles } from "./styles";
import { pagination } from "../../../../../utils/constants";
import { COContext } from "../../../COContext";
import {
  getExcludedData,
  getSelectedRows,
  getUserSession,
} from "../../../../../utils/helper";
import BasicPopup from "../../../../../components/Popup/BasicPopup";
import AccuracyConfirmationPopup from "./AccuracyConfirmationPopup";
import AccuracyConfirmationPopupFooter from "./AccuracyConfirmationPopupFooter";
import { getAllCesAssociatedToAddresses } from "../../../../../context/actions/Locations";

const RegisteredParticipatedTables = memo(
  forwardRef((props = {}, ref) => {
    const { searchTableProps, ceSelected } = props;
    const globalClasses = useGlobalStyles();
    const classes = useOPALocationsTablesStyles();
    const { participatingLocationsData, setParticipatingLocationsData } =
      useContext(COContext) || {};
    const defaultValues = {
      confirmedData: [],
    };
    const dispatch = useDispatch();
    const userSession = getUserSession();
    const internalUser = userSession.isInternalUser;

    const [showAccuracyPopup, setAccuracyPopup] = useState(false);
    const [searchResults, setSearchResults] = useState({});
    const [searchTableControllers, setSearchTableControllers] = useState({
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "",
      sortBy: "",
    });
    const [selectedSearchResults, setSelectedSearchResults] = useState({
      registered: [],
      participating: [],
    });
    const [cesWithSameAddress, setCesWithSameAddress] = useState([]);
    const searchTableRef = useRef(null);
    const draftTableRef = useRef(null);

    const { records: searchResultsInRedux } = useSelector(
      (state) => state.getRegisteredLocationListData
    );
    useEffect(() => {
      setSearchResults({
        ...searchResultsInRedux,
        content:
          (searchResultsInRedux.content &&
            searchResultsInRedux.content.map((row) => {
              return { ...row, tableData: {} };
            })) ||
          [],
      });
    }, [searchResultsInRedux]);

    const handleAddToDraft = (values) => {
      const selectedRows = getSelectedRows(searchTableRef);
      if (selectedRows.length) {
        let addingData = [];
        if (values) {
          //adding selected result which don't have multiple CEs with same address
          addingData = selectedRows.filter(
            (row) =>
              !cesWithSameAddress.find(
                (ele) =>
                  ele.standardAddrHashKey == row.standardAddrHashKey ||
                  ele.addrHashKey == row.nonStandardAddrHashKey
              )
          );

          // values are coming from accuracy popup

          const confirmedData = values.confirmedData.filter(
            (row) => row.tableData && row.tableData.checked
          );
          addingData = [...addingData, ...confirmedData];
        } else {
          addingData = selectedRows;
        }
        addingData = addingData.map((row) => ({
          ...row,
          tableData: {
            checked: false,
          },
        }));
        let totalRows = [...participatingLocationsData.content, ...addingData];
        // totalRows=totalRows.map((row)=>({
        //   ...row,
        //   tableData: {
        //     checked:false,
        //   },
        // }))
        setParticipatingLocationsData({
          content: totalRows,
          totalElements: totalRows.length,
        });

        // To unselect rows of search table. Otherwise if we removed from draft those rows are getting checked.
        const newData = searchResults.content.map((row) => ({
          ...row,
          tableData: {
            checked: false,
          },
        }));
        setSearchResults({
          ...searchResults,
          content: newData,
        });
        setSelectedSearchResults({
          ...selectedSearchResults,
          registered: [],
          participating: addingData,
        });
      }
      setCesWithSameAddress([]);
      setAccuracyPopup(false);
    };
    const handleConfirmationPopup = (state) => {
      if (state) {
        const selectedRows = getSelectedRows(searchTableRef);
        if (selectedRows.length) {
          const hashData = selectedRows.map((row) =>
            row.standardAddrHashKey
              ? { hashKey: row.standardAddrHashKey, isStandaredKey: true }
              : { hashKey: row.nonStandardAddrHashKey, isStandaredKey: false }
          );
          const payload = {
            hashKeyList: hashData || [],
            ceId: ceSelected.ceID,
          };
          dispatch(
            getAllCesAssociatedToAddresses(payload, (res) => {
              if (res.statusCode === 200) {
                setAccuracyPopup(true);
                setCesWithSameAddress(res.data || []);
              } else {
                handleAddToDraft();
                setAccuracyPopup(false);
              }
            })
          );
        }
      } else {
        setAccuracyPopup(false);
      }
    };

    const handleRemoveFromDraft = () => {
      const selectedRows = getSelectedRows(draftTableRef);
      if (selectedRows.length) {
        const updatedRowData = getExcludedData({
          originalList: participatingLocationsData.content,
          draftList: selectedRows,
          identifierKey: "id",
        });
        setParticipatingLocationsData({
          content: updatedRowData,
          totalElements: updatedRowData.length,
        });
        setSelectedSearchResults({
          ...selectedSearchResults,
          registered: [],
          participating: [],
        });
      }
    };

    const handleClearDraft = () => {
      const newData = searchResults.content.map((row) => ({
        ...row,
        tableData: {
          checked: false,
        },
      }));
      const participatingData = participatingLocationsData.content.map(
        (row) => ({
          ...row,
          tableData: {
            checked: false,
          },
        })
      );
      setParticipatingLocationsData({
        content: participatingData,
        totalElements: participatingData.length,
      });
      setSearchResults({
        ...searchResults,
        content: newData,
      });
      setSelectedSearchResults({ registered: [], participating: [] });
    };

    // useEffect(() => {
    //   return () => handleClearDraft();
    // }, []);

    const handleValidate = (values = {}) => {
      const error = {};
      if (
        !(
          values.confirmedData &&
          values.confirmedData.find(
            (ele) => ele.tableData && ele.tableData.checked
          )
        ) &&
        internalUser
      ) {
        error.confirmedData = "Please select and confirm";
      }
      return error;
    };

    return (
      <>
        <Grid container spacing={2} justifyContent="space-between">
          <Grid item className={classes.gridTableContainer}>
            <div className={globalClasses.tableCardPrimary}>
              <RegisteredOPATable
                searchResults={searchResults}
                ref={{ tableRef: searchTableRef, imperativeRef: ref }}
                controllers={searchTableControllers}
                setControllers={setSearchTableControllers}
                selectedSearchResults={selectedSearchResults}
                setSelectedSearchResults={setSelectedSearchResults}
                ceSelected={ceSelected}
                {...searchTableProps}
              />
            </div>
          </Grid>
          <Grid item className={classes.gridActionBtnContainer}>
            <Grid
              container
              spacing={2}
              direction="column"
              alignItems="center"
              className={classes.actionButtonContainer}
            >
              <Grid item>
                <Button
                  endIcon={<BsChevronRight size={14} />}
                  variant="contained"
                  size="small"
                  className={globalClasses.primaryBtn}
                  onClick={() => {
                    handleConfirmationPopup(true);
                  }}
                >
                  Add
                </Button>
              </Grid>
              <Grid item>
                <Button
                  startIcon={<BsChevronLeft size={14} />}
                  variant="contained"
                  size="small"
                  className={globalClasses.redBtn}
                  onClick={handleRemoveFromDraft}
                >
                  Remove
                </Button>
              </Grid>
              {/* <Grid item>
                <Button
                  variant="outlined"
                  size="small"
                  className={globalClasses.offWhiteBtn}
                  onClick={handleClearDraft}
                >
                  Clear
                </Button>
              </Grid> */}
            </Grid>
          </Grid>
          <Grid item className={classes.gridTableContainer}>
            <div className={globalClasses.tableCardPrimary}>
              <ParticipatingOPATable
                ref={draftTableRef}
                selectedSearchResults={selectedSearchResults}
                setSelectedSearchResults={setSelectedSearchResults}
              />
            </div>
          </Grid>
        </Grid>
        <BasicPopup
          disableCloseButton
          title="Confirmation of Accuracy Needed"
          show={showAccuracyPopup}
          disableFooter={true}
          isCustomFooter={true}
          footerActionElement={
            <AccuracyConfirmationPopupFooter
              setShowAccuracyPopup={(state) => {
                if (!state) handleAddToDraft({ confirmedData: [] });
                setAccuracyPopup(state);
              }}
            />
          }
          dialogProps={{
            maxWidth: "md",
          }}
          withFormik={true}
          formikProps={{
            initialValues: defaultValues,
            onSubmit: handleAddToDraft,
            validate: handleValidate,
          }}
          handleClose={() => {
            handleConfirmationPopup(false);
          }}
          dialogTitleProps={{ className: classes.dialogTitle }}
        >
          <AccuracyConfirmationPopup
            selectedRows={getSelectedRows(searchTableRef)}
            ceSelected={ceSelected}
            cesWithSameAddress={cesWithSameAddress}
          />
        </BasicPopup>
      </>
    );
  })
);

export default RegisteredParticipatedTables;
