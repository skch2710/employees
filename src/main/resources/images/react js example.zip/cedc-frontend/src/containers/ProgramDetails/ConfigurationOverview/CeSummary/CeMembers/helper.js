import { pagination } from "../../../../../utils/constants";

export const getMembersPayloadJson = (values = {}) => {
  const { ceId, ...rest } = values;
  return {
    ceid: [values.ceId],
    dob: "",
    endDate: "",
    firstName: "",
    lastName: "",
    mrn: "",
    sortBy: "",
    sortOrder: "",
    startDate: "",
    type: "",
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "",
    sortOrder: "",
    filter: [],
    export: false,
    ...rest,
  };
};
