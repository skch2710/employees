import React, { useCallback, useContext, useRef, useState, memo } from "react";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import { useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import MaterialTable, { MTableToolbar } from "material-table";
import { TiFilter } from "react-icons/ti";
import { pagination } from "../../../../../../utils/constants";
import { getBillingContactDetailsFiltersObject } from "./helpers";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useBillingContactTableStyles } from "./styles";
import { COContext } from "../../../../COContext";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import { getTableHeaderCount } from "../../../../../../utils/helper";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../../../components/common/Pagination";

const BillingContactTable = memo((props = {}) => {
  const { fetchBillingContactTableData, isAddUserEnable = true } = props;
  const { setOpenAddUserPopup } = useContext(COContext);
  const theme = useTheme();
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();

  const [enableFilters, setEnableFilters] = useState(false);
  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.billingLimit,
    sortBy: "userId",
    sortOrder: "asc",
  });
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});
  const { loading, records: billingContactTableData } = useSelector(
    (state) => state.coBillingContactList
  );
  const classes = useBillingContactTableStyles({
    totalElements: billingContactTableData.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.page,
  });

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      let rowsPerPage = Number(pageSize);
      const totalPages = Math.ceil(
        billingContactTableData.totalElements / rowsPerPage
      );
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchBillingContactTableData(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          filter: columnFilters,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
        },
        (resp) => {
          setController((prev) => ({
            ...prev,
            page: resp.pageNo || pagination.page,
            pageSize: resp.pageSize || pagination.billingLimit,
          }));
        }
      );
    },
    [columnFilters, billingContactTableData, controller]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = BILLING_CONTACT_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchBillingContactTableData({
        pageNumber: controller.page,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getBillingContactDetailsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchBillingContactTableData({
      ...controller,
      filter: filterPayload,
    });
  };

  const BILLING_CONTACT_COLUMNS = [
    {
      title: "Full Name",
      field: "fullname",
      defaultFilter: enableFilters && columnFiltersRef.current.fullname,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.fullname}>
            <span>{rowData.fullname}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.fullname}
          placeholder="Full Name"
        />
      ),
    },
    {
      title: "Email Address",
      field: "emailAddress",
      defaultFilter: enableFilters && columnFiltersRef.current.emailAddress,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.emailAddress}>
            <span>{rowData.emailAddress}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.emailAddress}
          placeholder="Email Address"
        />
      ),
    },
    {
      title: "Contact Number",
      field: "contactNumber",
      defaultFilter: enableFilters && columnFiltersRef.current.contactNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.contactNumber}>
            <span>{rowData.contactNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.contactNumber}
          placeholder="Contact Number"
        />
      ),
    },
    {
      title: "Title",
      field: "title",
      defaultFilter: enableFilters && columnFiltersRef.current.title,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.title}>
            <span>{rowData.title}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.title}
          placeholder="Title"
        />
      ),
    },
  ];

  const checkIsTableEmpty = (data) => {
    return _isEmpty(data) || data.totalElements < 1;
  };

  const FILTER_ACTION = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: "Enable Filter",
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      disabled: checkIsTableEmpty(billingContactTableData),
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  const ADD_USER_ACTION = [
    {
      icon: iconsAndButtons.AddUserButton(),
      isFreeAction: true,
      onClick: () => {
        setOpenAddUserPopup(true);
      },
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Billing Contact Information (${getTableHeaderCount(
              billingContactTableData.totalElements
            )})`}
          />
        }
        columns={BILLING_CONTACT_COLUMNS}
        data={billingContactTableData.content || []}
        page={controller.page - 1}
        totalCount={billingContactTableData.totalElements || 0}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        icons={{
          SortArrow: () => TableCustomSortArrow(controller),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={
          isAddUserEnable
            ? [...FILTER_ACTION, ...ADD_USER_ACTION]
            : FILTER_ACTION
        }
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          showTitle: true,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controller.pageSize,
          maxBodyHeight: 400,
          pageSizeOptions:
            _isEmpty(billingContactTableData) ||
            billingContactTableData.totalElements < 1
              ? []
              : pagination.pageBillingSizeOptions,
        }}
      />
    </div>
  );
});

export default BillingContactTable;
