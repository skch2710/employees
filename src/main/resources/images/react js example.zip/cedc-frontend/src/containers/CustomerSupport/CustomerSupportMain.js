import React, { useState, useEffect } from "react";
import { Grid, Typography, Link, Paper, FormLabel } from "@material-ui/core";
import "./CustomerSupport.css";
import Chartimg from "../../assets/Message.png";
import customer_Support_Email from "../../assets/customer_Support_Email.png";
import talk_supportTeam from "../../assets/talk_supportTeam.png";
import Hours_operation from "../../assets/Hours_operation.png";

const CustomerSupport = () => {
  return (
    <>
      <Grid>
        <Typography variant="h3" class="header_helpsupport">
          Help & Support
        </Typography>
        <p class="sub_header">Let's take a step ahead and help you better</p>
        <Grid>
          <Grid container spacing={2}>
            <Grid item sm={4} xs={12} md={6} lg={4}>
              <Paper className="card_backgroud card card-second-level">
                <Grid className="card-block connect_support">
                  <img class="icons_card" src={customer_Support_Email} alt="Active" />
                  <p class="card1_title">Connect with your support team</p>
                  <a href="mailto:ClientCare@340bdirect.com" class="link_340b cus-sup-text2 ">
                     ClientCare@340bdirect.com
                  </a>
                </Grid>
              </Paper>
            </Grid>
            <Grid item sm={4} xs={12} md={6} lg={4}>
              <Paper className="card_backgroud card card-second-level">
                <Grid className="card-block connect_support">
                  <img class="icons_card" src={talk_supportTeam} alt="Active" />
                  <p>
                    Talk with your support team <br />
                    <span class="cus-sup-text2">
                    (877) 848-9420, Press 4
                    </span>
                  </p>
                </Grid>
              </Paper>
            </Grid>
            <Grid item sm={4} xs={12} md={6} lg={4}>
              <Paper className="card_backgroud card card-second-level">
                <Grid className="card-block connect_support">
                  <img class="icons_card" src={Hours_operation} alt="Active" />
                  <p>
                    Hours of operation <br />
                    <span class="cus-sup-text2">
                    8:00am - 6:00pm (Central Time)
                    </span>
                  </p>
                </Grid>
              </Paper>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};
export default CustomerSupport;
