import React, { forwardRef, memo, useState } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEmpty from "lodash/isEmpty";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import moment from "moment";
import {
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { pagination } from "../../../../../../utils/constants";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import DatePicker from "../../../../../../components/common/DatePicker";
import Pagination from "../../../../../../components/common/Pagination";
import _get from "lodash/get";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";

const DynamicExclusionsTable = memo(
  forwardRef((props = {}, ref) => {
    const {
      appliedNdcExclusions = {},
      loading = false,
      handleNdcDetailsPopup = () => {},
      isDynamicListTerminated = false,
    } = props || {};
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const iconsAndButtons = useTableIconsAndButtons();

    const [enableFilters, setEnableFilters] = useState(false);

    const DYNAMIC_EXCLUSIONS_COLUMNS = [
      {
        title: "GCN",
        field: "gcn",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.gcn}>
              <span>{rowData.gcn}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="GCN" />
        ),
      },
      {
        title: "NDC",
        field: "ndc",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndc}>
              <a
                className={globalClasses.gridClickableLink}
                onClick={handleNdcDetailsPopup({ state: true, rowData })}
              >
                {rowData.ndc}
              </a>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="NDC" />
        ),
      },
      {
        title: "Drug Name",
        field: "drugName",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugName}>
              <span>{rowData.drugName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Drug Name" />
        ),
      },
      {
        title: "Manufacturer",
        field: "drugManufacturer",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugManufacturer}>
              <span>{rowData.drugManufacturer}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Manufacturer" />
        ),
      },
      {
        title: "Therapeutic Class",
        field: "therapeuticClass",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.therapeuticClass}>
              <span>{rowData.therapeuticClass}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Therapeutic Class" />
        ),
      },
      {
        title: "NDC Effective Start Date",
        field: "ndcEffecStartDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndcEffecStartDate}>
              <span>{rowData.ndcEffecStartDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
      {
        title: "NDC Effective End Date",
        field: "ndcEffecEndDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndcEffecEndDate}>
              <span>{rowData.ndcEffecEndDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
    ];

    const handleAppliedExclusionsExport = (data = []) => {
      const filteredData = data.map((row = {}) => ({
        GCN: row.gcn || "",
        NDC: row.ndc || "",
        "Drug Name": row.drugName || "",
        Manufacturer: row.drugManufacturer || "",
        "Therapeutic Class": row.therapeuticClass || "",
        "NDC Effective Start Date": row.ndcEffecStartDate || "",
        "NDC Effective End Date": row.ndcEffecEndDate || "",
      }));
      const ws = XLSX.utils.json_to_sheet(filteredData);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "Dynamic_NDC_Exclusions_List.xlsx");
    };

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(appliedNdcExclusions),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(appliedNdcExclusions),
        isFreeAction: true,
        onClick: () =>
          handleAppliedExclusionsExport(ref.current.dataManager.filteredData),
      },
    ];

    return (
      <>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Applied NDC Exclusions (${getTableHeaderCount(
                _get(appliedNdcExclusions, "totalElements", 0)
              )})`}
            />
          }
          tableRef={ref}
          columns={DYNAMIC_EXCLUSIONS_COLUMNS}
          data={_get(appliedNdcExclusions, "content", [])}
          totalCount={_get(appliedNdcExclusions, "totalElements", 0)}
          icons={{
            SortArrow: () => TableCustomSortArrow(),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            selection: !isDynamicListTerminated,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: pagination.limit,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(appliedNdcExclusions)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </>
    );
  })
);

export default DynamicExclusionsTable;
