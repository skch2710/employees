import React, { useState, useEffect, useContext, useRef } from "react";
import { useDispatch } from "react-redux";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Button, Grid, FormLabel } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import {
  getPharmacyGroups,
  getPharmacyStore,
} from "../../../../../../context/actions/Common";
import Pharmacytable from "./Pharmacytable";
import { LABELS, pagination } from "../../../../../../utils/constants";
import { VIEW_PHARMACIES } from "../../../../../../components/common/Table/TableHeadCells";
import { filterFunctionality } from "../../../../../../utils/common";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import { fetchSingleCePharmaciesTableData } from "../../../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import AutoComplete from "../../../../../../components/common/AutoComplete";

const ViewPharmacies = () => {
  const tableRef = useRef(null);
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    setPopupActiveMenu,
    setOpenAddCePopup,
    setCurrentPharmacy,
    messageUuid,
    currentPharmacy,
    setPhConfigStatusPercent,
    setPhGridPayload,
    setPhConfigSectionStatus,
    setIsNewPharmacy,
    setActiveInactiveCOMenus,
    activeInactiveCOMenus,
  } = useContext(COContext);

  const { ceid: ceId } = messageUuid || {};

  const [phNetworkId, setPhNetworkId] = useState(0);
  const [phStoreId, setPhStoreId] = useState(0);
  const [phNetworkList, setPhNetworkList] = useState([]);
  const [phStoreList, setPhStoreList] = useState([]);
  const [filterValues, setFilterValues] = useState([]);
  const [controllers, setControllers] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "pharmacyName",
  });
  const [viewPhTableData, setViewPhTableData] = useState({});
  const [viewPhLoading, setViewPhLoading] = useState(false);

  const onChangePagination = (newPage, pageSize) => {
    let currentPage = newPage + 1;
    const rowsPerPage = Number(pageSize);
    const { totalElements = 0 } = viewPhTableData;
    const totalPages = Math.ceil(totalElements / rowsPerPage) || 1;
    if (controllers.page > totalPages) currentPage = totalPages;
    else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
      currentPage = controllers.page;
    setControllers((prev) => ({
      ...prev,
      page: currentPage,
      pageSize: rowsPerPage,
    }));
    fetchPharmacies({
      pageNumber: currentPage,
      pageSize: rowsPerPage,
    });
  };

  const onChangeSorting = async (orderedColumnId) => {
    const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
    const sortBy = VIEW_PHARMACIES[orderedColumnId].field;
    setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
    fetchPharmacies({
      sortOrder: controllers.sortOrder === "asc" ? "desc" : "asc",
      sortBy: VIEW_PHARMACIES[orderedColumnId].field,
    });
  };

  const onChangeFilter = async (value) => {
    setControllers((prev) => ({ ...prev, page: pagination.page }));
    const payload = {
      pageNumber: 1,
    };

    if (value.length) {
      const responseValue = await filterFunctionality(value, "viewPharmacies");
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setFilterValues(responseValue);
    } else {
      payload.filter = [];
      setFilterValues([]);
    }
    fetchPharmacies(payload);
  };

  const handleChangePhNetwork = (value) => {
    tableRef.current.dataManager.changePageSize(pagination.limit);
    setFilterValues([]);
    setPhNetworkId(value ? value.phGroupId : 0);
    setPhStoreId(0);
    setPhStoreList([]);
    setControllers({
      page: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "asc",
      sortBy: "pharmacyName",
    });
    dispatch(
      getPharmacyStore(
        {
          ceid: [ceId],
          phGroupId: [value ? value.phGroupId : 0],
        },
        (res) => {
          setPhStoreList(res);
        }
      )
    );
    fetchPharmacies({
      phGroupId: value ? value.phGroupId : 0,
      phid: 0,
      pageNumber: pagination.page,
      sortBy: "pharmacyName",
      sortOrder: "asc",
      filter: [],
    });
  };

  const handleChangePhStore = (value) => {
    setFilterValues([]);
    setPhStoreId(value ? value.phid : 0);
    setControllers({
      page: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "asc",
      sortBy: "pharmacyName",
    });
    fetchPharmacies({
      phGroupId: phNetworkId,
      phid: value ? value.phid : 0,
      pageNumber: pagination.page,
      sortBy: "pharmacyName",
      sortOrder: "asc",
      filter: [],
    });
  };

  const fetchPharmacies = async (payload = {}) => {
    let json = {
      ceid: [ceId],
      phGroupId: phNetworkId,
      phid: phStoreId,
      export: false,
      pageNumber: controllers.page,
      pageSize: controllers.pageSize,
      sortBy: controllers.sortBy,
      sortOrder: controllers.sortOrder,
      startDate: "",
      endDate: "",
      status: "",
      filter: filterValues,
      ...payload,
    };
    setPhGridPayload(json);
    setViewPhLoading(true);
    const tableData = await dispatch(fetchSingleCePharmaciesTableData(json));
    setViewPhLoading(false);
    if (!_isEmpty(tableData)) {
      setViewPhTableData(tableData);
    }
  };

  const fetchPhGroups = async () => {
    const res = await dispatch(getPharmacyGroups([ceId]));
    setPhNetworkList(res);
  };

  useEffect(() => {
    setCurrentPharmacy({});
    setPhConfigSectionStatus({});
    fetchPhGroups();
    fetchPharmacies();
    setIsNewPharmacy(false);
    setActiveInactiveCOMenus({
      ...activeInactiveCOMenus,
      [MENUS.PH_BASIC_DETAILS]: false,
      [MENUS.PH_BILLING_AND_FEES]: false,
      [MENUS.PH_ELIGIBILITY]: false,
      [MENUS.PH_ORDERING_AND_REPLENISHMENT]: false,
    });
    if (_isEmpty(currentPharmacy)) setPhConfigStatusPercent(0);
  }, []);

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography
          variant="h4"
          title="Pharmacy Configuration > Select Pharmacy"
        />
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item md={12}>
            <BasicTypography variant="h5" title="Pharmacy Details" />
          </Grid>
          <Grid item md={12}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                <AutoComplete
                  options={_isArray(phNetworkList) ? phNetworkList : []}
                  inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                  disableCloseOnSelect={false}
                  onChange={(e, value) => handleChangePhNetwork(value)}
                  getOptionLabel={(option) => option.phGroupName || ""}
                  value={
                    phNetworkList.find((e) => e.phGroupId == phNetworkId) || ""
                  }
                  renderOption={(option, _other) => {
                    return (
                      <BasicTypography variant="subtitle2">
                        {option.phGroupName}
                      </BasicTypography>
                    );
                  }}
                  multiple={false}
                />
              </Grid>

              <Grid item xs={12} sm={4}>
                <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                <AutoComplete
                  options={_isArray(phStoreList) ? phStoreList : []}
                  inputPlaceholder={`Select ${LABELS.PharmacyStore}`}
                  disableCloseOnSelect={false}
                  onChange={(e, value) => handleChangePhStore(value)}
                  getOptionLabel={(option) => option.phName || ""}
                  value={phStoreList.find((e) => e.phid == phStoreId) || ""}
                  renderOption={(option, _other) => {
                    return (
                      <BasicTypography variant="subtitle2">
                        {option.phName}
                      </BasicTypography>
                    );
                  }}
                  multiple={false}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Pharmacytable
          onChangePagination={onChangePagination}
          tableRef={tableRef}
          onChangeSorting={onChangeSorting}
          onChangeFilter={onChangeFilter}
          controllers={controllers}
          viewPhTableData={viewPhTableData}
          defaultFilters={filterValues}
          ceId={ceId}
          phNetworkId={phNetworkId}
          phStoreId={phStoreId}
          viewPhLoading={viewPhLoading}
        />
      </Grid>
      <Grid item md={12}>
        <Grid container justifyContent="flex-end" spacing={2}>
          <Grid item>
            <Button
              type="submit"
              size="small"
              variant="contained"
              className={globalClasses.primaryBtn}
              onClick={() => setPopupActiveMenu(MENUS.PH_BASIC_DETAILS)}
            >
              Next
            </Button>
          </Grid>
          <Grid item>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              className={globalClasses.secondaryBtn}
              onClick={() => setPopupActiveMenu(MENUS.PH_BASIC_DETAILS)}
            >
              Skip
            </Button>
          </Grid>
          <Grid item>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              className={globalClasses.secondaryBtn}
              onClick={() => setOpenAddCePopup(false)}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};
export default ViewPharmacies;
