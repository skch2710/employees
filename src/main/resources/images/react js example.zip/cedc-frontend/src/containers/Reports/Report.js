import React, { useEffect } from "react";
import { Grid, Tooltip } from "@material-ui/core";
// import { useDispatch, useSelector } from "react-redux";
import BasicTypography from "../../components/common/Typography/BasicTypography";
// import { NavLink } from "react-router-dom";
// import { useGlobalStyles } from "../../Styles/useGlobalStyles";
// import { getUserSession } from "../../utils/helper";
// import { getAllPowerBiReports } from "../../context/actions/PowerBiReports";
// import { useReportRenderingStyles } from "./styles";

const Report = () => {
  // const globalClasses = useGlobalStyles();
  // const classes = useReportRenderingStyles();
  // const dispatch = useDispatch();
  // const userSession = getUserSession();
  // const powerBiData = useSelector((state) => state.powerBiReportDetails);

  // useEffect(() => {
  //   getPowerBiReports(userSession);
  // }, []);

  // const labelValue = (value, maxLength) =>
  //   value.length > maxLength ? value.slice(0, maxLength) + "..." : value;

  // const getPowerBiReports = () => {
  //   const requestObj = {
  //     userName: userSession.emailId || "",
  //     reportId:
  //       userSession.powerBiReportId || "",
  //     groupId:
  //       userSession.powerBiGroupId || "",
  //   };
  //   dispatch(getAllPowerBiReports(requestObj));
  // };

  return (
    <Grid container spacing={3}>
      <Grid item sm={12}>
        <BasicTypography variant="h1" title="Reports" />
      </Grid>
      {/* <Grid item sm={12}>
        <Grid container spacing={3}>
          {powerBiData &&
            powerBiData.embedReports &&
            powerBiData.embedReports.length > 0 &&
            powerBiData.embedReports.map((report) => {
              return (
                <Grid item sm={4} md={3} key={report.id}>
                  <div className={globalClasses.cardPrimary}>
                    <Grid className="card-block">
                      <NavLink
                        to={`/reports/${report.id}`}
                        activeClassName="active"
                        className={globalClasses.clickableLink}
                      >
                        <BasicTypography
                          variant="h4"
                          className={classes.reportNameStyle}
                        >
                          <Tooltip title={report.name} placement="bottom">
                            <span>{labelValue(report.name, 21)}</span>
                          </Tooltip>
                        </BasicTypography>
                      </NavLink>
                    </Grid>
                  </div>
                </Grid>
              );
            })}
        </Grid>
      </Grid> */}
    </Grid>
  );
};

export default Report;
