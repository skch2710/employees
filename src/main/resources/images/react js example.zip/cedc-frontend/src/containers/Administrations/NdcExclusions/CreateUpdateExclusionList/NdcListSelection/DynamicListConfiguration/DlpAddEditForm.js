import React, { memo, useContext, useEffect, useState } from "react";
import { Button, FormLabel, Grid } from "@material-ui/core";
import { Field, Form, Formik, useFormikContext } from "formik";
import moment from "moment";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import DatePicker from "../../../../../../components/common/DatePicker";
import {
  getDrugAttributeOneTypes,
  getDrugAttributeTwoTypes,
  getDynamicListSourceTypes,
  saveDynamicListParameters,
} from "../../../../../../context/actions/NdcExclusions";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import _isArray from "lodash/isArray";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { NdcContext } from "../../../NdcContext";
import { getUserSession } from "../../../../../../utils/helper";
import _get from "lodash/get";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { REGEX } from "../../../../../../utils/constants";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import {
  endDateValidation,
  startDateValidation,
} from "../../../../../../utils/common";
import AutoComplete from "../../../../../../components/common/AutoComplete";

const DlpAddEditForm = memo(
  ({ handleClose, initialValues, formType, dlpRowData }) => {
    const dispatch = useDispatch();
    const globalClasses = useGlobalStyles();
    const userSession = getUserSession();
    const { ndcData = {} } = useContext(NdcContext) || {};
    const { startDate, endDate } = ndcData;
    const maxDate = endDate;
    const minDate = startDate;

    const [loading, setLoading] = useState([]);
    const [sourceTypes, setSourceOptions] = useState([]);
    const [drugAttributeOneOptions, setDrugAttributeOneOptions] = useState([]);
    const [drugAttributeTwoOptions, setDrugAttributeTwoOptions] = useState([]);
    const [showConfirmationPopUp, setShowConfirmationPopUp] = useState(false);
    const [submitApiArgs, setSubmitApiArgs] = useState({});
    const { resetForm } = useFormikContext();

    useEffect(() => {
      setLoading(true);
      fetchSourceTypes();
      setLoading(false);
    }, []);

    // Get all available Drug Sources
    const fetchSourceTypes = async () => {
      const sourceTypeOptions = await dispatch(getDynamicListSourceTypes());
      if (_isArray(sourceTypeOptions)) {
        setSourceOptions([...sourceTypeOptions]);
      }
    };

    // Handle 'Source' Dropdown Field
    const handleSourceTypeDropdown = async (sourceId) => {
      setLoading(true);
      if (sourceId) fetchDrugAttributeOneTypes(sourceId);
      setLoading(false);
    };

    // Get Drug Attribute One options based on selected Source
    const fetchDrugAttributeOneTypes = async (sourceId = 0) => {
      const drugAttributeOneTypes = await dispatch(
        getDrugAttributeOneTypes(sourceId)
      );
      if (_isArray(drugAttributeOneTypes)) {
        setDrugAttributeOneOptions([...drugAttributeOneTypes]);
      }
    };

    // Handle 'Drug Attribute One' Dropdown Field
    const handleDrugAttributeOneDropdown = async (drugAttributeOneId) => {
      setLoading(true);
      if (drugAttributeOneId) fetchDrugAttributeTwoTypes(drugAttributeOneId);
      setLoading(false);
    };

    // Get 'Drug Attribute Two' options based on selected 'Drug Attribute One'
    const fetchDrugAttributeTwoTypes = async (drugAttributeOneId = 0) => {
      const drugAttributeOneIdInt = Number(drugAttributeOneId);
      if (
        drugAttributeOneIdInt === 6 ||
        drugAttributeOneIdInt === 9 ||
        drugAttributeOneIdInt === 10
      ) {
        setDrugAttributeTwoOptions([]);
      } else {
        const drugAttributeTwoTypes = await dispatch(
          getDrugAttributeTwoTypes(drugAttributeOneId)
        );
        if (_isArray(drugAttributeTwoTypes)) {
          setDrugAttributeTwoOptions([...drugAttributeTwoTypes]);
        }
      }
    };

    const renderDrugAttributeTwo = (
      drugAttributeOneId,
      setFieldValue,
      errors,
      touched
    ) => {
      const drugAttrOneIdInt = Number(drugAttributeOneId);
      // For Pack Size(=9), Case Size(=10), Labeler Code(=6) for these Drug Attribute One Options, corresponding
      // Drug attribute two is an input field, for remaining will be dropdown
      return drugAttrOneIdInt === 6 ||
        drugAttrOneIdInt === 9 ||
        drugAttrOneIdInt === 10 ? (
        <Grid item sm={3}>
          <FormLabel required>Drug Attribute 2</FormLabel>
          <Field
            name="drugAttributeTwoDesc"
            type="text"
            className={globalClasses.formControl}
            placeholder="Enter Value"
            onChange={(e) => {
              const { value } = e.target;
              const regEx =
                drugAttrOneIdInt === 6
                  ? REGEX.onlyNumbers
                  : REGEX.tenDigitNumberWithMaxTwoDecimals;
              if (value && !regEx.test(value)) {
                return;
              }
              setFieldValue("drugAttributeTwoDesc", value);
            }}
          />
          {errors.drugAttributeTwoDesc && touched.drugAttributeTwoDesc && (
            <BasicTypography color="error" variant="caption">
              {errors.drugAttributeTwoDesc}
            </BasicTypography>
          )}
        </Grid>
      ) : (
        <Grid item sm={3}>
          <FormLabel required>Drug Attribute 2</FormLabel>
          <Field
            as="select"
            className={globalClasses.formControl}
            name="drugAttributeTwoId"
          >
            {({ field }) => (
              <AutoComplete
                {...field}
                options={
                  _isArray(drugAttributeTwoOptions)
                    ? drugAttributeTwoOptions
                    : []
                }
                inputPlaceholder={"Select Drug Attribute 2"}
                disableCloseOnSelect={false}
                onChange={(_e, value) => {
                  setFieldValue("drugAttributeTwoId", value);
                  setFieldValue("drugAttributeTwoDesc", value && value.name);
                }}
                getOptionLabel={(option) => {
                  return option.name || "";
                }}
                renderOption={(option, _other) => {
                  return (
                    <BasicTypography variant="subtitle2">
                      {option.name}
                    </BasicTypography>
                  );
                }}
                multiple={false}
              />
            )}
          </Field>
          {errors.drugAttributeTwoId && touched.drugAttributeTwoId && (
            <BasicTypography color="error" variant="caption">
              {errors.drugAttributeTwoId}
            </BasicTypography>
          )}
        </Grid>
      );
    };

    // Form Validation
    const formValidate = async (values) => {
      const error = {};
      if (formType && formType === "Add") {
        if (!values.sourceId) {
          error.sourceId = "Please select Source";
        } else if (!values.drugAttributeOneId) {
          error.drugAttributeOneId = "Please select Drug Attribute 1";
        } else {
          if (
            Number(_get(values, "drugAttributeOneId.attributeId", "")) === 6
          ) {
            if (!values.drugAttributeTwoDesc) {
              error.drugAttributeTwoDesc = "Please Enter Drug Attribute 2";
            } else if (values.drugAttributeTwoDesc.length !== 5) {
              error.drugAttributeTwoDesc = "Please enter a 5 digit code";
            }
          } else if (
            Number(_get(values, "drugAttributeOneId.attributeId", "")) === 9 ||
            Number(_get(values, "drugAttributeOneId.attributeId", "")) === 10
          ) {
            if (!values.drugAttributeTwoDesc) {
              error.drugAttributeTwoDesc = "Please Enter Drug Attribute 2";
            }
          } else {
            if (!values.drugAttributeTwoId) {
              error.drugAttributeTwoId = "Please select Drug Attribute 2";
            }
          }
        }
      }
      if (!values.startDate) {
        error.startDate = "Please select NDC Effective Start Date";
      }

      return error;
    };

    // Form Submission
    const handleFormSubmit = async (values = {}, action = "", reset) => {
      const reqBody = {
        ...values,
        drugAttributeOneId: _get(
          values,
          "drugAttributeOneId.attributeId",
          ""
        ).toString(),
        drugAttributeTwoId: _get(
          values,
          "drugAttributeTwoId.id",
          values.drugAttributeTwoId
        ).toString(),
        sourceId: _get(values, "sourceId.sourceId", "").toString(),
        createdById: _get(userSession, "userId", 0),
        modifiedById: _get(userSession, "userId", 0),
      };
      if (formType && formType === "Edit") {
        if (
          values.startDate !== initialValues.startDate ||
          values.endDate !== initialValues.endDate
        ) {
          setShowConfirmationPopUp(true);
          setSubmitApiArgs(reqBody);
        } else {
          handleClose();
        }
      } else {
        const drugAttrOneIdInt = Number(values.drugAttributeOneId);
        const selectedDrugAttributeTwo = drugAttributeTwoOptions.find(
          (attr) => Number(attr.id) === Number(values.drugAttributeTwoId)
        );
        if (
          !(
            drugAttrOneIdInt === 6 ||
            drugAttrOneIdInt === 9 ||
            drugAttrOneIdInt === 10
          )
        ) {
          reqBody["drugAttributeTwoDesc"] = _get(
            values,
            "drugAttributeTwoDesc",
            ""
          );
        }
        triggerSubmitApi(reqBody, action, reset);
      }
    };

    const triggerSubmitApi = async (reqBody, action, reset) => {
      const res = await dispatch(saveDynamicListParameters(reqBody));
      if (res && res.successMessage) {
        toast.success(res.successMessage);
        if (action === "saveAndExit") {
          handleClose("save");
        } else {
          reset && reset({ values: initialValues });
        }
      }
    };

    const cancelConfirmation = () => {
      setShowConfirmationPopUp(false);
      resetForm({ values: initialValues });
    };

    const approveConfirmation = () => {
      setShowConfirmationPopUp(false);
      triggerSubmitApi(submitApiArgs, "saveAndExit");
    };

    return (
      <Formik
        initialValues={initialValues}
        validate={formValidate}
        enableReinitialize={true}
        onSubmit={(values, { resetForm }) =>
          handleFormSubmit(values, values.submitAction, resetForm)
        }
      >
        {({ values, errors, touched, setFieldValue }) => {
          return (
            <Form>
              {loading && <LoaderUI />}
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    {formType === "Add" && (
                      <Grid item sm={3}>
                        <FormLabel required>Source</FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="sourceId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={_isArray(sourceTypes) ? sourceTypes : []}
                              inputPlaceholder={"Select Source"}
                              disableCloseOnSelect={false}
                              getOptionDisabled={(option) =>
                                option.sourceId !== 1
                              }
                              onChange={(_e, value) => {
                                setFieldValue("sourceId", value);
                                setFieldValue("drugAttributeOneId", "");
                                setFieldValue("drugAttributeTwoId", "");
                                setFieldValue("drugAttributeTwoDesc", "");
                                handleSourceTypeDropdown(
                                  value && value.sourceId
                                );
                              }}
                              getOptionLabel={(option) => {
                                return option.sourceDesc || "";
                              }}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.sourceDesc}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                        {errors.sourceId && touched.sourceId && (
                          <BasicTypography color="error" variant="caption">
                            {errors.sourceId}
                          </BasicTypography>
                        )}
                      </Grid>
                    )}
                    {formType === "Add" && values && values.sourceId && (
                      <Grid item sm={3}>
                        <FormLabel required>Drug Attribute 1</FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="drugAttributeOneId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={
                                _isArray(drugAttributeOneOptions)
                                  ? drugAttributeOneOptions
                                  : []
                              }
                              inputPlaceholder={"Select Drug Attribute"}
                              disableCloseOnSelect={false}
                              getOptionDisabled={(option) =>
                                option.attributeId === 11 ||
                                option.attributeId === 12
                              }
                              onChange={(_e, value) => {
                                setFieldValue("drugAttributeOneId", value);
                                setFieldValue("drugAttributeTwoId", 0);
                                setFieldValue("drugAttributeTwoDesc", "");
                                handleDrugAttributeOneDropdown(
                                  value && value.attributeId
                                );
                              }}
                              getOptionLabel={(option) => {
                                return option.attributeDesc || "";
                              }}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.attributeDesc}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                        {errors.drugAttributeOneId &&
                          touched.drugAttributeOneId && (
                            <BasicTypography color="error" variant="caption">
                              {errors.drugAttributeOneId}
                            </BasicTypography>
                          )}
                      </Grid>
                    )}
                    {formType === "Add" &&
                      values.drugAttributeOneId &&
                      renderDrugAttributeTwo(
                        _get(values, "drugAttributeOneId.attributeId", ""),
                        setFieldValue,
                        errors,
                        touched
                      )}
                    {formType === "Edit" && (
                      <Grid item sm={12}>
                        <BasicTypography variant="subtitle2">
                          Update NDC Effective Dates
                        </BasicTypography>
                      </Grid>
                    )}
                    <Grid item sm={formType === "Add" ? 3 : 6}>
                      <FormLabel required>NDC Effective Start Date</FormLabel>
                      <Field name="startDate">
                        {({ field }) => (
                          <DatePicker
                            {...field}
                            placeholder="MM/DD/YYYY"
                            disabledDate={(date) =>
                              startDateValidation(date, values.endDate) ||
                              (minDate && !date.isSameOrAfter(minDate, "day"))
                            }
                            onChange={(_e, date) => {
                              if (!date) setFieldValue("endDate", "");
                              setFieldValue("startDate", date);
                            }}
                            value={
                              values.startDate
                                ? moment(values.startDate, "MM/DD/YYYY")
                                : ""
                            }
                            disabled={
                              formType === "Edit" &&
                              values.startDate &&
                              moment(values.startDate).isBefore(moment(), "day")
                            }
                          />
                        )}
                      </Field>
                      {errors.startDate && touched.startDate && (
                        <BasicTypography color="error" variant="caption">
                          {errors.startDate}
                        </BasicTypography>
                      )}
                    </Grid>
                    <Grid item sm={formType === "Add" ? 3 : 6}>
                      <FormLabel>NDC Effective End Date</FormLabel>
                      <Field name="endDate">
                        {({ field }) => (
                          <DatePicker
                            {...field}
                            placeholder="MM/DD/YYYY"
                            disabledDate={(date) =>
                              endDateValidation(date, values.startDate) ||
                              (maxDate && !date.isBefore(maxDate, "day"))
                            }
                            onChange={(_e, date) => {
                              setFieldValue("endDate", date);
                            }}
                            value={
                              values.endDate
                                ? moment(values.endDate, "MM/DD/YYYY")
                                : ""
                            }
                          />
                        )}
                      </Field>
                    </Grid>
                    <Grid item sm={12} />
                  </Grid>
                  <Grid container spacing={2} justifyContent="flex-end">
                    <Grid item>
                      <Button
                        type="submit"
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                        onClick={() =>
                          setFieldValue("submitAction", "saveAndExit")
                        }
                      >
                        {formType === "Add" ? "Add And Exit" : "Save"}
                      </Button>
                    </Grid>
                    {formType === "Add" && (
                      <Grid item>
                        <Button
                          type="submit"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                          onClick={() =>
                            setFieldValue("submitAction", "addAnother")
                          }
                        >
                          Add Another
                        </Button>
                      </Grid>
                    )}
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="contained"
                        className={globalClasses.grayButton}
                        onClick={handleClose}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              {showConfirmationPopUp && (
                <BasicPopup
                  show={showConfirmationPopUp}
                  handleClose={cancelConfirmation}
                  title={"Config Reset Warning"}
                  submitProps={{
                    buttonTitle: "Yes",
                    handleSubmit: approveConfirmation,
                  }}
                  cancelProps={{
                    buttonTitle: "No",
                    handleCancel: cancelConfirmation,
                  }}
                >
                  {`${
                    dlpRowData.ndcExclCount || 0
                  } NDC’s on the Applied NDC Exclusions container will be affected with this change. Do you want to continue?`}
                </BasicPopup>
              )}
            </Form>
          );
        }}
      </Formik>
    );
  }
);

export default DlpAddEditForm;
