import React, { forwardRef } from "react";
import Button from "@material-ui/core/Button";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import BackupOutlinedIcon from "@material-ui/icons/BackupOutlined";
import { RiDeleteBin5Line } from "react-icons/ri";
import { BiEditAlt } from "react-icons/bi";
import { FaSort } from "react-icons/fa";
import { AiOutlinePlus } from "react-icons/ai";
import { MdOutlineFilterList } from "react-icons/md";
import { MdOutlineHistory } from "react-icons/md";
import { TiExportOutline } from "react-icons/ti";
import { FaPrescription } from "react-icons/fa";
import {AiOutlineEye} from "react-icons/ai";

const tableIcons = {
  ExportButton: forwardRef((props, ref) => (
    <Button
      variant="outlined"
      size="small"
      component="button" 
      className="button2"
      {...props}
      ref={ref}
    >
      Export
    </Button>
  )),
  UploadButton: forwardRef((props, ref) => (
    <Button
      startIcon={<BackupOutlinedIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Upload Patient
    </Button>
  )),
  Delete: forwardRef((props, ref) => (
    <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => (
    <BiEditAlt fontSize="small" color="action" {...props} ref={ref} />
  )),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => (
    <MdOutlineFilterList {...props} ref={ref} />
  )),
  Plus: forwardRef((props, ref) => (
    <AiOutlinePlus fontSize="small" color="action" {...props} ref={ref} />
  )),
  History: forwardRef((props, ref) => (
    <MdOutlineHistory fontSize="small" color="disabled" {...props} ref={ref} />
  )),
  Export: forwardRef((props, ref) => (
    <TiExportOutline fontSize="small" color="disabled" {...props} ref={ref} />
  )),
  Claim: forwardRef((props, ref) => (
    <FaPrescription fontSize="small" color="disabled" {...props} ref={ref} />
  )),
  Eye:  forwardRef((props, ref) => (
    <AiOutlineEye fontSize="small" color="action" {...props} ref={ref} />
  )),
};

export default tableIcons;
