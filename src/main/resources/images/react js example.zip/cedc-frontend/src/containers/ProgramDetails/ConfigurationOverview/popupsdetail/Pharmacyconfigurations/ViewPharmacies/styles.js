import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../../../../utils/helper";

export const useCoViewPharmacies = makeStyles((_theme) => ({
  
}));
