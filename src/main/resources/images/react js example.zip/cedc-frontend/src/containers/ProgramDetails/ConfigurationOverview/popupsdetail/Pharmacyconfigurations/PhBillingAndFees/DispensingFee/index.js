import React, { memo } from "react";
import { Grid } from "@material-ui/core";
import BasicTypography from "../../../../../../../components/common/Typography/BasicTypography";
import DispensingFeesTable from "./DispensingFeesTable";

const DispensingFees = memo((props = {}) => {
  return (
    <Grid container spacing={2} direction="column">
      <Grid item md={12}>
        <BasicTypography variant="h5" title="Dispensing Fees" />
      </Grid>
      <Grid item md={12}>
        <DispensingFeesTable {...props} />
      </Grid>
    </Grid>
  );
});

export default DispensingFees;
