import React, { memo } from "react";
import { FormLabel, Grid, Typography } from "@material-ui/core";
import classNames from "classnames";
import { Field, useFormikContext } from "formik";
import BasicTypography from "../../../../../../../components/common/Typography/BasicTypography";
import AdminFeesTable from "./AdminFeesTable";
import { useAdminFeeStyles } from "../styles";
import { useGlobalStyles } from "../../../../../../../Styles/useGlobalStyles";

const AdminFee = memo((props = {}) => {
  const { errors, touched } = useFormikContext();
  const classes = useAdminFeeStyles();
  const globalClasses = useGlobalStyles();

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item md={12}>
            <BasicTypography variant="h5" title="Admin Fees" />
          </Grid>
          <Grid item md={12}>
            <Grid container spacing={2}>
              <Grid item md={4} xs={12}>
                <FormLabel required>
                  Billing Cycle
                </FormLabel>
                <div className={classes.radioContainer}>
                  <div className={classes.radioAndLabelContainer}>
                    <Field
                      id="monthly"
                      name="frequency"
                      type="radio"
                      value="1"
                      disabled
                      className={classes.radioInput}
                    />
                    <FormLabel
                      htmlFor="monthly"
                      className={globalClasses.noPaddingForLabels}
                    >
                      Monthly
                    </FormLabel>
                  </div>
                  <div className={classes.radioAndLabelContainer}>
                    <Field
                      id="biMonthly"
                      name="frequency"
                      type="radio"
                      value="2"
                      disabled
                      className={classNames(
                        classes.radioInput,
                        globalClasses.noPaddingForLabels
                      )}
                    />
                    <FormLabel
                      htmlFor="biMonthly"
                      className={globalClasses.noPaddingForLabels}
                    >
                      Bi-Monthly
                    </FormLabel>
                  </div>
                </div>
                {errors.frequency && touched.frequency && (
                  <Typography color="error" variant="caption">
                    {errors.frequency}
                  </Typography>
                )}
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <AdminFeesTable {...props} isConfigurable={true} />
      </Grid>
    </Grid>
  );
});

export default AdminFee;
