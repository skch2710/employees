import { pagination } from "../../../utils/constants";

export const getProviderDefaultPayload = (searchData) => {
  const {
    providerNPI,
    firstName,
    lastName,
    startDate,
    endDate,
    providerType,
    sortBy,
    sortOrder,
    pageNumber,
    pageSize,
    status,
  } = searchData || {};
  return {
    entityLocationId: [],
    pageNumber: pageNumber || pagination.page,
    pageSize: pageSize || pagination.limit,
    providerNPI: providerNPI || "",
    sortBy: sortBy || "",
    sortOrder: sortOrder || "",
    export: false,
    firstName: firstName || "",
    lastName: lastName || "",
    endDate: endDate || "",
    startDate: startDate || "",
    providerType: providerType || "",
    status: status || "",
  };
};
