import _isEmpty from "lodash/isEmpty";
import _noop from "lodash/noop";
import React, { createContext, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getPhSectionStatus,
  getSectionStatusByCEID,
} from "../../context/actions/ConfigOverview";
import { getCoveredEntity } from "../../utils/helper";
import {
  CO_MENUS,
  MENUS,
  MENUS_ID_TO_NAME,
} from "./ConfigurationOverview/PopupSidebar/constants";
import { POPUP_SECTION_TO_ACTIVE_INDEX_MAPPING } from "./ConfigurationOverview/constants";
import {
  getFirstIncompleteSection,
  getUpdatedPhSectionStatus,
  getUpdatedSectionStatus,
} from "./ConfigurationOverview/helper";

const COContext = createContext({
  ceId: null,
  setCeId: _noop(),
  setCeList: _noop(),
  setMessageUuid: _noop(),
  setCurrentPharmacy: _noop(),
  setOpenAddCePopup: _noop(),
  setPopupActiveMenu: _noop(),
  setMenusStatuses: _noop(),
  setCoveredEntityName: _noop(),
  setOpenAddUserPopup: _noop(),
  ceConfigStatusPercent: 0,
  setCeConfigStatusPercent: _noop(),
  setPhConfigSectionStatus: _noop(),
  setIsNewPharmacy: _noop(),
  setPhConfigStatusPercent: _noop(),
  setClickedOnPartial: _noop(),
  setActiveInactiveCOMenus: _noop(),
  setParticipatingLocationsData: _noop(),
});

const initialCOMenus = {
  [MENUS.CE_BASIC_DETAILS]: true,
  [CO_MENUS.ENTITY_DETAILS]: true,
  [MENUS.CE_BILLING_AND_FEES]: false,
  [MENUS.CE_ACH_CONFIGURATION]: false,
  [MENUS.CE_ELIGIBILITY]: false,
  [CO_MENUS.CE_CONFIGURATION]: false,
  [CO_MENUS.PH_CONFIGURATION]: false,
  [MENUS.CE_ORDERING_CONFIGURATION]: false,
};
const COContextProvider = ({ children, defaultValues }) => {
  const dispatch = useDispatch();
  const { ceID } = defaultValues || {};
  const { ceList: globalCeList = [] } =
    useSelector((state) => state.coveredEntities) || {};

  const [ceId, setCeId] = useState(ceID);
  const [ceList, setCeList] = useState([]);
  const [messageUuid, setMessageUuid] = useState(false);
  const [menusStatuses, setMenusStatuses] = useState({});
  const [currentPharmacy, setCurrentPharmacy] = useState({});
  const [openAddCePopup, setOpenCePopup] = useState(false);
  const [openAddUserPopup, setOpenAddUserPopup] = useState(false);
  const [popupActiveMenu, setPopupActiveMenu] = useState(
    MENUS.CE_BASIC_DETAILS
  );
  const [coveredEntityName, setCoveredEntityName] =
    useState("Add Covered Entity");
  const [ceConfigStatusPercent, setCeConfigStatusPercent] = useState(0);
  const [phConfigStatusPercent, setPhConfigStatusPercent] = useState(0);
  const [phConfigSectionStatus, setPhConfigSectionStatus] = useState({});
  const [isNewPharmacy, setIsNewPharmacy] = useState(false);
  const [clickedOnPartial, setClickedOnPartial] = useState(false);
  const [phGridPayload, setPhGridPayload] = useState({});
  const [termsGridPayload, setTermsGridPayload] = useState({});
  const [activeInactiveCOMenus, setActiveInactiveCOMenus] =
    useState(initialCOMenus);
  const [participatingLocationsData, setParticipatingLocationsData] = useState({
    content: [],
    totalElements: 0,
  });

  const setOpenAddCePopup = (state) => {
    if (!state) {
      setPopupActiveMenu(MENUS.CE_BASIC_DETAILS);
      setMenusStatuses({});
      setPhConfigSectionStatus({});
      setCeConfigStatusPercent(0);
      setPhConfigStatusPercent(0);
      setIsNewPharmacy(false);
      setCurrentPharmacy({});
      setActiveInactiveCOMenus({ ...initialCOMenus });
      setClickedOnPartial(false);
    }
    setOpenCePopup(state);
  };

  useEffect(() => {
    let obj = { ...activeInactiveCOMenus };
    if (coveredEntityName === "Add Covered Entity" && !ceId) {
      setActiveInactiveCOMenus({
        ...initialCOMenus,
      });
    } else {
      obj = {
        ...obj,
        [MENUS.CE_BASIC_DETAILS]: true,
        [MENUS.CE_BILLING_AND_FEES]: true,
        [MENUS.CE_ACH_CONFIGURATION]: true,
        [MENUS.CE_ELIGIBILITY]: true,
        [CO_MENUS.CE_CONFIGURATION]: true,
        [CO_MENUS.PH_CONFIGURATION]: true,
        [CO_MENUS.ENTITY_DETAILS]: true,
        [MENUS.CE_ORDERING_CONFIGURATION]: true,
      };
      if (!_isEmpty(currentPharmacy)) {
        obj = {
          ...obj,
          [MENUS.PH_BASIC_DETAILS]: true,
          [MENUS.PH_BILLING_AND_FEES]: true,
          [MENUS.PH_ELIGIBILITY]: true,
          [MENUS.PH_ORDERING_AND_REPLENISHMENT]: true,
        };
      } else if (isNewPharmacy) {
        obj = {
          ...obj,
          [MENUS.PH_BASIC_DETAILS]: true,
          [MENUS.PH_BILLING_AND_FEES]: false,
          [MENUS.PH_ELIGIBILITY]: false,
          [MENUS.PH_ORDERING_AND_REPLENISHMENT]: false,
        };
      }
      setActiveInactiveCOMenus({
        ...obj,
      });
    }
  }, [coveredEntityName, ceId, currentPharmacy, isNewPharmacy, openAddCePopup]);

  const clickOnPencil = (popupValue, ceId) => {
    setCeId(ceId);
    const currentCoveredEntity = ceId
      ? getCoveredEntity({
          ceId: ceId,
          ceList: globalCeList,
        })[0]
      : {};
    setMessageUuid({ ...currentCoveredEntity, ceid: ceId });
    setPopupActiveMenu(POPUP_SECTION_TO_ACTIVE_INDEX_MAPPING[popupValue]);
    setClickedOnPartial(false);
    setOpenAddCePopup(true);
  };

  const fetchCeSectionStatuses = ({ ceId, shouldNavigate = false } = {}) => {
    dispatch(
      getSectionStatusByCEID(ceId, (res) => {
        if (res.statusCode === 200) {
          const sectionStatuses =
            (res.data && res.data.ceSectionStatusDTOs) || [];
          const ceConfigPercent =
            (res.data && res.data.configPercentage) || ceConfigStatusPercent;
          setMenusStatuses(getUpdatedSectionStatus(sectionStatuses));
          setCeConfigStatusPercent(ceConfigPercent);
          const sectionObject = getFirstIncompleteSection(sectionStatuses);
          if (!_isEmpty(sectionObject) && shouldNavigate) {
            setPopupActiveMenu(
              MENUS[MENUS_ID_TO_NAME[sectionObject.configSectionId]]
            );
          }
        }
      })
    );
  };

  const fetchPhSectionStatuses = ({
    ceId,
    clientId,
    shouldNavigate = false,
  } = {}) => {
    dispatch(
      getPhSectionStatus(ceId, clientId, (res) => {
        if (res.statusCode === 200) {
          const phSectionStatus =
            (res.data && res.data.clientSectionStatusDTO) || [];
          const phConfigPercentage =
            (res.data && res.data.configPercentage) || phConfigStatusPercent;
          setPhConfigSectionStatus(getUpdatedPhSectionStatus(phSectionStatus));
          setPhConfigStatusPercent(phConfigPercentage);
          const sectionObject = getFirstIncompleteSection(phSectionStatus);
          if (!_isEmpty(sectionObject) && shouldNavigate) {
            setPopupActiveMenu(
              MENUS[MENUS_ID_TO_NAME[sectionObject.sectionId]]
            );
          }
        }
      })
    );
  };

  const value = {
    ceId,
    setCeId,
    ceList,
    setCeList,
    messageUuid,
    setMessageUuid,
    currentPharmacy,
    setCurrentPharmacy,
    openAddCePopup,
    setOpenAddCePopup,
    popupActiveMenu,
    setPopupActiveMenu,
    menusStatuses,
    setMenusStatuses,
    coveredEntityName,
    setCoveredEntityName,
    openAddUserPopup,
    setOpenAddUserPopup,
    clickOnPencil,
    ceConfigStatusPercent,
    setCeConfigStatusPercent,
    phConfigSectionStatus,
    setPhConfigSectionStatus,
    isNewPharmacy,
    setIsNewPharmacy,
    phConfigStatusPercent,
    setPhConfigStatusPercent,
    clickedOnPartial,
    setClickedOnPartial,
    phGridPayload,
    setPhGridPayload,
    termsGridPayload,
    setTermsGridPayload,
    activeInactiveCOMenus,
    setActiveInactiveCOMenus,
    participatingLocationsData,
    setParticipatingLocationsData,
    fetchCeSectionStatuses,
    fetchPhSectionStatuses,
  };

  return <COContext.Provider value={value}>{children}</COContext.Provider>;
};

export { COContext, COContextProvider };
