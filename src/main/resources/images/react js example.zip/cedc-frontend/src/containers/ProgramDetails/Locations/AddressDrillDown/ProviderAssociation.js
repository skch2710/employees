import React, { useState, useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../Styles/useGlobalStyles";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEmpty from "lodash/isEmpty";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { pagination } from "../../../../utils/constants";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import Pagination from "../../../../components/common/Pagination";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import { fetchProviderAssociationGridData } from "../../../../context/actions/Locations";
import DataNotFound from "../../../../components/common/DataNotFound";
import { getProviderAssociationFiltersObject } from "./helper";
import { PROVIDER_ASSOCIATION } from "../../../../context/reducers/Locations/constants";

const ProviderAssociation = ({ locationData }) => {
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const theme = useTheme();
  const dispatch = useDispatch();
  const tableRef = useRef(null);

  const [filter, setFilter] = useState(false);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "",
    sortOrder: "",
  });
  const [columnFilters, setColumnFilters] = useState([]);
  const filterValuesRef = useRef({});

  const { records: providerAssociationGridData, loading } =
    useSelector((state) => state.getProviderAssociationData) || {};

  const PROVIDER_ASSOCIATION_COLUMNS = [
    {
      title: "Provider First Name",
      field: "providerFirstName",
      defaultFilter: filter && filterValuesRef.current.providerFirstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerFirstName}>
            <span>{rowData.providerFirstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.providerFirstName}
          placeholder="Provider First Name"
        />
      ),
    },

    {
      title: "Provider Last Name",
      field: "providerLastName",
      defaultFilter: filter && filterValuesRef.current.providerLastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerLastName}>
            <span>{rowData.providerLastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.providerLastName}
          placeholder="Provider Last Name"
        />
      ),
    },
    {
      title: "Provider NPI",
      field: "providerNpi",
      defaultFilter: filter && filterValuesRef.current.providerNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerNpi}>
            <span>{rowData.providerNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.providerNpi}
          placeholder="Provider NPI"
        />
      ),
    },

    {
      title: "Provider DEA",
      field: "providerDea",
      defaultFilter: filter && filterValuesRef.current.providerDea,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerDea}>
            <span>{rowData.providerDea}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.providerDea}
          placeholder="Provider DEA"
        />
      ),
    },
    {
      title: "Provider SPI",
      field: "providerSpi",
      defaultFilter: filter && filterValuesRef.current.providerSpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerSpi}>
            <span>{rowData.providerSpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.providerSpi}
          placeholder="Prescriber SPI"
        />
      ),
    },
    {
      title: "Provider Type",
      field: "providerType",
      defaultFilter: filter && filterValuesRef.current.providerType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerType}>
            <span>{rowData.providerType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.providerType}
          placeholder="Provider Type"
        />
      ),
    },

    {
      title: "Start Date",
      field: "startDate",
      defaultFilter: filter && filterValuesRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValuesRef.current.startDate
                ? moment(filterValuesRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "End Date",
      field: "endDate",
      defaultFilter: filter && filterValuesRef.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValuesRef.current.endDate
                ? moment(filterValuesRef.current.endDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(providerAssociationGridData),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(providerAssociationGridData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(providerAssociationGridData),
      onClick: () =>
        getProviderAssociationGridData({
          export: true,
        }),
    },
  ];

  useEffect(() => {
    getProviderAssociationGridData();
    return () =>  dispatch({ type: PROVIDER_ASSOCIATION, data: {} });
  }, []);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onChangeSorting = (orderedColumnId) => {
    const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
    const sortBy = PROVIDER_ASSOCIATION_COLUMNS[orderedColumnId].field;
    setControllers((prev) => ({ ...prev, sortBy, sortOrder }));
    getProviderAssociationGridData(
      {
        sortBy,
        sortOrder,
      },
      (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
    );
  };

  const onChangePagination = (newPage, pageSize) => {
    let currentPage = Number(newPage) + 1;
    const rowsPerPage = Number(pageSize);
    const totalPages =
      Math.ceil(providerAssociationGridData.totalElements / rowsPerPage) || 1;
    if (controllers.pageNumber > totalPages) currentPage = totalPages;
    else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
      currentPage = controllers.pageNumber;
    getProviderAssociationGridData(
      {
        pageNumber: currentPage,
        pageSize: rowsPerPage,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const onChangeColumnFilters = (filters = []) => {
    const filterPayload = getProviderAssociationFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
      filterValuesRef.current = updatedFiltersObj;
      getProviderAssociationGridData(
        {
          pageNumber: pagination.page,
          filter: filterPayload,
        },
        (resp) => setControllersOnResp(resp)
      );
    });
  };

  const getProviderAssociationGridData = async (payload = {}, callback) => {
    const payloadJson = {
      pageNumber: controllers.pageNumber,
      pageSize: controllers.pageSize,
      sortBy: controllers.sortBy,
      sortOrder: controllers.sortOrder,
      filter: columnFilters,
      export: false,
      entityLocationId: locationData.entityLocationId,
      ceId: locationData.ceid,
      ...payload,
    };
    const tableData = await dispatch(
      fetchProviderAssociationGridData(payloadJson)
    );
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Active Providers Associated with the Standard Address (${getTableHeaderCount(
              providerAssociationGridData.totalElements
            )})`}
          />
        }
        tableRef={tableRef}
        columns={PROVIDER_ASSOCIATION_COLUMNS}
        data={providerAssociationGridData.content || []}
        page={controllers.pageNumber - 1}
        totalCount={providerAssociationGridData.totalElements}
        onChangePage={onChangePagination}
        onOrderChange={onChangeSorting}
        onFilterChange={onChangeColumnFilters}
        actions={Actions}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        icons={{
          SortArrow: () => TableCustomSortArrow(controllers),
          Filter: ColumnFilterIcon,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: filter,
          paginationType: "stepped",
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controllers.pageSize,
          draggable: false,
          maxBodyHeight: 285,
          doubleHorizontalScroll: false,
          pageSizeOptions: isEmptyGrid(providerAssociationGridData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};
export default ProviderAssociation;
