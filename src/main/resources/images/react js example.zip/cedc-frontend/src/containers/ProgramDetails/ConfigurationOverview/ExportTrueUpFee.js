import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { phTrueUpFeesDetailsExport } from "../../../context/actions/ConfigOverview";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import { notNull } from "../../../utils/constants";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import "jspdf-autotable";
const fileName = "Trueup Fee List";

const ExportTrueUpFee = ({
  ciId, 
  sortBy,
  sortOrder,
  count,
}) => {
  const dispatch = useDispatch();
  const classes = useStyles()

  const [values, setValues] = useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const dataa = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8" });
    FileSaver.saveAs(dataa, fileName + ".xlsx");
  };

  let heads = [];
  let rows = [];

  const ExportTOPDF = (data) => {
    const listheads = data.map((i) => {
      let keys_heads = {
              "Covered Entity": Object.keys(i)[0],
              "True Up Type": Object.keys(i)[1],
              "True Up Model": Object.keys(i)[2],
              "Applied AC Type": Object.keys(i)[3],
              "Adh Percentage": Object.keys(i)[4],
              "True Up Dispensing Fee": Object.keys(i)[5],
              "Start Date": Object.keys(i)[6],
              "End Date":Object.keys(i)[7],
      };
      heads.push(keys_heads);
    });

    const listrows = data.map((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
        phTrueUpFeesDetailsExport(
        {
          ceID: ciId,
          sortBy: sortBy,
          sortOrder: sortOrder,
          startDate:"",
          endDate:"",
          export: true,
        },
        function (result) {
          var data = result.content.map(
            ({
              trueUpType,
              trueUpModel,
              appliedACType,
              adhPercentage,
              trueUpDispensingFee,
              startDate, 
              endDate, 
            }) => ({
              "True Up Type": notNull(trueUpType),
              "True Up Model": notNull(trueUpModel),
              "Applied AC Type": notNull(appliedACType),
              "Adh Percentage": notNull(adhPercentage),
              "True Up Dispensing Fee": notNull(trueUpDispensingFee),
              "Start Date": notNull(startDate),
              "End Date": notNull(endDate),
            })
          );

          if (e.target.value == "excel") {
            setTimeout(ExportToExcel(data), 5000);
            setValues("");
          }
          if (e.target.value == "pdf") {
            setTimeout(ExportTOPDF(data), 5000);
            const doc = new jsPDF();
            doc.autoTable({
              head: [heads[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...rows],
            });
            doc.save("trueup_fee.pdf");
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset disabled={count > 0 ? false : true} className={classes.exportAlign}>
        <select onChange={handleChange} value={values}>
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default ExportTrueUpFee;
