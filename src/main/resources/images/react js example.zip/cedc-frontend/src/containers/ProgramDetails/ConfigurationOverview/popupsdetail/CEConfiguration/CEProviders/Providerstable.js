import React, { useState } from "react";
import { Paper, Tooltip } from "@material-ui/core";
import { useDispatch } from "react-redux";

//Common
import HeaderTitle from "../../../../../../components/common/Typography/HeaderTitle";
import MaterialTable, { MTableToolbar } from "material-table";
import { useStyles } from "../../../../../../mui-styles/commonTableMuiStyle";
import tableIcons from "./MaterielTableIcons";
import AddProvider from "./AddProvider";
import { TiFilter } from "react-icons/ti";
import { pagination } from "../../../../../../utils/constants";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";

const ColumnFilterIcon = () => {
  return <TiFilter fontSize="small" />;
};

const Providerstable = ({ locationCollapse, setlocationCollapse, ciId }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [rowsPerPage, setRowsPerPage] = useState(pagination.limit);
  const [page, setPage] = useState(pagination.page);
  const [sortBy, setsortBy] = useState("locationName");
  const [sortorder, setOrder] = useState("asc");
  const [actiontitle, setActionTitle] = useState("");
  const [submitactiontype, setSubmitActionType] = useState("");
  const [openPopup, setOpenPopup] = useState(false);
  const onChangeRowsperpage = (pagesize) => {
    setRowsPerPage(pagesize);
    setPage(pagination.page);
  };

  const onChangePagination = (data) => {
    let currentpage = data + 1;
    setPage(currentpage);
  };

  const onChangeSorting = async (orderedColumnId) => {
    setOrder(sortorder === "asc" ? "desc" : "asc");
  };

  const columns = [
    {
      title: "First Name",
      field: "firstName",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.firstName}>
            <span>{rowData.firstName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Last Name",
      field: "lastName",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastName}>
            <span>{rowData.lastName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Provider NPI",
      field: "providerNPI",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerNPI}>
            <span>{rowData.providerNPI}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Provider DEA",
      field: "providerDEA",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerDEA}>
            <span>{rowData.providerDEA}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Provider SPI",
      field: "prescriberSPI",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.prescriberSPI}>
            <span>{rowData.prescriberSPI}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Provider Type",
      field: "exclusive",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.exclusive}>
            <span>{rowData.exclusive}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Start Date",
      field: "startDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "End Date",
      field: "endDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Last Modified Date",
      field: "lastModifiedDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastModifiedDate}>
            <span>{rowData.lastModifiedDate}</span>
          </Tooltip>
        );
      },
    },
  ];

  const Actions = [
    {
      icon: tableIcons.plus,
      tooltip: "Provider info",
      isFreeAction: false,
    },
    {
      icon: tableIcons.AddButton,
      tooltip: "Add Provider",
      isFreeAction: true,
      onClick: (event, rowData) => {
        setOpenPopup(true);
        // setRecordForEdit(null);
        setActionTitle("Add Provider");
        setSubmitActionType("Add Provider");
      },
    },
    {
      icon: tableIcons.UploadButton,
      tooltip: "Upload",
      isFreeAction: true,
    },
  ];
  return (
    <div>
      {/* <Paper className="card card-first-level p-20 "> */}

      <div className={classes.root}>
        <div className="card card-first-level">
          <MaterialTable
            title={<HeaderTitle variant="h6" title="Data Preview" />}
            columns={columns}
            data={[]}
            page={page - 1}
            // totalCount={locationsTableData.totalElements}
            onChangePage={onChangePagination}
            onOrderChange={onChangeSorting}
            onChangeRowsPerPage={onChangeRowsperpage}
            actions={Actions}
            icons={{
              SortArrow: () => TableCustomSortArrow({ sortOrder: sortorder }),
              Filter: ColumnFilterIcon,
            }}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Toolbar: (props) => (
                <div
                  style={{
                    marginRight: "259px",
                    marginTop: "-48px",
                    marginBottom: "18px",
                  }}
                >
                  <MTableToolbar {...props} />
                </div>
              ),
            }}
            options={{
              search: false,
              searchFieldAlignment: "right",
              searchAutoFocus: true,
              searchFieldVariant: "standard",
              actionsColumnIndex: 0,
              filtering: false,
              paginationType: "stepped",
              paging: "true",
              showFirstLastPageButtons: false,
              paginationPosition: "top",
              exportButton: false,
              exportAllData: false,
              exportFileName: "Locations List",
              headerStyle: {
                background: "#EFF4FA",
                color: "#8F9BB3",
                fontSize: "11px",
                whiteSpace: "nowrap",
              },
              tableLayout: "auto",
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: rowsPerPage,
              draggable: false,
            }}
          />
          <BasicPopup
            title={actiontitle}
            show={openPopup}
            handleClose={() => {
              setOpenPopup(false);
            }}
            disableFooter={true}
            dialogProps={{
              maxWidth: "lg",
              classes: {
                paper: classes.dialogPaper,
              },
            }}
          >
            <AddProvider
              submitactiontype={submitactiontype}
              setOpenPopup={setOpenPopup}
            />
          </BasicPopup>
        </div>
      </div>
      {/* </Paper> */}
    </div>
  );
};

export default Providerstable;
