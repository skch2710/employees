import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  useCallback,
} from "react";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../Styles/useGlobalStyles";
import { isEmptyGrid } from "../../../../../utils/helper";
import { pagination } from "../../../../../utils/constants";
import DataNotFound from "../../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import MaterialTable, { MTableToolbar } from "material-table";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import { ColumnFilterIcon } from "../../../../../components/common/Table/usetableStyle";
import { NdcContext } from "../../NdcContext";
import { NDC_TABS } from "../../constants";

import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../../components/common/DatePicker";
import moment from "moment";
import { getZeroValueInTotalElements } from "../../../../../utils/common";
import { useDispatch } from "react-redux";
import { getDynamicListParametersTblData } from "../../../../../context/actions/NdcExclusions";
import {
  getDlpFiltersObject,
  getNdcDynamicListParamsSearchPayload,
} from "../NdcListSelection/helper";

const DynamicListParamsTable = ({ historyObj }) => {
  const dlpColumnFiltersRef = useRef({});
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const { setActiveNdcConfigTab, setActiveInactiveTabs, activeInactiveTabs } =
    useContext(NdcContext) || {};
  const theme = useTheme();
  const dispatch = useDispatch();
  const { ndcData } = useContext(NdcContext) || {};
  const [enableDlpFilters, setEnableDlpFilters] = useState(false);
  const [dlpLoading, setDlpLoading] = useState(false);
  const [dlpGridData, setDlpGridData] = useState({});
  const [dlpColumnFilters, setColumnFilters] = useState([]);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
    listHistoryId: ndcData.listHistoryId,
  });

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = DLP_COLUMNS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchDynamicListParametersTblData({
        pageNumber: controllers.pageNumber,
        pageSize: controllers.pageSize,
        sortOrder,
        sortBy,
        filter: dlpColumnFilters,
        listHistoryId: ndcData.listHistoryId,
      });
    },
    [controllers, dlpColumnFilters, dlpGridData]
  );

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getDlpFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    dlpColumnFiltersRef.current = { ...updatedFiltersObj };
    fetchDynamicListParametersTblData({
      ...controllers,
      filter: filterPayload,
      pageNumber: pagination.page,
      listHistoryId: ndcData.listHistoryId,
    });
  };
  const DLP_COLUMNS = [
    {
      title: "NDC Count",
      field: "ndcExclCount",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.ndcExclCount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcExclCount}>
            <span>{rowData.ndcExclCount}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.ndcExclCount}
          placeholder="NDC Count"
        />
      ),
    },
    {
      title: "NDC Exceptions",
      field: "ndcExcpCount",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.ndcExcpCount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcExcpCount}>
            <span>{rowData.ndcExcpCount}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.ndcExcpCount}
          placeholder="NDC Exceptions"
        />
      ),
    },
    {
      title: "NDC Effective Start Date",
      field: "dynamicListEffecStartDate",
      defaultFilter:
        enableDlpFilters &&
        dlpColumnFiltersRef.current.dynamicListEffecStartDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dynamicListEffecStartDate}>
            <span>{rowData.dynamicListEffecStartDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              dlpColumnFiltersRef.current.dynamicListEffecStartDate
                ? moment(dlpColumnFiltersRef.current.dynamicListEffecStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "NDC Effective End Date",
      field: "dynamicListEffecEndDate",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.dynamicListEffecEndDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dynamicListEffecEndDate}>
            <span>{rowData.dynamicListEffecEndDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              dlpColumnFiltersRef.current.dynamicListEffecEndDate
                ? moment(dlpColumnFiltersRef.current.dynamicListEffecEndDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Source",
      field: "source",
      defaultFilter: enableDlpFilters && dlpColumnFiltersRef.current.source,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.source}>
            <span>{rowData.source}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.source}
          placeholder="Source"
        />
      ),
    },
    {
      title: "Attribute #1",
      field: "drugAttributeOneDesc",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.drugAttributeOneDesc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugAttributeOneDesc}>
            <span>{rowData.drugAttributeOneDesc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.drugAttributeOneDesc}
          placeholder="Attribute #1"
        />
      ),
    },
    {
      title: "Attribute #2",
      field: "drugAttributeTwoDesc",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.drugAttributeTwoDesc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugAttributeTwoDesc}>
            <span>{rowData.drugAttributeTwoDesc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.drugAttributeTwoDesc}
          placeholder="Attribute #2"
        />
      ),
    },
    {
      title: "Modified By",
      field: "modifiedBy",
      defaultFilter: enableDlpFilters && dlpColumnFiltersRef.current.modifiedBy,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.modifiedBy}>
            <span>{rowData.modifiedBy}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.modifiedBy}
          placeholder="Modified By"
        />
      ),
    },
    {
      title: "Modified Date",
      field: "modifiedDate",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.modifiedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.modifiedDate}>
            <span>{rowData.modifiedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              dlpColumnFiltersRef.current.modifiedDate
                ? moment(dlpColumnFiltersRef.current.modifiedDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const DLP_ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableDlpFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(dlpGridData),
      onClick: () => {
        setEnableDlpFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.Edit(),
      isFreeAction: true,
      disabled: isEmptyGrid(dlpGridData),
      onClick: () => {
        setActiveNdcConfigTab(NDC_TABS.NDC_SELECTION);
        if (!activeInactiveTabs[NDC_TABS.NDC_SELECTION]) {
          setActiveInactiveTabs((prev) => {
            return {
              ...prev,
              [NDC_TABS.NDC_SELECTION]: true,
            };
          });
        }
      },
    },
  ];

  useEffect(() => {
    fetchDynamicListParametersTblData({ listHistoryId: historyObj.listHistoryId });
  }, [historyObj]);

  const fetchDynamicListParametersTblData = async (payload) => {
    const searchPayload = getNdcDynamicListParamsSearchPayload({
      ...payload,
    });
    setDlpLoading(true);
    const res = await dispatch(getDynamicListParametersTblData(searchPayload));
    setDlpLoading(false);
    if (!_isEmpty(res)) {
      setDlpGridData(res);
    }
  };
  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Dynamic List Parameters (${getZeroValueInTotalElements(
              dlpGridData
            )})`}
          />
        }
        columns={DLP_COLUMNS}
        data={(dlpGridData && dlpGridData.content) || []}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        icons={{
          SortArrow: () => TableCustomSortArrow(controllers),
          Filter: ColumnFilterIcon,
        }}
        actions={DLP_ACTIONS}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Toolbar: (props) => <MTableToolbar {...props} />,
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !dlpLoading ? <DataNotFound /> : "",
          },
        }}
        isLoading={dlpLoading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableDlpFilters,
          paging: false,
          showFirstLastPageButtons: false,
          paginationPosition: "top",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          pageSizeOptions: isEmptyGrid(dlpGridData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default DynamicListParamsTable;
