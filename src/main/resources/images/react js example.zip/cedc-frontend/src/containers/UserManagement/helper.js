import React from "react";
import _isEmpty from "lodash/isEmpty";
import { ALLOWED_CREATING_USERS_MAP } from "./constant";
import { Tooltip } from "@material-ui/core";

export const validateContactNumber = (value) => {
  let errorMessage;
  if (value && value.toString() !== "" && value.toString().length < 10) {
    errorMessage = "Please Enter Valid 10 Digit Phone Number";
  }
  return errorMessage;
};

export const validateZipCode = (value) => {
  let errorMessage;
  if (value.toString() !== "" && value.toString().length < 4) {
    errorMessage = "Please Enter Valid Zip Code";
  }
  return errorMessage;
};

export const getRolePriority = (userRoles, user, loginUser) => {
  const currUserRole = userRoles.find((role) => {
    if (user && role.roleID === user.roleID) return true;
  });
  if (!_isEmpty(currUserRole)) {
    return ALLOWED_CREATING_USERS_MAP[loginUser.roleId].includes(
      currUserRole.roleID
    )
      ? true
      : false;
  }
  return false;
};

export const getFilteredUsersRoles = (roles) => {
  let internalUsersRoles = [];
  let externalUsersRoles = [];
  roles.forEach((role) => {
    if (role.externalRole) externalUsersRoles.push(role);
    else internalUsersRoles.push(role);
  });
  return { internalUsersRoles, externalUsersRoles };
};

const getComponent = ({
  initialFlag,
  acceptableFlag,
  enabledNode,
  disabledNode,
  rowFlag,
  view,
  greenCheckNode,
  redCrossNode,
  NaNode,
}) => {
  if (initialFlag && acceptableFlag) {
    if (view) {
      return rowFlag ? greenCheckNode : redCrossNode;
    }
    return enabledNode;
  } else if (!initialFlag && acceptableFlag) {
    return disabledNode;
  } else return NaNode;
};

export const getPermissionMapping = ({
  row,
  defaultUserPrivileges,
  enabledNode,
  permission,
  disabledNode,
  view = false,
  greenCheckNode,
  redCrossNode,
  NaNode,
}) => {
  const defaultRow = defaultUserPrivileges.find(
    (prev) => prev.rolePrivilegeID === row.rolePrivilegeID
  );
  if (permission === "read") {
    const { readOnlyFlag } = defaultRow || {};
    if (view) {
      return readOnlyFlag
        ? row.readOnlyFlag
          ? greenCheckNode
          : redCrossNode
        : disabledNode;
    }
    return readOnlyFlag ? enabledNode : disabledNode;
  } else if (permission === "readWrite") {
    const { readWriteFlag, readWriteApplicable } = defaultRow || {};
    return getComponent({
      initialFlag: readWriteFlag,
      acceptableFlag: readWriteApplicable,
      rowFlag: row.readWriteFlag,
      enabledNode,
      disabledNode,
      view,
      greenCheckNode,
      redCrossNode,
      NaNode,
    });
  } else {
    const { terminateFlag, terminateApplicable } = defaultRow || {};
    return getComponent({
      initialFlag: terminateFlag,
      acceptableFlag: terminateApplicable,
      rowFlag: row.terminateFlag,
      enabledNode,
      disabledNode,
      view,
      greenCheckNode,
      redCrossNode,
      NaNode,
    });
  }
};

export const getPermissionDisableState = ({ row, permissions }) => {
  if (row.resourceID === 8 || row.resourceID === 6) {
    const phiPerm = permissions.find((perm) => perm.resourceID === 15);
    return !phiPerm.readOnlyFlag;
  }
  return false;
};

export const getCeObject = (ceList = [], ceId = "") => {
  const obj = ceList.find((ce) => ce.ceID === ceId) || {};
  return obj;
};

export const getLabelValue = (value) => {
  const labelValue = value.slice(0, 35) + "...";
  if (value && value.length < 35) return value;
  else
    return (
      <Tooltip title={value} placement="bottom">
        <span>{labelValue}</span>
      </Tooltip>
    );
};
