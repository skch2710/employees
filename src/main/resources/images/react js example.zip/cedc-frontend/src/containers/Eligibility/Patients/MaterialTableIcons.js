import React, { forwardRef } from "react";
import Button from "@material-ui/core/Button";
//react-icons
import { RiDeleteBin5Line } from "react-icons/ri";
import { BiEditAlt } from "react-icons/bi";
import { FaSort, FaRegHandshake } from "react-icons/fa";
import { AiOutlinePlus } from "react-icons/ai";
import { MdOutlineFilterList } from "react-icons/md";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import { BiUpload } from "react-icons/bi";
import {AiOutlineEye} from "react-icons/ai";

const tableIcons = {
  AddButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Add Patient
    </Button>
  )),
  UploadButton: forwardRef((props, ref) => (
    <Button
      startIcon={<BiUpload />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Bulk Upload
    </Button>
  )),
  Eye:  forwardRef((props, ref) => (
    <AiOutlineEye fontSize="small" color="action" {...props} ref={ref} />
  )),
  Delete: forwardRef((props, ref) => (
    <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => (
    <BiEditAlt fontSize="small" color="action" {...props} ref={ref} />
  )),
  plus: forwardRef((props, ref) => (
    <AiOutlinePlus fontSize="small" color="action" {...props} ref={ref} />
  )),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => (
    <MdOutlineFilterList {...props} ref={ref} />
  )),
  Handshake: forwardRef((props, ref) => (
    <FaRegHandshake {...props} ref={ref} fontSize="small" color="action" />
  )),
};

export default tableIcons;
