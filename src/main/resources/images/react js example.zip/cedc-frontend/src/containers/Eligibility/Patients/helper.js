
export const filterFunctionality = (filterCValue, module) => {
  const filterValue = [];
  return new Promise((resolve, reject) => {
    if (filterCValue.length < 1) resolve(filterValue);
    filterCValue.map((keyItem, index) => {
      keyItem.operator = getOperatorValue(keyItem.column.field, module);
      filterValue.push(keyItem);
      if (filterCValue.length - 1 == index) {
        resolve(filterValue);
      }
    });
  });
};

const getOperatorValue = (value, module = false) => {
  let parsingValue;
  if (module == "Patients") {
    const stringFields = [
      "mrn",
      "firstName",
      "middleName",
      "lastName",
      "suffix",
      "gender",
      "slidingScaleIndicator",
    ];
    return (parsingValue = stringFields.includes(value) ? "startWith" : "=");
  }
  if (module == "CeMember") {
    const stringFields = [
      "mrn",
      "firstName",
      "middleName",
      "lastName",
      "suffix",
      "gender",
      "slidingScaleIndicator",
      "coveredEntity",
      "id340b",
      "hospitalService",
      "admitType",
      "servicingFacility",
      "assignedPatientLocation",
      "providerNpi",
      "providerFn",
      "providerLn",
      "providerNpi",
      "providerDea",
      "prescriberSpi",
    ];
    return (parsingValue = stringFields.includes(value) ? "startWith" : "=");
  }
  return parsingValue;
};

export const getCeObject = (ceList = [], ceId = "") => {
  const obj = ceList.find((ce) => ce.ceID === ceId) || {};
  return obj;
};