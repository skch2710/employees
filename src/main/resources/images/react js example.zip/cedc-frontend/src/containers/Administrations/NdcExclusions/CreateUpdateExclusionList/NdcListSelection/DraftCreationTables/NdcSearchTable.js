import React, {
  forwardRef,
  memo,
  useContext,
  useImperativeHandle,
  useRef,
  useState,
  useCallback,
  useEffect,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEmpty from "lodash/isEmpty";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { pagination } from "../../../../../../utils/constants";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import {
  getNdcSearchPayload,
  getNdcSelectionSearchFiltersObject,
} from "../helper";
import {
  getDraftExcludedData,
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import { NdcContext } from "../../../NdcContext";
import { useDispatch, useSelector } from "react-redux";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import NdcDetailsTable from "./NdcDetailsTable";
import Pagination from "../../../../../../components/common/Pagination";
import { exportNdcSearchResultTableData } from "../../../../../../context/actions/NdcExclusions";
import _get from "lodash/get";

const NdcSearchTable = memo(
  forwardRef((props = {}, ref) => {
    const { tableRef, imperativeRef } = ref;
    const {
      searchResults = {},
      formSubmittedValues,
      getNdcSearchTableData,
      controllers,
      setControllers,
    } = props || {};
    const dispatch = useDispatch();
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const iconsAndButtons = useTableIconsAndButtons();
    const { ndcSelectionDraftTableData } = useContext(NdcContext);

    const { loading } = useSelector((state) => state.ndcSelectionSearchList);

    const [columnFilters, setColumnFilters] = useState([]);
    const [enableFilters, setEnableFilters] = useState(false);
    const [showNdcDetailsPopup, setShowNdcDetailsPopup] = useState(false);
    const [ndcDetailsRowData, setNdcDetailsRowData] = useState({});
    const columnFiltersRef = useRef({});

    useImperativeHandle(imperativeRef, () => ({
      // This function will be called when submit button clicked from search component
      submitForm(resp) {
        columnFiltersRef.current = {};
        setControllersOnResp(resp);
      },
      // This function will be called when clear button clicked from search component
      clearForm(_initialPayload) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
      },
    }));

    const setControllersOnResp = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          pageNumber: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        const rowsPerPage = Number(pageSize);
        const totalPages =
          Math.ceil(_get(searchResults, "totalElements", 0) / rowsPerPage) || 1;
        if (controllers.pageNumber > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
          currentPage = controllers.pageNumber;

        getNdcSearchTableData(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: controllers.sortOrder,
            sortBy: controllers.sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp)
        );
      },
      [columnFilters, searchResults, controllers, formSubmittedValues]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = NDC_SEARCH_RESULT_COLUMNS[orderedColumnId].field;
        setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        getNdcSearchTableData(
          {
            pageNumber: controllers.pageNumber,
            pageSize: controllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        );
      },
      [controllers, formSubmittedValues, columnFilters, searchResults]
    );

    const handleColumnFilter = (filters = []) => {
      const filterPayload = getNdcSelectionSearchFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      getNdcSearchTableData(
        {
          ...formSubmittedValues,
          ...controllers,
          filter: filterPayload,
          pageNumber: pagination.page,
        },
        (resp) => setControllersOnResp(resp)
      );
    };

    const handleNdcDetailsPopup = useCallback(
      (prop = {}) =>
        () => {
          const { state, rowData } = prop;
          if (state) {
            setNdcDetailsRowData(rowData);
          }
          setShowNdcDetailsPopup(state);
        },
      []
    );

    const NDC_SEARCH_RESULT_COLUMNS = [
      {
        title: "GCN",
        field: "gcn",
        defaultFilter: enableFilters && columnFiltersRef.current.gcn,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.gcn}>
              <span>{rowData.gcn}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.gcn}
            placeholder="GCN"
          />
        ),
      },
      {
        title: "NDC",
        field: "ndc",
        defaultFilter: enableFilters && columnFiltersRef.current.ndc,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndc}>
              <a
                className={globalClasses.gridClickableLink}
                onClick={handleNdcDetailsPopup({ state: true, rowData })}
              >
                {rowData.ndc}
              </a>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.ndc}
            placeholder="NDC"
          />
        ),
      },
      {
        title: "Drug Name",
        field: "drugName",
        defaultFilter: enableFilters && columnFiltersRef.current.drugName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugName}>
              <span>{rowData.drugName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.drugName}
            placeholder="Drug Name"
          />
        ),
      },
      {
        title: "Manufacturer",
        field: "drugManufacturer",
        defaultFilter:
          enableFilters && columnFiltersRef.current.drugManufacturer,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugManufacturer}>
              <span>{rowData.drugManufacturer}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.drugManufacturer}
            placeholder="Manufacturer"
          />
        ),
      },
      {
        title: "Therapeutic Class",
        field: "therapeuticClass",
        defaultFilter:
          enableFilters && columnFiltersRef.current.therapeuticClass,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.therapeuticClass}>
              <span>{rowData.therapeuticClass}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.therapeuticClass}
            placeholder="Therapeutic Class"
          />
        ),
      },
    ];

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(searchResults),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(searchResults),
        isFreeAction: true,
        onClick: async () => {
          const payload = getNdcSearchPayload({
            ...formSubmittedValues,
            ...controllers,
            export: true,
          });
          await dispatch(
            exportNdcSearchResultTableData({
              ...payload,
              filter: columnFilters,
            })
          );
        },
      },
    ];

    const tableData = getDraftExcludedData({
      originalList: _get(searchResults, "content", []),
      draftList: _get(ndcSelectionDraftTableData, "content", []),
    });

    return (
      <>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`NDC Search Results (${getTableHeaderCount(
                _get(searchResults, "totalElements", 0)
              )})`}
            />
          }
          tableRef={tableRef}
          columns={NDC_SEARCH_RESULT_COLUMNS}
          data={tableData}
          page={controllers.pageNumber - 1}
          totalCount={_get(searchResults, "totalElements", 0)}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            sorting: _get(searchResults, "totalElements", 0),
            selection: true,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(searchResults)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
        <BasicPopup
          title="NDC History"
          show={showNdcDetailsPopup}
          disableFooter={true}
          dialogProps={{
            maxWidth: "md",
          }}
          handleClose={handleNdcDetailsPopup({ state: false })}
        >
          <NdcDetailsTable ndcDetailsRowData={ndcDetailsRowData} />
        </BasicPopup>
      </>
    );
  })
);

export default NdcSearchTable;
