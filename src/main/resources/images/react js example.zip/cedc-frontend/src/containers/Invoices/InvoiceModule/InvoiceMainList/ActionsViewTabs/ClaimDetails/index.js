import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import DatePicker from "../../../../../../components/common/DatePicker";
import moment from "moment";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { formatValue, getUserPreveleges } from "../../../../../../utils/common";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import { LABELS, pagination } from "../../../../../../utils/constants";
import { isEmptyGrid } from "../../../../../../utils/helper";
import { getClaimsList } from "../../../../../../context/actions/Invoice";
import { getClaimsFiltersObject } from "../../../helper";
import { GET_CLAIM_LIST } from "../../../../../../context/constants";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import tableIcons from "../../../../../../components/common/TableIcons/MaterialTableIcons";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../../../components/common/Pagination";

const ClaimDetails = ({ actionsRowDataDetails, filtersValues } = {}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const phiAccess = getUserPreveleges("PHI Access");
  const theme = useTheme();
  const { ceId, invoicePeriodEndDate, invoicePeriodStartDate } =
    actionsRowDataDetails || {};
  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const startDate = new Date(actionsRowDataDetails.invoicePeriodStartDate);
  const endDate = new Date(actionsRowDataDetails.invoicePeriodEndDate);
  const formattedStartDate = moment(startDate).format("MMMM D , Y");
  const formattedEndDate = moment(endDate).format("MMMM D , Y");
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);

  const { records: claimDetailsRecords, loading } = useSelector(
    (state) => state.getClaimData
  );

  const fetchClaimsDetails = (payload = {}) => {
    dispatch(
      getClaimsList(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          ceid: ceId,
          startPeriod: invoicePeriodStartDate,
          endPeriod: invoicePeriodEndDate,
          phGroupId:
            filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
          phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    fetchClaimsDetails();
    return () => {
      dispatch({ type: GET_CLAIM_LIST, data: {} });
    };
  }, []);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setController((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(claimDetailsRecords.totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchClaimsDetails(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controller.sortOrder,
          sortBy: controller.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, controller, claimDetailsRecords]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = CLAIMS_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchClaimsDetails(
        {
          pageNumber: controller.page,
          pageSize: controller.pageSize,
          sortOrder,
          sortBy,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controller]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getClaimsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchClaimsDetails({
      ...controller,
      filter: filterPayload,
    });
  };

  const actions = [
    {
      icon: tableIcons.Filter,
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: claimDetailsRecords && claimDetailsRecords.totalElements < 1,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  const CLAIMS_COLUMNS = [
    {
      title: "Admin Name",
      field: "adminName",
      defaultFilter: enableFilters && columnFiltersRef.current.adminName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.adminName}>
            <span>{rowData.adminName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.adminName}
          placeholder="Admin Name"
        />
      ),
    },
    {
      title: "Covered Entity",
      field: "ceName",
      defaultFilter: enableFilters && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceName}>
            <span>{rowData.ceName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceName}
          placeholder="Covered Entity"
        />
      ),
    },
    {
      title: "HRSA ID",
      field: "adminHRSAID",
      defaultFilter: enableFilters && columnFiltersRef.current.adminHRSAID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.adminHRSAID}>
            <span>{rowData.adminHRSAID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.adminHRSAID}
          placeholder="HRSA ID"
        />
      ),
    },
    {
      title: "Covered Entity Reimbursement Model",
      field: "ceReimbursementModel",
      defaultFilter:
        enableFilters && columnFiltersRef.current.ceReimbursementModel,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceReimbursementModel}>
            <span>{rowData.ceReimbursementModel}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceReimbursementModel}
          placeholder="Covered Entity Reimbursement Model"
        />
      ),
    },
    {
      title: "Covered Entity Replenishment Model",
      field: "ceReplenishmentModel",
      defaultFilter:
        enableFilters && columnFiltersRef.current.ceReplenishmentModel,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceReplenishmentModel}>
            <span>{rowData.ceReplenishmentModel}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceReplenishmentModel}
          placeholder="Covered Entity Replenishment Model"
        />
      ),
    },
    {
      title: LABELS.PharmacyChain,
      field: "pharmacyGroup",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyGroup,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyGroup}>
            <span>{rowData.pharmacyGroup}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyGroup}
          placeholder={LABELS.PharmacyChain}
        />
      ),
    },
    {
      title: LABELS.PharmacyStore,
      field: "pharmacyStoreName",
      defaultFilter:
        enableFilters && columnFiltersRef.current.pharmacyStoreName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyStoreName}>
            <span>{rowData.pharmacyStoreName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyStoreName}
          placeholder={LABELS.PharmacyStore}
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "pharmacyNPI",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyNPI,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNPI}>
            <span>{rowData.pharmacyNPI}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyNPI}
          placeholder="Pharmacy NPI"
        />
      ),
    },
    {
      title: "Physician First Name",
      field: "physicianFirstName",
      defaultFilter:
        enableFilters && columnFiltersRef.current.physicianFirstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.physicianFirstName}>
            <span>{rowData.physicianFirstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.physicianFirstName}
          placeholder="Physician First Name"
        />
      ),
    },
    {
      title: "Physician Last Name",
      field: "physicianLastName",
      defaultFilter:
        enableFilters && columnFiltersRef.current.physicianLastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.physicianLastName}>
            <span>{rowData.physicianLastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.physicianLastName}
          placeholder="Physician Last Name"
        />
      ),
    },
    {
      title: "Prescriber NPI",
      field: "prescriberId",
      defaultFilter: enableFilters && columnFiltersRef.current.prescriberId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.prescriberId}>
            <span>{rowData.prescriberId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.prescriberId}
          placeholder="Prescriber NPI"
        />
      ),
    },
    {
      title: "Claim ID",
      field: "claimID",
      defaultFilter: enableFilters && columnFiltersRef.current.claimID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimID}>
            <span>{rowData.claimID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimID}
          placeholder="Claim ID"
        />
      ),
    },
    {
      title: "Rx Number",
      field: "rxNumber",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.rxNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.rxNumber}>
            <span>{rowData.rxNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.rxNumber}
          placeholder="Rx Number"
        />
      ),
    },
    {
      title: "Refill #",
      field: "refillCode",
      defaultFilter: enableFilters && columnFiltersRef.current.refillCode,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.refillCode}>
            <span>{rowData.refillCode}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.refillCode}
          placeholder="Refill #"
        />
      ),
    },
    {
      title: "Rx Written Date",
      field: "pgmDateRxWritten",
      defaultFilter: enableFilters && columnFiltersRef.current.pgmDateRxWritten,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pgmDateRxWritten}>
            <span>{rowData.pgmDateRxWritten}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.pgmDateRxWritten
                ? moment(columnFiltersRef.current.pgmDateRxWritten)
                : ""
            }
            getPopupContainer={(triggerNode) => {
              return triggerNode.parentNode;
            }}
          />
        );
      },
    },
    {
      title: "Date of Service",
      field: "dateOfService",
      defaultFilter: enableFilters && columnFiltersRef.current.dateOfService,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dateOfService}>
            <span>{rowData.dateOfService}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.dateOfService
                ? moment(columnFiltersRef.current.dateOfService)
                : ""
            }
            getPopupContainer={(triggerNode) => {
              return triggerNode.parentNode;
            }}
          />
        );
      },
    },
    {
      title: "Patient First Name",
      field: "patientFirstName",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.patientFirstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientFirstName}>
            <span>{rowData.patientFirstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.patientFirstName}
          placeholder="Patient First Name"
        />
      ),
    },
    {
      title: "Patient Middle Name",
      field: "patientMiddleName",
      defaultFilter:
        enableFilters && columnFiltersRef.current.patientMiddleName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientMiddleName}>
            <span>{rowData.patientMiddleName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.patientMiddleName}
          placeholder="Patient Middle Name"
        />
      ),
    },
    {
      title: "Patient Last Name",
      field: "patientLastName",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.patientLastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientLastName}>
            <span>{rowData.patientLastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.patientLastName}
          placeholder="Patient Last Name"
        />
      ),
    },
    {
      title: "Patient DOB",
      field: "patientDateofBirth",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter:
        enableFilters && columnFiltersRef.current.patientDateofBirth,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientDateofBirth}>
            <span>{rowData.patientDateofBirth}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.patientDateofBirth
                ? moment(columnFiltersRef.current.patientDateofBirth)
                : ""
            }
            getPopupContainer={(triggerNode) => {
              return triggerNode.parentNode;
            }}
          />
        );
      },
    },
    {
      title: "Patient MRN",
      field: "patientMemberid",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.patientMemberid,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientMemberid}>
            <span>{rowData.patientMemberid}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.patientMemberid}
          placeholder="Patient MRN"
        />
      ),
    },
    {
      title: "Processed Date",
      field: "processedDate",
      defaultFilter: enableFilters && columnFiltersRef.current.processedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.processedDate}>
            <span>{rowData.processedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.processedDate
                ? moment(columnFiltersRef.current.processedDate)
                : ""
            }
            getPopupContainer={(triggerNode) => {
              return triggerNode.parentNode;
            }}
          />
        );
      },
    },
    {
      title: "Date Reversed",
      field: "dateReversed",
      defaultFilter: enableFilters && columnFiltersRef.current.dateReversed,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dateReversed}>
            <span>{rowData.dateReversed}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.dateReversed
                ? moment(columnFiltersRef.current.dateReversed)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Claim Status",
      field: "claimStatusCode",
      defaultFilter: enableFilters && columnFiltersRef.current.claimStatusCode,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimStatusCode}>
            <span>{rowData.claimStatusCode}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimStatusCode}
          placeholder="Claim Status"
        />
      ),
    },
    {
      title: "Claim Type",
      field: "claimType",
      defaultFilter: enableFilters && columnFiltersRef.current.claimType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimType}>
            <span>{rowData.claimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimType}
          placeholder="Claim Type"
        />
      ),
    },
    {
      title: "BIN",
      field: "bin",
      defaultFilter: enableFilters && columnFiltersRef.current.bin,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bin}>
            <span>{rowData.bin}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.bin}
          placeholder="BIN"
        />
      ),
    },
    {
      title: "PCN",
      field: "pcn",
      defaultFilter: enableFilters && columnFiltersRef.current.pcn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pcn}>
            <span>{rowData.pcn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pcn}
          placeholder="PCN"
        />
      ),
    },
    {
      title: "Group Number",
      field: "groupNumber",
      type: "text",
      defaultFilter: enableFilters && columnFiltersRef.current.groupNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.groupNumber}>
            <span>{rowData.groupNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.groupNumber}
          placeholder="Group Number"
        />
      ),
    },
    {
      title: "NDC11",
      field: "ndc",
      defaultFilter: enableFilters && columnFiltersRef.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ndc}
          placeholder="NDC11"
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: enableFilters && columnFiltersRef.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugName}
          placeholder="Drug Name"
        />
      ),
    },
    {
      title: "Brand or Generic Indicator",
      field: "borGIndicator",
      defaultFilter: enableFilters && columnFiltersRef.current.borGIndicator,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.borGIndicator}>
            <span>{rowData.borGIndicator}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.borGIndicator}
          placeholder="Brand or Generic Indicator"
        />
      ),
    },
    {
      title: "Qty Disp",
      field: "qtyDisp",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.qtyDisp,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.qtyDisp}>
            <span className={globalClasses.tableNumericPadding}>
              {rowData.qtyDisp}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.qtyDisp}
          placeholder="Qty Disp"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Replenished Qty",
      field: "replenishedQty",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.replenishedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishedQty}>
            <span className={globalClasses.tableNumericPadding}>
              {rowData.replenishedQty}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishedQty}
          placeholder="Replenished Qty"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Replenishment Percentage",
      field: "replenishmentPercentage",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.replenishmentPercentage,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishmentPercentage}>
            <span className={globalClasses.tableNumericPadding}>
              {rowData.replenishmentPercentage}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishmentPercentage}
          placeholder="Replenishment Percentage"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Patient Pay",
      field: "patientPay",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.patientPay,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.patientPay}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.patientPay)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.patientPay}
          placeholder="Patient Pay"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Third Party Payment",
      field: "thirdPartyPayment",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.thirdPartyPayment,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.thirdPartyPayment}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.thirdPartyPayment)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.thirdPartyPayment}
          placeholder="Third Party Payment"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Covered Entity Plan Subsidy",
      field: "cePlanSubsidy",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.cePlanSubsidy,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.cePlanSubsidy}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.cePlanSubsidy)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.cePlanSubsidy}
          placeholder="Covered Entity Plan Subsidy"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Total Collected",
      field: "totalCollected",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.totalCollected,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.totalCollected}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.totalCollected)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalCollected}
          placeholder="Total Collected"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Estimated 340B Drug Cost",
      field: "tfbIngredientCost",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.tfbIngredientCost,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.tfbIngredientCost}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.tfbIngredientCost)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.tfbIngredientCost}
          placeholder="Estimated 340B Drug Cost"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Invoiced 340B Drug Cost",
      field: "actualIngredientCost",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.actualIngredientCost,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.actualIngredientCost}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.actualIngredientCost)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.actualIngredientCost}
          placeholder="Invoiced 340B Drug Cost"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Pharmacy EAC",
      field: "totalInvoiced",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.totalInvoiced,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.totalInvoiced}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.totalInvoiced)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalInvoiced}
          placeholder="Pharmacy EAC"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Dispensing Fee",
      field: "dispensingFee",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensingFee,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.dispensingFee}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.dispensingFee)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingFee}
          placeholder="Dispensing Fee"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Covered Entity Gross Savings",
      field: "grossSavings",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.grossSavings,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.grossSavings}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.grossSavings)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.grossSavings}
          placeholder="Covered Entity Gross Savings"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Subsidy",
      field: "subsidy",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.subsidy,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.subsidy}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.subsidy)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.subsidy}
          placeholder="Subsidy"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Replenishment Type",
      field: "replenishmentType",
      defaultFilter:
        enableFilters && columnFiltersRef.current.replenishmentType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishmentType}>
            <span>{rowData.replenishmentType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishmentType}
          placeholder="Replenishment Type"
        />
      ),
    },
    {
      title: "810 Debit Invoice #",
      field: "eightTenDebitInvoice",
      defaultFilter:
        enableFilters && columnFiltersRef.current.eightTenDebitInvoice,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.eightTenDebitInvoice}>
            <span>{rowData.eightTenDebitInvoice}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.eightTenDebitInvoice}
          placeholder="810 Debit Invoice #"
        />
      ),
    },
    {
      title: "Debit Invoice Date",
      field: "invoiceDate",
      defaultFilter: enableFilters && columnFiltersRef.current.invoiceDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.invoiceDate}>
            <span>{rowData.invoiceDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.invoiceDate}
          placeholder="Debit Invoice Date"
        />
      ),
    },
    {
      title: "810 Credit Invoice #",
      field: "eightTenCreditInvoice",
      defaultFilter:
        enableFilters && columnFiltersRef.current.eightTenCreditInvoice,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.eightTenCreditInvoice}>
            <span>{rowData.eightTenCreditInvoice}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.eightTenCreditInvoice}
          placeholder="810 Credit Invoice #"
        />
      ),
    },
    {
      title: "Credit Invoice Date",
      field: "creditInvoiceDate",
      defaultFilter:
        enableFilters && columnFiltersRef.current.creditInvoiceDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.creditInvoiceDate}>
            <span>{rowData.creditInvoiceDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.creditInvoiceDate}
          placeholder="Credit Invoice Date"
        />
      ),
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={3}>
            <BasicTypography
              variant="h5"
              title={`Invoice Number : ${actionsRowDataDetails.invoiceNumber}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={`Billing Cycle : ${formattedStartDate} -
                    ${formattedEndDate}`}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Grid className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h4"
                title={`Claims Details - (${
                  claimDetailsRecords.totalElements || 0
                })`}
              />
            }
            ref={tableRef}
            columns={CLAIMS_COLUMNS}
            data={claimDetailsRecords.content}
            page={controller.page - 1}
            totalCount={claimDetailsRecords.totalElements || 0}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={actions}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              exportAllData: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(claimDetailsRecords)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default memo(ClaimDetails);
