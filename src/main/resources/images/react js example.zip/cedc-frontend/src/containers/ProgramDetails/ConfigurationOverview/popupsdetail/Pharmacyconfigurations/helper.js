import {
  checkBooleanWithYorN,
  returnYorNWithBoolean,
} from "../../../../../utils/helper";

export const getDefaultValuesFromResponse = (resp = {}) => {
  return {
    phGroupId: resp.phGroupId || "",
    npi: resp.npi || "",
    phName: resp.pharmacyName || "",
    storeNumber: resp.storeNumber || "",
    nabp: resp.nabp || "",
    division: resp.phDivisionId || "",
    region: resp.phRegionId || "",
    iCode: resp.icode || "",
    district: resp.phDistrictId || "",
    address1: resp.addressLine1 || "",
    address2: resp.addressLine2 || "",
    city: resp.city || "",
    stateId: resp.stateId || "",
    zipCode: resp.zip || "",
    parentAssociation: resp.parentAssociation || "",
    network: checkBooleanWithYorN(resp.network),
    isSpecialtyStore: checkBooleanWithYorN(resp.specialityPharmacy),
    isCentralFillStore: checkBooleanWithYorN(resp.centralFillLocation),
    cecontractDate: resp.ceContractDate || "",
    pharmacyLiveDate: resp.effectiveDate || "",
    productionDate: resp.goLiveDate || "",
    pharmacyTerminationDate: resp.terminatedDate || "",
    opaeffectiveDate: resp.opaEffectiveDate || "",
    feeEffectiveDate: resp.feeStartDate || "",
    phContactFN: resp.pharmacyContactFirstName || "",
    phContactLN: resp.pharmacyContactLastName || "",
    phone: resp.phone || "",
    emailId: resp.email || "",
    primaryContactIndicator: checkBooleanWithYorN(resp.primaryContactIndicator),
  };
};

export const createPhPayload = (values) => {
  return {
    ...(values.phId ? { phId: Number(values.phId) } : {}),
    ceid: Number(values.ceId),
    phGroupId: Number(values.phGroupId),
    phName: values.phName,
    nabp: values.nabp,
    storeNumber: values.storeNumber,
    npi: values.npi,
    division: values.division ? Number(values.division) : null,
    region: values.region ? Number(values.region) : null,
    district: values.district ? Number(values.district) : null,
    icode: values.iCode || "",
    isSpecialtyStore: returnYorNWithBoolean(values.isSpecialtyStore),
    isCentralFillStore: returnYorNWithBoolean(values.isCentralFillStore),
    network: returnYorNWithBoolean(values.network),
    parentAssociation: values.parentAssociation,
    entityAddress: {
      address1: values.address1,
      address2: values.address2,
      city: values.city,
      stateId: Number(values.stateId),
      zipCode: values.zipCode,
      contactName: `${values.phContactFN}-${values.phContactLN}`,
      phone: values.phone ? Number(values.phone) : values.phone,
      emailId: values.emailId,
      primaryContactIndicator: values.primaryContactIndicator ? "Y" : "N",
      createdBy: values.createdBy || 1,
      modifiedBy: values.modifiedBy || 1,
    },
    clientConfiguration: {
      ...(values.clientConfigId
        ? { clientConfigId: values.clientConfigId }
        : {}),
      pharmacyLiveDate: values.pharmacyLiveDate,
      productionDate: values.productionDate,
      pharmacyTerminationDate: values.pharmacyTerminationDate,
      feeEffectiveDate: values.feeEffectiveDate,
      opaeffectiveDate: values.opaeffectiveDate,
      cecontractDate: values.cecontractDate,
    },
    createdBy: values.createdBy || 1,
    modifiedBy: values.modifiedBy || 1,
  };
};

export const getDocumentsFiltersObject = (filters) => {
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: "startWith",
      value: filter.value,
    };
  });
};

export const getClientOrderReplenish = (resp) => {
  return {
    OrderingPharmacy: checkBooleanWithYorN(resp.OrderingPharmacy),
    generateC2OrdersOutOfSwell: checkBooleanWithYorN(
      resp.generateC2OrdersOutOfSwell
    ),
    participateInCentralReplenishment: checkBooleanWithYorN(
      resp.participateInCentralReplenishment
    ),
    turnOffTrueUp: checkBooleanWithYorN(resp.turnOffTrueUp),
    replenishThresholdPercent: resp.replenishThresholdPercent,
    turnOffCeOwnedInventory: checkBooleanWithYorN(resp.turnOffCeOwnedInventory),
    centralReplenishment: checkBooleanWithYorN(resp.centralReplenishment),
    processUnsolicited855and810: checkBooleanWithYorN(
      resp.processUnsolicited855and810
    ),
    wholesalerAccountNo: resp.wholesalerAccountNo,
    wholesalerId: resp.wholesalerId,
  };
};

export const getPharmacyGroupOrderReplenish = (resp) => {
  return {
    supportMultipleWholesalerForCeNetwork: checkBooleanWithYorN(
      resp.supportMultipleWholesalerForCeNetwork
    ),
    billingModelId: resp.billingModelId,
    inventorySwellProgramId: resp.inventorySwellProgramId,
    sendOrderNotifications: checkBooleanWithYorN(resp.sendOrderNotifications),
  };
};

export const getContextCurrentPharmacyData = (data = {}) => {
  return {
    ...data,
    phid: data.phId,
    clientId: data.clientConfiguration.clientID,
    clientConfigId: data.clientConfiguration.clientConfigId,
  };
};
