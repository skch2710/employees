import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../../../utils/helper";

export const useTrueupStyle = makeStyles((theme) => {
  return {
    tableHeader: {
      background: theme.colors.monochrome.tableHeaderBackground,
      color: theme.colors.monochrome.tableHeaderText,
      fontSize: "11px",
      whiteSpace: "nowrap",
      border: "none",
      textAlign: "center",
      padding: "5px 0",
    },
    colSpanFirstHeaderStyle: {
      width: "100%",
      borderRight: `1px solid ${theme.colors.monochrome.tableHeaderText}`,
    },
  };
});
