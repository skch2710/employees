import React, { useContext, useState, useCallback } from "react";
import { useDispatch } from "react-redux";
import { Button, FormLabel, Grid } from "@material-ui/core";
import { toast } from "react-toastify";
import { Field, Form, Formik } from "formik";
import _isEmpty from "lodash/isEmpty";
import _get from "lodash/get";
import _debounce from "lodash/debounce";
import { NdcContext } from "../../NdcContext";
import DatePicker from "../../../../../components/common/DatePicker";
import moment from "moment";
import { REGEX } from "../../../../../utils/constants";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import { NDC_TABS } from "../../constants";
import {
  checkForDuplicateListName,
  copyNdcList,
  fetchNdcSectionStatus,
  saveNdcListBasicDetails,
  getListNames,
  ndcSearchList,
} from "../../../../../context/actions/NdcExclusions";
import LoaderUI from "../../../../../components/common/Loader/Loader";
import { getUserSession } from "../../../../../utils/helper";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import {
  endDateValidation,
  startDateValidation,
} from "../../../../../utils/common";

const NdcListBasicDetails = () => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    handleConfigPopup,
    setActiveInactiveTabs,
    setActiveNdcConfigTab,
    activeInactiveTabs,
    setNdcData,
    ndcData,
    setNdcConfigPopupTitle,
    setProgress,
    ndcSearchPayload,
  } = useContext(NdcContext) || {};
  const { startDate, endDate, listName, isCopy = false } = ndcData || {};

  const userSession = getUserSession();

  const defaultFormValues = {
    listId: ndcData.listId || 0,
    listName: listName || "",
    startDate: startDate || "",
    endDate: endDate || "",
    listHistoryId: ndcData.listHistoryId || 0,
  };

  const [listNameError, setListNameError] = useState(null);
  const [loading, setLoading] = useState(null);

  const handleSubmit = async (values, { setFieldError }) => {
    const payload = {
      ...values,
      createdById: _get(userSession, "userId", 0),
      modifiedById: _get(userSession, "userId", 0),
    };
    if (isCopy) {
      setLoading(true);
      const listName = _get(values, "listName", "");
      const resp = await checkForDuplicateListName(listName);
      setLoading(false);
      if (resp) {
        setFieldError("listName", resp);
        return;
      } else {
        const response = await dispatch(
          copyNdcList({ ...payload, listHistoryId: ndcData.listHistoryId })
        );
        if (response && !_isEmpty(response)) {
          dispatch(getListNames());
          dispatch(ndcSearchList(ndcSearchPayload));
          setNdcData(response.ndcBasicDetails);
          setNdcConfigPopupTitle(response.ndcBasicDetails.listName);
          setActiveInactiveTabs({
            [NDC_TABS.NDC_BASIC_DETAILS]: true,
            [NDC_TABS.NDC_SELECTION]: true,
            [NDC_TABS.NDC_LIST_APPLICATION]: true,
            [NDC_TABS.NDC_LIST_REVIEW]: true,
          });
          setActiveNdcConfigTab(NDC_TABS.NDC_SELECTION);
          getNdcSectionStatus(response.ndcBasicDetails.listId);
        }
      }
    } else {
      setLoading(true);
      saveNdcListBasicDetails(payload)
        .then((res) => {
          if (res && res.successMessage) {
            toast.success(res.successMessage);
            dispatch(getListNames());
            dispatch(ndcSearchList(ndcSearchPayload));
            setNdcData(res.data);
            setNdcConfigPopupTitle(res.data.listName);
            if (!activeInactiveTabs[NDC_TABS.NDC_SELECTION]) {
              setActiveInactiveTabs((prev) => {
                return {
                  ...prev,
                  [NDC_TABS.NDC_SELECTION]: true,
                };
              });
            }
            getNdcSectionStatus(res.data.listId);
            setActiveNdcConfigTab(NDC_TABS.NDC_SELECTION);
          }
        })
        .finally(() => {
          setLoading(false);
        });
    }
  };

  const getNdcSectionStatus = async (listId) => {
    const res = await dispatch(fetchNdcSectionStatus(listId));
    !_isEmpty(res) && setProgress(res);
  };

  const handleListNameChange = _debounce(async (listName) => {
    setLoading(true);
    const listNameError = listName
      ? await checkForDuplicateListName(listName)
      : null;
    setListNameError(listNameError);
    setLoading(false);
  }, 500);

  // Form validation
  const formValidate = async (values) => {
    const error = {};
    if (!values.listName) {
      error.listName = "Please enter the NDC Exclusion List Name";
    }
    if (values.listName && listNameError) {
      error.listName = listNameError;
    }
    if (!values.startDate) {
      error.startDate = "Please select the List Effective Start Date";
    }
    return error;
  };

  return (
    <Formik
      initialValues={defaultFormValues}
      onSubmit={handleSubmit}
      validate={formValidate}
      enableReinitialize={true}
    >
      {({ values, errors, touched, setFieldValue, initialValues }) => {
        return (
          <Form>
            {loading && <LoaderUI />}
            <Grid container direction="column" spacing={2}>
              <Grid item md>
                <BasicTypography
                  variant="inherit"
                  title={"NDC List Basic Details"}
                />
              </Grid>
              <Grid item>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4} md={3}>
                    <FormLabel required>NDC Exclusion List Name</FormLabel>
                    <Field
                      name="listName"
                      id="listName"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter NDC Exclusion List Name"
                      maxLength={250}
                      onChange={(e) => {
                        const { value } = e.target;
                        if (
                          value &&
                          !REGEX.alphabetsWithDotHyphenExcludeLeadingAndTrailingSpaces.test(
                            value
                          )
                        )
                          return;
                        setFieldValue("listName", value);
                        if (value && initialValues.listName !== value) {
                          handleListNameChange(value);
                        }
                      }}
                      disabled={
                        ndcData &&
                        ndcData.listId &&
                        moment(values.startDate).isBefore(moment(), "day") &&
                        !ndcData.isCopy
                      }
                    />
                    {errors.listName && touched.listName && (
                      <BasicTypography color="error" variant="caption">
                        {errors.listName}
                      </BasicTypography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4} md={2}>
                    <FormLabel required>List Effective Start Date</FormLabel>
                    <Field name="startDate">
                      {({ field }) => (
                        <DatePicker
                          placeholder="MM/DD/YYYY"
                          disabledDate={(date) =>
                            !date ||
                            date.isBefore(moment(), "day") ||
                            startDateValidation(date, values.endDate)
                          }
                          {...field}
                          onChange={(_e, date) => {
                            if (!date) setFieldValue("endDate", "");
                            setFieldValue("startDate", date);
                          }}
                          value={
                            values.startDate
                              ? moment(values.startDate, "MM/DD/YYYY")
                              : ""
                          }
                          disabled={
                            ndcData &&
                            ndcData.listId &&
                            values.startDate &&
                            moment(values.startDate).isBefore(
                              moment(),
                              "day"
                            ) &&
                            !ndcData.isCopy
                          }
                        />
                      )}
                    </Field>
                    {errors.startDate && touched.startDate && (
                      <BasicTypography color="error" variant="caption">
                        {errors.startDate}
                      </BasicTypography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4} md={2}>
                    <FormLabel>List Effective End Date</FormLabel>
                    <Field name="endDate">
                      {({ field }) => (
                        <DatePicker
                          placeholder="MM/DD/YYYY"
                          disabledDate={(date) =>
                            endDateValidation(date, values.startDate)
                          }
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("endDate", date);
                          }}
                          value={
                            values.endDate
                              ? moment(values.endDate, "MM/DD/YYYY")
                              : ""
                          }
                        />
                      )}
                    </Field>
                  </Grid>
                </Grid>
                <Grid container spacing={2} justifyContent="flex-end">
                  <Grid item>
                    <Button
                      type="submit"
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                    >
                      Save And Continue
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="contained"
                      className={globalClasses.grayButton}
                      onClick={() => handleConfigPopup({ state: false })}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        );
      }}
    </Formik>
  );
};

export default NdcListBasicDetails;
