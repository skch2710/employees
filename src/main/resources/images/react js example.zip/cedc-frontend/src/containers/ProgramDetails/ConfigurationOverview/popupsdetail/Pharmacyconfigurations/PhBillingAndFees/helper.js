export const getDefaultFormValues = () => ({
  feesType: 0,
  adminFee: "",
  startDate: "",
  endDate: "",
  claimType: 0,
  addClaimType: 0,
  adminFeePercentage: "",
  switch: 0,
  basisOf: 0,
});

export const getAddEditDispensingFeeDefaultFormValues = (prevValues = {}) => {
  return {
    ...(prevValues.dispensingAddedFeesId
      ? { dispensingFeeId: Number(prevValues.dispensingAddedFeesId) }
      : {}),
    dispensingFeeType: prevValues.dispensingFeeTypeId || 0,
    formularyType: prevValues.formularyTypeId || 0,
    isVaryFees: prevValues.isVaryingFlatFeeFlag || false,
    drugType: prevValues.brandGenericIdNew || 0,
    ceReimbursementModel: prevValues.ceReimbursementModelId || 0,
    dispenseFeeCalc: prevValues.dispensingFeeCalculationId || 0,
    percentage: prevValues.eacPercent || "",
    appliedAcType: prevValues.eacTypeId || 0,
    bin: prevValues.bin || "",
    pcn: prevValues.pcn || "",
    group: prevValues.group || "",
    dispensingFeePercentage: prevValues.dispensingFeePercentageOfEac || "",
    flatDispensingFee: prevValues.flatDispensingFee || "",
    startDate: prevValues.startDate || "",
    expDate: prevValues.expirationDate || "",
    accessBy: prevValues.feeAccessTypeId
      ? String(prevValues.feeAccessTypeId)
      : "",
  };
};

export const getEditAdminFeeDefaultFormValues = (rowData = {}) => ({
  feesType: rowData.adminFeeTypeNewId,
  adminFee:
    rowData.adminFeeTypeNewId !== 4
      ? rowData.flatFee
        ? rowData.flatFee.slice(1)
        : rowData.percentage && rowData.percentage.slice(0, -1)
      : "",
  startDate: rowData.feeStartDate ? rowData.feeStartDate : "",
  endDate: rowData.feeEndDate ? rowData.feeEndDate : "",
  claimType: rowData.adminFeeClaimTypeId ? rowData.adminFeeClaimTypeId : 0,
  addClaimType: rowData.adminFeeAddlClaim_typeId
    ? rowData.adminFeeAddlClaim_typeId
    : 0,
  adminFeePercentage: rowData.percentage ? rowData.percentage.slice(0, -1) : "",
  switch: rowData.adminFeeSwitchTypeId ? rowData.adminFeeSwitchTypeId : 0,
  basisOf: rowData.adminFeePercentageBasisId
    ? rowData.adminFeePercentageBasisId
    : 0,
  clientAdminFeeNewId: rowData.id,
  isEdit: rowData.isEdit || false,
  feeTypeLabel: rowData.feeType || "",
});

export const getAdminFeeSavePayload = (values) => ({
  clientId: values.clientId || 0,
  adminFeeTypeNewId: Number(values.feesType),
  adminFeeClaimTypeId: Number(values.claimType),
  adminFeeAddlClaimTypeId: Number(values.addClaimType),
  adminFeeSwitchTypeId: Number(values.switch),
  adminFee: values.adminFee || "",
  adminFeePercentage: values.adminFeePercentage || "",
  adminFeeStartDate: values.startDate,
  adminFeeEndDate: values.endDate,
  adminFeePercentageBasisId:
    values.feesType === "4" || values.feesType === "5" ? 1 : values.basisOf,
  ...(values.clientAdminFeeNewId
    ? {
        clientAdminFeeNewId: values.clientAdminFeeNewId,
      }
    : {}),
  isCustomized: values.isEdit || false,
});

export const createDispensingFeePayload = (values = {}) => ({
  clientId: values.clientId,
  ...(values.dispensingFeeId
    ? { dispensingFeeId: Number(values.dispensingFeeId) }
    : {}),
  ...(values.drugType ? { drugTypeId: Number(values.drugType) } : {}),
  ...(values.previousDispensingFeeId
    ? { previousDispensingFeeList: values.previousDispensingFeeId }
    : {}),
  formularyTypeId: Number(values.formularyType),
  dispensingFeeTypeId: Number(values.dispensingFeeType),
  percentage: values.percentage ? Number(values.percentage) : "",
  ceReimbursementModelId: values.ceReimbursementModel,
  dispensingFeeCalculationId: values.dispenseFeeCalc,
  appliedAcType: values.appliedAcType,
  feeAccessTypeId: values.accessBy,
  bin: values.bin,
  pcn: values.pcn,
  groupNumber: values.group,
  percentDispensingFee: values.dispensingFeePercentage,
  flatDispensingFee: values.flatDispensingFee,
  startDate: values.startDate,
  expirationDate: values.expDate,
  varyingFeesByIndicator: values.isVaryFees,
  createdById: values.createdBy || 1,
  modifiedById: values.modifiedBy || 1,
});

export const getAdminFeesFiltersObject = (filters) => {
  const dateFields = ["feeStartDate", "feeEndDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getDispensingFeesFiltersObject = (filters) => {
  const DATE_FIELDS = ["startDate", "expirationDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: DATE_FIELDS.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};
