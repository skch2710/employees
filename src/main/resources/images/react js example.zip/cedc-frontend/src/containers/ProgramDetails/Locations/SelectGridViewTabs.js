import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useLocationStyles } from "./styles";
import ToggleButton from "@material-ui/lab/ToggleButton";
import ToggleButtonGroup from "@material-ui/lab/ToggleButtonGroup";
import { Badge } from "@material-ui/core";
import { updateLocationStatus } from "../../../context/actions/Locations";
import { pagination } from "../../../utils/constants";
import {
  ALL,
  NEW,
  OPPORTUNITY_ADDRESS,
  PARTICIPATING,
  TERMINATED,
} from "./constants";

const SelectGridViewTabs = ({
  ceSelected,
  tabSelected,
  setTabSelected,
  newLocationsCount,
  setNewLocationsCount,
  setControllers,
  setColumnFilters,
  fetchLocations,
  formSubmittedValues,
  fetchNewLocationsCount,
}) => {
  const classes = useLocationStyles();
  const dispatch = useDispatch();

  const handleChange = (_event, tab) => {
    if (tab) {
      setColumnFilters([]);
      setTabSelected(tab);
      fetchLocations(
        {
          locationStatus: tab === ALL ? "" : tab,
          pageNo: pagination.page,
          filter: [],
        },
        (resp) => setControllers((prev) => ({ ...prev, pageNo: resp.pageNo }))
      );
      if (tab === NEW && newLocationsCount > 0) {
        const payload = {
          isNewStatus: "N",
          ceId: [ceSelected.ceID],
          entityLocationId: formSubmittedValues.locations.map(
            (a) => a.entityLocationId
          ),
          site340B: formSubmittedValues.site340B,
          startDate: formSubmittedValues.startDate,
          endDate: formSubmittedValues.endDate,
          locationHrsaId: formSubmittedValues.locationHRSAID,
          city: formSubmittedValues.city,
          stateId: formSubmittedValues.state || 0,
        };
        dispatch(
          updateLocationStatus(payload, (res) => {
            if (res.statusCode === 200) {
              fetchNewLocationsCount(ceSelected.ceID);
            }
          })
        );
      }
    }
  };

  return (
    <ToggleButtonGroup
      size="small"
      value={tabSelected}
      exclusive
      onChange={handleChange}
      className={classes.ToggleButtonGroup}
    >
      <ToggleButton className={classes.ToggleButton} value={ALL}>
        All
      </ToggleButton>

      {/* <ToggleButton className={classes.ToggleButton} value={NEW}>
        <Badge badgeContent={newLocationsCount} color="primary">
          New
        </Badge>
      </ToggleButton> */}

      <ToggleButton className={classes.ToggleButton} value={PARTICIPATING}>
        Participating
      </ToggleButton>
      <ToggleButton className={classes.ToggleButton} value={TERMINATED}>
        Terminated
      </ToggleButton>
      {/* required in Future */}
      {/* <ToggleButton
        className={classes.ToggleButton}
        value={OPPORTUNITY_ADDRESS}
      >
        Opportunity Address
      </ToggleButton> */}
    </ToggleButtonGroup>
  );
};

export default SelectGridViewTabs;
