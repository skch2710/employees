import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const useCoFiltersStyles = makeStyles((_theme) => {
  return {
    filterHeader: {
      display: "flex",
      justifyContent: "space-between",
    },
    actionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
      gap: "18px",
      paddingTop: "20px",
    },
  };
});

export const useAddCEStyles = makeStyles((_theme) => ({
  root: {
    flexGrow: 1,
    display: "flex",
    maxHeight: 380,
    "& .MuiTab-wrapper": {
      alignItems: "flex-start",
      textTransform: "initial",
    },
    "& .MuiTabs-vertical": {
      minWidth: "50vh !important",
    },
    "& .MuiTab-textColorInherit.Mui-selected": {
      textDecoration: "underline",
    },
    "& .MuiFormControlLabel-root": {
      marginLeft: "8px",
    },
  },
  content: {
    paddingTop: "10px",
  },
  dialogPaper: {
    height: "85vh",
  },
}));

export const coScreenStyles = makeStyles((_theme) => ({
  exportButtonsWrapper: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 10,
  },
  configGlobalActionBtnContainer: {
    display: "flex",
    alignItems: "center",
  },
  actionButtons: {
    display: "flex",
    justifyContent: "flex-end",
    paddingTop: "24px",
    gap: "16px",
  },
}));

export const useLocationTableStyles = makeStyles((_theme) => {
  return {
    enableFilterButton: (props) => {
      return {
        marginRight: getGridActionButtonsMarginRight(props),
        marginTop: "-38px",
        marginBottom: "6px",
        paddingLeft: "6px",
        minHeight: "30px",
      };
    },
  };
});
