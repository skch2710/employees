import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { useHistory } from "react-router-dom";
import { Button, Grid } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import { Element, scroller } from "react-scroll";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import _debounce from "lodash/debounce";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import PharmaciesSearchForm from "./PharmaciesSearchForm";
import excel from "../../../assets/excel.png";
import PharmaciesTable from "./PharmaciesTable";
import { defaultPhSearchPayload, resetReduxSummaryStates } from "./helper";
import {
  fetchPharmaciesTableData,
  exportPharmacyConfigDataToPdf,
} from "../../../context/actions/Pharmacies";
import PhBasicDetails from "./PhBasicDetails";
import useQuery from "../../../utils/useQuery";
import { TiExport } from "react-icons/ti";
import { usePhStyles } from "./styles";
import PhBillingAndFees from "./PhBillingAndFees";
import EligibilityAndOrdering from "./EligibilityAndOrdering";
import { COContext } from "../COContext";
import { getUserSession } from "../../../utils/helper";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { ALL_CE_OPTION } from "../../../utils/constants";
import { SET_PHARMACIES_LIST } from "../../../context/reducers/Pharmacies/constants";

const Pharmacies = memo((props = {}) => {
  const { isFromMainModule = true, coSearchPayload, ceId } = props;
  const dispatch = useDispatch();
  const classes = usePhStyles();
  const history = useHistory();
  const userSession = getUserSession();
  const globalClasses = useGlobalStyles();
  const { ceList = [] } = useSelector((state) => state.coveredEntities) || {};
  const { openAddCePopup, setPhGridPayload } = useContext(COContext);

  const [formSubmittedValues, setFormSubmittedValues] = useState({
    ceId: ALL_CE_OPTION,
  });
  const [selectedPharmacy, setSelectedPharmacy] = useState({});
  const [isAllCollapsed, setIsAllCollapsed] = useState(true);
  const { ceId: searchParamCeId } = useQuery();
  const actionRef = useRef(null);

  const getPharmaciesTableData = async (payload = {}, callback) => {
    setSelectedPharmacy({});
    const gridPayload = defaultPhSearchPayload({ ...payload, ceList });
    setPhGridPayload(gridPayload);
    const tableData = await dispatch(fetchPharmaciesTableData(gridPayload));
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  useEffect(() => {
    return () => {
      dispatch({ type: SET_PHARMACIES_LIST, data: {} });
    };
  }, []);

  useEffect(() => {
    if (ceList.length && !openAddCePopup && isFromMainModule) {
      getPharmaciesTableData({
        ceId: searchParamCeId ? [{ ceID: Number(searchParamCeId) }] : ceList,
      });
      if (!userSession.isInternalUser) {
        setFormSubmittedValues({ ceId: ceList });
      }
      if (searchParamCeId) {
        setFormSubmittedValues({ ceId: [{ ceID: Number(searchParamCeId) }] });
      }
    }
  }, [ceList]);

  useEffect(() => {
    if (!isFromMainModule) {
      const { phGroupId, pharmacy } = coSearchPayload || {};
      const payload = {
        ceId: [{ ceID: ceId }],
        phGroupId,
        pharmacy,
      };
      getPharmaciesTableData(payload);
      setFormSubmittedValues(payload);
    }
  }, [coSearchPayload, ceId]);

  const handleSubmit = (values) => {
    getPharmaciesTableData(values, (resp) => {
      actionRef.current && actionRef.current.submitForm(resp);
    });
    setFormSubmittedValues(values);
  };

  const handleClear = (values) => {
    setFormSubmittedValues(values);
    searchParamCeId && history.push(history.location.pathname);
    actionRef.current && actionRef.current.clearForm(values);
  };

  const handleCompletedPharmacyClick = useCallback(
    _debounce((pharmacy = {}) => {
      scroller.scrollTo("phSummary", {
        smooth: true,
        offset: -60,
      });
      setSelectedPharmacy((prev) => {
        if (prev.clientId !== pharmacy.clientId)
          resetReduxSummaryStates(dispatch);
        return pharmacy;
      });
    }, 100),
    []
  );

  const handlePharmacyConfigExport = ({ clientId = "", phid = "" } = {}) => {
    const isInternalUser = userSession.isInternalUser ? "true" : "false";
    dispatch(exportPharmacyConfigDataToPdf(clientId, phid, isInternalUser));
  };

  return (
    <Grid container spacing={2}>
      {isFromMainModule && (
        <>
          <Grid item md={12}>
            <BasicTypography
              variant="h1"
              title="Program Details - Pharmacies"
            />
          </Grid>
          <Grid item md={12}>
            <PharmaciesSearchForm
              handleSubmit={handleSubmit}
              handleClear={handleClear}
              ceList={ceList}
            />
          </Grid>
          <Grid item md={12} className="Download_template">
            <img src={excel} alt="download-template" /> Download Template
          </Grid>
        </>
      )}
      <Grid item md={12}>
        <PharmaciesTable
          getPharmaciesTableData={getPharmaciesTableData}
          formSubmittedValues={formSubmittedValues}
          ref={actionRef}
          ceList={ceList}
          handleCompletedPharmacyClick={handleCompletedPharmacyClick}
        />
      </Grid>
      <Grid item md={12}>
        <Element name="phSummary">
          {!_isEmpty(selectedPharmacy) && (
            <Grid
              container
              spacing={2}
              className={classes.configurationWrapper}
            >
              <Grid item md={12}>
                <Grid container justifyContent="space-between" spacing={2}>
                  <Grid item md={6} sm={12}>
                    <BasicTypography variant="h2">
                      {`${
                        selectedPharmacy.pharmacyName || "Pharmacy Name"
                      } - Configuration Overview`}
                    </BasicTypography>
                  </Grid>
                  <Grid
                    item
                    md={6}
                    sm={12}
                    className={classes.configGlobalActionBtnContainer}
                  >
                    <Button
                      startIcon={<TiExport />}
                      variant="outlined"
                      size="small"
                      component="button"
                      className={globalClasses.grayButton}
                      onClick={() =>
                        handlePharmacyConfigExport(selectedPharmacy)
                      }
                    >
                      Export Pharmacy Config
                    </Button>
                    <Button
                      variant="outlined"
                      size="small"
                      component="button"
                      className="text-capitalize"
                      onClick={() => setIsAllCollapsed(true)}
                    >
                      Expand All
                    </Button>
                    <Button
                      variant="outlined"
                      size="small"
                      component="button"
                      className="text-capitalize"
                      onClick={() => setIsAllCollapsed(false)}
                    >
                      Collapse All
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <PhBasicDetails
                  selectedPharmacy={selectedPharmacy}
                  isAllCollapsed={isAllCollapsed}
                />
              </Grid>
              <Grid item md={12}>
                <PhBillingAndFees
                  selectedPharmacy={selectedPharmacy}
                  isAllCollapsed={isAllCollapsed}
                />
              </Grid>
              <Grid item md={12}>
                <EligibilityAndOrdering
                  selectedPharmacy={selectedPharmacy}
                  isAllCollapsed={isAllCollapsed}
                />
              </Grid>
            </Grid>
          )}
        </Element>
      </Grid>
    </Grid>
  );
});

export default Pharmacies;
