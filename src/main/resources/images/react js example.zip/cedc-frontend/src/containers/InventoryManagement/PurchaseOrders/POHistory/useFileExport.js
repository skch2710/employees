import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { getPOHistoryExport } from "../../../../context/actions/PurchaseOrders";
import { notNull } from "../../../../utils/constants";
import { PO_HISTORY_EXPORT_FILE_NAME } from "../constants";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { poID, poItemID, controller, columnFilters } = props;
    dispatch(
      getPOHistoryExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          poItemID: poItemID,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              poDate,
              poStatus,
              reasonDesc,
              poStatusDate,
              invoiceNumber,
              edi855FileCount,
              edi810FileCount,
              createdDate,
              createdByID,
            }) => ({
              "PO Date": notNull(poDate),
              "PO Status": notNull(poStatus),
              Reason: notNull(reasonDesc),
              "PO Status Date": notNull(poStatusDate),
              "810 Invoice Number": notNull(invoiceNumber),
              "EDI 855 File Count": notNull(edi855FileCount),
              "EDI 810 File Count": notNull(edi810FileCount),
              "Created Date": notNull(createdDate),
              "Created By": notNull(createdByID),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, PO_HISTORY_EXPORT_FILE_NAME + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
