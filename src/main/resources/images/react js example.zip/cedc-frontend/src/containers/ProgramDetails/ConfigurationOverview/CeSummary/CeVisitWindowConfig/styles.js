import { makeStyles } from "@material-ui/core";

export const useCeVisitWindowConfigStyle = makeStyles((_theme) => {
  return {};
});
