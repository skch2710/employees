import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../Styles/useGlobalStyles";
import { isEmptyGrid } from "../../../../../utils/helper";
import { pagination } from "../../../../../utils/constants";
import DataNotFound from "../../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../../components/common/DatePicker";
import moment from "moment";
import { getZeroValueInTotalElements } from "../../../../../utils/common";
import {
  exportNdcDraftExclusionList,
  getDraftExclusionList,
} from "../../../../../context/actions/NdcExclusions";
import { TiFilter } from "react-icons/ti";
import { getDraftExclusionListFiltersObject } from "../NdcListSelection/helper";
import Pagination from "../../../../../components/common/Pagination";

const NdcDraftExclusionTable = ({ historyObj }) => {
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const theme = useTheme();
  const dispatch = useDispatch();

  const [enableColumnFilters, setEnableColumnFilters] = useState(false);
  const [draftExclusionControllers, setDraftExclusionControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
    listId: historyObj.listId,
    listHistoryId: historyObj.listHistoryId,
  });
  const [columnFilters, setColumnFilters] = useState([]);

  const { loading, records: draftExclusionGridData = {} } =
    useSelector((state) => state.draftExclusionListData) || {};

  const DRAFT_EXCLUSION_COLUMNS = [
    {
      title: "GCN",
      field: "gcn",
      defaultFilter: enableColumnFilters && columnFiltersRef.current.gcn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.gcn}>
            <span>{rowData.gcn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.gcn}
          placeholder="GCN"
        />
      ),
    },
    {
      title: "NDC",
      field: "ndc",
      defaultFilter: enableColumnFilters && columnFiltersRef.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ndc}
          placeholder="NDC"
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: enableColumnFilters && columnFiltersRef.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugName}
          placeholder="Drug Name"
        />
      ),
    },
    {
      title: "Manufacturer",
      field: "drugManufacturer",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.drugManufacturer,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugManufacturer}>
            <span>{rowData.drugManufacturer}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugManufacturer}
          placeholder="Manufacturer"
        />
      ),
    },
    {
      title: "NDC Effective Start Date",
      field: "ndcEffectiveStartDate",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.ndcEffectiveStartDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcEffectiveStartDate}>
            <span>{rowData.ndcEffectiveStartDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.ndcEffectiveStartDate
                ? moment(columnFiltersRef.current.ndcEffectiveStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "NDC Effective End Date",
      field: "ndcEffectiveEndDate",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.ndcEffectiveEndDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcEffectiveEndDate}>
            <span>{rowData.ndcEffectiveEndDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.ndcEffectiveEndDate
                ? moment(columnFiltersRef.current.ndcEffectiveEndDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const TABLE_ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableColumnFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(draftExclusionGridData),
      onClick: () => {
        setEnableColumnFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportToExcel(),
      disabled: isEmptyGrid(draftExclusionGridData),
      isFreeAction: true,
      onClick: () => {
        dispatch(
          exportNdcDraftExclusionList({
            listId: historyObj.listId,
            listHistoryId: historyObj.listHistoryId,
            pageNumber: pagination.page,
            pageSize: pagination.limit,
            sortBy: draftExclusionControllers.sortBy || "",
            sortOrder: draftExclusionControllers.sortOrder || "",
            filter: columnFilters,
            listId: historyObj.listId,
            listHistoryId: historyObj.listHistoryId,
            export: true,
            downloadFlag: true,
          })
        );
      },
    },
  ];

  useEffect(() => {
    fetchDraftExclusionList({
      listId: historyObj.listId,
      listHistoryId: historyObj.listHistoryId,
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "",
      sortBy: "",
      filter: [],
    });
    tableRef.current.dataManager.changePageSize(pagination.limit);
    setDraftExclusionControllers({
      listId: historyObj.listId,
      listHistoryId: historyObj.listHistoryId,
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "",
      sortBy: "",
    });
    setColumnFilters([]);
    setEnableColumnFilters(false);
  }, [historyObj]);

  const fetchDraftExclusionList = (payload = {}) => {
    const json = {
      filter: columnFilters,
      ...draftExclusionControllers,
      ...payload,
    };
    dispatch(getDraftExclusionList(json));
  };

  const onChangePagination = (newPage, pageSize) => {
    let currentPage = newPage + 1;
    let obj = {};
    const rowsPerPage = Number(pageSize);
    const totalPages =
      Math.ceil(draftExclusionGridData.totalElements / rowsPerPage) || 1;
    if (draftExclusionControllers.pageNumber > totalPages)
      currentPage = totalPages;
    else if (
      newPage === 0 &&
      rowsPerPage !== draftExclusionControllers.pageSize
    )
      currentPage = draftExclusionControllers.pageNumber;
    obj.pageNumber = currentPage;
    setDraftExclusionControllers((prev) => ({
      ...prev,
      pageNumber: currentPage,
      pageSize: rowsPerPage,
    }));
    obj.pageSize = rowsPerPage;
    fetchDraftExclusionList(obj);
  };

  const handleSort = async (orderedColumnId) => {
    const sortOrder =
      draftExclusionControllers.sortOrder === "asc" ? "desc" : "asc";
    const sortBy = DRAFT_EXCLUSION_COLUMNS[orderedColumnId].field;
    setDraftExclusionControllers((prev) => ({ ...prev, sortOrder, sortBy }));
    fetchDraftExclusionList({
      sortBy,
      sortOrder,
    });
  };

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getDraftExclusionListFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchDraftExclusionList({
      filter: filterPayload,
      pageNumber: pagination.page,
    });
  };

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`NDC - Draft Exclusion List (${getZeroValueInTotalElements(
              draftExclusionGridData
            )})`}
          />
        }
        tableRef={tableRef}
        columns={DRAFT_EXCLUSION_COLUMNS}
        data={(draftExclusionGridData && draftExclusionGridData.content) || []}
        page={draftExclusionControllers.pageNumber - 1}
        totalCount={draftExclusionGridData.totalElements}
        onChangePage={onChangePagination}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        icons={{
          SortArrow: () => TableCustomSortArrow(draftExclusionControllers),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={TABLE_ACTIONS}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => <MTableToolbar {...props} />,
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
          },
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableColumnFilters,
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          pageSize: draftExclusionControllers.pageSize,
          pageSizeOptions: isEmptyGrid(draftExclusionGridData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default NdcDraftExclusionTable;
