import React, { useContext, useEffect, useState } from "react";
import { Grid, Tab, Tabs } from "@material-ui/core";
import { a11yProps, TabPanel } from "../../../../components/common/Tabs";
import { ADDRESS_TABS } from "../constants";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import _isEmpty from "lodash/isEmpty";
import { AddressDrillDownStyles } from "../styles";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import ProviderAssociation from "./ProviderAssociation";
import LocationHistory from "./LocationHistory";
import AddressVariations from "./AddressVariations";

const AddressDrillDown = (props) => {
  const { activeTab, setActiveTab, locationData = {} } = props;

  const globalClasses = useGlobalStyles();
  const classes = AddressDrillDownStyles();
  const handleChangeTab = (_e, newValue) => {
    setActiveTab(newValue);
  };

  return (
    <Grid container spacing={2} direction="column">
      <Grid item>
        <Tabs
          value={activeTab}
          onChange={handleChangeTab}
          indicatorColor="primary"
          classes={{
            indicator: classes.tabsIndicator,
            flexContainer: classes.tabsContainer,
          }}
        >
          <Tab
            label="Address Variations"
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            {...a11yProps(0)}
          />
          <Tab
            label="Provider Associations"
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            {...a11yProps(1)}
          />
          <Tab
            label="Location History"
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            {...a11yProps(2)}
          />
        </Tabs>
      </Grid>
      <Grid item>
        <Grid
          container
          direction="column"
          spacing={2}
          className={classes.headerContainer}
        >
          <Grid item>
            <BasicTypography variant="h3" className={classes.selectedTab}>
              Standardized Location
            </BasicTypography>
          </Grid>
          <Grid item>
            <BasicTypography
              variant="h4"
              className={classes.locationName}
            >{`${locationData.locationName} , ${locationData.locationHrsaId}`}</BasicTypography>
            <BasicTypography
              variant="h5"
              className={classes.locationAddress}
            >{`${locationData.addressLine1} , ${locationData.addressLine2}`}</BasicTypography>
            <BasicTypography
              variant="h5"
              className={classes.locationAddress}
            >{`${locationData.city} , ${locationData.state}, ${locationData.zip}`}</BasicTypography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md>
        <div className={classes.tabPanelContainer}>
          <TabPanel
            value={activeTab}
            index={ADDRESS_TABS.ADDRESS_VARIATIONS}
            className={globalClasses.fullHeight}
          >
            <AddressVariations locationData={locationData} />
          </TabPanel>
          <TabPanel
            value={activeTab}
            index={ADDRESS_TABS.PROVIDER_ASSOCIATIONS}
            className={globalClasses.fullHeight}
          >
            <ProviderAssociation locationData={locationData}/>
          </TabPanel>
          <TabPanel
            value={activeTab}
            index={ADDRESS_TABS.LOCATION_HISTORY}
            className={globalClasses.fullHeight}
          >
            <LocationHistory locationData={locationData} />
          </TabPanel>
        </div>
      </Grid>
    </Grid>
  );
};

export default AddressDrillDown;
