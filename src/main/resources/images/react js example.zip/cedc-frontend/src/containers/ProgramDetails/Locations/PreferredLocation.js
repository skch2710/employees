import React, { useEffect, useState, useRef } from "react";
import { Formik, Form, Field } from "formik";
import { useHistory } from "react-router-dom";
import {
  Button,
  Grid,
  IconButton,
  FormLabel,
  Typography,
} from "@material-ui/core";
import { IoIosCloseCircleOutline } from "react-icons/io";
import DatePicker from "../../../components/common/DatePicker";
import { useDispatch, useSelector } from "react-redux";
import { pagination, setAutoCompleteInputVal } from "../../../utils/constants";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import excel from "../../../assets/excel.png";
import { getPreferredLocationDefaultValue, statusArray } from "../../../utils/constants";
import {
  endDateValidation,
  getUserPreveleges,
  startDateValidation,
} from "../../../utils/common";
import {
  getLocationList,
  getLocationsGridData,
  getNewLocationsCount,
  getHRSAID,
} from "../../../context/actions/Locations";
import { getAllCoveredEntities } from "../../../context/actions/Common";
import { userdata } from "../../../utils/common";
import LocationsListTable from "./LocationsListTable";
import moment from "moment";
import AutoComplete from "../../../components/common/AutoComplete";
import { getstates } from "../../../context/actions/CoCebasicdetails";
import Tooltip from "@mui/material/Tooltip";
import _isEmpty from "lodash/isEmpty";
import _get from "lodash/get";
import _debounce from "lodash/debounce";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import useQuery from "../../../utils/useQuery";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { getCoveredEntity } from "../../../utils/helper";
import classNames from "classnames";
import MultiSelectDropdown from "../../../components/common/MultiSelectDropdown";
import SelectGridViewTabs from "./SelectGridViewTabs";
import _isArray from "lodash/isArray";
import {
  ALL,
  NEW,
  OPPORTUNITY_ADDRESS,
  PARTICIPATING,
  TERMINATED,
} from "./constants";
import { SET_LOCATIONS_LIST } from "../../../context/reducers/Locations/constants";

const PreferredLocation = ({ Co = false, messageUuid, clickOnAdd }) => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const { ceId: searchParamCeId } = useQuery();
  const userRole = JSON.parse(userdata());
  const history = useHistory();
  const [ceList, setCeList] = useState([userRole.coveredEntityDTOs[0]]);
  const [clearButton, setclearButton] = useState(false);

  const initialValues = {
    ...getPreferredLocationDefaultValue(),
    ceid: !searchParamCeId
      ? ceList.length > 0 && ceList[0].ceID
      : Number(searchParamCeId),
  };

  const site340BOptions = [
    { label: "Yes", value: "true" },
    { label: "No", value: "false" },
  ];

  const formikRef = useRef(null);
  const actionRef = useRef({});
  const [open, setOpen] = useState(true);
  const [controllers, setControllers] = useState({
    pageNo: pagination.page,
    pageSize: pagination.limit,
    sortBy: "locationName",
    sortOrder: "asc",
  });
  const [openPopup, setOpenPopup] = useState(false);
  const [actiontitle, setActionTitle] = useState("");
  const [submitactiontype, setSubmitActionType] = useState("");
  const [permissionsObj, setpermissionsObj] = useState(null);
  const [formSubmittedValues, setFormSubmittedValues] = useState(initialValues);
  const [columnFilters, setColumnFilters] = useState([]);
  const [ceSelected, setCeSelected] = useState(
    Co
      ? { ...messageUuid, ceID: messageUuid.ceid, ceCode: messageUuid.hrsaId }
      : userRole.coveredEntityDTOs[0]
  );
  const [urlCeId, setUrlCeId] = useState(searchParamCeId);
  const [tabSelected, setTabSelected] = useState(ALL);
  const [newLocationsCount, setNewLocationsCount] = useState(0);
  const [hrsaIDLoading, setHRSAIDLoading] = useState(false);
  const [hrsaIDList, setHrsaIDList] = useState([]);
  const [defaultValues, setDefaultValues] = useState(initialValues);

  const locationsList =
    useSelector((state) => state.getLocationListValues.records) || [];
  const stateList = useSelector((state) => state.ce_states_list.records) || [];

  useEffect(async () => {
    dispatch(getstates());
    const ceId = !_isEmpty(formSubmittedValues)
      ? formSubmittedValues.ceid
      : defaultValues.ceid;
    let locations = [];
    setpermissionsObj(getUserPreveleges("Covered Entity Locations"));
    if (!Co) {
      if (userRole.isInternalUser) {
        fetchCoveredEntities();
      } else {
        setCeList(userRole.coveredEntityDTOs);
      }
      fetchNewLocationsCount(ceId);

      const resp = await dispatch(
        getLocationList({
          ceIDs: [ceId],
          locationName: "",
        })
      );
      if (resp) {
        locations = _isArray(resp) ? resp : [];
      }
    }
    fetchLocations(!Co && { ceid: ceId, locations: locations });
    setFormSubmittedValues((prev) => ({
      ...prev,
      ceid: ceId,
      locations: locations,
    }));
    setDefaultValues((prev) => ({ ...prev, locations: locations || [] }));
  }, []);

  useEffect(() => {
    return () => {
      dispatch({ type: SET_LOCATIONS_LIST, data: {} });
      dispatch({ type: "locationList", data: [] });
    };
  }, []);

  const handleCeDropdown = async (newValue) => {
    const value = newValue ? Number(newValue) : 0;
    const { values } = formikRef.current;
    setUrlCeId("");
    setCeSelected(value ? ceList.find((itm) => itm.ceID === value) : {});
    const resp = await dispatch(
      getLocationList({ ceIDs: [value], locationName: "" })
    );
    setHrsaIDList([]);
    setDefaultValues((prev) => ({
      ...prev,
      ...values,
      ceid: value,
      locationHRSAID: "",
      locations: resp || [],
    }));
  };

  const handleChangeHRSAID = _debounce(async (value) => {
    setHRSAIDLoading(true);
    const res = await dispatch(
      getHRSAID({ ceid: [ceSelected.ceID], locationHrsaId: value })
    );
    if (res.length >= 1) setHrsaIDList(res);
    else setHrsaIDList([]);
    setHRSAIDLoading(false);
  }, 500);

  const fetchCoveredEntities = async () => {
    const ces = await dispatch(getAllCoveredEntities());
    setCeList(ces || []);
  };

  const fetchNewLocationsCount = (ceId) => {
    dispatch(
      getNewLocationsCount(ceId, (res) => {
        if (res.statusCode === 200) {
          setNewLocationsCount(res.data.count);
        }
      })
    );
  };

  const locationsGridDataPayload = (values) => {
    return {
      ceid: !Co
        ? [values.ceid]
        : messageUuid && messageUuid.ceid !== null && [messageUuid.ceid],
      endDate: values.endDate || "",
      entityLocationId: values.locations.map((a) => a.entityLocationId) || [],
      pageNumber: values.pageNo || pagination.page,
      pageSize: values.pageSize || pagination.limit,
      sortBy: values.sortBy || "locationName",
      sortOrder: values.sortOrder || "asc",
      startDate: values.startDate || "",
      site340B: values.site340B || "",
      filter: values.filter || [],
      locationHrsaId: values.locationHRSAID || "",
      city: values.city || "",
      stateId: values.state || 0,
      locationStatus:
        formSubmittedValues && formSubmittedValues.ceid != values.ceid
          ? ""
          : values.locationStatus,
      parentId: 0,
      status: values.status || ""
    };
  };

  const handleSubmit = (values) => {
    setclearButton(false)
    let payload = locationsGridDataPayload({
      ...values,
      locationStatus: getSelectedTabPayload(),
      pageNo: pagination.page,
      pageSize: pagination.limit,
      sortBy: "locationName",
      sortOrder: "asc",
      filter: [],
    });
    dispatch(
      getLocationsGridData(payload, (resp) => {
        actionRef.current && actionRef.current.submitForm(resp);
      })
    );
    if (formSubmittedValues && formSubmittedValues.ceid != values.ceid) {
      fetchNewLocationsCount(values.ceid);
      setTabSelected(ALL);
    }
    setFormSubmittedValues((prev) => ({ ...prev, ...values }));
    setDefaultValues((prev) => ({ ...prev, ...values }));
  };

  const fetchLocations = async (values = {}, callback) => {
    const newValues = {
      ...controllers,
      filter: columnFilters,
      ...formSubmittedValues,
      locationStatus: getSelectedTabPayload(),
      ...values,
    };
    const payload = locationsGridDataPayload(newValues);
    const tableData = await dispatch(getLocationsGridData(payload));
    if (!_isEmpty(tableData)) {
      setFormSubmittedValues((prev) => ({
        ...prev,
        ceid: payload.ceid[0],
        locations: newValues.locations,
      }));
      callback && callback(tableData);
    }
    if (clearButton){
      setDefaultValues((prev) => ({
        ...prev,
        ceid: payload.ceid[0],
      }));
    }
  };

  const openAddLocationPopup = () => {
    if (urlCeId) setCeSelected(getCoveredEntity({ ceId: urlCeId, ceList })[0]);
    setOpenPopup(true);
    setActionTitle("Add Covered Entity Location");
    setSubmitActionType("submit");
  };

  const formValidate = (values) => {
    let errors = {};
    if (!values.ceid) {
      errors.ceid = "Please select the Covered Entity";
    }
    return errors;
  };

  const getSelectedTabPayload = () => {
    if (tabSelected === ALL) return "";
    if (tabSelected === NEW) return "Pending";
    if (tabSelected === PARTICIPATING) return "Participating";
    if (tabSelected === TERMINATED) return "Terminated";
    if (tabSelected === OPPORTUNITY_ADDRESS) return "opportunityAddress";
  };
  const handleClear = async () => {
    setclearButton(true)
    searchParamCeId && history.push(history.location.pathname);
    const ceId = userRole.coveredEntityDTOs[0].ceID;
    const resp = await dispatch(
      getLocationList({
        ceIDs: [ceId],
        locationName: "",
      })
    );
    fetchNewLocationsCount(ceId);
    actionRef.current &&
      actionRef.current.clearForm({
        ...initialValues,
        locations: resp || [],
        locationStatus: "",
        pageNo: pagination.page,
        pageSize: pagination.limit,
        sortBy: "locationName",
        sortOrder: "asc",
        filter: [],
      });

    setFormSubmittedValues((prev) => ({
      ...prev,
      ...initialValues,
      locations: resp || [],
      locationStatus: "",
    }));
    setDefaultValues({
      ...initialValues,
      locations: resp || [],
      locationStatus: "",
    });
    setTabSelected(ALL);
    setCeSelected(userRole.coveredEntityDTOs[0]);
  };
  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      validate={formValidate}
      innerRef={formikRef}
      enableReinitialize={true}
    >
      {({ values, errors, touched, setFieldValue, isSubmitting }) => (
        <>
          <Grid container spacing={2}>
            <Grid item md={12}>
              {!Co && (
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography
                      variant="h1"
                      title="Program Details - Covered Entity Locations"
                    />
                  </Grid>
                  <Grid item md={12}>
                    <Form>
                      {open ? (
                        <div className={globalClasses.cardPrimary}>
                          <Grid item md={12}>
                            <Grid
                              container
                              spacing={2}
                              justifyContent="space-between"
                            >
                              <Grid item>
                                <BasicTypography variant="h4" title="Filters" />
                              </Grid>
                              <Grid item>
                                <IconButton
                                  onClick={() => {
                                    setOpen(false);
                                  }}
                                >
                                  <IoIosCloseCircleOutline />
                                </IconButton>
                              </Grid>
                            </Grid>
                          </Grid>
                          <Grid item md={12}>
                            <Grid container spacing={2}>
                              <Grid item xs={12} sm={4}>
                                <FormLabel required>Covered Entity</FormLabel>
                                <Field
                                  as="select"
                                  name="ceid"
                                  className={globalClasses.formControl}
                                >
                                  {({ field }) => (
                                    <AutoComplete
                                      {...field}
                                      disabled={!userRole.isInternalUser}
                                      options={_isArray(ceList) ? ceList : []}
                                      inputPlaceholder={"Select Covered Entity"}
                                      disableCloseOnSelect={false}
                                      onChange={(e, value) => {
                                        setFieldValue(
                                          "ceid",
                                          value ? value.ceID : ""
                                        );
                                        handleCeDropdown(
                                          value ? value.ceID : ""
                                        );
                                      }}
                                      getOptionLabel={(option) =>
                                        option.ceName || ""
                                      }
                                      value={
                                        (_isArray(ceList) &&
                                          ceList.find(
                                            (e) => e.ceID == values.ceid
                                          )) ||
                                        ""
                                      }
                                      renderOption={(option, _other) => {
                                        return (
                                          <BasicTypography variant="subtitle2">
                                            {option.ceName}
                                          </BasicTypography>
                                        );
                                      }}
                                      multiple={false}
                                      textFieldProps={{
                                        inputProps: {
                                          name: "ceid",
                                        },
                                      }}
                                    />
                                  )}
                                </Field>
                                {touched.ceid && errors.ceid && (
                                  <Typography color="error" variant="caption">
                                    {errors.ceid}
                                  </Typography>
                                )}
                              </Grid>
                              <Grid item xs={12} sm={4}>
                                <FormLabel>Locations</FormLabel>
                                <Field as="select" multiple name="locations">
                                  {({ field }) => (
                                    <MultiSelectDropdown
                                      inputPlaceholder="Select Locations"
                                      options={locationsList || []}
                                      getOptionLabel={(option) =>
                                        `${option.locationName}-${option.locationHrsaId}`
                                      }
                                      {...field}
                                      onChange={(_e, value) => {
                                        setFieldValue("locations", value || []);
                                      }}
                                      getOptionSelected={(option, value) =>
                                        option.entityLocationId ===
                                        value.entityLocationId
                                      }
                                      // inputValue={values.locationsInput || ""}
                                      // onInputChange={(_e, value) =>
                                      //   setAutoCompleteInputVal({
                                      //     value,
                                      //     callback: (newValue) => {
                                      //       setFieldValue(
                                      //         "locationsInput",
                                      //         newValue
                                      //       );
                                      //     },
                                      //   })
                                      // }
                                    />
                                  )}
                                </Field>
                              </Grid>

                              <Grid item xs={12} sm={4}>
                                <FormLabel>Provider Location HRSA ID</FormLabel>
                                <Field as="select" name="locationHRSAID">
                                  {({ field }) => (
                                    <AutoComplete
                                      disabled={!ceSelected.ceID}
                                      loading={hrsaIDLoading}
                                      options={hrsaIDList}
                                      getOptionLabel={(option) =>
                                        option.locationHrsaId || option
                                      }
                                      multiple={false}
                                      disableCloseOnSelect={false}
                                      inputPlaceholder="Enter Provider Location HRSA ID"
                                      onInputChange={(_e, inputValue) => {
                                        handleChangeHRSAID(inputValue);
                                      }}
                                      {...field}
                                      onChange={(_e, value) => {
                                        setFieldValue(
                                          "locationHRSAID",
                                          value && value.locationHrsaId
                                            ? value.locationHrsaId
                                            : ""
                                        );
                                      }}
                                      textFieldProps={{
                                        inputProps: {
                                          name: "locationHRSAID",
                                        },
                                      }}
                                    />
                                  )}
                                </Field>
                              </Grid>

                              <Grid item xs={12} sm={4}>
                                <FormLabel>Participating 340B Site</FormLabel>
                                <Field
                                  as="select"
                                  className={globalClasses.formControl}
                                  name="site340B"
                                >
                                  {({ field }) => (
                                    <AutoComplete
                                      {...field}
                                      disableCloseOnSelect={false}
                                      options={site340BOptions}
                                      inputPlaceholder={
                                        "Select Participating 340B Site"
                                      }
                                      onChange={(e, obj) => {
                                        setFieldValue(
                                          "site340B",
                                          obj ? obj.value : ""
                                        );
                                      }}
                                      value={
                                        site340BOptions.find(
                                          (e) => e.value == values.site340B
                                        ) || ""
                                      }
                                      getOptionLabel={(option) =>
                                        option.label || ""
                                      }
                                      renderOption={(option, _other) => {
                                        return (
                                          <BasicTypography variant="subtitle2">
                                            {option.label}
                                          </BasicTypography>
                                        );
                                      }}
                                      multiple={false}
                                    />
                                  )}
                                </Field>
                              </Grid>

                              <Grid item xs={12} sm={4}>
                                <FormLabel>City</FormLabel>
                                <Field
                                  name="city"
                                  type="text"
                                  className={globalClasses.formControl}
                                  placeholder="Enter City"
                                  maxLength={100}
                                />
                              </Grid>

                              <Grid item xs={12} sm={4}>
                                <FormLabel>State</FormLabel>
                                <Field as="select" name="state">
                                  {({ field }) => (
                                    <AutoComplete
                                      {...field}
                                      options={
                                        _isArray(stateList) ? stateList : []
                                      }
                                      inputPlaceholder={"Select State"}
                                      disableCloseOnSelect={false}
                                      onChange={(e, value) => {
                                        setFieldValue(
                                          "state",
                                          value && value.stateId
                                        );
                                      }}
                                      getOptionLabel={(option) =>
                                        option.stateName || ""
                                      }
                                      value={
                                        stateList.find(
                                          (e) => e.stateId == values.state
                                        ) || ""
                                      }
                                      renderOption={(option, _other) => {
                                        return (
                                          <BasicTypography variant="subtitle2">
                                            {option.stateName}
                                          </BasicTypography>
                                        );
                                      }}
                                      multiple={false}
                                    />
                                  )}
                                </Field>
                              </Grid>

                              <Grid item xs={12} sm={2}>
                                <FormLabel>Location Start Date</FormLabel>
                                <DatePicker
                                  onChange={(e, date) => {
                                    if (!date) setFieldValue("endDate", "");
                                    setFieldValue("startDate", date);
                                  }}
                                  disabledDate={(date) =>
                                    startDateValidation(date, values.endDate)
                                  }
                                  value={
                                    values.startDate !== ""
                                      ? moment(values.startDate)
                                      : ""
                                  }
                                />
                              </Grid>
                              <Grid item xs={12} sm={2}>
                                <FormLabel>Location End Date</FormLabel>
                                <DatePicker
                                  onChange={(e, date) => {
                                    setFieldValue("endDate", date);
                                  }}
                                  disabledDate={(d) =>
                                    endDateValidation(d, values.startDate)
                                  }
                                  value={
                                    values.endDate !== ""
                                      ? moment(values.endDate)
                                      : ""
                                  }
                                />
                              </Grid>

                              <Grid item xs={12} sm={4}>
                                <FormLabel>Status</FormLabel>
                                <Field as="select" name="status">
                                  {({ field }) => (
                                    <AutoComplete
                                      {...field}
                                      options={
                                        _isArray(statusArray) ? statusArray : []
                                      }
                                      inputPlaceholder={"Select Status"}
                                      disableCloseOnSelect={false}
                                      disableClearable={true}
                                      onChange={(e, value) => {
                                        setFieldValue(
                                          "status",
                                          value && value.status
                                        );
                                      }}
                                      getOptionLabel={(option) =>
                                        option.status || ""
                                      }
                                      value={
                                        statusArray.find(
                                          (e) => e.status == values.status
                                        ) || statusArray[0]
                                      }
                                      renderOption={(option, _other) => {
                                        return (
                                          <BasicTypography variant="subtitle2">
                                            {option.status}
                                          </BasicTypography>
                                        );
                                      }}
                                      multiple={false}
                                      textFieldProps={{
                                        inputProps: {
                                          name: "status",
                                        },
                                      }}
                                      
                                    />
                                  )}
                                </Field>
                              </Grid>
                            </Grid>
                          </Grid>
                          <Grid item md={12}>
                            <Grid
                              container
                              justifyContent="flex-end"
                              spacing={2}
                            >
                              <Grid item>
                                <Tooltip
                                  placement="top"
                                  title={
                                    permissionsObj !== null &&
                                    !permissionsObj.readWriteFlag
                                      ? "You don't have Permission."
                                      : !ceSelected
                                      ? "Please select a Covered Entity to enable this button"
                                      : ""
                                  }
                                >
                                  <span>
                                    <Button
                                      startIcon={<AddCircleOutlineIcon />}
                                      variant="outlined"
                                      size="small"
                                      component="button"
                                      className={globalClasses.grayButton}
                                      onClick={openAddLocationPopup}
                                      disabled={
                                        !_isEmpty(ceSelected)
                                          ? permissionsObj !== null &&
                                            !permissionsObj.readWriteFlag
                                          : true
                                      }
                                    >
                                      Add Covered Entity Location
                                    </Button>
                                  </span>
                                </Tooltip>
                              </Grid>
                              <Grid item>
                                <Button
                                  type="submit"
                                  size="small"
                                  variant="contained"
                                  className={globalClasses.primaryBtn}
                                >
                                  Search
                                </Button>
                              </Grid>
                              <Grid item>
                                <Button
                                  type="reset"
                                  size="small"
                                  variant="outlined"
                                  className={globalClasses.secondaryBtn}
                                  onClick={handleClear}
                                >
                                  Clear
                                </Button>
                              </Grid>
                            </Grid>
                          </Grid>
                        </div>
                      ) : (
                        <Button
                          variant="contained"
                          className={globalClasses.primaryBtn}
                          onClick={() => {
                            setOpen(true);
                          }}
                        >
                          Filters
                        </Button>
                      )}
                    </Form>
                  </Grid>
                </Grid>
              )}
            </Grid>
            {!Co && (
              <Grid item md={12}>
                <Grid container justifyContent="space-between">
                  <Grid item md={9}>
                    <Grid container spacing={1} alignItems="center">
                      <Grid item>
                        <BasicTypography variant="h5">
                          Selected View
                        </BasicTypography>
                      </Grid>
                      <Grid item md>
                        <SelectGridViewTabs
                          ceSelected={ceSelected}
                          tabSelected={tabSelected}
                          setTabSelected={setTabSelected}
                          newLocationsCount={newLocationsCount}
                          setNewLocationsCount={setNewLocationsCount}
                          setControllers={setControllers}
                          setColumnFilters={setColumnFilters}
                          fetchLocations={fetchLocations}
                          fetchNewLocationsCount={fetchNewLocationsCount}
                          formSubmittedValues={formSubmittedValues}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={3} container justifyContent="flex-end">
                    <Tooltip
                      title={
                        permissionsObj !== null && !permissionsObj.readWriteFlag
                          ? "You don't have Permission."
                          : ""
                      }
                    >
                      <a
                        href={`/templates/Locations_Template.xlsx`}
                        download="Locations_Template"
                        className={classNames(
                          globalClasses.iconPlusClickableLink,
                          permissionsObj !== null &&
                            permissionsObj.readWriteFlag
                            ? null
                            : globalClasses.disabledDownloadTemp
                        )}
                        disabled={
                          permissionsObj !== null &&
                          permissionsObj.readWriteFlag
                            ? false
                            : true
                        }
                      >
                        <img src={excel} alt="Active" />
                        <span>Download Template</span>
                      </a>
                    </Tooltip>
                  </Grid>
                </Grid>
              </Grid>
            )}
            <Grid item md={12}>
              <LocationsListTable
                ref={actionRef}
                isSubmitting={isSubmitting}
                searchData={formSubmittedValues}
                columnFilters={columnFilters}
                controllers={controllers}
                setControllers={setControllers}
                Co={Co}
                setOpenPopup={setOpenPopup}
                setActionTitle={setActionTitle}
                setSubmitActionType={setSubmitActionType}
                permissionObj={permissionsObj}
                submitActionType={submitactiontype}
                openPopup={openPopup}
                actionTitle={actiontitle}
                ceSelected={ceSelected}
                messageUuid={messageUuid}
                clickOnAdd={clickOnAdd}
                tabSelected={tabSelected}
                fetchLocations={fetchLocations}
                tabPayload={getSelectedTabPayload()}
                fetchNewLocationsCount={fetchNewLocationsCount}
                setTabSelected={setTabSelected}
                setColumnFilters={setColumnFilters}
                setDefaultValues={setDefaultValues}
                initialValues={initialValues}
              />
            </Grid>
          </Grid>
        </>
      )}
    </Formik>
  );
};
export default PreferredLocation;
