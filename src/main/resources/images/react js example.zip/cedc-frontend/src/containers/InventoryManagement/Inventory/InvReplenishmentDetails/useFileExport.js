import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { InventoryinnerSubgridExport } from "../../../../context/actions/Inventory";
import { notNull } from "../../../../utils/constants";


const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const {  claimRx, ceID, controller, columnFilters , dispensedDate, ndc , phID ,
      wholesalerID , refillCode , claimCreatedDate  } = props;
    dispatch(
      InventoryinnerSubgridExport(
        {
          phID : phID,
          wholesalerID  : wholesalerID,
          dispensedDate: dispensedDate,
          ndc: ndc,
          rxNumber: claimRx,
          ceID: ceID,
          export: true,
          pageNumber: 1,
          pageSize: 20,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          refillCode: refillCode,
          claimCreatedDate: claimCreatedDate
        },
        (result) => {
          var data = result.content.map(
            ({
              actionDate,
              action,
              capturedDate,
              refNo,
              storeNumber,
              dispensedQty,
              replenishedQty,
              returnedQty,
              trueUpQty,
              replenishedPerc,
              totalPrice,
              wholesaler,
              status,
            }) => ({
              "Action Date": notNull(actionDate),
              "Action": action,
              "Captured Date": notNull(capturedDate),
              "Ref.No.": notNull(refNo),
              "Store #" : notNull(storeNumber),
              "Dispensed Qty": notNull(dispensedQty),
              "Replenished Qty": notNull(replenishedQty),
              "Returned Qty": notNull(returnedQty),
              "True Up Qty": notNull(trueUpQty),
              "Replenished %": notNull(replenishedPerc),
              "Total Price": notNull(totalPrice),
              "Wholesaler": notNull(wholesaler),
              "Status": notNull(status),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Inventory Details/NDC/Replenishment Claim Details" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
