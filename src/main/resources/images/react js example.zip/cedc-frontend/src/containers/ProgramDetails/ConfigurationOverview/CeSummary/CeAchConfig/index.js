import React, { useCallback, useContext, useEffect, useState } from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { getCeAchConfig } from "../../../../../context/actions/ConfigOverview";
import { useCeSummaryStyle } from "../styles";
import AchGrid from "../../popupsdetail/EntityDetails/ACHConfiguration/AchGrid";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";

const CeAchConfig = (props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};

  const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      dispatch(getCeAchConfig(selectedCeForOverview.ceid));
    }
  }, [selectedCeForOverview]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="ACH Configuration" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              {/* don't remove this commented code it will be used in future as per the client requirement */}
              {/* <IconButton
                  size="small"
                  disabled={
                    !userSession.isInternalUser || !coPermissions.readWriteFlag
                  }
                >
                  <BsPencilSquare
                    onClick={() => {
                      setCoveredEntityName(selectedCeForOverview.ceName);
                      clickOnPencil(
                        MENUS.CE_ACH_CONFIGURATION,
                        selectedCeForOverview.ceid
                      );
                    }}
                  />
                </IconButton> */}
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <AchGrid wizard={false} />
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CeAchConfig;
