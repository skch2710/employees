export const getServices = (data = []) => {
  const services = data[0] || {};
  return {
    hospitalServices: services["Hospital Service"] || [],
    admitTypes: services["Admit Type"] || [],
    servicingFacilities: services["Servicing Facility"] || [],
    patientLocations: services["Patient Location"] || [],
    patientTypes: services["Patient Type"] || [],
  };
};
