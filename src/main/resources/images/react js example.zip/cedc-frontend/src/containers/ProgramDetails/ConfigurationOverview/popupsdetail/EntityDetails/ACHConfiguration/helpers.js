import { formatDate } from "../../../../../../utils/common";
import { getUserSession } from "../../../../../../utils/helper";
import { tableCellGlobalJson } from "../../../../../../components/common/Table/usetableStyle";
import { Grid, Paper, Tooltip, useTheme, Button } from "@material-ui/core";

const userRole = getUserSession();

export const getAddAchFormDefaultValues = () => ({
  accountNumber: "",
  routingNumber: "",
  bankName: "",
  percentageOfRemittance: "",
  pennyTestCompleted: false,
  pennyTestCompletionDate: "",
  bankInfoID: 0,
  payerBankAccountId: 0,
  createdBy: userRole.userId,
  modifiedBy: userRole.userId,
  payerPaymentaccountId: 0,
});

export const getSaveAchPayload = (values = {}) => ({
  bankInfoID: values.bankInfoID,
  payerBankAccountId: values.payerBankAccountId,
  bankName: values.bankName,
  routingNumber: values.routingNumber,
  payerAccountNumber: values.accountNumber,
  percentageOfRemittance: Number(values.percentageOfRemittance),
  pennyTestCompleted: values.pennyTestCompleted,
  createdBy: values.createdBy ? values.createdBy : 0,
  modifiedBy: values.modifiedBy ? values.modifiedBy : 0,
  ceId: values.ceId,
  inActiveFlag: "N",
  payerPaymentaccountId: values.payerPaymentaccountId,
  parentCEID: 0,
  startDatePennyTestCompleted: values.pennyTestCompletionDate,
});

export const getEditAchFormDefaultValues = (rowData={}) => ({
  accountNumber: rowData.payerAccountNumber,
  routingNumber: rowData.routingNumber,
  bankName: rowData.bankName,
  percentageOfRemittance: rowData.percentageOfRemittance,
  pennyTestCompleted: rowData.pennyTestCompleted,
  pennyTestCompletionDate: rowData.startDatePennyTestCompleted
    ? formatDate(rowData)
    : "",
  bankInfoID: rowData.bankInfoID,
  payerBankAccountId: rowData.payerBankAccountId,
  createdBy: rowData.createdByID,
  modifiedBy: rowData.modifiedByID,
  payerPaymentaccountId: rowData.payerPaymentaccountId,
});

