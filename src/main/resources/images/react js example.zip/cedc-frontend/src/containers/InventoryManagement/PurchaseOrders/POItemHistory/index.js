import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import { DatePicker } from "antd";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import useFileExport from "./useFileExport";
import DataNotFound from "../../../../components/common/DataNotFound";
import { pagination } from "../../../../utils/constants";
import { getPOItemHistoryList } from "../../../../context/actions/PurchaseOrders";
import { getPoItemHistoryFiltersObject } from "../helper";
import { GET_PO_ITEM_HISTORY_LIST } from "../../../../context/constants";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const POItemHistory = ({ po } = {}) => {
  const { poID, poItemID } = po || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const iconsAndButtons = useTableIconsAndButtons();

  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});

  const { records: poItemHistoryList = {}, loading } =
    useSelector((state) => state.getPOItemHistoryData) || {};

  const fetchPoItemHistory = (payload = {}) => {
    dispatch(
      getPOItemHistoryList(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          poID: poID,
          poItemID: poItemID,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (poID) {
      fetchPoItemHistory();
    }
    return () => {
      dispatch({ type: GET_PO_ITEM_HISTORY_LIST, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(poItemHistoryList.totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;

      fetchPoItemHistory({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller, poItemHistoryList]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PO_HISTORY_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchPoItemHistory({
        pageNumber: controller.page,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getPoItemHistoryFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchPoItemHistory({
      ...controller,
      filter: filterPayload,
    });
  };

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(poItemHistoryList),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(poItemHistoryList),
      }),
      tooltip: "Export",
      isFreeAction: true,
      disabled: isEmptyGrid(poItemHistoryList),
      onClick: () =>
        exportToExcel({
          poID,
          poItemID,
          controller,
          columnFilters,
        }),
    },
  ];

  const PO_HISTORY_COLUMNS = [
    {
      title: "PO Item ID",
      field: "poItemID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.poItemID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poItemID}>
            <span>{rowData.poItemID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.poItemID}
          placeholder="PO Item ID"
        />
      ),
    },
    {
      title: "PO Item SEQID",
      field: "poItemSeqID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.poItemSeqID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poItemSeqID}>
            <span>{rowData.poItemSeqID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.poItemSeqID}
          placeholder="PO Item SEQID"
        />
      ),
    },
    {
      title: "File PO Item Number",
      field: "filePoItemNumber",
      defaultFilter: enableFilters && columnFiltersRef.current.filePoItemNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.filePoItemNumber}>
            <span>{rowData.filePoItemNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.filePoItemNumber}
          placeholder="File PO Item Number"
        />
      ),
    },
    {
      title: "Item Invoice Number",
      field: "itemInvoiceNumber",
      defaultFilter:
        enableFilters && columnFiltersRef.current.itemInvoiceNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemInvoiceNumber}>
            <span>{rowData.itemInvoiceNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.itemInvoiceNumber}
          placeholder="Item Invoice Number"
        />
      ),
    },
    {
      title: "PO Item Status",
      field: "poItemStatusID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.poItemStatusID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poItemStatusID}>
            <span>{rowData.poItemStatusID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.poItemStatusID}
          placeholder="PO Item Status"
        />
      ),
    },
    {
      title: "Package Ordered",
      field: "packageOrdered",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.packageOrdered,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.packageOrdered}>
            <span>{rowData.packageOrdered}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.packageOrdered}
          placeholder="Package Ordered"
        />
      ),
    },
    {
      title: "Package Acknowledged",
      field: "packageAcknowledged",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.packageAcknowledged,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.packageAcknowledged}>
            <span>{rowData.packageAcknowledged}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.packageAcknowledged}
          placeholder="Package Acknowledged"
        />
      ),
    },
    {
      title: "Package Invoiced",
      field: "packageInvoiced",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.packageInvoiced,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.packageInvoiced}>
            <span>{rowData.packageInvoiced}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.packageInvoiced}
          placeholder="Package Invoiced"
        />
      ),
    },
    {
      title: "Package Reconciled",
      field: "packageReconciled",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.packageReconciled,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.packageReconciled}>
            <span>{rowData.packageReconciled}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.packageReconciled}
          placeholder="Package Reconciled"
        />
      ),
    },
    {
      title: "File Item Status Code",
      field: "fileItemStatusCode",
      defaultFilter:
        enableFilters && columnFiltersRef.current.fileItemStatusCode,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.fileItemStatusCode}>
            <span>{rowData.fileItemStatusCode}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.fileItemStatusCode}
          placeholder="File Item Status Code"
        />
      ),
    },
    {
      title: "Item Ordered Date",
      field: "itemOrderedDate",
      defaultFilter: enableFilters && columnFiltersRef.current.itemOrderedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemOrderedDate}>
            <span>{rowData.itemOrderedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.itemOrderedDate
                ? moment(columnFiltersRef.current.itemOrderedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Item Acknowledged Date",
      field: "itemAcknowledgedDate",
      defaultFilter:
        enableFilters && columnFiltersRef.current.itemAcknowledgedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemAcknowledgedDate}>
            <span>{rowData.itemAcknowledgedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.itemAcknowledgedDate
                ? moment(columnFiltersRef.current.itemAcknowledgedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Item Invoiced Date",
      field: "itemInvoicedDate",
      defaultFilter: enableFilters && columnFiltersRef.current.itemInvoicedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemInvoicedDate}>
            <span>{rowData.itemInvoicedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.itemInvoicedDate
                ? moment(columnFiltersRef.current.itemInvoicedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Item Reconciled Date",
      field: "itemReconciledDate",
      defaultFilter:
        enableFilters && columnFiltersRef.current.itemReconciledDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemReconciledDate}>
            <span>{rowData.itemReconciledDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.itemReconciledDate
                ? moment(columnFiltersRef.current.itemReconciledDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Acknowledged NDC",
      field: "acknowledgedNDC",
      defaultFilter: enableFilters && columnFiltersRef.current.acknowledgedNDC,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.acknowledgedNDC}>
            <span>{rowData.acknowledgedNDC}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.acknowledgedNDC}
          placeholder="Acknowledged NDC"
        />
      ),
    },
    {
      title: "Invoiced NDC",
      field: "inVoicedNDC",
      defaultFilter: enableFilters && columnFiltersRef.current.inVoicedNDC,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.inVoicedNDC}>
            <span>{rowData.inVoicedNDC}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.inVoicedNDC}
          placeholder="Invoiced NDC"
        />
      ),
    },
    {
      title: "Substituted Parent PO Item ID",
      field: "substitutedParentpoItemId",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.substitutedParentpoItemId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.substitutedParentpoItemId}>
            <span>{rowData.substitutedParentpoItemId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.substitutedParentpoItemId}
          placeholder="Substituted Parent PO Item ID"
        />
      ),
    },
    {
      title: "Pgm Package Size",
      field: "pgmPackageSize",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.pgmPackageSize,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pgmPackageSize}>
            <span>{rowData.pgmPackageSize}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pgmPackageSize}
          placeholder="Pgm Package Size"
        />
      ),
    },
    {
      title: "Created By",
      field: "createdByID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.createdByID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.createdByID}>
            <span>{rowData.createdByID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.createdByID}
          placeholder="Created By"
        />
      ),
    },
    {
      title: "Created Date",
      field: "createdDate",
      defaultFilter: enableFilters && columnFiltersRef.current.createdDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.createdDate}>
            <span>{rowData.createdDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.createdDate
                ? moment(columnFiltersRef.current.createdDate)
                : ""
            }
          />
        );
      },
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <BasicTypography variant="subtitle2">{`PO #: ${poID}`}</BasicTypography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <div className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Purchase Order Item History Data (${getTableHeaderCount(
                  poItemHistoryList.totalElements
                )})`}
              />
            }
            columns={PO_HISTORY_COLUMNS}
            data={poItemHistoryList.content}
            page={controller.page - 1}
            totalCount={poItemHistoryList.totalElements}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={ACTIONS}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              showTitle: true,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              actionsCellStyle: getTableActionCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              detailPanelType: "single",
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(poItemHistoryList)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </div>
      </Grid>
    </Grid>
  );
};

export default memo(POItemHistory);
