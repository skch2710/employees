import _get from "lodash/get";
import { pagination } from "../../../utils/constants";
import { getDefaultCeId } from "../../../utils/helper";

export const ALL_ADDITIONAL_DATE_FILTER_OPTION = [
  { id: 1, category: "Quarter", value: "quarter" },
  { id: 2, category: "Month", value: "month" },
  { id: 3, category: "Date Range", value: "dateRange" },
  { id: 4, category: "Current Week", value: "currentWeek" },
  { id: 5, category: "Today", value: "today" },
];

export const LIMITED_ADDITIONAL_DATE_FILTER_OPTION = [
  { id: 1, category: "Month", value: "month" },
  { id: 2, category: "Quarter", value: "quarter" },
  { id: 3, category: "Date Range", value: "dateRange" },
];

export const QUARTER_OPTIONS = [
  { id: 1, label: "Q1", value: 1 },
  { id: 2, label: "Q2", value: 2 },
  { id: 3, label: "Q3", value: 3 },
  { id: 4, label: "Q4", value: 4 },
];

export const TABLE_CELL_STYLE = {
  fontSize: "11px",
  whiteSpace: "nowrap",
  padding: "12px",
  textAlign: "left",
};

// These are default form values.
export const getFilteredPurchaseOrderDefaultValue = () => {
  return {
    ceID: "",
    coveredEntityInput: "",
    phGroupId: 0,
    phID: "",
    wholesalerID: 0,
    drugManufacturerID: [],
    poStatusID: 0,
    addPOStatusID: "",
    poCatergoryID: 0,
    po: "",
    invoiceNumber: "",
    drugDEAClassID: [],
    poSearchCriteria: "",
    ndc: "",
    year: "",
    poDateFilter: "",
    month: 0,
    poStartDate: "",
    poEndDate: "",
    quarter: 0,
  };
};

// We need to pass some default payload every time to fetch data. So storing it in common place will reduce code duplication.
export const getDefaultPOListPayload = (user = {}) => {
  return {
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "",
    sortOrder: "",
    export: false,
    ceID: [getDefaultCeId(user)],
    po: "",
    phID: "",
    wholesalerID: 0,
    drugDEAClassID: [],
    poStatusID: 0,
    reatil304BOrderID: 0,
    ndc: "",
    invoiceNumber: "",
    creditInvoiceNumber: "",
    poSearchCriteria: "",
    year: 0,
    poDateFilter: "",
    poStartDate: "",
    poEndDate: "",
    notOrderFlag: "",
    stalledOrderFlag: "",
    productReturnFlag: "",
    manualOrdersFlag: "",
    addPOStatusID: "",
    quarter: 0,
    month: 0,
    phGroupId: 0,
    drugManufacturerID: [],
    poCatergoryID: 0,
  };
};

export const getPOListPayload = (values = {}) => {
  return {
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortBy: values.sortBy || "",
    sortOrder: values.sortOrder || "",
    export: values.export || false,
    ceID: [_get(values, "ceID.ceID", 0)],
    po: values.po || "",
    phID: _get(values, "phID.phid", ""),
    wholesalerID: _get(values, "wholesalerID.wholesalerID", 0),
    drugDEAClassID: [],
    poStatusID: _get(values, "poStatusID.poStatusID", 0),
    reatil304BOrderID: 0,
    ndc: "",
    invoiceNumber: "",
    creditInvoiceNumber: "",
    poSearchCriteria: _get(values, "poSearchCriteria.poSearchCriteriaType", ""),
    year: values.year || "",
    poDateFilter: _get(values, "poDateFilter.value", ""),
    poStartDate: "",
    poEndDate: "",
    notOrderFlag: "",
    stalledOrderFlag: "",
    productReturnFlag: "",
    manualOrdersFlag: "",
    addPOStatusID: values.addPOStatusID || "",
    quarter: _get(values, "quarter.id", 0),
    month: _get(values, "month.value", 0),
    phGroupId: _get(values, "phGroupId.phGroupId", 0),
    drugManufacturerID: _get(
      values,
      "drugManufacturerID.drugManufacturerID",
      ""
    )
      ? [_get(values, "drugManufacturerID.drugManufacturerID", "")]
      : [],
    poCatergoryID: _get(values, "poCatergoryID.pocategoryID", 0),
    filter: values.filter || [],
  };
};

export const PO_ORDER_EXPORT_FILE_NAME = "Purchase Orders List";
export const CLAIMS_EXPORT_FILE_NAME = "PO Claims List";
export const PO_HISTORY_EXPORT_FILE_NAME = "PO History List";
export const PO_ITEM_HISTORY_EXPORT_FILE_NAME = "PO Items History List";
export const PO_ITEM_INFO_EXPORT_FILE_NAME = "PO Items Info List";
