import React, { forwardRef } from "react";
import Button  from "@material-ui/core/Button";
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import BackupOutlinedIcon from '@material-ui/icons/BackupOutlined';
//react-icons
import { RiDeleteBin5Line } from "react-icons/ri";
import { BiEditAlt } from "react-icons/bi";
import { FaSort } from 'react-icons/fa';
import { TiFilter } from "react-icons/ti";
import {MdOutlineFilterList} from "react-icons/md";

const tableIcons = {
   AddButton: forwardRef((props,ref)=>
    <Button  startIcon={<AddCircleOutlineIcon/>} variant='outlined' size="small" component="button" className="button2" {...props} ref={ref}>Add Location</Button>),
  UploadButton : forwardRef((props,ref)=>
  <Button startIcon={<BackupOutlinedIcon/>} variant="outlined"  size="small" component="button" className="button2" {...props} ref={ref}>
     Upload Locations</Button>
  ),
  Delete: forwardRef((props, ref) => 
            <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
          ),
  Edit: forwardRef((props, ref) =>  
          <BiEditAlt fontSize="small" color="action" {...props} ref={ref} />),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref}/>),
  Filter: forwardRef((props, ref) => <MdOutlineFilterList {...props} ref={ref}/>),



};

export default tableIcons;