import { Divider, Grid, Link } from "@mui/material";
import React from "react";

const footerStyles = {
  margin: "auto",
  padding: "20px 0",
  borderTop: "2px solid #e6eaea",
  fontSize: "12px",
};

const dividerStyles = { height: "auto !important", margin: "0 25px" };

const linkStyles = {
  color: "#1BADBB",
  textDecoration: "none",
  "&:hover": { color: "#1BADBB", textDecoration: "none", cursor: "pointer" },
};

const Footer = () => (
  <footer className="login-footer">
    <Grid xs={10} sx={footerStyles} container justifyContent="space-between">
      <Grid>Copyright Reserved @2022</Grid>
      <Grid sx={{ display: "flex" }}>
        <Link sx={linkStyles}>Terms and conditions</Link>
        <Divider sx={dividerStyles} orientation="vertical" flexItem />
        <Link sx={linkStyles}>Privacy policy</Link>
      </Grid>
    </Grid>
  </footer>
);

export default Footer;
