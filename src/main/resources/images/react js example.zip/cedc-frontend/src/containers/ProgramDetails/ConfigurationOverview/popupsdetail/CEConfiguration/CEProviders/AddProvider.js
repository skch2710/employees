import React, { useState, useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AddProvideroverview from "./AddProvideroverview";
import AddProviderdetails from "./AddProviderdetails";
import { getProvidertype } from "../../../../../../context/actions/ConfigOverview";
import { getLocationList } from "../../../../../../context/actions/Locations";
import { pagination } from "../../../../../../utils/constants";
import { getProvidersLocationGridData } from "../../../../../../context/actions/providers";
import { getAddProviderDefaultValues } from "./constant";
import { useCeProviderStyles } from "./styles";
import { Grid } from "@material-ui/core";
import { TabPanel, a11yProps } from "../../../../../../components/common/Tabs";
import _isEmpty from "lodash/isEmpty";

const AddProvider = ({
  setOpenPopup,
  messageUuid,
  ceSelected,
  rowData,
  title,
  clickOnAdd,
  setMenusStatuses,
  provider,
  defaultFilters,
  searchData,
}) => {
  const classes = useCeProviderStyles();
  const dispatch = useDispatch();
  const [value, setValue] = useState(0);
  const view = title === "View Provider";
  const editProvider = title === "Edit Provider";
  const defaultValues = getAddProviderDefaultValues(rowData);
  const [formData, setFormData] = useState(defaultValues);
  const [npiExist, setNpiExist] = useState("");
  const [spiExist, setSpiExist] = useState("");
  const [deaExist, setDeaExist] = useState("");
  const formRef = useRef(null);
  const handleChangeTab = (_e, newValue) => {
    setValue(newValue);
    setFormData(formRef && formRef.current && formRef.current.values);
  };

  useEffect(() => {
    dispatch(getProvidertype());
    dispatch(
      getLocationList({
        ceIDs:
          messageUuid && messageUuid.ceid !== null
            ? [messageUuid.ceid]
            : [(ceSelected && ceSelected.ceID) || (rowData && rowData.ceid)],
        locationName: "",
      })
    );
    !_isEmpty(rowData) &&
      dispatch(
        getProvidersLocationGridData({
          pageNumber: pagination.page,
          pageSize: pagination.maxLimit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          ceid: rowData
            ? rowData.ceid
            : messageUuid
            ? messageUuid.ceid
            : ceSelected && ceSelected.ceID,
          prescriberId: !_isEmpty(rowData) ? [rowData.prescriberId] : [],
        })
      );
  }, []);

  return (
    <Grid container spacing={2}>
      <Grid item md={2}>
        <Tabs orientation="vertical" value={value} onChange={handleChangeTab}>
          <Tab
            label="Provider Overview"
            classes={{ wrapper: classes.tabLabel }}
            {...a11yProps(0)}
          />
          <Tab
            label="Details"
            classes={{ wrapper: classes.tabLabel }}
            {...a11yProps(1)}
          />
        </Tabs>
      </Grid>
      <Grid item md={10}>
        <TabPanel value={value} index={0}>
          <AddProvideroverview
            setValue={setValue}
            setOpenPopup={setOpenPopup}
            setIndexValue={handleChangeTab}
            setFormData={setFormData}
            formData={formData}
            messageUuid={messageUuid}
            ceSelected={ceSelected}
            view={view}
            rowData={rowData}
            editProvider={editProvider}
            title={title}
            formRef={formRef}
            spiExist={spiExist}
            setSpiExist={setSpiExist}
            deaExist={deaExist}
            setDeaExist={setDeaExist}
            npiExist={npiExist}
            setNpiExist={setNpiExist}
          />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <AddProviderdetails
            setValue={setValue}
            setOpenPopup={setOpenPopup}
            setFormData={setFormData}
            formData={formData}
            messageUuid={messageUuid}
            ceSelected={ceSelected}
            view={view}
            rowData={rowData}
            editProvider={editProvider}
            clickOnAdd={clickOnAdd}
            setMenusStatuses={setMenusStatuses}
            provider={provider}
            defaultFilters={defaultFilters}
            searchData={searchData}
            formRef={formRef}
            spiExist={spiExist}
            deaExist={deaExist}
            npiExist={npiExist}
          />
        </TabPanel>
      </Grid>
    </Grid>
  );
};

export default AddProvider;
