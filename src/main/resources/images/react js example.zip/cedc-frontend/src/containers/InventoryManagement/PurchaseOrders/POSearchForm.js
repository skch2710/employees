import {
  Button,
  FormLabel,
  Grid,
  IconButton,
  Typography,
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import _get from "lodash/get";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import React, { memo, useEffect, useState } from "react";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { useDispatch, useSelector } from "react-redux";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import BasicPopup from "../../../components/Popup/BasicPopup";
import AutoComplete from "../../../components/common/AutoComplete";
import DatePicker from "../../../components/common/DatePicker";
import MultiSelectDropdown from "../../../components/common/MultiSelectDropdown";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import {
  getDrugManufacturer,
  getWholeSaler,
} from "../../../context/actions/Common";
import {
  getOrderStatus,
  getPOSearchCriteria,
  getPharmacyGroups,
  getPharmacyStore,
  getPoCategories,
  getScheduleType,
} from "../../../context/actions/PurchaseOrders";
import { GET_PO_LIST } from "../../../context/constants";
import { LABELS, setAutoCompleteInputVal } from "../../../utils/constants";
import { getUserSession } from "../../../utils/helper";
import { getFilteredPurchaseOrderDefaultValue } from "./constants";
import {
  getAdditionalDateFilterOptions,
  getMonthsList,
  getQuartersList,
} from "./helper";
import { usePOStyles } from "./styles";

const POSearchForm = memo((props) => {
  const { handleSubmit, formRef, handleClear } = props || {};
  const dispatch = useDispatch();
  const classes = usePOStyles();
  const userSession = getUserSession();
  const globalClasses = useGlobalStyles();
  const { ceList } = useSelector((state) => state.coveredEntities) || [];
  const [defaultValues, setDefaultValues] = useState(
    getFilteredPurchaseOrderDefaultValue()
  );
  const pharmacyList = useSelector((state) => state.getPharamacy.records) || [];
  const orderStatusList =
    useSelector((state) => state.getOtherStatusList.records) || [];
  const currentYear = new Date().getFullYear();
  const years = Array.from(new Array(20), (_val, index) => currentYear - index);

  const [filtersOpen, setFiltersOpen] = useState(true);
  const [poCategories, setPOCategories] = useState([]);
  const [scheduleTypes, setScheduleTypes] = useState([]);
  const [poSearchCriteria, setPOSearchCriteria] = useState([]);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);
  const [wholesalerList, setWholesalerList] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [quarterFilterOpen, setQuarterFilterOpen] = useState(false);
  const [monthFilterOpen, setMonthFilterOpen] = useState(false);
  const [dateRangeFilterOpen, setDateRangeFilterOpen] = useState(false);
  const [currentWeekFilterOpen, setCurrWeekFilterOpen] = useState(false);

  const resetStates = ({
    month = false,
    quarter = false,
    dateRange = false,
    currentWeek = false,
  } = {}) => {
    setMonthFilterOpen(month);
    setQuarterFilterOpen(quarter);
    setDateRangeFilterOpen(dateRange);
    setCurrWeekFilterOpen(currentWeek);
  };

  const handleAdditionalDateFilterChange = (value) => {
    const secondValue = value && value.value ? value.value : "";
    if (secondValue === "quarter") {
      resetStates({ quarter: true });
    } else if (secondValue === "month") {
      resetStates({ month: true });
    } else if (secondValue === "dateRange") {
      resetStates({ dateRange: true });
    } else if (secondValue === "currentWeek") {
      resetStates({ currentWeek: true });
    } else {
      resetStates();
    }
  };

  const fetchCriteria = async () => {
    const criteria = (await getPOSearchCriteria()) || [];
    setPOSearchCriteria([...criteria]);
  };

  const fetchScheduleTypes = async () => {
    const schTypes = (await getScheduleType()) || [];
    if (schTypes.length > 0) {
      setScheduleTypes([...schTypes]);
    }
  };
  const fetchPOCategories = async () => {
    const poCat = (await getPoCategories()) || [];
    setPOCategories([...poCat]);
  };
  const fetchPharmacyGroups = (ceIds, disableLoader = false) => {
    dispatch(
      getPharmacyGroups(ceIds, disableLoader, (groups = []) => {
        setPharmacyGroups([...groups]);
      })
    );
  };

  useEffect(() => {
    dispatch(getOrderStatus());
    fetchCriteria();
    fetchScheduleTypes();
    fetchPOCategories();
  }, []);

  useEffect(() => {
    if (ceList.length && !userSession.isInternalUser) {
      if (!userSession.isInternalUser) {
        setDefaultValues((prev) => ({
          ...prev,
          ceID: ceList[0],
          coveredEntityInput: ceList[0].ceName,
        }));
        fetchPharmacyGroups([ceList[0].ceID], true);
        handleSubmit({ ceID: ceList[0] });
      }
    }
  }, [ceList]);

  const onClear = (values) => {
    resetStates();
    if (!userSession.isInternalUser) {
      handleSubmit(values);
    } else {
      dispatch({ type: GET_PO_LIST, data: {} });
    }
    handleClear && handleClear(values);
  };

  const resetAdditionalDateFilterValues = (setFieldValue) => {
    setFieldValue("month", "");
    setFieldValue("quarter", "");
    setFieldValue("poStartDate", "");
    setFieldValue("poEndDate", "");
  };

  const handleAdditionalDateValidation = ({
    selectedYear = "",
    values = {},
    setFieldValue,
  } = {}) => {
    const currentYear = moment().year();
    // quarter validation
    if (values.quarter && selectedYear === currentYear) {
      const currentQuarter = moment().quarter();
      if (values.quarter > currentQuarter) {
        setFieldValue("quarter", "");
      }
    }
    // month validation
    if (values.month && selectedYear === currentYear) {
      const currentMonth = moment().month() + 1;
      if (values.month > currentMonth) {
        setFieldValue("month", "");
      }
    }
    // date range validation
    if (values.poStartDate) {
      setFieldValue("poStartDate", "");
    }
    if (values.poEndDate) {
      setFieldValue("poEndDate", "");
    }
  };

  const formValidate = (values) => {
    const error = {};
    if (!_get(values, "ceID.ceID", 0)) {
      error.ceID = "Please select the Covered Entity";
    }
    return error;
  };

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      validate={formValidate}
      innerRef={formRef}
      enableReinitialize={true}
    >
      {({ values, errors, touched, setFieldValue, initialValues }) => {
        return (
          <Form>
            {filtersOpen ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <Grid container spacing={2} justifyContent="space-between">
                      <Grid item>
                        <BasicTypography variant="h4" title="Filters" />
                      </Grid>
                      <Grid item>
                        <IconButton
                          classes={{
                            root: classes.closeFilterIcon,
                          }}
                        >
                          <IoIosCloseCircleOutline
                            onClick={() => {
                              setFiltersOpen(false);
                            }}
                          />
                        </IconButton>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Covered Entity</FormLabel>
                        {
                          <Field
                            as="select"
                            className={globalClasses.formControl}
                            name="ceID"
                          >
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disabled={!userSession.isInternalUser}
                                disableCloseOnSelect={false}
                                options={_isArray(ceList) ? ceList : []}
                                inputPlaceholder={"Select Covered Entity"}
                                onChange={(_e, value) => {
                                  setFieldValue(
                                    "coveredEntityInput",
                                    value ? value.ceName : ""
                                  );
                                  fetchPharmacyGroups(
                                    value !== null ? [value.ceID] : [0]
                                  );
                                  setFieldValue("ceID", value);
                                  setFieldValue("phGroupId", 0);
                                  setFieldValue("phID", "");
                                  setFieldValue("wholesalerID", 0);
                                  setFieldValue("drugManufacturerID", []);
                                  setFieldValue("year", currentYear.toString());
                                  setFieldValue("poDateFilter", {
                                    id: 5,
                                    category: "Today",
                                    value: "today",
                                  });
                                }}
                                getOptionLabel={(option) => option.ceName || ""}
                                getOptionSelected={(option, value) =>
                                  option.ceID === value.ceID
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.ceName}
                                    </BasicTypography>
                                  );
                                }}
                                inputValue={values.coveredEntityInput || ""}
                                onInputChange={(_e, value) =>
                                  setAutoCompleteInputVal({
                                    value,
                                    callback: (newValue) => {
                                      setFieldValue(
                                        "coveredEntityInput",
                                        newValue
                                      );
                                    },
                                  })
                                }
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                        {errors.ceID && touched.ceID && (
                          <Typography color="error" variant="caption">
                            {errors.ceID}
                          </Typography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                        {
                          <Field
                            as="select"
                            name="phGroupId"
                            className={globalClasses.formControl}
                          >
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disabled={_isEmpty(values.ceID)}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(pharmacyGroups) ? pharmacyGroups : []
                                }
                                inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                                onChange={(_e, value) => {
                                  setFieldValue("phGroupId", value);
                                  dispatch(
                                    getPharmacyStore({
                                      ceid: [
                                        _get(values, "ceID.ceID", values.ceID),
                                      ],
                                      phGroupId: [_get(value, "phGroupId", 0)],
                                    })
                                  );
                                  setFieldValue("phID", "");
                                  setFieldValue("wholesalerID", 0);
                                  setFieldValue("drugManufacturerID", []);
                                }}
                                getOptionLabel={(option) =>
                                  option.phGroupName || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.phGroupName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                        {
                          <Field as="select" name="phID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(pharmacyList) ? pharmacyList : []
                                }
                                disabled={!values.phGroupId}
                                inputPlaceholder={` Select ${LABELS.PharmacyStore}`}
                                onChange={async (_e, value) => {
                                  setFieldValue("phID", value);
                                  setFieldValue("wholesalerID", 0);
                                  setFieldValue("drugManufacturerID", []);
                                  const data = {
                                    ceId: _get(values, "ceID.ceID", 0)
                                      ? [_get(values, "ceID.ceID", 0)]
                                      : _get(values, "ceID", []),
                                    pharmacyId: _get(value, "phid", 0),
                                  };
                                  const resp = await dispatch(
                                    getWholeSaler(data)
                                  );
                                  setWholesalerList(resp);
                                }}
                                getOptionLabel={(option) => option.phName || ""}
                                renderOption={(option) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.phName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Wholesaler</FormLabel>
                        {
                          <Field as="select" name="wholesalerID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(wholesalerList) ? wholesalerList : []
                                }
                                inputPlaceholder={"Select Wholesaler"}
                                disabled={!values.phID}
                                disableCloseOnSelect={false}
                                onChange={async (_e, value) => {
                                  setFieldValue("drugManufacturerID", []);
                                  setFieldValue("wholesalerID", value);
                                  const resp = await dispatch(
                                    getDrugManufacturer({
                                      ceID: _get(values, "ceID.ceID", 0) || 0,
                                      phID: _get(values, "phID.phid", 0) || 0,
                                      wholesalerID: _get(
                                        value,
                                        "wholesalerID",
                                        0
                                      ),
                                    })
                                  );
                                  setManufacturers(resp);
                                }}
                                getOptionLabel={(option) =>
                                  option.wholesalerName || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.wholesalerName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Manufacturer</FormLabel>
                        {
                          <Field as="select" name="drugManufacturerID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(manufacturers) ? manufacturers : []
                                }
                                inputPlaceholder={"Select Manufacturer"}
                                disabled={Number(values.wholesalerID) === 0}
                                disableCloseOnSelect={false}
                                onChange={(_e, value) => {
                                  setFieldValue("drugManufacturerID", value);
                                }}
                                getOptionLabel={(option) =>
                                  option.drugManufacturerName || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.drugManufacturerName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>PO Category</FormLabel>
                        {
                          <Field as="select" name="poCatergoryID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(poCategories) ? poCategories : []
                                }
                                inputPlaceholder={"Select PO Category"}
                                disableCloseOnSelect={false}
                                onChange={(_e, value) => {
                                  setFieldValue("poCatergoryID", value);
                                }}
                                getOptionLabel={(option) =>
                                  option.pocategory || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.pocategory}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Order Status</FormLabel>
                        {
                          <Field as="select" name="poStatusID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(orderStatusList)
                                    ? orderStatusList
                                    : []
                                }
                                inputPlaceholder={"Select PO Category"}
                                disableCloseOnSelect={false}
                                onChange={(_e, value) => {
                                  setFieldValue("poStatusID", value);
                                  setFieldValue("addPOStatusID", "");
                                }}
                                getOptionLabel={(option) =>
                                  option.poStatus || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.poStatus}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={2}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <span>(Or)</span>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              id="stalledOrders"
                              name="addPOStatusID"
                              type="radio"
                              value="2"
                              disabled={
                                (values.poStatusID === null
                                  ? 0
                                  : values.poStatusID) !==
                                defaultValues.poStatusID
                              }
                            />
                            <FormLabel
                              htmlFor="stalledOrders"
                              className={globalClasses.switchRadioLabels}
                            >
                              Stalled Orders
                            </FormLabel>
                          </div>
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={2}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              id="productReturns"
                              name="addPOStatusID"
                              type="radio"
                              value="3"
                              disabled={
                                (values.poStatusID === null
                                  ? 0
                                  : values.poStatusID) !==
                                defaultValues.poStatusID
                              }
                            />
                            <FormLabel
                              htmlFor="productReturns"
                              className={globalClasses.switchRadioLabels}
                            >
                              Returned Units
                            </FormLabel>
                          </div>
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              id="manualOrders"
                              name="addPOStatusID"
                              type="radio"
                              value="4"
                              disabled={
                                (values.poStatusID === null
                                  ? 0
                                  : values.poStatusID) !==
                                defaultValues.poStatusID
                              }
                            />
                            <FormLabel
                              htmlFor="manualOrders"
                              className={globalClasses.switchRadioLabels}
                            >
                              Manual Orders
                            </FormLabel>
                          </div>
                        </div>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Purchase Order</FormLabel>
                        <Field
                          id="purchaseOrder"
                          name="po"
                          type="text"
                          placeholder="Enter Purchase Order"
                          className={globalClasses.formControl}
                          maxLength={19}
                          onChange={(e) => {
                            const { value } = e.target;
                            const regEx = /^[0-9]*$/g;
                            if (value && !regEx.test(value)) return;
                            setFieldValue("po", value.toString());
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Invoice / Credit Invoice Number</FormLabel>
                        <Field
                          id="invoiceNumber"
                          name="invoiceNumber"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Invoice / Credit Invoice Number"
                          maxLength={50}
                          onChange={(e) => {
                            const { value } = e.target;
                            const regEx = /^[a-z0-9]*$/g;
                            if (value && !regEx.test(value)) return;
                            setFieldValue("invoiceNumber", value.toString());
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>NDC</FormLabel>
                        <Field
                          name="ndc"
                          id="ndc"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter NDC"
                          maxLength={11}
                          onChange={(e) => {
                            const { value } = e.target;
                            const regEx = /^[0-9]*$/g;
                            if (value && !regEx.test(value)) return;
                            setFieldValue("ndc", value.toString());
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Schedule</FormLabel>
                        <Field as="select" multiple name="drugDEAClassID">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              inputPlaceholder="Select Schedule"
                              options={scheduleTypes}
                              getOptionSelected={(option, value) =>
                                option.drugDEAClassID === value.drugDEAClassID
                              }
                              getOptionLabel={(option) =>
                                `C${option.drugDEAClassCode}-${option.drugDEAClassDesc}`
                              }
                              onChange={(_e, value) => {
                                setFieldValue("drugDEAClassID", value);
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>PO Search Criteria</FormLabel>
                        {
                          <Field as="select" name="poSearchCriteria">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(poSearchCriteria)
                                    ? poSearchCriteria
                                    : []
                                }
                                inputPlaceholder={"Select PO Category"}
                                disableCloseOnSelect={false}
                                onChange={(_e, value) => {
                                  setFieldValue("poSearchCriteria", value);
                                }}
                                getOptionLabel={(option) =>
                                  option.poSearchCriteriaType || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.poSearchCriteriaType}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Year</FormLabel>
                        {
                          <Field as="select" name="year">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={_isArray(years) ? years : []}
                                inputPlaceholder={"Select Year"}
                                disableCloseOnSelect={false}
                                onChange={(_e, value) => {
                                  const selectedYear = value;
                                  setFieldValue("year", selectedYear || "");
                                  if (
                                    values.poDateFilter &&
                                    (values.poDateFilter.value === "today" ||
                                      values.poDateFilter.value ===
                                        "currentWeek")
                                  ) {
                                    setFieldValue("poDateFilter", "");
                                  }
                                  handleAdditionalDateValidation({
                                    selectedYear: Number(selectedYear),
                                    values,
                                    setFieldValue,
                                  });
                                }}
                                getOptionLabel={(option) =>
                                  option.toString() || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.toString()}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Additional Date Filter</FormLabel>
                        {
                          <Field as="select" name="poDateFilter">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  getAdditionalDateFilterOptions(values.year)
                                    ? getAdditionalDateFilterOptions(
                                        values.year
                                      )
                                    : []
                                }
                                inputPlaceholder={"Select Date Filter"}
                                disableCloseOnSelect={false}
                                onChange={(_e, value) => {
                                  setFieldValue("poDateFilter", value || "");
                                  resetAdditionalDateFilterValues(
                                    setFieldValue
                                  );
                                  handleAdditionalDateFilterChange(value);
                                }}
                                getOptionLabel={(option) =>
                                  option.category || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.category}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      {monthFilterOpen && (
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Month</FormLabel>
                          {
                            <Field as="select" name="month">
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  options={getMonthsList(values.year)}
                                  onChange={(_e, value) => {
                                    setFieldValue("month", value || "");
                                  }}
                                  inputPlaceholder={"Select Month"}
                                  disableCloseOnSelect={false}
                                  getOptionLabel={(option) => {
                                    return option.month || "";
                                  }}
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.month}
                                      </BasicTypography>
                                    );
                                  }}
                                  multiple={false}
                                />
                              )}
                            </Field>
                          }
                        </Grid>
                      )}
                      {dateRangeFilterOpen && (
                        <>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>From Date</FormLabel>
                            <Field as="select" name="poStartDate">
                              {({ field }) => (
                                <DatePicker
                                  disabledDate={(date) =>
                                    !date ||
                                    (values.poEndDate &&
                                      !date.isSameOrBefore(
                                        values.poEndDate,
                                        "day"
                                      ))
                                  }
                                  {...field}
                                  onChange={(_e, date) => {
                                    if (!date) setFieldValue("poEndDate", "");
                                    setFieldValue("poStartDate", date);
                                  }}
                                  value={
                                    values.poStartDate
                                      ? moment(values.poStartDate, "MM/DD/YYYY")
                                      : ""
                                  }
                                />
                              )}
                            </Field>
                          </Grid>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>To Date</FormLabel>
                            <Field as="select" name="poEndDate">
                              {({ field }) => (
                                <DatePicker
                                  disabledDate={(date) =>
                                    !date ||
                                    !date.isSameOrAfter(
                                      values.poStartDate,
                                      "day"
                                    )
                                  }
                                  {...field}
                                  onChange={(_e, date) => {
                                    setFieldValue("poEndDate", date);
                                  }}
                                  value={
                                    values.poEndDate
                                      ? moment(values.poEndDate, "MM/DD/YYYY")
                                      : ""
                                  }
                                />
                              )}
                            </Field>
                          </Grid>
                        </>
                      )}
                      {quarterFilterOpen && (
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Quarter Filter</FormLabel>
                          {
                            <Field as="select" name="quarter">
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  options={
                                    getQuartersList(values.year)
                                      ? getQuartersList(values.year)
                                      : []
                                  }
                                  onChange={(_e, value) => {
                                    setFieldValue("quarter", value);
                                  }}
                                  inputPlaceholder={"Select Quarter"}
                                  disableCloseOnSelect={false}
                                  getOptionLabel={(option) =>
                                    option.label || ""
                                  }
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.label}
                                      </BasicTypography>
                                    );
                                  }}
                                  multiple={false}
                                />
                              )}
                            </Field>
                          }
                        </Grid>
                      )}
                    </Grid>
                    <Grid container spacing={2} justifyContent="flex-end">
                      <Grid item>
                        <Button
                          type="submit"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                        >
                          Search
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          onClick={() => onClear(initialValues)}
                        >
                          Clear
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <BasicPopup
                  title="Current Week"
                  show={currentWeekFilterOpen}
                  handleClose={() => setCurrWeekFilterOpen(false)}
                  submitProps={{
                    buttonTitle: "OK",
                    handleSubmit: () => setCurrWeekFilterOpen(false),
                  }}
                >
                  <p>
                    Current week means - Purchase Orders that fall between the
                    past Sunday and the current day
                  </p>
                </BasicPopup>
              </div>
            ) : (
              <Button
                type="submit"
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setFiltersOpen(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
});

export default POSearchForm;
