import { makeStyles } from "@material-ui/core/styles";

export const useCeVisitWindowStyles = makeStyles((_theme) => {
  return {};
});
