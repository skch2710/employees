import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { InventoryinnergridExport } from "../../../../context/actions/Inventory";
import { notNull } from "../../../../utils/constants";


const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { phID, wholesalerID , ndc , ceID ,  controller, columnFilters } = props;
    dispatch(
      InventoryinnergridExport(
        {
          wholesalerID: wholesalerID,
          ndc: ndc,
          ceID: ceID,
          phID: phID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              claimRx,
              refillCode,
              dispensedDate,
              dispensedQty,
              replenishmentPercentage,
              latestStatus,
            }) => ({
              "Claim(RX)": notNull(claimRx),
              "Fill Number" : notNull(refillCode),
              "Dispensed Date": dispensedDate,
              "Disp.Qty": notNull(dispensedQty),
              "Replenishment % ": notNull(replenishmentPercentage),
              "Latest Status": notNull(latestStatus),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Inventory Details/NDC" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
