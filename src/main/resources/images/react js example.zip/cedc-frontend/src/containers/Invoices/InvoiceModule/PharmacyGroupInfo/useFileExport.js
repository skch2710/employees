import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { InvoicePharmacyGroupExport } from "../../../../context/actions/Invoice";
import { LABELS, notNull } from "../../../../utils/constants";


const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const {ceId, billingPeriod, invoicePeriodStartDate, invoicePeriodEndDate , controller, columnFilters } = props;
    dispatch(
      InvoicePharmacyGroupExport(
        {
          invoicePeriodStartDate: invoicePeriodStartDate,
          invoicePeriodEndDate: invoicePeriodEndDate,
          ceId: [ceId],
          billPeriod: billingPeriod,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              ceName,
              phGroupName,
              invoicePeriodStartDate,
              invoicePeriodEndDate,
              totalInvoiced,
              dispensingFee,
              trueUp,
              direct340BTrxnFee
            }) => ({
              "Covered Entity" : (ceName),
              [LABELS.PharmacyChain]: notNull(phGroupName),
              "Billing Period":  `${invoicePeriodStartDate} - ${invoicePeriodEndDate}` ,
              "Total Invoiced": notNull(totalInvoiced),
              "Dispensing Fees": notNull(dispensingFee),
              "True Up Fees": notNull(trueUp),
              "340BDirect+ Fees": notNull(direct340BTrxnFee),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Pharmacy Chain level details" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
