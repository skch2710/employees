import { Grid } from "@material-ui/core";
import moment from "moment";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { getPurchaseList } from "../../../context/actions/PurchaseOrders";
import { GET_PO_LIST } from "../../../context/constants";
import { pagination } from "../../../utils/constants";
import POList from "./POList";
import POSearchForm from "./POSearchForm";
import { getPOListPayload } from "./constants";
import { getScheduleTypeIds, getTodayDatePayload } from "./helper";

const PurchaseFilters = () => {
  const dispatch = useDispatch();
  const formRef = useRef(null);
  const actionRef = useRef(null);
  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [poControllers, setPoControllers] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });

  const fetchPurchaseOrders = (payload = {}, callback) => {
    const { poDateFilter, drugDEAClassID } = payload;
    const payloadJson = {
      ...getPOListPayload(payload),
      ...getTodayDatePayload(poDateFilter),
      ...getScheduleTypeIds(drugDEAClassID),
    };
    dispatch(
      getPurchaseList(payloadJson, (resp) => callback && callback(resp))
    );
  };

  useEffect(() => {
    return () => {
      dispatch({ type: GET_PO_LIST, data: {} });
    };
  }, []);

  const handleSubmit = (values) => {
    fetchPurchaseOrders({ ...values }, (resp) => {
      actionRef.current && actionRef.current.submitForm(resp);
    });
    // Need to use this state because whenever form values changes the values object will get updated even if we didn't hit search button. That was creating issue, so maintaining one more state to store only those values which are submitted.
    setFormSubmittedValues(values);
  };

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={12}>
          <BasicTypography
            variant="h1"
            title="Inventory Management - Purchase Orders"
          />
        </Grid>
        <Grid item md={12}>
          <POSearchForm
            handleSubmit={handleSubmit}
            formRef={formRef}
            handleClear={(values) =>
              actionRef.current && actionRef.current.clearForm(values)
            }
          />
        </Grid>
        <Grid item md={12}>
          <POList
            fetchPurchaseOrders={fetchPurchaseOrders}
            formRef={formRef}
            ref={actionRef}
            formSubmittedValues={formSubmittedValues}
            poControllers={poControllers}
            setPoControllers={setPoControllers}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default PurchaseFilters;
