import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { ViewFullReportUnrepExport } from "../../context/actions/Home";
import { LABELS, notNull } from "../../utils/constants";

const useFileExportUnrepInv = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const {
      ceid,
      phid,
      phGroupId,
      processedStartDate,
      processedEndDate,
      controller,
      columnFilters,
    } = props;

    dispatch(
      ViewFullReportUnrepExport(
        {
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
          ceid: ceid,
          phid: phid,
          phGroupId: phGroupId,
          processedStartDate: processedStartDate,
          processedEndDate: processedEndDate,
        },
        (result) => {
          var data = result.content.map(
            ({ ceName, phName, unreplenishedInventoryCost }) => ({
              [LABELS.CoveredEntity]: notNull(ceName),
              "Pharmacy Store": notNull(phName),
              "Unreplenished Inventory Cost": notNull(
                unreplenishedInventoryCost
              ),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(
            fileData,
            "Unreplenished Inventory Cost by Pharmacy - Full Report.xlsx"
          );
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExportUnrepInv;
