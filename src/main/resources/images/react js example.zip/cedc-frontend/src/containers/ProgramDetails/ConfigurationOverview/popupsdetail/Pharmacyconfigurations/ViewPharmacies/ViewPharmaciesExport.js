import FileSaver from "file-saver";
import "jspdf-autotable";
import _isEmpty from "lodash/isEmpty";
import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import { fetchPharmaciesTableData } from "../../../../../../context/actions/Pharmacies";
import { LABELS, notNull } from "../../../../../../utils/constants";
const fileName = "ViewPharmacies List";

const ViewPharmaciesExport = () => {
  const dispatch = useDispatch();

  const exportViewPharmacies = async (props) => {
    const { ceId, sortBy, sortOrder, defaultFilters, phNetworkId, phStoreId } =
      props;

    const tableData = await dispatch(
      fetchPharmaciesTableData({
        ceid: [ceId],
        phGroupId: phNetworkId,
        phid: phStoreId,
        sortBy: sortBy,
        sortOrder: sortOrder,
        filter: defaultFilters,
        export: true,
        startDate: "",
        endDate: "",
        status: "",
      })
    );

    if (!_isEmpty(tableData)) {
      var data = tableData.content.map(
        ({
          pharmacyName,
          pharmacyNetwork,
          goLiveDate,
          startDate,
          endDate,
          brandDispensingFeeThirdParty,
          genericDispensingFeeThirdParty,
          specialtyBrandDispensingFeeThirdParty,
          specialtyGenericDispensingFeeThirdParty,
          cashFlatFeeBoth,
          specialtyBrandDispensingFeeCash,
          specialtyGenericDispensingFeeCash,
          brandDispensingFeeCash,
          genericDispensingFeeCash,
          programType,
          billingModel,
          wholesaler,
          participatingInCashProgram,
          configStatus,
        }) => ({
          "Configuration Status": notNull(configStatus),
          [LABELS.PharmacyStore]: notNull(pharmacyName),
          [LABELS.PharmacyChain]: notNull(pharmacyNetwork),
          "Pharmacy Go-Live Date": notNull(goLiveDate),
          "PSA Start Date": notNull(startDate),
          "PSA Termination Date": notNull(endDate),
          "Third Party Brand $+%": notNull(brandDispensingFeeThirdParty),
          "Third Party Generic $+%": notNull(genericDispensingFeeThirdParty),
          "Third Party Specialty Brand $+%": notNull(
            specialtyBrandDispensingFeeThirdParty
          ),
          "Third Party Specialty Generic $+%": notNull(
            specialtyGenericDispensingFeeThirdParty
          ),
          "Cash Flat Fee $+%": notNull(cashFlatFeeBoth),
          "Cash Specialty Brand $+%": notNull(specialtyBrandDispensingFeeCash),
          "Cash Specialty Generic $+%": notNull(
            specialtyGenericDispensingFeeCash
          ),
          "Cash Brand $+%": notNull(brandDispensingFeeCash),
          "Cash Generic $+%": notNull(genericDispensingFeeCash),
          "Program Type": notNull(programType),
          "Billing Model": notNull(billingModel),
          Wholesaler: notNull(wholesaler),
          "Participating in Cash Program": notNull(participatingInCashProgram),
        })
      );

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, fileName + ".xlsx");
    }
  };

  return { exportViewPharmacies };
};

export default ViewPharmaciesExport;
