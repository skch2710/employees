import { pagination } from "../../../utils/constants";
import { userdata, filterFunctionality } from "../../../utils/common";
import _get from "lodash/get";
const userrole = JSON.parse(userdata());
const CELIST = userrole.coveredEntityDTOs;

export const TABLE_CELL_STYLE = {
  fontSize: "11px",
  whiteSpace: "nowrap",
  padding: "12px",
};

export const getFilteredInvDefaultValue = (ceList) => {
  return {
    ceID: ceList.length === 1 ? ceList[0].ceID : 0,
    drugDEAClassID: 0,
    drugManufacturerID: 0,
    drugName: "",
    inventoryFilter: "A",
    ndc: "",
    phID: "",
    phGroupId: "",
    wholesalerID: 0,
  };
};

export const getDefaultInvListPayload = (values = {}) => {
  return {
    ceID: [_get(values, "ceID.ceID", CELIST[0].ceID)],
    pageNumber: values.pageNumber,
    pageSize: values.pageSize,
    sortBy: _get(values, "sortBy", ""),
    sortOrder: _get(values, "sortOrder", ""),
    drugDEAClassID: _get(values, "drugDEAClassID.drugDEAClassID", 0),
    drugManufacturerID: _get(
      values,
      "drugManufacturerID.drugManufacturerID",
      0
    ),
    drugName: values.drugName,
    inventoryFilter: values.inventoryFilter,
    ndc: values.ndc,
    phID: _get(values, "phID.phid", 0),
    phGroupId: _get(values, "phGroupId.phGroupId", 0),
    wholesalerID: _get(values, "wholesalerID.wholesalerID", 0),
    filter: values.filter,
  };
};
