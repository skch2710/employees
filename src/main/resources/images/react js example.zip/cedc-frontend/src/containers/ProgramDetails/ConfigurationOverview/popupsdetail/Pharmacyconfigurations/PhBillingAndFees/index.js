import React, { useContext, useEffect, useRef, useState } from "react";
import { Button, Grid } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import { Form, Formik } from "formik";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import { updatePharmacySectionStatus } from "../../../../../../context/actions/ConfigOverview";
import {
  fetchClientFrequency,
  saveBillingAndFees,
  editBillingAndFees,
} from "../../../../../../context/actions/PharmacyConfiguration";
import { pagination } from "../../../../../../utils/constants";
import AdminFee from "./AdminFee";
import DispensingFees from "./DispensingFee";
import { userdata } from "../../../../../../utils/common";
import {
  fetchPhAdminFeesTableData,
  fetchPharmaciesTableData,
  fetchPhDispensingFeesTableData,
} from "../../../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";

const PhBillingAndFees = () => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const userSessionData = JSON.parse(userdata());
  const {
    currentPharmacy = {},
    setOpenAddCePopup,
    setPopupActiveMenu,
    phConfigSectionStatus,
    setPhConfigSectionStatus,
    messageUuid,
    phConfigStatusPercent,
    setPhConfigStatusPercent,
    isNewPharmacy,
    phGridPayload,
  } = useContext(COContext);
  const clientFreqData = useRef("");
  const { phBillingAndFee } = phConfigSectionStatus;
  const { ceid: ceId } = messageUuid || {};

  const [defaultValues, setDefaultValues] = useState({
    frequency: "2",
  });

  const { records: adminFeesTableData } =
    useSelector((state) => state.phAdminFeesList) || {};
  const { records: dispensingFeesTableData } =
    useSelector((state) => state.phDispensingFeesList) || {};

  const getAdminFeeTableData = async (payload = {}, callback) => {
    const resp = await dispatch(
      fetchPhAdminFeesTableData({
        clientId: currentPharmacy.clientId || 0,
        pageNumber: 1,
        pageSize: pagination.limit,
        sortBy: "",
        sortOrder: "",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(resp) && callback && callback(resp);
  };

  const getDispensingFeesTableData = async (payload = {}, callback) => {
    const tableData = await dispatch(
      fetchPhDispensingFeesTableData({
        clientId: currentPharmacy.clientId || 0,
        pageNumber: 1,
        pageSize: pagination.limit,
        sortBy: "",
        sortOrder: "",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(tableData) && callback && callback(tableData);
  };

  const getFrequency = async () => {
    const resp = await dispatch(fetchClientFrequency(currentPharmacy.clientId));
    if (!_isEmpty(resp) && _isArray(resp)) {
      clientFreqData.current = resp;
      setDefaultValues({
        frequency: `${resp[0].freqId}`,
      });
    }
  };

  const handleFormSubmit = async (values) => {
    const clientFreqId = !_isEmpty(clientFreqData.current)
      ? clientFreqData.current[0].clientFreqId
      : "";
    const payload = {
      ...(clientFreqId ? { clientFreqId } : {}),
      clientId: currentPharmacy.clientId || 0,
      freqId: Number(values.frequency),
      createdById: userSessionData.userId,
      modifiedById: userSessionData.userId,
    };
    const resp = clientFreqId
      ? await dispatch(editBillingAndFees(payload))
      : await dispatch(saveBillingAndFees(payload));

    if (resp) {
      if (
        (isNewPharmacy || phBillingAndFee) &&
        adminFeesTableData.totalElements > 0 &&
        dispensingFeesTableData.totalElements > 0
      ) {
        dispatch(
          updatePharmacySectionStatus({
            ceId,
            clientId: currentPharmacy.clientId,
            sectionId: 13,
            callback: statusCallback,
          })
        );
      }
      values.isStopNavigation
        ? setOpenAddCePopup(false)
        : setPopupActiveMenu(MENUS.PH_ELIGIBILITY);
    }
  };

  const statusCallback = (res) => {
    if (res.statusCode === 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || phConfigStatusPercent;
      if (ceConfigPercent) {
        setPhConfigStatusPercent(ceConfigPercent);
      }
      setPhConfigSectionStatus((prev) => ({
        ...prev,
        phBillingAndFee: false,
      }));
      dispatch(fetchPharmaciesTableData(phGridPayload));
    }
  };

  useEffect(() => {
    getAdminFeeTableData();
    getDispensingFeesTableData();
    currentPharmacy.clientId && getFrequency();
  }, []);

  const handleValidate = (values) => {
    const error = {};
    if (!values.frequency) {
      error.frequency = "Please select the Frequency";
    }
    return error;
  };

  return (
    <Formik
      enableReinitialize={true}
      initialValues={defaultValues}
      onSubmit={handleFormSubmit}
      validate={handleValidate}
    >
      {({ setFieldValue, submitForm }) => {
        return (
          <Form>
            <Grid container spacing={2} direction="column">
              <Grid item md={12}>
                <BasicTypography
                  variant="h4"
                  title={`${
                    currentPharmacy.pharmacyName ||
                    currentPharmacy.phName +
                      " " +
                      "#" +
                      currentPharmacy.storeNumber ||
                    "Pharmacy Name"
                  } > Billing And Fees`}
                />
              </Grid>
              <Grid item md={12}>
                <AdminFee getAdminFeeTableData={getAdminFeeTableData} />
              </Grid>
              <Grid item md={12}>
                <DispensingFees
                  getDispensingFeesTableData={getDispensingFeesTableData}
                />
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2} justifyContent="flex-end">
                  <Grid item>
                    <Button
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                      onClick={() => {
                        setFieldValue("isStopNavigation", false);
                        submitForm();
                      }}
                    >
                      Next
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setPopupActiveMenu(MENUS.PH_ELIGIBILITY);
                      }}
                    >
                      Skip
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setFieldValue("isStopNavigation", true);
                        submitForm();
                      }}
                    >
                      Save and Exit
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setOpenAddCePopup(false);
                      }}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        );
      }}
    </Formik>
  );
};

export default PhBillingAndFees;
