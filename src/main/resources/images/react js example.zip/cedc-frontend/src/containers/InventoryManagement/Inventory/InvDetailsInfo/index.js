import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { useTheme } from "@material-ui/core/styles";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import DatePicker from "../../../../components/common/DatePicker";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { pagination } from "../../../../utils/constants";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import "antd/dist/antd.css";
import { getinventoryInnerList } from "../../../../context/actions/Inventory";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import { getInvInnergridFiltersObject } from "../helper";
import { GET_INVENTORY_INNER_LIST } from "../../../../context/constants";
import DataNotFound from "../../../../components/common/DataNotFound";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import useFileExport from "./useFileExport";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import InvReplenishmentDetails from "../InvReplenishmentDetails";
import { getUserPreveleges } from "../../../../utils/common";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const InvItemInfoTable = ({ MainGridData }) => {
  const {
    phID,
    wholesalerID,
    ndc,
    ceID,
    drugName,
    packageSize,
    unitsDispensed,
    unitsReplenished,
    ceOwnedInventory,
    pxOwedInventory,
  } = MainGridData || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const iconsAndButtons = useTableIconsAndButtons();
  const phiAccess = getUserPreveleges("PHI Access");
  const currentInventoryValue =
    ceOwnedInventory !== "0" ? ceOwnedInventory : pxOwedInventory;
  const packageSizeValue = packageSize !== null ? packageSize : "";
  const unitsDispensedValue = unitsDispensed !== null ? unitsDispensed : "";
  const unitsReplenishedValue =
    unitsReplenished !== null ? unitsReplenished : "";
  const [controller, setController] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "claimRx",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [showInnerSubGridItemInfo, setShowInnerSubGridItemInfo] =
    useState(false);
  const [rowData, setRowData] = useState({});
  const columnFiltersRef = useRef({});

  const { records: invInfoList, loading } = useSelector(
    (state) => state.getinventoryInnerGrid
  );

  const fetchInvInnerItemInfo = (payload = {}) => {
    dispatch(
      getinventoryInnerList(
        {
          wholesalerID: MainGridData.wholesalerID,
          ndc: MainGridData.ndc,
          ceID: MainGridData.ceID,
          phID: MainGridData.phID,
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "claimRx",
          sortOrder: "asc",
          filter: [],
          export: false,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            pageNumber: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (phID) {
      fetchInvInnerItemInfo();
    }
    return () => {
      dispatch({ type: GET_INVENTORY_INNER_LIST, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(invInfoList.totalElements / rowsPerPage) || 1;
      if (controller.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.pageNumber;

      fetchInvInnerItemInfo({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = INV_INFO_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchInvInnerItemInfo({
        pageNumber: controller.pageNumber,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getInvInnergridFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchInvInnerItemInfo({
      ...controller,
      filter: filterPayload,
    });
  };

  const actions = [
    {
      icon: iconsAndButtons.Plus(),
      tooltip: "Replenishment Claim Details",
      isFreeAction: false,
      onClick: (_event, rowData) => {
        setRowData(rowData);
        setShowInnerSubGridItemInfo(true);
      },
    },
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      disabled: invInfoList && invInfoList.totalElements < 1,
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(invInfoList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(invInfoList),
      onClick: () =>
        exportToExcel({
          phID,
          wholesalerID,
          ndc,
          ceID,
          controller,
          columnFilters,
        }),
    },
  ];
  const INV_INFO_COLUMNS = [
    {
      title: "Claim(Rx)",
      field: "claimRx",
      defaultFilter: enableFilters && columnFiltersRef.current.claimRx,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimRx}>
            <span>{rowData.claimRx}</span>
          </Tooltip>
        );
      },
      cellStyle: {
        ...getTableCellStyles(theme),
        color:
          phiAccess && phiAccess.readOnlyFlag
            ? theme.colors.yellow.default
            : "",
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimRx}
          placeholder="Claim(Rx)"
        />
      ),
    },
    {
      title: "Fill Number",
      field: "refillCode",
      defaultFilter: enableFilters && columnFiltersRef.current.refillCode,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.refillCode}>
            <span>{rowData.refillCode}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.refillCode}
          placeholder="Fill Number"
        />
      ),
    },
    {
      title: "Dispensed Date",
      field: "dispensedDate",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensedDate}>
            <span>{rowData.dispensedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.dispensedDate
                ? moment(columnFiltersRef.current.dispensedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Disp.Qty",
      field: "dispensedQty",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensedQty}>
            <span>{rowData.dispensedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensedQty}
          placeholder="Disp.Qty"
        />
      ),
    },
    {
      title: "Replenishment %",
      field: "replenishmentPercentage",
      defaultFilter:
        enableFilters && columnFiltersRef.current.replenishmentPercentage,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishmentPercentage}>
            <span>{rowData.replenishmentPercentage}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishmentPercentage}
          placeholder="Replenishment %"
        />
      ),
    },
    {
      title: "Latest Status",
      field: "latestStatus",
      defaultFilter: enableFilters && columnFiltersRef.current.latestStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.latestStatus}>
            <span>{rowData.latestStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.latestStatus}
          placeholder="Latest Status"
        />
      ),
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <BasicTypography variant="h5" title={`NDC : ${ndc}`} />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography variant="h5" title={`Drug Name : ${drugName}`} />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={`Package Size : ${packageSizeValue}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={`Units Dispensed : ${unitsDispensedValue}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={`Units Replenished : ${unitsReplenishedValue}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={`Current Inventory Owed : ${currentInventoryValue}`}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Grid className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Inventory Details (${getTableHeaderCount(
                  invInfoList.totalElements
                )})`}
              />
            }
            columns={INV_INFO_COLUMNS}
            data={invInfoList.content || []}
            page={controller.pageNumber - 1}
            totalCount={invInfoList.totalElements || 0}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={actions}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              exportAllData: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              actionsCellStyle: getTableActionCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(invInfoList)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
          <BasicPopup
            title={"Inventory Details/NDC/Replenishment Claim Details"}
            show={showInnerSubGridItemInfo}
            disableFooter={true}
            dialogProps={{
              maxWidth: "lg",
            }}
            handleClose={() => setShowInnerSubGridItemInfo(false)}
          >
            <InvReplenishmentDetails
              InnerGridRowdata={rowData}
              packageSize={packageSizeValue}
              unitsDispensed={unitsDispensedValue}
              unitsReplenished={unitsDispensedValue}
              currentInventory={currentInventoryValue}
            />
          </BasicPopup>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default memo(InvItemInfoTable);
