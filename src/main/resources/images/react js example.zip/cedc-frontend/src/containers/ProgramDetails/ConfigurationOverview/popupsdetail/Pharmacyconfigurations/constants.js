export const TABLE_CELL_STYLE = {
  maxWidth: "100px",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  overflow: "hidden",
  fontSize: "11px",
  padding: "12px",
  textAlign: "left",
};
