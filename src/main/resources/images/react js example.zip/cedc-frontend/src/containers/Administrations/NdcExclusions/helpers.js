import { pagination } from "../../../utils/constants";
import _get from "lodash/get";
import _isArray from "lodash/isArray";
import {
  getCeIdsArray,
  getListIdsArray,
  getTherapeuticIds,
  getExcIds,
  getNdcIds,
  getGcnIds,
  getPhGroupIdArray,
  getPhIdArray,
  getWhIdArray,
  getManufIdArray,
} from "../../../utils/helper";

export const getFilteredNdcListDefaultValue = () => {
  return {
    listId: [],
    ceId: [],
    phGroupId: [],
    pharmacy: [],
    manufacturer: [],
    wholesaler: [],
    startDate: "",
    endDate: "",
    therapeuticClass: [],
    ndc: "",
    gcn: "",
    exclusionType: [],
    activeInactiveAll: "",
  };
};

export const getDefaultNdcListPayload = (formSubmittedValues) => {
  return {
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: formSubmittedValues.sortBy
      ? formSubmittedValues.sortBy
      : "listName",
    sortOrder: formSubmittedValues.sortOrder
      ? formSubmittedValues.sortOrder
      : "asc",
    filter: formSubmittedValues.filter ? formSubmittedValues.filter : [],
    export: false,
    listId: getListIdsArray(formSubmittedValues.listId),
    ceid: getCeIdsArray(formSubmittedValues.ceId),
    phGroupId: getPhGroupIdArray(formSubmittedValues.phGroupId),
    phid: getPhIdArray(formSubmittedValues.pharmacy),
    drugManufacturerId: getManufIdArray(formSubmittedValues.manufacturer),
    drugTherapeuticClassId: getTherapeuticIds(
      formSubmittedValues.therapeuticClass
    ),
    ndcExcTypeId: getExcIds(formSubmittedValues.exclusionType),
    wholesalerId: getWhIdArray(formSubmittedValues.wholesaler),
    startDate: formSubmittedValues.startDate
      ? formSubmittedValues.startDate
      : "",
    endDate: formSubmittedValues.endDate ? formSubmittedValues.endDate : "",
    status: formSubmittedValues.activeInactiveAll
      ? formSubmittedValues.activeInactiveAll
      : "",
    ndc: getNdcIds(formSubmittedValues.ndc),
    gcn: formSubmittedValues.gcn ? formSubmittedValues.gcn : [],
    isList: true,
    isCoveredEntity: false,
    isPhGroup: false,
  };
};

export const getDefaultNdcListExportPayload = (formSubmittedValues) => {
  return {
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: formSubmittedValues.sortBy ? formSubmittedValues.sortBy : "",
    sortOrder: formSubmittedValues.sortOrder
      ? formSubmittedValues.sortOrder
      : "",
    filter: formSubmittedValues.filter ? formSubmittedValues.filter : [],
    listId: getListIdsArray(formSubmittedValues.listId),
    ceid: getCeIdsArray(formSubmittedValues.ceId),
    phGroupId: getPhGroupIdArray(formSubmittedValues.phGroupId),
    phid: getPhIdArray(formSubmittedValues.pharmacy),
    drugManufacturerId: getManufIdArray(formSubmittedValues.manufacturer),
    drugTherapeuticClassId: getTherapeuticIds(
      formSubmittedValues.therapeuticClass
    ),
    ndcExcTypeId: getExcIds(formSubmittedValues.exclusionType),
    wholesalerId: getWhIdArray(formSubmittedValues.wholesaler),
    startDate: formSubmittedValues.startDate
      ? formSubmittedValues.startDate
      : "",
    endDate: formSubmittedValues.endDate ? formSubmittedValues.endDate : "",
    status: formSubmittedValues.activeInactiveAll
      ? formSubmittedValues.activeInactiveAll
      : "",
    ndc: getNdcIds(formSubmittedValues.ndc),
    gcn: formSubmittedValues.gcn ? formSubmittedValues.gcn : [],
  };
};

export const getNdcListPayload = (values = {}) => {
  return {
    pageNumber: values.pageNumber ? values.pageNumber : pagination.page,
    pageSize: values.pageSize ? values.pageSize : pagination.limit,
    sortBy: values.sortBy ? values.sortBy : "listName",
    sortOrder: values.sortOrder ? values.sortOrder : "asc",
    filter: values.filter ? values.filter : [],
    export: false,
    listId: getListIdsArray(values.listId),
    ceid: getCeIdsArray(values.ceId),
    phGroupId: getPhGroupIdArray(values.phGroupId),
    phid: getPhIdArray(values.pharmacy),
    drugManufacturerId: getManufIdArray(values.manufacturer),
    drugTherapeuticClassId: getTherapeuticIds(values.therapeuticClass),
    ndcExcTypeId: getExcIds(
      values.exclusionType && values.exclusionType.ndcExcTypeId
    ),
    wholesalerId: getWhIdArray(values.wholesaler),
    startDate: values.startDate ? values.startDate : "",
    endDate: values.endDate ? values.endDate : "",
    status: values.activeInactiveAll ? values.activeInactiveAll : "",
    ndc: values.ndc ? [values.ndc] : [],
    gcn: values.gcn ? [values.gcn] : [],
    isList: true,
    isCoveredEntity: false,
    isPhGroup: false,
  };
};

export const getNdcAllDropdownPayload = (values = {}) => {
  return {
    listId: getListIdsArray(values.listId),
    ceid: getCeIdsArray(values.ceId),
    phGroupId: getPhGroupIdArray(values.phGroupId),
    phid: getPhIdArray(values.pharmacy),
    drugManufacturerId: getManufIdArray(values.manufacturer),
    drugTherapeuticClassId: getTherapeuticIds(values.therapeuticClass),
    ndcExcTypeId: getExcIds(values.exclusionType),
    wholesalerId: getWhIdArray(values.wholesaler),
    status: "",
    ndc: values.ndc ? [values.ndc] : [],
    gcn: values.gcn ? [values.gcn] : [],
  };
};

export const conditionsCheck = ({ options, values, key }) => {
  return _isArray(options) &&
    options.length > 1 &&
    options.length === _isArray(values[key]) &&
    values[key].length
    ? []
    : values[key];
};

export const getNdcListsFiltersObject = (filters) => {
  const numericFieldsArray = ["startDate", "endDate", "lastUpdatedDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: numericFieldsArray.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getCeNdcListsFiltersObject = (filters) => {
  const numericFieldsArray = [
    "listAppliedDate",
    "listTerminationDate",
    "lastUpdatedDate",
  ];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: numericFieldsArray.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getPhNdcFiltersObject = (filters) => {
  const numericFieldsArray = [
    "listAppliedDate",
    "listTerminationDate",
    "lastUpdatedDate",
  ];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: numericFieldsArray.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getNdcListsAppliedClientFiltersObject = (filters) => {
  const numericFieldsArray = [
    "exclusionAppliedStartDate",
    "exclusionAppliedEndDate",
    "lastUpdatedDate",
  ];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: numericFieldsArray.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getAllIncompleteTabs = (tabsObjs = []) => {
  if (_isArray(tabsObjs)) {
    return tabsObjs.filter((el = {}) => el.statusId === 1);
  } else return [];
};
