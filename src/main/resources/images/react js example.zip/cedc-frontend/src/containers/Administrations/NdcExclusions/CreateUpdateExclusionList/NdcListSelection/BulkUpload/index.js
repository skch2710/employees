import React, { useContext, useMemo, useState } from "react";
import { Button, Grid, useTheme } from "@material-ui/core";
import { useDropzone } from "react-dropzone";
import { useDispatch } from "react-redux";
import _get from "lodash/get";
import Excel from "../../../../../../assets/excel.png";
import DragDropUpload from "../../../../../../assets/dragdropupload.png";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { CircularBar } from "../../../../../../components/common/ProgressBar/CircularBar";
import { getDroppableStyle, useBulkUploadStyles } from "./styles";
import {
  ndcBulkUpload,
  validateNdcFile,
} from "../../../../../../context/actions/NdcExclusions";
import { NdcContext } from "../../../NdcContext";

const BulkUpload = (props = {}) => {
  const { handleBulkUploadPopup, handleNdcUploadSuccess } = props;
  const dispatch = useDispatch();
  const theme = useTheme();
  const globalClasses = useGlobalStyles();
  const classes = useBulkUploadStyles();
  const { setNdcSelectionBulkUploadReport, ndcData } =
    useContext(NdcContext) || {};

  const [progress, setProgress] = useState(0);
  const [loading, setIsLoading] = useState(false);
  const [files, setFiles] = useState([]);
  const [errors, setErrors] = useState("");

  const onDropAccepted = async (acceptedFiles) => {
    setIsLoading(true);
    let data = new FormData();
    acceptedFiles.forEach((file) => {
      data.append("file", file);
    });
    await dispatch(
      validateNdcFile({
        data,
        successCallback: (res) => {
          if (res.statusCode === 200) {
            setFiles(acceptedFiles);
          } else {
            setFiles([]);
            setErrors(_get(res, "data.0", {}));
          }
        },
        setProgress,
        setLoading: setIsLoading,
      })
    );
  };

  const {
    getRootProps,
    getInputProps,
    isDragActive,
    isDragAccept,
    isDragReject,
    open,
  } = useDropzone({
    onDropAccepted,
    accept: {
      "application/vnd.ms-excel": [".xls", ".xlsx"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        ".xls",
        ".xlsx",
      ],
      "text/csv": [".csv"],
    },
    maxFiles: 1,
  });

  const style = useMemo(
    () =>
      getDroppableStyle({ isDragActive, isDragReject, isDragAccept, theme }),
    [isDragActive, isDragReject, isDragAccept]
  );

  const handleUpload = () => {
    let data = new FormData();
    let listHistoryId = ndcData.listHistoryId || 0;
    files.forEach((file) => {
      data.append("file", file);
    });
    dispatch(
      ndcBulkUpload({
        data,
        listHistoryId,
        callback: (res) => {
          setNdcSelectionBulkUploadReport(
            {
              ...res.data,
              bulkUploaded: true,
            } || {}
          );
          if (res.statusCode === 200) {
            handleNdcUploadSuccess(res.data);
            handleBulkUploadPopup(false);
          }
          if (res.statusCode === 404 && res.errorMessage) {
            handleBulkUploadPopup(false);
          }
        },
      })
    );
  };

  const getDropzoneContent = () => {
    if (loading) {
      return (
        <CircularBar
          value={progress}
          active
          label={`${progress}%`}
          style={{ color: theme.colors.green.active }}
        />
      );
    } else if (!loading && files.length) {
      if (files.length === 1) {
        return (
          <Grid container spacing={1} direction="column" alignItems="center">
            <Grid item>
              <img src={Excel} alt="excel-preview" width={35} height={35} />
            </Grid>
            <Grid item>{files[0].path}</Grid>
          </Grid>
        );
      } else {
        return (
          <Grid container spacing={1} direction="column" alignItems="center">
            {`${files.length} files selected`}
          </Grid>
        );
      }
    } else if (!loading && errors) {
      return (
        <Grid container spacing={1} direction="column" alignItems="center">
          <Grid item>
            <BasicTypography variant="caption" color="error">
              {errors}
            </BasicTypography>
          </Grid>
        </Grid>
      );
    }
    return (
      <Grid container spacing={1} direction="column" alignItems="center">
        <Grid item>
          <img src={DragDropUpload} />
        </Grid>
        <Grid item>
          <p>Drag and drop a file here</p>
        </Grid>
      </Grid>
    );
  };

  return (
    <Grid container direction="column" classes={{ root: classes.rowGap }}>
      <Grid item>
        <Grid
          container
          alignItems="center"
          justifyContent="space-between"
          spacing={2}
        >
          <Grid item>
            <BasicTypography variant="h5">
              Don't have the template?
            </BasicTypography>
          </Grid>
          <Grid item>
            <a href="/templates/NDC_template.xlsx">
              <Button
                startIcon={<img src={Excel} width={20} height={20} />}
                variant="outlined"
                color="primary"
                size="small"
                className={globalClasses.secondaryBtn}
              >
                Download Template
              </Button>
            </a>
          </Grid>
        </Grid>
      </Grid>
      <Grid item>
        <div {...getRootProps({ style })}>
          <input {...getInputProps()} />
          <div className={classes.droppableContainer}>
            {getDropzoneContent()}
          </div>
        </div>
      </Grid>
      <Grid item container justifyContent="center">
        <Grid item>
          <BasicTypography variant="h5">(OR)</BasicTypography>
        </Grid>
      </Grid>
      <Grid item container justifyContent="center" spacing={2}>
        <Grid item>
          {files.length ? (
            <Button
              color="primary"
              size="small"
              variant="contained"
              onClick={handleUpload}
              className={globalClasses.primaryBtn}
              disabled={loading}
            >
              Upload
            </Button>
          ) : (
            <Button
              color="primary"
              size="small"
              variant="contained"
              onClick={open}
              className={globalClasses.primaryBtn}
              disabled={loading}
            >
              Choose File
            </Button>
          )}
        </Grid>
        <Grid item>
          <Button
            size="small"
            variant="outlined"
            color="default"
            className={globalClasses.secondaryBtn}
            onClick={() => handleBulkUploadPopup(false)}
          >
            Close
          </Button>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default BulkUpload;
