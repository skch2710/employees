import { useDispatch } from "react-redux";
import { patientVisitInfoExport } from "../../../context/actions/Patients";
import { notNull } from "../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
const fileName = "Patients Visit Info List";

const ExportPatientVisitInfo = () => {
  const dispatch = useDispatch();

  const exportToExcel = ({
    patientPayload
  }) => {
    dispatch(
      patientVisitInfoExport(patientPayload, (res) => {
        var data = res.content.map(
          ({
            coveredEntity,
            tfbId,
            admitVisitDate,
            hospitalService,
            admitType,
            servicingFacility,
            assignedPatientLocation,
            providerNpi,
            providerFn,
            providerLn
          }) => ({
            "Covered Entity": notNull(coveredEntity),
            "340B ID": notNull(tfbId),
            "Visit Date": notNull(admitVisitDate),
            "Hospital Service": notNull(hospitalService),
            "Admit Type": notNull(admitType),
            "Servicing Facility": notNull(servicingFacility),
            "Assigned Patient Location": notNull(assignedPatientLocation),
            "Provider NPI": notNull(providerNpi),
            "Provider FN": notNull(providerFn),
            "Provider LN": notNull(providerLn)
          })
        );
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, {
          bookType: "xlsx",
          type: "array",
        });
        const fileData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(fileData, fileName + ".xlsx");
      })
    );
  };
  return { exportToExcel };
};

export default ExportPatientVisitInfo;
