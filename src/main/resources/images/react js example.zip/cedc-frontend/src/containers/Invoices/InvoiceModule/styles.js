import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const useInvoiceStyles = makeStyles((theme) => {
  return {
    cardContainer: {
      padding: "20px",
    },
    filterHeading: {
      color: theme.colors.monochrome.title,
      fontFamily: theme.fontFamily,
    },
    selectedCheckBox: {
      color: theme.colors.blue[500],
    },
    closeFilterIcon: {
      padding: "5px",
    },
    enableFilterButton: (props) => ({
      marginRight: getGridActionButtonsMarginRight(props),
      marginTop: "-38px",
      marginBottom: "6px",
      paddingLeft: "6px",
      minHeight: "30px",
    }),
    formActionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
    },
    exportContainer: {
      textAlign: "right",
      padding: "8px 10px 0 0",
    },
    exportSelect: {
      height: "30px",
      padding: "0 6px",
      borderRadius: "4px",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
    InvoiceEndDate: {
      margin: "27px 8px 0px 0px !important ",
    },
  };
});

export const InvoicesTabsStyles = makeStyles((theme) => ({
  tabsContainer: {
    borderBottom: `1px solid ${theme.colors.monochrome.border}`,
  },
  tabsIndicator: {
    background: theme.colors.blue[800],
  },
  tabsLabel: {
    textTransform: "capitalize",
    color: theme.colors.blue[800],
  },
  selectedTab: { color: theme.colors.blue[800] },
  tabPanelContainer: {
    padding: "0 12px",
    height: "100%",
  },
  headerContainer: {
    padding: "0 12px",
  },
}));
