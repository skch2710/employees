import moment from "moment";

export const getDynamicExclusionsMinDate = (selectedRows = []) => {
  const startDatesArray =
    selectedRows.map((row = {}) => {
      if (row.ndcEffecStartDate) {
        return moment(row.ndcEffecStartDate);
      }
      return moment();
    }) || [];
  return moment.max(startDatesArray).format("MM/DD/YYYY");
};

export const getAppliedExclusionsSavePayload = ({ list = [] } = {}) => {
  return (
    list.map(
      ({
        ndcExcDtlId = 0,
        listHistoryId = 0,
        isDynamicList = "Y",
        dynamicListId = 0,
        drugId = 0,
        ndcEffecStartDate = "",
        ndcEffecEndDate = "",
        gcn = "",
        ndc = "",
        drugManufacturerId = "",
        drugTherapeuticClassId = "",
      }) => {
        return {
          ndcExcDtlId,
          listHistoryId,
          isDynamicList,
          dynamicListId,
          drugId,
          gcn,
          ndc,
          drugManufacturerId,
          drugTherapeuticClassId,
          startDate: ndcEffecStartDate,
          endDate: ndcEffecEndDate,
        };
      }
    ) || []
  );
};

export const getDynamicExceptionsSavePayload = ({ list = [] } = {}) => {
  return (
    list.map(
      ({
        ndcExcDtlId = 0,
        listHistoryId = 0,
        dynamicListId = 0,
        drugId = 0,
        ndcEffecStartDate = "",
        ndcEffecEndDate = "",
        gcn = "",
        ndc = "",
        drugManufacturerId = "",
        drugTherapeuticClassId = "",
      }) => {
        return {
          ndcExcDtlId,
          listHistoryId,
          dynamicListId,
          drugId,
          gcn,
          ndc,
          drugManufacturerId,
          drugTherapeuticClassId,
          startDate: ndcEffecStartDate,
          endDate: ndcEffecEndDate,
        };
      }
    ) || []
  );
};
