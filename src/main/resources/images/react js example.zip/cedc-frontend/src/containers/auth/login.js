import React, { useEffect, useState } from "react";
import { useHistory, Link, useLocation } from "react-router-dom";
import { Typography } from "@material-ui/core";
import { Formik, Field, Form } from "formik";
import { Label } from "reactstrap";
import { Grid, Button } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import LoginImages from "./LoginImages";
import { login } from "../../context/actions/Auth";
import LoaderUI from "../../components/common/Loader/Loader";
import "./account.scss";
import Footer from "./footer";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import classNames from "classnames";
import { useLoginStyles } from "./styles";
import BasicTypography from "../../components/common/Typography/BasicTypography";

const EMAIL_RE = /\S+@\S+\.\S+/;

const Login = ({ location }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const classes = useLoginStyles();
  const globalClasses = useGlobalStyles();
  const routerLocation = useLocation();
  const [defaultValues, setDefaultValues] = useState({
    un: "",
    pw: "",
    cb: false,
  });
  const { state: locationState = {} } = location;
  const [ErrorMessage, setErrorMessage] = useState();

  const loader = useSelector((state) => state.user.loading);

  const handleSubmit = (values) => {
    if (values.cb)
      localStorage.setItem("rememberMeUserDetails", JSON.stringify(values));
    else localStorage.removeItem("rememberMeUserDetails");
    dispatch(
      login({ userName: values.un.trim(), password: values.pw }, (result) => {
        if (result.statusCode === 200) {
          if (result.otpEnable) {
            if (locationState.routeBack)
              history.push({
                pathname: "/login-verification",
                state: { routeBack: locationState.routeBack },
              });
            else history.push("/login-verification");
          } else {
            if (locationState.routeBack) history.push(locationState.routeBack);
            else history.push("/home");
          }
        } else {
          setErrorMessage(result.errorMessage);
        }
      })
    );
  };
  const formValidate = (values) => {
    let error = {};
    if (values.un.trim() === "") {
      error.un = "Please enter the Email ID";
    } else if (!EMAIL_RE.test(values.un)) {
      error.un = "Please enter the valid Email ID";
    } else if (values.un.trim().length > 50)
      error.un = "Email ID should not be more than 50 characters";
    if (values.pw.trim() === "") {
      error.pw = "Please enter the Password";
    }
    return error;
  };

  const replaceHistory = () => {
    history.replace({ ...routerLocation, state: undefined });
  };

  useEffect(() => {
    if (!locationState.message) {
      dispatch({ type: "RESET_APP" });
    }
    const userCredentials = JSON.parse(
      localStorage.getItem("rememberMeUserDetails") || "{}"
    );
    setDefaultValues({ ...defaultValues, ...userCredentials });

    // To remove any warnings on page refresh
    window.onbeforeunload = function () {
      replaceHistory();
    };
    return () => {
      window.onbeforeunload = null;
    };
  }, []);

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={defaultValues}
        onSubmit={handleSubmit}
        validate={formValidate}
      >
        {({ errors, touched }) => (
          <>
            <Grid className="login-bg">
              <Grid className="container-fluid">
                {loader && <LoaderUI />}
                <div className="row login-height">
                  <LoginImages />
                  <Grid className="col-12 col-lg-5 col-md-5 col-sm-12">
                    <Grid className="login-right-wrapper">
                      <Grid className="mb-3">
                        <Typography variant="h1">Welcome Back!</Typography>
                        <BasicTypography
                          variant="h2"
                          className={classNames(classes.signUpTitle, "mb-3")}
                        >
                          Sign in to continue
                        </BasicTypography>
                        {locationState.message && (
                          <Grid classes={{ root: classes.messageGrid }}>
                            {locationState.message}
                          </Grid>
                        )}
                        {ErrorMessage && (
                          <Grid classes={{ root: classes.messageGrid }}>
                            {ErrorMessage}
                          </Grid>
                        )}
                      </Grid>
                      <Form>
                        <Grid className="mb-3">
                          <Field
                            name="un"
                            type="text"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.userNameBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            id="exampleInputEmail1"
                            aria-describedby="emailHelp"
                            placeholder="Enter Email ID"
                            maxLength={50}
                          />
                          {touched.un && errors.un && (
                            <Typography color="error" variant="caption">
                              {errors.un}
                            </Typography>
                          )}
                        </Grid>
                        <Grid className="mb-3">
                          <Field
                            name="pw"
                            type="password"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.loginScreenInputFields,
                              globalClasses.passwordBackgroundIcon
                            )}
                            id="exampleInputPassword1"
                            placeholder="Enter Password"
                            maxLength={50}
                          />
                          {touched.pw && errors.pw && (
                            <Typography color="error" variant="caption">
                              {errors.pw}
                            </Typography>
                          )}
                        </Grid>
                        <div className="m-b-30 form-check">
                          {
                            <Field
                              type="checkbox"
                              name="cb"
                              className="form-check-input"
                              id="exampleCheck1"
                            />
                          }
                          <Label
                            className="form-check-label"
                            for="exampleCheck1"
                          >
                            Remember Me
                          </Label>
                          <Link
                            to="/forgot-password"
                            className="form-check-label flo-rig"
                          >
                            Forgot Password?
                          </Link>
                        </div>
                        <Button
                          color="primary"
                          disabled={loader}
                          type="submit"
                          className="btn btn-primary"
                          component="button"
                          variant="contained"
                          size="large"
                        >
                          Login
                        </Button>
                      </Form>
                    </Grid>
                  </Grid>
                </div>
              </Grid>
            </Grid>
          </>
        )}
      </Formik>
      <Footer />
    </>
  );
};
export default Login;
