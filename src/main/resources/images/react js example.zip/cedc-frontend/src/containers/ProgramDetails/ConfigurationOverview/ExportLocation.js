import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { locationsExport } from "../../../context/actions/Locations";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import { notNull } from "../../../utils/constants";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import "jspdf-autotable";
const fileName = "Location List";

const ExportLocation = ({
  ciId, 
  sortBy,
  sortOrder,
  count,
}) => {
  const dispatch = useDispatch();
  const classes = useStyles()

  const [values, setValues] = useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const dataa = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8" });
    FileSaver.saveAs(dataa, fileName + ".xlsx");
  };

  let heads = [];
  let rows = [];

  const ExportTOPDF = (data) => {
    const listheads = data.map((i) => {
      let keys_heads = {
        "Source": Object.keys(i)[0],
        "Participating 340B Site" : Object.keys(i)[1],
        "Covered Entity": Object.keys(i)[2],
        "Location Name": Object.keys(i)[3],
        "Location HRSA ID": Object.keys(i)[4],
        "Address Line 1": Object.keys(i)[5],
        "Address Line 2": Object.keys(i)[6],
        City: Object.keys(i)[7],
        State: Object.keys(i)[8],
        Zip: Object.keys(i)[9],
        "Start Date": Object.keys(i)[10],
        "End Date": Object.keys(i)[11],
        "last Modified Date" : Object.keys(i)[12],
      };
      heads.push(keys_heads);
    });

    const listrows = data.map((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
      locationsExport(
        {
          pageNumber: 1,
          pageSize: 1000,
          ceid: [ciId],
          sortBy: sortBy,
          sortOrder: sortOrder,
          startDate:"",
          endDate:"",
          entityLocationID:  [],
          export: true,
        },
        function (result) {
          var data = result.content.map(
            ({
              source,
              coveredEntity,
              locationName,
              locationHrsaId,
              site340b,
              addressLine1,
              addressLine2,
              city,
              state,
              zip,
              startDate,
              endDate,
              lastModifiedDate
            }) => ({
              "Source":notNull(source),
              "Participating 340B Site": notNull(site340b === 'true' ? 'Yes' : 'No'),
              "Covered Entity": notNull(coveredEntity),
              "Location Name": notNull(locationName),
              "Location HRSA ID": notNull(locationHrsaId),
              "Address Line 1": notNull(addressLine1),
              "Address Line 2": notNull(addressLine2),
              City: notNull(city),
              State: notNull(state),
              Zip: notNull(zip),
              "Start Date": notNull(startDate),
              "End Date": notNull(endDate),
              "last Modified Date" : notNull(lastModifiedDate)
            })
          );

          if (e.target.value == "excel") {
            setTimeout(ExportToExcel(data), 5000);
            setValues("");
          }
          if (e.target.value == "pdf") {
            setTimeout(ExportTOPDF(data), 5000);
            const doc = new jsPDF();
            doc.autoTable({
              head: [heads[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...rows],
            });
            doc.save("location_sheet.pdf");
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset disabled={count > 0 ? false : true} className={classes.exportAlign}>
        <select onChange={handleChange} value={values}>
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default ExportLocation;
