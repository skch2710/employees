import React, { useState, useEffect, useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Button,
  Grid,
  Checkbox,
  FormControlLabel,
  Tooltip,
  FormLabel,
} from "@material-ui/core";
import Eligibilityconfigpopup from "./Eligibilityconfigpopup";
import {
  fetchTermsGridTableData,
  getCoServiceAreaConfig,
  getServiceArea,
  getServiceConfigLookup,
  saveServiceArea,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import { getUserSession } from "../../../../../../utils/helper";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { serviceAreaPopUpStyles } from "./styles";
import { POLLING_COUNT } from "../../../../../../utils/constants";
import _isArray from "lodash/isArray";

const Servicearea = ({ clickOnAdd }) => {
  const classes = serviceAreaPopUpStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    messageUuid,
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext);
  const { serviceArea } = menusStatuses;

  const [OpenPopup, setOpenPopup] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [isConfigurable, setIsConfigurable] = useState(true);
  const [loader, setLoader] = useState(false);
  const [tempData, setTempData] = useState(null);
  const [openConfirmationPopUp, setOpenConfirmationPopUp] = useState(false);
  const [checkBoxDisabled, setCheckBoxDisabled] = useState(false);

  const serviceAreaData = useSelector((state) => state.getServiceLookUp.data);
  const userSession = getUserSession();
  const initialServiceData =
    serviceAreaData && _isArray(serviceAreaData) && serviceAreaData.length > 0
      ? [
          ...(serviceAreaData[0]["Admit Type"] || []),
          ...(serviceAreaData[0]["Hospital Service"] || []),
          ...(serviceAreaData[0]["Servicing Facility"] || []),
          ...(serviceAreaData[0]["Patient Location"] || []),
          ...(serviceAreaData[0]["Patient Type"] || []),
        ]
      : [];

  useEffect(() => {
    dispatch(getServiceConfigLookup({ ceid: messageUuid.ceid }));
  }, []);

  useEffect(() => {
    checkForEligibleConfigs();
  }, [serviceAreaData]);

  const onChangeCheckBox = (event) => {
    if (event.target.checked == true) {
      event && event.preventDefault();
      setOpenConfirmationPopUp(true);
    } else {
      setIsConfigurable(true);
      setIsChecked(false);
    }
  };

  const checkForEligibleConfigs = () => {
    if (initialServiceData && initialServiceData.length > 0) {
      const availableConfigs = initialServiceData;
      const eligibleConfigs = availableConfigs.filter(
        (config) => config.inactiveFlag === "N"
      );
      if (availableConfigs.length === eligibleConfigs.length) {
        setIsChecked(true);
        setIsConfigurable(false);
      } else {
        setIsChecked(false);
        setIsConfigurable(true);
      }
      setCheckBoxDisabled(false);
    } else {
      setIsChecked(true);
      setCheckBoxDisabled(true);
      setIsConfigurable(false);
    }
  };

  const submitData = (type, data) => {
    setLoader(true);
    const payload = data;
    const availableCount = initialServiceData.length;
    const payloadCountWithDeselectedTrue = payload.filter(
      (item) => item.deselected
    ).length;

    const payloadCountWithVisitIds = payload.filter(
      (item) => item.ceEligibleItemId
    ).length;

    // If All available configs are deselected=true and none have a visitId,
    // then no need to hit Pub-Sub API, else trigger the API.
    if (
      payloadCountWithDeselectedTrue === availableCount &&
      payloadCountWithVisitIds === 0
    ) {
      updateSectionStatusAndNavigate(type);
    } else {
      dispatch(
        saveServiceArea({ configItemIds: payload }, (res) => {
          if (res.statusCode === 200) {
            handlePolling({
              messageUUID: res.data,
              currentCount: POLLING_COUNT,
              type: type,
            });
          } else {
            setLoader(false);
          }
        })
      );
    }
  };

  const handlePolling = async ({ messageUUID, currentCount, type }) => {
    const count = currentCount;
    dispatch(
      getServiceArea({ messageuuid: messageUUID }, (response) => {
        if (response.statusCode === 200) {
          // Update Section Status on SA update Success
          updateSectionStatusAndNavigate(type);
        } else if (response && response.statusCode === 102 && count > 1) {
          handlePolling({ messageUUID, currentCount: count - 1, type });
        } else {
          setLoader(false);
        }
      })
    );
  };

  const updateSectionStatusAndNavigate = (type) => {
    dispatch(
      updateSectionStatus({
        ceId: messageUuid.ceid,
        sectionId: 9,
        callback,
      })
    );
    setLoader(false);
    // If stays wizard popup fetch updated SA config for wizard
    // If exits Wizard popup fetch updated SA config for CO screen
    if (type) {
      if (type !== "stayInCurrentSection") {
        setPopupActiveMenu(MENUS.CE_VISIT_WINDOW);
      }
      dispatch(getServiceConfigLookup({ ceid: messageUuid.ceid }));
    } else {
      dispatch(getCoServiceAreaConfig(messageUuid.ceid));
      setOpenAddCePopup(false);
    }
  };

  const handleSave = (json) => {
    setTempData(json);
  };

  const callback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({
        ...prev,
        serviceArea: false,
      }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  const cancelConfirmation = () => {
    setOpenConfirmationPopUp(false);
  };

  const approveConfirmation = async () => {
    let array = [];
    if (serviceAreaData && serviceAreaData.length > 0) {
      let json = initialServiceData;
      json.map((key) => {
        let obj = {
          ceid: messageUuid && messageUuid.ceid,
          configItemId: key.configItemId,
          deselected: true,
          createdById: userSession.createdBy,
          modifiedById: userSession.userId,
        };
        //  As per latest API changes (as on 06 Feb 2023), if we get 'ceVisitItemId' as null
        //  in GET call then consider that config as 'New', in this case we need not pass 'ceEligibleItemId' key
        if (key.ceVisitItemId) {
          obj["ceEligibleItemId"] = key.ceVisitItemId;
        }
        array.push({ ...obj });
      });
      if (array.length > 0) {
        submitData("stayInCurrentSection", array);
        setIsChecked(true);
        setIsConfigurable(false);
        setOpenConfirmationPopUp(false);
      } else {
        setIsChecked(false);
        setIsConfigurable(true);
        setOpenConfirmationPopUp(false);
      }
    }
  };

  return (
    <>
      {loader && <LoaderUI />}
      <Grid container spacing={2}>
        <Grid item md={12}>
          <Grid container spacing={2}>
            <Grid item md={12}>
              <BasicTypography
                variant="h4"
                title="Covered Entity Configuration > Service Area Configurations"
              />
            </Grid>

            <Grid item md={12}>
              <BasicTypography variant="h5" title="Eligibility Configuration" />
            </Grid>

            <Grid item md={12}>
              <Grid container spacing={2} justifyContent="space-between">
                <Grid item>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="serviceAreas"
                        color="primary"
                        size="small"
                        checked={isChecked}
                        disabled={checkBoxDisabled}
                        onClick={onChangeCheckBox}
                      />
                    }
                    label={
                      <FormLabel className={globalClasses.noPaddingForLabels}>
                        No ineligible services, types, or facilities
                      </FormLabel>
                    }
                  />
                </Grid>
                <Grid item>
                  <Tooltip
                    title={
                      serviceAreaData && serviceAreaData.length === 0
                        ? "To configure eligibility, please upload patient data."
                        : "Configure Eligibility"
                    }
                  >
                    <span>
                      <Button
                        type="button"
                        size="small"
                        variant="outlined"
                        disabled={
                          serviceAreaData &&
                          serviceAreaData.length > 0 &&
                          isConfigurable
                            ? false
                            : true
                        }
                        className={globalClasses.secondaryBtn}
                        onClick={() => {
                          setOpenPopup(true);
                        }}
                      >
                        Configure Eligibility
                      </Button>
                    </span>
                  </Tooltip>
                </Grid>
              </Grid>
            </Grid>
            <Grid item md={12}>
              <div className={classes.globalErrorMsg}>
                {!isConfigurable && checkBoxDisabled && (
                  <BasicTypography
                    title={
                      "To configure Service Areas, please upload patient data."
                    }
                  />
                )}
              </div>
            </Grid>
          </Grid>
        </Grid>
        <Grid item md={12}>
          <Grid container justifyContent="flex-end" spacing={2}>
            <Grid item>
              <Button
                type="submit"
                color="primary"
                size="small"
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  tempData && _isArray(tempData) && tempData.length > 0
                    ? submitData(true, tempData)
                    : setPopupActiveMenu(MENUS.CE_VISIT_WINDOW);
                }}
              >
                Next
              </Button>
            </Grid>
            <Grid item>
              <Button
                type="reset"
                size="small"
                variant="outlined"
                className={globalClasses.secondaryBtn}
                onClick={() => {
                  setPopupActiveMenu(MENUS.CE_VISIT_WINDOW);
                }}
              >
                Skip
              </Button>
            </Grid>
            <Grid item>
              <Button
                type="reset"
                size="small"
                variant="outlined"
                className={globalClasses.secondaryBtn}
                onClick={() => {
                  tempData && _isArray(tempData) && tempData.length > 0
                    ? submitData(false, tempData)
                    : setOpenAddCePopup(false);
                }}
              >
                Save and Exit
              </Button>
            </Grid>
            <Grid item>
              <Button
                type="reset"
                size="small"
                variant="outlined"
                className={globalClasses.secondaryBtn}
                onClick={() => {
                  setOpenAddCePopup(false);
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      {OpenPopup && (
        <BasicPopup
          title="Configure Eligibility"
          show={OpenPopup}
          handleClose={() => {
            setOpenPopup(false);
          }}
          disableFooter={true}
          dialogProps={{
            maxWidth: "md",
          }}
        >
          <Eligibilityconfigpopup
            handleSave={handleSave}
            setOpenPopup={setOpenPopup}
            clickOnAdd={clickOnAdd}
            serviceAreaData={serviceAreaData}
          />
        </BasicPopup>
      )}
      {openConfirmationPopUp && (
        <BasicPopup
          show={openConfirmationPopUp}
          handleClose={cancelConfirmation}
          title={"Config Reset Warning"}
          submitProps={{
            buttonTitle: "Yes",
            handleSubmit: approveConfirmation,
          }}
          cancelProps={{
            buttonTitle: "No",
            handleCancel: cancelConfirmation,
          }}
        >
          Make All available Configurations as eligible
        </BasicPopup>
      )}
    </>
  );
};
export default Servicearea;
