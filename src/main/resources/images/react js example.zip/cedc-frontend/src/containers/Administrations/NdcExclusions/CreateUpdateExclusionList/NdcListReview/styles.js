import { makeStyles } from "@material-ui/core";

export const useNdcListReviewStyles = makeStyles((theme) => {
  return {
    listHistoryPadding: {
      padding: "16px",
    },
    listHistoryItem: {
      borderTop: `3px solid ${theme.colors.monochrome.tableHeaderBackground}`,
      display: "flex",
      alignItems: "center",
    },
    listHistoryCard: {
      backgroundColor: theme.colors.monochrome.offWhite,
      borderRadius: "10px",
      boxShadow: "0 0 18px rgb(78 125 150 / 8%)",
      border: `1px solid ${theme.colors.secondary.default}`,
    },
    historyItemsContainer: {
      backgroundColor: theme.colors.grey.cardBackground,
    },
    historyItemUser: {
      color: theme.colors.grey.inactive,
    },
    activeHistoryItem: {
      color: theme.colors.green.default,
    },
    inactiveHistoryItem: {
      color: theme.colors.yellow.default,
    },
    timeStamp: {
      color: theme.colors.monochrome.label,
      fontSize: "11px",
      lineHeight: "20px",
    },
    viewHistoryLinkItem: {
      display: "flex",
      justifyContent: "flex-end",
    },
    viewHistoryLink: {
      color: theme.colors.blue.default,
      textDecoration: "underline",
      cursor: "pointer",
    },
    iconWrapper: {
      cursor: "pointer",
    },
    editIcon: {
      marginLeft: "2px",
      width: "16px",
      height: "16px",
    },
    exportPdf: {
      border: `1px solid ${theme.colors.monochrome.border}`,
      float: "right",
      padding: "1px 6px 2px 2px",
      fontSize: "12px",
      textTransform: "capitalize",
    },
  };
});
