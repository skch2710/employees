import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import { userdata } from "../../../utils/common";
import { pagination } from "../../../utils/constants";
const userSessionData = JSON.parse(userdata());
export const TABLE_CELL_STYLE = {
  fontSize: "11px",
  whiteSpace: "nowrap",
  padding: "12px",
  textAlign: "left",
};

export const fetchPatientDefaultValues = (patientSearchData) => {
  const {
    ceid,
    dob,
    firstName,
    lastName,
    startDate,
    endDate,
    mrn,
    patientType,
    sortBy,
    sortOrder,
    pageNumber,
    pageSize,
  } = patientSearchData || {};
  return {
    ceid: ceid,
    dob: dob,
    endDate: endDate,
    firstName: firstName,
    lastName: lastName,
    export: false,
    mrn: mrn,
    sortBy: sortBy,
    sortOrder: sortOrder,
    pageNumber: pageNumber,
    pageSize: pageSize,
    startDate: startDate,
    patientType: patientType,
  };
};

export const getFilteredPatientDefaultValue = (ceList, searchParamCeId) => {
  return {
    ceid: !searchParamCeId ? ceList.length > 0 && ceList[0].ceID : Number(searchParamCeId),
    dob: "",
    firstName: "",
    lastName: "",
    patientType: "",
    mrn: "",
    startDate: "",
    endDate: "",
    status: "Active"
  };
};

export const getPatientVisitDefaultValue = (data) => {
  const { patientId, personId } = data || {};
  return {
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "",
    sortOrder: "",
    filter: [],
    export: false,
    patientId: patientId || personId,
  };
};

export const addPatientDefaultValues = (
  recordForEdit,
  ceList,
  memberConfigFile
) => {
  const {
    ceid,
    dateOfBirth,
    personTypeId,
    firstName,
    gender,
    lastName,
    middleName,
    suffix,
    recentVisitDate,
  } = (recordForEdit && recordForEdit.patientDTO) || {};
  const {
    effectiveDate,
    mrn,
    slidingScaleEffectiveDate,
    slidingScale,
    terminationDate,
    personEligibilityId,
  } = (recordForEdit && recordForEdit.patientEligibilityDTO) || {};
  const ceObj =
    (ceList &&
      ceList.find(
        (obj) => obj.ceID == (ceid || (recordForEdit && recordForEdit.ceid))
      )) ||
    {};
  const coveredEntity =
    !userSessionData.isInternalUser && userSessionData.coveredEntityDTOs[0];

  let terminateDate;
  if (terminationDate && recordForEdit.status == "Inactive") {
    terminateDate = moment(terminationDate).format("MM/DD/YYYY");
  } else if (
    recentVisitDate &&
    !_isEmpty(memberConfigFile) &&
    memberConfigFile.eligibilityPeriod
  ) {
    terminateDate = moment(recentVisitDate)
      .add(memberConfigFile.eligibilityPeriod, "d")
      .format("MM/DD/YYYY");
  } else if (recentVisitDate) {
    terminateDate = moment(recentVisitDate).format("MM/DD/YYYY");
  }
  return {
    ceid: coveredEntity.ceID || ceObj.ceID || 0,
    ceName: ceObj.ceName || "",
    ID340B: coveredEntity.ceCode || ceObj.ceCode || "",
    mrn: mrn || "",
    firstName: firstName || "",
    middleName: middleName || "",
    lastName: lastName || "",
    suffix: suffix || "",
    dateOfBirth: dateOfBirth || "",
    gender: gender || "",
    recentVisitDate: recentVisitDate || "",
    effectiveDate: effectiveDate || "",
    terminationDate: terminateDate || "",
    personTypeId: personTypeId || 2,
    visitDate: "",
    hospitalServiceId: 0,
    admitTypeId: 0,
    servicingFacilityId: 0,
    patientLocationId: 0,
    slidingScaleEffectiveDate: slidingScaleEffectiveDate || "",
    slidingScale: slidingScale || "",
    prescriberId: 0,
    newSlidingScale: "",
    inactiveFlag: "N",
    providerFirstName: "",
    providerLastName: "",
    providerSpi: "",
    providerDea: "",
    createdBy: userSessionData.userId,
    modifiedBy: userSessionData.userId,
    personId: recordForEdit && recordForEdit.personId,
    personEligibilityId: personEligibilityId || 0,
  };
};

export const addPatientPayload = (data) => {
  return {
    patientDTO: {
      ceid: data.ceid,
      firstName: data.firstName,
      lastName: data.lastName,
      middleName: data.middleName,
      dateOfBirth: data.dateOfBirth,
      gender: data.gender,
      suffix: data.suffix,
      source: data.source,
      personTypeId: data.personTypeId,
      source: "",
    },
    patientVisitDTO: [
      {
        visitDate: data.visitDate,
        hospitalServiceId: Number(data.hospitalServiceId),
        admitTypeId: Number(data.admitTypeId),
        servicingFacilityId: Number(data.servicingFacilityId),
        patientLocationId: Number(data.patientLocationId),
        prescriberId: data.prescriberId == 0 ? null : data.prescriberId,
        inactiveFlag: data.inactiveFlag,
      },
    ],
    patientEligibilityDTO: {
      slidingScale:
        data.slidingScale === "Other"
          ? data.newSlidingScale
          : data.slidingScale,
      effectiveDate: data.effectiveDate,
      mrn: data.mrn,
      terminationDate: data.terminationDate,
      slidingScaleEffectiveDate: data.slidingScaleEffectiveDate,
    },
    createdById: data.createdBy || 1,
    modifiedById: data.modifiedBy || 1,
  };
};

export const addVisitPayload = (data) => {
  const {
    patientId,
    visitDate,
    hospitalServiceId,
    admitTypeId,
    servicingFacilityId,
    patientLocationId,
    prescriberId,
    inactiveFlag,
    createdBy,
    modifiedBy,
  } = data || {};
  return {
    personId: patientId,
    visitDate: visitDate,
    hospitalServiceId: Number(hospitalServiceId),
    admitTypeId: Number(admitTypeId),
    servicingFacilityId: Number(servicingFacilityId),
    patientLocationId: Number(patientLocationId),
    prescriberId: prescriberId == 0 ? null : prescriberId,
    inactiveFlag: inactiveFlag,
    createdById: createdBy || 1,
    modifiedById: modifiedBy || 1,
  };
};

export const patientVisitPayload = (patientVisitInfo) => {
  return (
    patientVisitInfo &&
    _isArray(patientVisitInfo.content) &&
    patientVisitInfo.content.map(
      ({
        admitVisitDate,
        admitTypeId,
        hospitalServiceId,
        patientLocationId,
        personVisitId,
        prescriberId,
        servicingFacilityId,
      }) => {
        return {
          personVisitId: personVisitId,
          visitDate: admitVisitDate,
          hospitalServiceId: Number(hospitalServiceId),
          admitTypeId: Number(admitTypeId),
          servicingFacilityId: Number(servicingFacilityId),
          patientLocationId: Number(patientLocationId),
          prescriberId: prescriberId == 0 ? null : prescriberId,
          inactiveFlag: "N",
        };
      }
    )
  );
};

export const validationMessages = (value, title) => {
  let error = "";
  const patientDetailError =
    !value.ceid ||
    value.firstName === "" ||
    value.lastName === "" ||
    value.mrn === "" ||
    value.dateOfBirth === "" ||
    value.gender === "" ||
    value.effectiveDate === "";
  const visitInfoError = title === "Add Patient" && value.visitDate === "";
  if (patientDetailError && visitInfoError) {
    error =
      "Please fill the patient basic details and visit info required fields.";
  } else if (patientDetailError) {
    error = "Please fill the patient basic details required fields.";
  } else if (visitInfoError) {
    error = "Please fill the visit info required fields.";
  }
  return error;
};
