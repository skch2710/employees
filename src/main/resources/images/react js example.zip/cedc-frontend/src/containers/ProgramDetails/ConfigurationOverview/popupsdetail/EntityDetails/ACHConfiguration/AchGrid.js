import React from "react";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import MaterialTable, { MTableToolbar } from "material-table";
import { tableCellGlobalJson } from "../../../../../../components/common/Table/usetableStyle";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Paper, useTheme, Tooltip } from "@material-ui/core";
import { useAchTableStyles } from "./style";
import { formatDate } from "../../../../../../utils/common";
import { useSelector } from "react-redux";
import {
  useGlobalStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { getTableHeaderCount } from "../../../../../../utils/helper";

const AchGrid = ({ wizard = false, achActions = [] }) => {
  const classes = useAchTableStyles();
  const theme = useTheme();
  const globalClasses = useGlobalStyles();

  const { achConfig = [], loading } =
    useSelector((state) => state.ceAchConfig) || {};

  const ACH_COLUMNS = [
    {
      title: "Account Number",
      field: "payerAccountNumber",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.payerAccountNumber || ""}>
            <span>{rowData.payerAccountNumber || ""}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Routing Number",
      field: "routingNumber",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.routingNumber || ""}>
            <span>{rowData.routingNumber || ""}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Bank Name",
      field: "bankName",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bankName || ""}>
            <span>{rowData.bankName || ""}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "% of Remittance",
      field: "percentageOfRemittance",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.percentageOfRemittance || ""}>
            <span>{rowData.percentageOfRemittance || ""}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Penny Test Completed",
      field: "pennyTestCompleted",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pennyTestCompleted == true ? "Yes" : "No"}>
            <span>{rowData.pennyTestCompleted == true ? "Yes" : "No"}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Penny Test Completion Date",
      field: "startDatePennyTestCompleted",
      render: (rowData) => {
        return (
          <Tooltip title={formatDate(rowData) || ""}>
            <span>{formatDate(rowData) || ""}</span>
          </Tooltip>
        );
      },
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`ACH Details (${getTableHeaderCount(achConfig.length)})`}
          />
        }
        columns={ACH_COLUMNS}
        data={achConfig || []}
        actions={wizard ? achActions : []}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
          },
        }}
        isLoading={loading}
        options={{
          search: false,
          sorting: false,
          actionsColumnIndex: 0,
          paging: false,
          showFirstLastPageButtons: false,
          paginationPosition: "top",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          maxBodyHeight: 400,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};
export default AchGrid;
