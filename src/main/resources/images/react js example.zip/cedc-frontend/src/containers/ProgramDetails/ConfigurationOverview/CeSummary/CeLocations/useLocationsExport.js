import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import _isEmpty from "lodash/isEmpty";
import { getCeLocationPayloadJson } from "./helper";
import { getCeLocations } from "../../../../../context/actions/ConfigOverview";
const fileName = "Locations List";

const useLocationExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = async ({ ceId, controllers, columnFilters }) => {
    const tableData = await dispatch(
      getCeLocations(
        getCeLocationPayloadJson({
          ceId,
          sortBy: controllers.sortBy,
          sortOrder: controllers.sortOrder,
          filter: columnFilters,
          export: true,
        })
      )
    );
    if (!_isEmpty(tableData)) {
      var data = tableData.content.map(
        ({
          coveredEntity,
          locationName,
          locationHrsaId,
          site340b,
          addressLine1,
          addressLine2,
          city,
          state,
          zip,
          startDate,
          endDate,
          locationStatus,
          source,
        }) => ({
          Source: source || "",
          "Participating 340B Site": site340b === "true" ? "Yes" : "No",
          "Covered Entity": coveredEntity || "",
          "Location Name": locationName || "",
          "Location HRSA ID": locationHrsaId || "",
          "Address Line 1": addressLine1 || "",
          "Address Line 2": addressLine2 || "",
          City: city || "",
          State: state || "",
          Zip: zip || "",
          "OPA Location Start Date": startDate || "",
          "OPA Location End Date": endDate || "",
          "Status": locationStatus || "",
        })
      );
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, fileName + ".xlsx");
    }
  };
  return { exportToExcel };
};

export default useLocationExport;
