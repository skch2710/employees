import { pagination } from "../../../../../utils/constants";

export const getCeLocationPayloadJson = (values = {}) => {
  const { ceId, ...rest } = values;
  return {
    ceid: [values.ceId],
    startDate: "",
    endDate: "",
    site340B: "",
    city: "",
    locationHrsaId: "",
    stateId: 0,
    parentId: 0,
    entityLocationID: [],
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "",
    sortOrder: "",
    filter: [],
    export: false,
    ...rest,
  };
};

export const getCeLocationsFiltersObject = (filters = []) => {
  const dateFields = ["site340b", "startDate", "endDate", "lastModifiedDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};
