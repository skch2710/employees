export const MENUS = {
  CE_BASIC_DETAILS: 1,
  CE_BILLING_AND_FEES: 2,
  CE_ACH_CONFIGURATION: 3,
  CE_ELIGIBILITY: 4,
  CE_BIN_PCN: 5,
  CE_LOCATIONS: 6,
  CE_PROVIDERS: 7,
  CE_MEMBERS: 8,
  CE_SERVICE_AREA: 9,
  CE_VISIT_WINDOW: 10,
  PH_VIEW_PHARMACIES: 11,
  PH_BASIC_DETAILS: 12,
  PH_BILLING_AND_FEES: 13,
  PH_ELIGIBILITY: 14,
  PH_ORDERING_AND_REPLENISHMENT: 15,
  PH_BIN_PCN: 16,
  CE_ORDERING_CONFIGURATION: 0,
};

export const MENUS_ID_TO_NAME = {
  1: "CE_BASIC_DETAILS",
  2: "CE_BILLING_AND_FEES",
  3: "CE_ACH_CONFIGURATION",
  4: "CE_ELIGIBILITY",
  5: "CE_BIN_PCN",
  6: "CE_LOCATIONS",
  7: "CE_PROVIDERS",
  8: "CE_MEMBERS",
  9: "CE_SERVICE_AREA",
  10: "CE_VISIT_WINDOW",
  11: "PH_VIEW_PHARMACIES",
  12: "PH_BASIC_DETAILS",
  13: "PH_BILLING_AND_FEES",
  14: "PH_ELIGIBILITY",
  15: "PH_ORDERING_AND_REPLENISHMENT",
  16: "PH_BIN_PCN",
  0: "CE_ORDERING_CONFIGURATION",
};
export const CO_MENUS = {
  ENTITY_DETAILS: "entityDetails",
  CE_CONFIGURATION: "ceConfiguration",
  PH_CONFIGURATION: "phConfiguration",
};

export const getPopupMenus = (
  partialMenuObj = {},
  phConfigMenuObj = {},
  activeInactiveCOMenus = {}
) => {
  return [
    {
      id: CO_MENUS.ENTITY_DETAILS,
      title: "Entity Details",
      icon: true,
      subNav: [
        {
          id: MENUS.CE_BASIC_DETAILS,
          title: "Basic Details",
          isPartialCompleted: partialMenuObj.basicDetails || false,
          disabled: !activeInactiveCOMenus[MENUS.CE_BASIC_DETAILS],
        },
        {
          id: MENUS.CE_BILLING_AND_FEES,
          title: "340BDirect+ Admin Billing and Fees",
          isPartialCompleted: partialMenuObj.billingAndFee || false,
          disabled: !activeInactiveCOMenus[MENUS.CE_BILLING_AND_FEES],
        },
        {
          id: MENUS.CE_ACH_CONFIGURATION,
          title: "ACH Configuration",
          isPartialCompleted: partialMenuObj.achConfiguration || false,
          disabled: !activeInactiveCOMenus[MENUS.CE_ACH_CONFIGURATION],
        },
        {
          id: MENUS.CE_ELIGIBILITY,
          title: "Eligibility Rules",
          isPartialCompleted: partialMenuObj.ceEligibility || false,
          disabled: !activeInactiveCOMenus[MENUS.CE_ELIGIBILITY],
        },
        {
          id: MENUS.CE_ORDERING_CONFIGURATION,
          title: "Ordering Configuration",
          isPartialCompleted: false,
          disabled: !activeInactiveCOMenus[MENUS.CE_ORDERING_CONFIGURATION],
        },
      ],
    },
    {
      title: "Covered Entity Configuration",
      id: CO_MENUS.CE_CONFIGURATION,
      icon: true,
      subNav: [
        {
          id: MENUS.CE_LOCATIONS,
          title: "Covered Entity Locations",
          isPartialCompleted: partialMenuObj.coLocation || false,
        },
        {
          id: MENUS.CE_PROVIDERS,
          title: "Providers",
          isPartialCompleted: partialMenuObj.provider || false,
        },
        {
          id: MENUS.CE_MEMBERS,
          title: "Patients",
          isPartialCompleted: partialMenuObj.member || false,
        },
        {
          id: MENUS.CE_SERVICE_AREA,
          title: "Service Area",
          isPartialCompleted: partialMenuObj.serviceArea || false,
        },
        {
          id: MENUS.CE_VISIT_WINDOW,
          title: "Visit Window",
          isPartialCompleted: partialMenuObj.visitWindow || false,
        },
      ],
    },
    {
      title: "Pharmacy Configuration",
      id: CO_MENUS.PH_CONFIGURATION,
      icon: true,
      subNav: [
        {
          id: MENUS.PH_VIEW_PHARMACIES,
          title: "Select Pharmacy",
        },
        {
          id: MENUS.PH_BASIC_DETAILS,
          title: "Basic Details",
          isPartialCompleted: phConfigMenuObj.phBasicDetails || false,
          disabled: !activeInactiveCOMenus[MENUS.PH_BASIC_DETAILS],
        },
        {
          id: MENUS.PH_BILLING_AND_FEES,
          title: "Billing and Fees",
          isPartialCompleted: phConfigMenuObj.phBillingAndFee || false,
          disabled: !activeInactiveCOMenus[MENUS.PH_BILLING_AND_FEES],
        },
        {
          id: MENUS.PH_ELIGIBILITY,
          title: "Eligibility",
          isPartialCompleted: phConfigMenuObj.phEligibility || false,
          disabled: !activeInactiveCOMenus[MENUS.PH_BILLING_AND_FEES],
        },
        {
          id: MENUS.PH_ORDERING_AND_REPLENISHMENT,
          title: "Ordering and Replenishment",
          isPartialCompleted: phConfigMenuObj.orderingAndRepl || false,
          disabled: !activeInactiveCOMenus[MENUS.PH_BILLING_AND_FEES],
        },
      ],
    },
  ];
};

export const collapseItemParentMapping = {
  [MENUS.CE_BASIC_DETAILS]: "entityDetails",
  [MENUS.CE_BILLING_AND_FEES]: "entityDetails",
  [MENUS.CE_ACH_CONFIGURATION]: "entityDetails",
  [MENUS.CE_ELIGIBILITY]: "entityDetails",
  [MENUS.CE_BIN_PCN]: "entityDetails",
  [MENUS.CE_LOCATIONS]: "ceConfiguration",
  [MENUS.CE_PROVIDERS]: "ceConfiguration",
  [MENUS.CE_MEMBERS]: "ceConfiguration",
  [MENUS.CE_SERVICE_AREA]: "ceConfiguration",
  [MENUS.CE_VISIT_WINDOW]: "ceConfiguration",
  [MENUS.PH_VIEW_PHARMACIES]: "phConfiguration",
  [MENUS.PH_BASIC_DETAILS]: "phConfiguration",
  [MENUS.PH_BILLING_AND_FEES]: "phConfiguration",
  [MENUS.PH_ELIGIBILITY]: "phConfiguration",
  [MENUS.PH_ORDERING_AND_REPLENISHMENT]: "phConfiguration",
  [MENUS.PH_BIN_PCN]: "phConfiguration",
  [MENUS.CE_ORDERING_CONFIGURATION]: "entityDetails",
};
