import React, { useContext } from "react";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Button, Grid } from "@material-ui/core";
import Tooltip from "@mui/material/Tooltip";
import PreferredLocation from "../../../../Locations/PreferredLocation";
import excel from "../../../../../../assets/excel.png";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useCeLocationsStyles } from "./styles";
import _isEmpty from "lodash/isEmpty";
import classNames from "classnames";

const Locations = ({
  isConfigOverview,
  locatPermissionObj,
  clickOnAdd,
  isinternaluser,
}) => {
  const globalClasses = useGlobalStyles();
  const classes = useCeLocationsStyles();
  const { setPopupActiveMenu, setOpenAddCePopup, messageUuid } =
    useContext(COContext) || {};

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={12}>
          <Grid
            container
            spacing={2}
            justifyContent="space-between"
            alignItems="center"
          >
            <Grid item md={6}>
              <BasicTypography
                variant="h4"
                title="Covered Entity Configuration > Locations"
              />
            </Grid>
            <Grid item md={6} container justifyContent="flex-end">
              <Tooltip
                title={
                  !_isEmpty(locatPermissionObj) &&
                  !locatPermissionObj.readWriteFlag
                    ? "You don't have Permission."
                    : ""
                }
              >
                <a
                  href={`/templates/Locations_Template.xlsx`}
                  download="Locations_Template"
                  className={classNames(
                    globalClasses.iconPlusClickableLink,
                    !_isEmpty(locatPermissionObj) &&
                      locatPermissionObj.readWriteFlag
                      ? null
                      : globalClasses.disabledDownloadTemp
                  )}
                  disabled={
                    !_isEmpty(locatPermissionObj) &&
                    locatPermissionObj.readWriteFlag
                      ? false
                      : true
                  }
                >
                  <img src={excel} alt="Active" />
                  <span>Download Template</span>
                </a>
              </Tooltip>
            </Grid>
          </Grid>
        </Grid>
        <Grid item md={12}>
          <PreferredLocation
            Co={isConfigOverview}
            messageUuid={messageUuid}
            clickOnAdd={clickOnAdd}
          />
        </Grid>
        <Grid item md={12}>
          <Grid container justifyContent="flex-end" spacing={2}>
            <Grid item>
              <Button
                type={
                  !_isEmpty(locatPermissionObj) &&
                  !locatPermissionObj.readWriteFlag
                    ? "submit"
                    : "button"
                }
                color="primary"
                size="small"
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => setPopupActiveMenu(MENUS.CE_PROVIDERS)}
              >
                Next
              </Button>
            </Grid>
            <Grid item>
              <Button
                type="reset"
                size="small"
                variant="outlined"
                color="default"
                className={globalClasses.secondaryBtn}
                onClick={() => setPopupActiveMenu(MENUS.CE_PROVIDERS)}
              >
                Skip
              </Button>
            </Grid>
            <Grid item>
              <Tooltip
                placement="top"
                title={
                  !_isEmpty(locatPermissionObj) &&
                  !locatPermissionObj.readWriteFlag
                    ? "You don't have Permission."
                    : ""
                }
              >
                <span>
                  <Button
                    type="submit"
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    disabled={
                      !_isEmpty(locatPermissionObj) &&
                      locatPermissionObj.readWriteFlag
                        ? false
                        : true
                    }
                    onClick={() => setOpenAddCePopup(false)}
                  >
                    Save and Exit
                  </Button>
                </span>
              </Tooltip>
            </Grid>
            <Grid item>
              <Button
                type="reset"
                size="small"
                variant="outlined"
                color="default"
                className={globalClasses.secondaryBtn}
                onClick={() => setOpenAddCePopup(false)}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};
export default Locations;
