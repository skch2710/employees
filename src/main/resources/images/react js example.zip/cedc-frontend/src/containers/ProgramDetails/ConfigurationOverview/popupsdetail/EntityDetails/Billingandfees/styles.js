import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../../../utils/helper";

export const useAdminFeeStyles = makeStyles((theme) => {
  return {
    radioContainer: {
      display: "flex",
      alignItems: "center",
      height: "30px",
      gap: "16px",
    },
    radioAndLabelContainer: {
      display: "flex",
      gap: "5px",
      alignItems: "center",
      "& label": {
        color: `${theme.colors.monochrome.input} !important`,
        fontFamily: theme.fontFamily,
        cursor: "pointer",
      },
    },
    radioInput: {
      margin: "0 !important",
    },
  };
});

export const useBillingContactTableStyles = makeStyles((_theme) => {
  return {};
});

export const useAdminFeesTableStyles = makeStyles((theme) => {
  return {
    checkbox: {
      color: theme.colors.green[500],
      "&$checked": {
        color: theme.colors.green[500],
      },
    },
    btnLabelContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    dialogPaper: {
      height: "75vh",
    },
  };
});

export const useCeBillingAndFeesStyles = makeStyles((theme) => {
  return {
    adminFeesApplyBtnContainer: {
      display: "flex",
      alignItems: "flex-end",
    },
    percentageWrapper: {
      display: "flex",
      alignItems: "center",
      gap: "5px",
    },
    adminFeeTypeNotice: {
      height: "30px",
      display: "flex",
      alignItems: "center",
      marginTop: "18px",
      "& p": {
        color: theme.colors.monochrome.disabledText,
        margin: 0,
        fontStyle: "italic",
        fontSize: "13px",
      },
    },
    cardWrapper: {
      border: `1px solid ${theme.colors.monochrome.cardBorder}`,
      borderRadius: "10px",
      boxShadow: `0 0 18px 0 ${theme.colors.monochrome.cardBoxShadow}`,
      lineHeight: "1.42857143",
    },
    collapseTitle: {
      pointerEvents: "none",
    },
    collapseIcon: {
      pointerEvents: "auto",
      border: `1px solid ${theme.colors.monochrome.border}`,
      borderRadius: "4px",
      backgroundColor: theme.colors.grey.inputDisableBg,
    },
    checkbox: {
      color: theme.colors.green[500],
      "&$checked": {
        color: theme.colors.green[500],
      },
    },
    tableContainer: {
      width: "100%",
    },
  };
});
