export const getOrderingReplenishmentDefaultValues = () => {
  return {
    supportMultipleWholesalerForCeNetwork: false,
    billingModelId: "",
    inventorySwellProgramId: "",
    sendOrderNotifications: false,
    orderingPharmacy: false,
    generateC2OrdersOutOfSwell: false,
    participateInCentralReplenishment: false,
    turnOffTrueUp: false,
    replenishThresholdPercent: "100",
    turnOffCeOwnedInventory: false,
    processUnsolicited855and810: false,
    wholesalers: [],
  };
};

const getBooleanValue = (value) => {
  if (value === "Y") return true;
  else return false;
};

export const ORDefaultValuesFromResponse = (res = {}) => {
  return {
    supportMultipleWholesalerForCeNetwork: getBooleanValue(
      res.supportMultipleWholesalerForCeNetwork
    ),
    billingModelId: res.billingModelId || "",
    inventorySwellProgramId: res.inventorySwellProgramId || "",
    sendOrderNotifications: getBooleanValue(res.sendOrderNotifications),
    orderingPharmacy: getBooleanValue(res.orderingPharmacy),
    generateC2OrdersOutOfSwell: getBooleanValue(res.generateC2OrdersOutOfSwell),
    participateInCentralReplenishment: getBooleanValue(
      res.participateInCentralReplenishment
    ),
    turnOffTrueUp: res.turnOffTrueUp == "Y" ? false : true,
    replenishThresholdPercent: res.replenishThresholdPercent || "",
    turnOffCeOwnedInventory: res.turnOffCeOwnedInventory == "Y" ? false : true,
    processUnsolicited855and810: getBooleanValue(
      res.processUnsolicited855and810
    ),
    wholesalers: res.wholesalers || [],
  };
};
