import { makeStyles } from "@material-ui/core/styles";

export const useBulkUploadStyles = makeStyles((_theme) => ({
  rowGap: {
    rowGap: "15px",
  },
  columnGap: {
    columnGap: "10px",
  },
  droppableContainer: {
    minHeight: "100px",
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
}));

export const getDroppableStyle = ({
  isDragActive,
  isDragAccept,
  isDragReject,
  theme,
}) => {
  return {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "10px",
    borderWidth: 2,
    borderRadius: 2,
    borderColor: theme.colors.monochrome.border,
    borderStyle: "dashed",
    backgroundColor: theme.colors.monochrome.bg,
    color: theme.colors.monochrome.placeholder,
    transition: "border .3s ease-in-out",
    cursor: "auto",
    ...(isDragActive ? { borderColor: theme.colors.blue[900] } : {}),
    ...(isDragAccept ? { borderColor: theme.colors.green.default } : {}),
    ...(isDragReject ? { borderColor: theme.colors.red[500] } : {}),
  };
};
