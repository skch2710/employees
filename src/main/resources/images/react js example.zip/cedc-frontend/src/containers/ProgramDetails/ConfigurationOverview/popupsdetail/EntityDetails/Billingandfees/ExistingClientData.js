import { Checkbox, FormControlLabel, Grid } from "@material-ui/core";
import { Field, useFormikContext } from "formik";
import _isArray from "lodash/isArray";
import _uniqBy from "lodash/uniqBy";
import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { useDispatch } from "react-redux";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { getAdminFeesAndPharmacies } from "../../../../../../context/actions/ConfigOverview/EntityConfiguration/CeBillingAndFees";
import { COContext } from "../../../../COContext";
import ClientFeeTables from "./ClientFeeTables";

const ExistingClientData = (_props) => {
  const { values, setFieldValue, handleChange, errors } = useFormikContext();
  const { ceId } = useContext(COContext);
  const dispatch = useDispatch();

  const [pharmacies, setPharmacies] = useState([]);

  const fetchPharmacies = async () => {
    const response = await dispatch(
      getAdminFeesAndPharmacies({
        ceId,
        feeId: values.feesType,
      })
    );
    if (_isArray(response)) setPharmacies(response);
  };

  useEffect(() => {
    fetchPharmacies();
  }, []);

  const getCheckedUpdatedData = ({ prevArr, customizedCond, checkboxCond }) => {
    let newArr = [...prevArr];
    const newPh = pharmacies.map((ph) => {
      const clients = ph.clientAdminFees.map((cl) => {
        if (values.customizedOrNot.includes(checkboxCond)) {
          newArr = [...newArr, cl];
          return {
            ...cl,
            tableData: {
              ...cl.tableData,
              checked: true,
            },
          };
        } else {
          if (cl.customized === customizedCond) newArr = [...newArr, cl];
          return {
            ...cl,
            tableData: {
              ...cl.tableData,
              checked: cl.customized === customizedCond ? true : false,
            },
          };
        }
      });
      return {
        ...ph,
        clientAdminFees: clients,
      };
    });
    return { newPh, updatedArr: newArr };
  };

  const getUncheckedUpdatedData = ({
    prevArr,
    customizedCond,
    reverseCond,
  }) => {
    let newArr = [...prevArr];
    const newPh = pharmacies.map((ph) => {
      const clients = ph.clientAdminFees.map((cl = {}) => {
        const { customized, tableData = {} } = cl;
        if (customized === customizedCond && tableData.checked) {
          newArr = [...newArr, cl];
        }
        return {
          ...cl,
          tableData: {
            ...tableData,
            checked:
              customized === reverseCond ? false : tableData.checked || false,
          },
        };
      });
      return {
        ...ph,
        clientAdminFees: clients,
      };
    });
    return { newPh, updatedArr: newArr };
  };

  const handleCheckBoxChange = useCallback(
    (e) => {
      let newArr = [];
      if (Number(e.target.value) === 1) {
        if (e.target.checked) {
          const { newPh, updatedArr } = getCheckedUpdatedData({
            prevArr: newArr,
            customizedCond: "Yes",
            checkboxCond: "2",
          });
          newArr = [...updatedArr];
          setPharmacies(newPh);
        } else {
          const { newPh, updatedArr } = getUncheckedUpdatedData({
            prevArr: newArr,
            customizedCond: "No",
            reverseCond: "Yes",
          });
          newArr = [...updatedArr];
          setPharmacies(newPh);
        }
      } else if (Number(e.target.value) === 2) {
        if (e.target.checked) {
          const { newPh, updatedArr } = getCheckedUpdatedData({
            prevArr: newArr,
            customizedCond: "No",
            checkboxCond: "1",
          });
          newArr = [...updatedArr];
          setPharmacies(newPh);
        } else {
          const { newPh, updatedArr } = getUncheckedUpdatedData({
            prevArr: newArr,
            customizedCond: "Yes",
            reverseCond: "No",
          });
          newArr = [...updatedArr];
          setPharmacies(newPh);
        }
      }
      setFieldValue("selectedClients", newArr);
      handleChange(e);
    },
    [values, pharmacies]
  );

  const handleUncheckAll = ({ pharmacy }) => {
    const filteredPh = pharmacies.find((ph) => ph.phId === pharmacy.phId);
    const filteredFeeIds = filteredPh.clientAdminFees.map((fee) => fee.id);
    const newArr = values.selectedClients.filter(
      (fee) => !filteredFeeIds.includes(fee.id)
    );
    setFieldValue("customizedOrNot", []);
    setFieldValue("selectedClients", newArr);
  };

  const handleCheckAll = ({ rows }) => {
    const uniqueArr = _uniqBy([...values.selectedClients, ...rows], "id");
    setFieldValue("selectedClients", uniqueArr);
  };

  const handleRowSelection = useCallback(
    (data) => {
      const { rowData, checked } = data;
      let fees = [];
      if (checked)
        fees = [
          ...(_isArray(values.selectedClients) ? values.selectedClients : []),
          rowData,
        ];
      else {
        if (
          rowData.customized === "Yes" &&
          values.customizedOrNot.includes("1")
        ) {
          const checkboxArr = values.customizedOrNot.filter(
            (value) => value !== "1"
          );
          setFieldValue("customizedOrNot", checkboxArr);
        } else if (
          rowData.customized === "No" &&
          values.customizedOrNot.includes("2")
        ) {
          const checkboxArr = values.customizedOrNot.filter(
            (value) => value !== "2"
          );
          setFieldValue("customizedOrNot", checkboxArr);
        }
        fees = values.selectedClients.filter((fee) => fee.id !== rowData.id);
      }
      setFieldValue("selectedClients", fees);
    },
    [values]
  );

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="h5">
          Impacted Client Level Configurations
        </BasicTypography>
      </Grid>
      <Grid item md={12}>
        <Grid
          container
          justifyContent="flex-end"
          alignItems="center"
          spacing={2}
        >
          <Grid item>
            <Grid container spacing={1} alignItems="center">
              <Field
                type="checkbox"
                name="customizedOrNot"
                value={1}
                as={FormControlLabel}
                control={<Checkbox />}
                checked={values.customizedOrNot.includes("1")}
                label="Apply where the fee is customized"
                onChange={handleCheckBoxChange}
              />
            </Grid>
          </Grid>
          <Grid item>
            <Grid container spacing={1} alignItems="center">
              <Field
                type="checkbox"
                name="customizedOrNot"
                value={2}
                as={FormControlLabel}
                control={<Checkbox />}
                checked={values.customizedOrNot.includes("2")}
                label="Apply where the fee is not customized"
                onChange={handleCheckBoxChange}
              />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      {errors.selectedClients && (
        <Grid item md={12} container justifyContent="flex-end">
          <Grid item>
            <BasicTypography variant="caption" color="error">
              {errors.selectedClients}
            </BasicTypography>
          </Grid>
        </Grid>
      )}
      <Grid item md={12}>
        <Grid container spacing={1}>
          {pharmacies.map((pharmacy = {}) => {
            return (
              <ClientFeeTables
                key={pharmacy.phId}
                pharmacy={pharmacy}
                handleRowSelection={handleRowSelection}
                handleUncheckAll={handleUncheckAll}
                handleCheckAll={handleCheckAll}
              />
            );
          })}
        </Grid>
      </Grid>
    </Grid>
  );
};

export default memo(ExistingClientData);
