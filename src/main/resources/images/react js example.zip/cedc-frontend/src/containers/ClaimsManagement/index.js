import React, { useState, useEffect, useRef } from "react";
import { Formik, Form, Field } from "formik";
import {
  Button,
  Grid,
  IconButton,
  FormLabel,
  Checkbox,
  Typography,
  Tooltip,
} from "@material-ui/core";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import { IoIosCloseCircleOutline } from "react-icons/io";
import _debounce from "lodash/debounce";
import moment from "moment";
import DatePicker from "../../components/common/DatePicker";
import { useDispatch, useSelector } from "react-redux";
import { useClaimsStyles } from "./style";
import AutoComplete from "../../components/common/AutoComplete";
import { filterFunctionality } from "../../utils/common";
import {
  LABELS,
  pagination,
  REGEX,
  setAutoCompleteInputVal,
} from "../../utils/constants";
import { CLAIMS_MANAGEMENT } from "../../components/common/Table/TableHeadCells";
import {
  getClaimsManagementTableData,
  getPatientMRN,
  getRxNumber,
  getClaimStatus,
  getClaimType,
  getBrandGenericBoth,
  getShowPatientInformation,
  getFalloutReason,
  getBIN,
  getPatientFn,
  getPatientLn,
} from "../../context/actions/ClaimsManagement";
import { getLatestCE } from "../../context/actions/ConfigOverview";
import {
  Getpharmacystorevalues,
  GetCEPharmacyGroup,
} from "../../context/actions/Inventory";
import { getLocationList } from "../../context/actions/Locations";
import ClaimsManagementTable from "./ClaimsManagementTable";
import { getClaimsManagementFiltersDefaultValue } from "../../utils/constants";
import _isArray from "lodash/isArray";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import { getUserSession } from "../../utils/helper";
import { SET_CLAIMS_LIST } from "../../context/reducers/ClaimsManagement/constants";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import MultiSelectDropdown from "../../components/common/MultiSelectDropdown";
import _get from "lodash/get";
import { values } from "lodash";
import _isEmpty from "lodash/isEmpty";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const regex = /^[a-zA-Z-]+$/;

const ClaimsManagement = () => {
  const formikRef = useRef(null);
  const classes = useClaimsStyles();
  const globalClasses = useGlobalStyles();

  const userSession = getUserSession();
  const internalUser = userSession.isInternalUser;
  const dispatch = useDispatch();
  const { isSubmitting } = (formikRef && formikRef.current) || {};

  const checkedIcon = (
    <CheckBoxIcon
      classes={{ root: classes.selectedCheckBox }}
      fontSize="small"
    />
  );

  const { ceList } = useSelector((state) => state.coveredEntities) || [];
  const initialFormik = getClaimsManagementFiltersDefaultValue(ceList);
  const activeCeList = useSelector((state) => state.getLatestCE.data) || [];
  const PharmacyGroup =
    useSelector((state) => state.getPharmacygroupvalues.records) || [];
  const pharmacyList =
    useSelector((state) => state.getPharmacystorevalues.records) || [];
  const { records: claimsTableData } = useSelector(
    (state) => state.getClaimsListTableData
  );
  const claimStatusList =
    useSelector((state) => state.getClaimStatus.records) || [];
  const claimTypeList =
    useSelector((state) => state.getClaimType.records) || [];
  const brandGenericBothList =
    useSelector((state) => state.getBrandGenericBoth.records) || [];
  const falloutReasonList =
    useSelector((state) => state.getFalloutReason.records) || [];
  const binList = useSelector((state) => state.getBIN.records) || [];

  const [open, setOpen] = useState(true);
  const [ceId, setCeId] = useState(internalUser ? "" : ceList[0].ceID);
  const [capturedFromDate, setCapturedFromDate] = useState("");
  const [capturedToDate, setCapturedToDate] = useState("");
  const [page, setPage] = useState(pagination.page);
  const [rowsPerPage, setRowsPerPage] = useState(pagination.limit);
  const [sortBy, setsortBy] = useState("rxNumber");
  const [sortorder, setOrder] = useState("asc");
  const [showFilter, setShowFilter] = useState(false);
  const [patientDOB, setPatientDOB] = useState("");
  const [showSearchOptions, setShowSearchOptions] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);

  const [rxNumberOptions, setRxNumberOptions] = useState([]);
  const [rxNoLoading, setRxNoLoading] = useState(false);
  const [mrnOptions, setMrnOptions] = useState([]);
  const [mrnOptionsLoading, setMrnOptionsLoading] = useState(false);
  const [patientFnList, setPatientFnList] = useState([]);
  const [patientFnListLoading, setPatientFnListLoading] = useState(false);
  const [patientLnList, setPatientLnList] = useState([]);
  const [patientLnListLoading, setPatientLnListLoading] = useState(false);
  const [showToolTip, setShowToolTip] = useState(true);
  const [defaultValues, setDefaultValues] = useState(
    getClaimsManagementFiltersDefaultValue()
  );
  const [filterValues, setFilterValues] = useState([]);

  const fetchClaims = (payload = {}) => {
    let json = {
      ceID: [Number(ceId)],
      entityLocationID: defaultValues.locations.map((i) => i.entityLocationId),
      pageNumber: page,
      pageSize: rowsPerPage,
      phGroupID: defaultValues.pGroup.map((i) => i.phGroupId),
      phID: defaultValues.pharmacy.map((i) => i.phid),
      sortBy: sortBy,
      sortOrder: sortorder,
      mrn: defaultValues.patientMRN.map((i) => i.mrn),
      patientDOB: patientDOB,
      rxNumber: defaultValues.rxNumber.map((i) => i.rxNumber),
      status: defaultValues.claimStatus.map((i) => i.claimStatus),
      claimTypeID: defaultValues.claimType.map((i) => i.claimTypeId),
      reasonID: defaultValues.falloutReason.map((i) => i.reasonID),
      binID: defaultValues.BIN.map((i) => i.binID),
      savingsMin: defaultValues.savingsMin,
      savingsMax: defaultValues.savingsMax,
      providerNPI: defaultValues.providerNPI,
      brandGenericTypeID: defaultValues.brandType,
      ndc: defaultValues.NDC,
      patientFirstName: defaultValues.patientFirstName,
      patientLastName: defaultValues.patientLastName,
      provider: defaultValues.provider,
      capturedFromDate: capturedFromDate,
      capturedToDate: capturedToDate,
      dosFromDate: defaultValues.dosFromDate,
      dosToDate: defaultValues.dosToDate,
      filter: filterValues,
      export: false,
      patientInfo: defaultValues.showPatientInformation,
      externalUser: !internalUser,
      ...payload,
    };
    dispatch(getClaimsManagementTableData(json));
  };

  const resetCheckBox = (rows) => {
    setSelectedRows(rows);
  };

  const onChangePagination = (newPage, pagesize) => {
    let currentPage = newPage + 1;
    let obj = {};
    let rowsPerPageNew = Number(pagesize);
    if (currentPage === 0 && rowsPerPageNew != rowsPerPage) currentPage = page;
    if (rowsPerPageNew === rowsPerPage) setPage(currentPage);
    const { totalElements = 0 } = claimsTableData;
    const totalPages = Math.ceil(totalElements / rowsPerPageNew);
    const pages = totalPages === 0 ? 1 : totalPages;
    obj.pageNumber = currentPage;
    if (page > totalPages) {
      setPage(pages);
      obj.pageNumber = pages;
    }
    setRowsPerPage(rowsPerPageNew);
    setSelectedRows([]);
    obj.pageSize = rowsPerPageNew;
    fetchClaims(obj);
  };

  const onChangeSorting = async (orderedColumnId) => {
    if (isSubmitting) {
      setOrder(sortorder === "asc" ? "desc" : "asc");
      setsortBy(CLAIMS_MANAGEMENT[orderedColumnId].field);
      fetchClaims({
        sortOrder: sortorder === "asc" ? "desc" : "asc",
        sortBy: CLAIMS_MANAGEMENT[orderedColumnId].field,
      });
    }
  };

  const onChangeFilter = async (value) => {
    setPage(1);
    const payload = {
      pageNumber: 1,
    };

    if (value.length) {
      const responseValue = await filterFunctionality(value, "claims");
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setFilterValues(responseValue);
    } else {
      payload.filter = null;
      setFilterValues([]);
    }
    fetchClaims(payload);
  };

  const handleSubmit = (values) => {
    setDefaultValues(values);
    setSelectedRows([]);
    setFilterValues([]);
    setPage(pagination.page);
    let json = {
      ceID: [Number(ceId)],
      entityLocationID: values.locations.map((i) => i.entityLocationId),
      pageNumber: 1,
      pageSize: rowsPerPage,
      phGroupID: values.pGroup.map((i) => i.phGroupId),
      phID: values.pharmacy.map((i) => i.phid),
      sortBy: sortBy,
      sortOrder: sortorder,
      mrn: values.patientMRN.map((i) => i.mrn),
      patientDOB: patientDOB,
      rxNumber: values.rxNumber.map((i) => i.rxNumber),
      status: values.claimStatus.map((i) => i.claimStatus),
      claimTypeID: values.claimType.map((i) => i.claimTypeId),
      reasonID: values.falloutReason.map((i) => i.reasonID),
      binID: values.BIN.map((i) => i.binID),
      savingsMin: values.savingsMin,
      savingsMax: values.savingsMax,
      providerNPI: values.providerNPI,
      brandGenericTypeID: values.brandType,
      ndc: values.NDC,
      patientFirstName: values.patientFirstName,
      patientLastName: values.patientLastName,
      provider: values.provider,
      capturedFromDate: capturedFromDate,
      capturedToDate: capturedToDate,
      dosFromDate: values.dosFromDate,
      dosToDate: values.dosToDate,
      filter: [],
      export: false,
      patientInfo: "Yes",
      externalUser: !internalUser,
    };
    dispatch(getClaimsManagementTableData(json));
  };

  const formValidate = (values) => {
    const errors = {};
    if (userSession.isInternalUser) {
      if (!values.ceID) {
        errors.ceID = "Please select the Covered Entity";
        setShowToolTip(false);
      }
    }
    if (values.dosFromDate == "") {
      errors.dosFromDate = "Please select the DOS Start Date";
      setShowToolTip(false);
    }
    return errors;
  };

  useEffect(() => {
    dispatch(getClaimStatus());
    dispatch(getClaimType());
    dispatch(getBrandGenericBoth());
    dispatch(getShowPatientInformation());
    dispatch(getFalloutReason());
    dispatch(getBIN());
    if (internalUser) dispatch(getLatestCE());
    if (internalUser) dispatch(GetCEPharmacyGroup({ ceid: [0] }));
    if (!internalUser) {
      dispatch(getLocationList({ ceIDs: [ceId], locationName: "" }));
      dispatch(GetCEPharmacyGroup({ ceid: [ceId] }));
    }
    return () => {
      dispatch({ type: SET_CLAIMS_LIST, data: [] });
    };
  }, []);

  const clearFields = (_initialValues) => {
    setCeId(internalUser ? "" : ceList[0].ceID);
    if (internalUser) {
      dispatch(getLocationList({ ceIDs: [0], locationName: "" }));
      dispatch(GetCEPharmacyGroup({ ceid: [0] }));
      dispatch(
        Getpharmacystorevalues({
          ceid: [0],
          phGroupId: [0],
        })
      );
    }
    setOrder("asc");
    setsortBy("rxNumber");
    setCapturedFromDate("");
    setCapturedToDate("");
    setPatientDOB("");
    setPage(pagination.page);
    setRowsPerPage(pagination.limit);
    setSelectedRows([]);
    setDefaultValues(initialFormik);
    setFilterValues([]);
    setShowFilter(false);
    let json = {
      ceID: [Number(0)],
      entityLocationID: [],
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      phGroupID: [],
      phID: [],
      sortBy: "rxNumber",
      sortOrder: "asc",
      mrn: [],
      patientDOB: "",
      rxNumber: [],
      status: [],
      claimTypeID: [],
      reasonID: [],
      binID: [],
      savingsMin: "",
      savingsMax: "",
      providerNPI: "",
      brandGenericTypeID: 0,
      ndc: "",
      patientFirstName: "",
      patientLastName: "",
      provider: "",
      capturedFromDate: "",
      capturedToDate: "",
      dosFromDate: "",
      dosToDate: "",
      filter: [],
      export: false,
      patientInfo: "Yes",
      externalUser: !internalUser,
    };
    dispatch(getClaimsManagementTableData(json));
  };

  const handleCeDropdown = ({ value, resetForm, setFieldValue }) => {
    setRxNumberOptions([]);
    resetForm();
    setFieldValue("ceID", value ? value.ceID : 0);
    setCeId(_isEmpty(value) ? 0 : value.ceID);
    dispatch(
      getLocationList({ ceIDs: [value ? value.ceID : 0], locationName: "" })
    );
    dispatch(GetCEPharmacyGroup({ ceid: [value ? value.ceID : 0] }));
    dispatch({ type: "Pharmacystorevalues", data: [] });
  };

  const handleChangeForBrandGereicBoth = (e, setFieldValue) => {
    setFieldValue("brandType", e.target.value);
  };

  const onChangePatientMRN = async (value) => {
    if (value) {
      setMrnOptionsLoading(true);
      dispatch(
        getPatientMRN({ ceID: [ceId], mrn: value }, (res) => {
          if (res.length >= 1) {
            setMrnOptions(res);
          } else {
            setMrnOptions([]);
          }
          setMrnOptionsLoading(false);
        })
      );
    }
  };

  const handleChangeRxNumber = (value) => {
    setRxNoLoading(true);
    getRxNumber({ ceID: [ceId], rxNumber: value }, (resp) => {
      _isArray(resp) && setRxNumberOptions(resp);
      setRxNoLoading(false);
    });
  };

  const handleChangePatientFn = _debounce(async (value) => {
    setPatientFnListLoading(true);
    dispatch(
      getPatientFn({ ceID: [ceId], firstName: value }, (res) => {
        if (res.length >= 1) setPatientFnList(res);
        else setPatientFnList([]);
        setPatientFnListLoading(false);
      })
    );
  }, 500);

  const handleChangePatientLn = _debounce(async (value) => {
    setPatientLnListLoading(true);
    dispatch(
      getPatientLn({ ceID: [ceId], lastName: value }, (res) => {
        if (res.length >= 1) setPatientLnList(res);
        else setPatientLnList([]);
        setPatientLnListLoading(false);
      })
    );
  }, 500);

  const handleChangeSavingsMin = (e, setFieldValue) => {
    const { name, value } = e.target;
    if (value.match(/\./g)) {
      const [, decimal] = value.split(".");
      if (decimal.length > 2) {
        return;
      }
    }
    setFieldValue(name, value);
  };

  const handleChangeSavingsMax = (e, setFieldValue) => {
    const { name, value } = e.target;
    if (value.match(/\./g)) {
      const [, decimal] = value.split(".");
      if (decimal.length > 2) {
        return;
      }
    }
    setFieldValue(name, value);
  };

  const resetPharmacyField = (groups, setFieldValue) => {
    const selectedPhGroupIds = groups.map((group) => group.phGroupId);
    const selectedPharmacies = values.pharmacy || [];
    if (selectedPhGroupIds && selectedPhGroupIds.length > 0) {
      const filteredPharmacies = selectedPharmacies.filter((pharmacy) =>
        selectedPhGroupIds.includes(pharmacy.phGroupId)
      );
      setFieldValue("pharmacy", filteredPharmacies);
    } else {
      setFieldValue("pharmacy", []);
    }
  };

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="h1" title="Claims Management" />
      </Grid>
      <Grid item md={12}>
        <Formik
          initialValues={initialFormik}
          onSubmit={handleSubmit}
          validate={formValidate}
          innerRef={formikRef}
        >
          {({
            values,
            errors,
            touched,
            initialValues,
            resetForm,
            setFieldValue,
          }) => (
            <Form>
              {open ? (
                <div className={globalClasses.cardPrimary}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <Grid
                        container
                        spacing={2}
                        justifyContent="space-between"
                        alignItems="center"
                      >
                        <Grid item>
                          <BasicTypography variant="h4" title="Filters" />
                        </Grid>
                        <Grid item>
                          <Grid
                            container
                            spacing={2}
                            justifyContent="flex-end"
                            alignItems="center"
                          >
                            <Grid item>
                              <a
                                onClick={() => {
                                  setShowSearchOptions(!showSearchOptions);
                                }}
                                className={classes.additionalFiltersLink}
                              >
                                {showSearchOptions
                                  ? "Less Search Options"
                                  : "More Search Options"}
                              </a>
                            </Grid>
                            <Grid item>
                              <IconButton
                                onClick={() => {
                                  setOpen(false);
                                }}
                              >
                                <IoIosCloseCircleOutline />
                              </IconButton>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} md={4}>
                          <FormLabel required>Covered Entity</FormLabel>

                          <Field
                            as="select"
                            className={globalClasses.formControl}
                            name="ceID"
                          >
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                disabled={!userSession.isInternalUser}
                                options={_isArray(ceList) ? ceList : []}
                                inputPlaceholder={
                                  internalUser
                                    ? "Select Covered Entity"
                                    : ceList[0].ceName
                                }
                                onChange={(e, value) => {
                                  handleCeDropdown({
                                    value,
                                    resetForm,
                                    setFieldValue,
                                  });
                                }}
                                value={
                                  _isArray(ceList) &&
                                  ceList.find((e) => e.ceID === values.ceID) || ""
                                }
                                getOptionLabel={(option) => option.ceName || ""}
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.ceName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                                textFieldProps={{
                                  inputProps: {
                                    name: "ceID",
                                  },
                                }}
                              />
                            )}
                          </Field>

                          {touched.ceID && errors.ceID && (
                            <Typography color="error" variant="caption">
                              {errors.ceID}
                            </Typography>
                          )}
                        </Grid>

                        <Grid item xs={12} md={4}>
                          <FormLabel required>DOS Start Date</FormLabel>
                          <Grid container justifyContent="space-between">
                            <Grid item xs={12} md>
                              <Field as="select" name="dosFromDate">
                                {({ field }) => (
                                  <DatePicker
                                    {...field}
                                    onChange={(_e, date) => {
                                      setFieldValue("dosFromDate", date);
                                      setFieldValue(
                                        "dosToDate",
                                        date != ""
                                          ? moment(date)
                                              .add(1, "years")
                                              .add(-1, "days")
                                              .format("MM/DD/YYYY")
                                          : ""
                                      );
                                    }}
                                    placeholder="Start Date"
                                    value={
                                      values.dosFromDate !== ""
                                        ? moment(values.dosFromDate)
                                        : ""
                                    }
                                    disabledDate={(d) =>
                                      !d || d.isAfter(new Date())
                                    }
                                  />
                                )}
                              </Field>

                              {touched.dosFromDate && errors.dosFromDate && (
                                <Typography color="error" variant="caption">
                                  {errors.dosFromDate}
                                </Typography>
                              )}
                            </Grid>
                            <Grid item xs={12} md={1}>
                              <div className={classes.dateOfServiceTo}>to</div>
                            </Grid>
                            <Grid item xs={12} md>
                              <Field as="select" name="dosToDate">
                                {({ field }) => (
                                  <DatePicker
                                    {...field}
                                    onChange={(_e, date) =>
                                      setFieldValue("dosToDate", date)
                                    }
                                    placeholder="End Date"
                                    value={
                                      values.dosToDate !== ""
                                        ? moment(values.dosToDate)
                                        : ""
                                    }
                                    disabled={values.dosFromDate == ""}
                                    disabledDate={(current) => {
                                      const startDate = values.dosFromDate;
                                      return (
                                        moment(startDate) >= current ||
                                        moment(startDate).add(1, "years") <=
                                          current
                                      );
                                    }}
                                  />
                                )}
                              </Field>
                            </Grid>
                          </Grid>
                        </Grid>

                        {/* location dropdown is currently hidden as there are no location for claims as of now need to show in future */}
                        {/* <Grid item xs={12} sm={4}>
                            <FormLabel>Locations</FormLabel>
                            <Tooltip
                              title={
                                ceId === "" || ceId === "0"
                                  ? "Please select a Covered Entity to view the list of Locations"
                                  : ""
                              }
                            >
                              <span>
                                <Field as="select" multiple name="locations">
                                  {({ field }) => (
                                    <AutoComplete
                                      inputPlaceholder="Select Locations"
                                      options={locationsList}
                                      disabled={ceId === "" || ceId === "0"}
                                      getOptionLabel={(option) =>
                                        option.locationName
                                      }
                                      renderOption={(option, other) => {
                                        return (
                                          <>
                                            <Checkbox
                                              icon={icon}
                                              checkedIcon={checkedIcon}
                                              checked={other.selected}
                                            />
                                            {option.locationName}
                                          </>
                                        );
                                      }}
                                      {...field}
                                      onChange={(e, value) =>
                                        formik.setFieldValue("locations", value)
                                      }
                                    />
                                  )}
                                </Field>
                              </span>
                            </Tooltip>
                          </Grid> */}

                        <Grid item xs={12} sm={4}>
                          <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                          <Field as="select" multiple name="pGroup">
                            {({ field }) => (
                              <MultiSelectDropdown
                                inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                                options={PharmacyGroup}
                                getOptionLabel={(option) =>
                                  option.phGroupId === -1
                                    ? "All"
                                    : option.phGroupName
                                }
                                {...field}
                                onChange={(_e, value) => {
                                  setFieldValue("pGroup", value);
                                  resetPharmacyField(value, setFieldValue);
                                  dispatch(
                                    Getpharmacystorevalues({
                                      ceid: [
                                        _get(values, "ceID.ceID", values.ceID),
                                      ],
                                      phGroupId: value.map((i) => i.phGroupId),
                                    })
                                  );
                                }}
                              />
                            )}
                          </Field>
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                          <Field as="select" multiple name="pharmacy">
                            {({ field }) => (
                              <MultiSelectDropdown
                                inputPlaceholder={`Select ${LABELS.PharmacyStore}`}
                                options={pharmacyList}
                                getOptionLabel={(option) => option.phName}
                                {...field}
                                onChange={(_e, value) =>
                                  setFieldValue("pharmacy", value)
                                }
                              />
                            )}
                          </Field>
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>Provider NPI</FormLabel>
                          <Field
                            name="providerNPI"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter Provider NPI"
                            maxLength={15}
                            onChange={(e) => {
                              const value = e.target.value;
                              const regex = REGEX.onlyNumbers;
                              if (value && !regex.test(e.target.value)) return;
                              setFieldValue("providerNPI", e.target.value);
                            }}
                          />
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>Provider</FormLabel>
                          <Field
                            name="provider"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter Provider"
                            maxLength={50}
                            onChange={(e) => {
                              const value = e.target.value;
                              if (value && !REGEX.alphabetsAndHypen.test(value))
                                return;
                              setFieldValue("provider", value);
                            }}
                          />
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>RX Number</FormLabel>
                          <Tooltip
                            title={
                              !ceId
                                ? "Please select a Covered Entity to enable this"
                                : ""
                            }
                          >
                            <Field as="select" name="rxNumber">
                              {({ field }) => (
                                <MultiSelectDropdown
                                  multiple
                                  loading={rxNoLoading}
                                  disabled={!ceId}
                                  options={rxNumberOptions || []}
                                  getOptionLabel={(option) => option.rxNumber}
                                  disableCloseOnSelect={true}
                                  inputPlaceholder="Enter RX Number"
                                  getOptionSelected={(option, value) =>
                                    option.rxNumber === value.rxNumber
                                  }
                                  inputValue={values.rxNumberInputValue}
                                  onInputChange={(_e, inputValue) => {
                                    setFieldValue(
                                      "rxNumberInputValue",
                                      inputValue
                                    );
                                    if (inputValue) {
                                      handleChangeRxNumber(inputValue);
                                    } else {
                                      setRxNumberOptions([]);
                                    }
                                  }}
                                  {...field}
                                  onChange={(_e, value) => {
                                    setFieldValue("rxNumber", value);
                                  }}
                                  textFieldProps={{
                                    inputProps: {
                                      name: "rxNumber",
                                    },
                                  }}
                                />
                              )}
                            </Field>
                          </Tooltip>
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>Claim Status</FormLabel>
                          <Field as="select" multiple name="claimStatus">
                            {({ field }) => (
                              <MultiSelectDropdown
                                inputPlaceholder="Select Claim Status"
                                options={claimStatusList}
                                getOptionLabel={(option) => option.claimStatus}
                                {...field}
                                onChange={(_e, value) =>
                                  setFieldValue("claimStatus", value)
                                }
                              />
                            )}
                          </Field>
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>NDC</FormLabel>
                          <Field
                            name="NDC"
                            id="ndc"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter NDC"
                            maxLength={11}
                            onChange={(e) => {
                              const value = e.target.value;
                              const regEx = /^[0-9]{1,11}$/g;
                              if (value && !regEx.test(e.target.value)) return;
                              setFieldValue("NDC", e.target.value);
                            }}
                          />
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <FormLabel>Fallout Reason</FormLabel>
                          <Field as="select" multiple name="falloutReason">
                            {({ field }) => (
                              <MultiSelectDropdown
                                inputPlaceholder="Select Fallout Reason"
                                options={falloutReasonList}
                                getOptionLabel={(option) => option.reasonDesc}
                                {...field}
                                onChange={(_e, value) =>
                                  setFieldValue("falloutReason", value)
                                }
                              />
                            )}
                          </Field>
                        </Grid>

                        {!showSearchOptions && (
                          <Grid item xs={12} sm={4}></Grid>
                        )}

                        {showSearchOptions && (
                          <>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Claim Type</FormLabel>
                              <Field as="select" multiple name="claimType">
                                {({ field }) => (
                                  <MultiSelectDropdown
                                    inputPlaceholder="Select Claim Type"
                                    options={claimTypeList}
                                    getOptionLabel={(option) =>
                                      option.id === -1
                                        ? "All"
                                        : option.claimType
                                    }
                                    {...field}
                                    onChange={(_e, value) =>
                                      setFieldValue("claimType", value)
                                    }
                                  />
                                )}
                              </Field>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>Captured Date</FormLabel>
                              <Grid
                                container
                                justifyContent="space-between"
                                spacing={1}
                              >
                                <Grid item xs={12} md={6}>
                                  <DatePicker
                                    onChange={(_e, date) => {
                                      if (!date) setCapturedToDate("");
                                      setCapturedFromDate(date);
                                    }}
                                    placeholder="Select From Date"
                                    value={
                                      capturedFromDate !== ""
                                        ? moment(capturedFromDate)
                                        : ""
                                    }
                                    disabledDate={(d) =>
                                      !d ||
                                      (capturedToDate &&
                                        !d.isSameOrBefore(
                                          capturedToDate,
                                          "day"
                                        ))
                                    }
                                  />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                  <DatePicker
                                    onChange={(_e, date) =>
                                      setCapturedToDate(date)
                                    }
                                    placeholder="Select To Date"
                                    value={
                                      capturedToDate !== ""
                                        ? moment(capturedToDate)
                                        : ""
                                    }
                                    disabledDate={(d) =>
                                      !d ||
                                      !d.isSameOrAfter(capturedFromDate, "day")
                                    }
                                  />
                                </Grid>
                              </Grid>
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Savings Min</FormLabel>
                              <Field
                                name="savingsMin"
                                type="number"
                                className={`${globalClasses.formControl} hideclass`}
                                placeholder="Enter Savings Min"
                                onChange={(e) =>
                                  handleChangeSavingsMin(e, setFieldValue)
                                }
                                onKeyDown={(e) =>
                                  (e.key === "e" ||
                                    e.key === "-" ||
                                    e.key === "+") &&
                                  e.preventDefault()
                                }
                              />
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Savings Max</FormLabel>
                              <Field
                                name="savingsMax"
                                type="number"
                                className={`${globalClasses.formControl} hideclass`}
                                placeholder="Enter Savings Max"
                                onChange={(e) =>
                                  handleChangeSavingsMax(e, setFieldValue)
                                }
                                onKeyDown={(e) =>
                                  (e.key === "e" ||
                                    e.key === "-" ||
                                    e.key === "+") &&
                                  e.preventDefault()
                                }
                              />
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>BIN</FormLabel>
                              <Field as="select" multiple name="BIN">
                                {({ field }) => (
                                  <MultiSelectDropdown
                                    inputPlaceholder="Select BIN"
                                    options={binList}
                                    getOptionLabel={(option) =>
                                      option.id === -1
                                        ? "All"
                                        : option.binNumber
                                    }
                                    {...field}
                                    onChange={(_e, value) =>
                                      setFieldValue("BIN", value)
                                    }
                                  />
                                )}
                              </Field>
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Patient MRN</FormLabel>
                              <Tooltip
                                title={
                                  ceId === "" || ceId === "0" || !ceId
                                    ? "Please select a Covered Entity to enable this"
                                    : ""
                                }
                              >
                                <span>
                                  <Field as="select" name="patientMRN">
                                    {({ field }) => (
                                      <>
                                        <MultiSelectDropdown
                                          disabled={!ceId}
                                          options={mrnOptions}
                                          loading={mrnOptionsLoading}
                                          getOptionLabel={(option) =>
                                            option.id === -1
                                              ? "All"
                                              : option.mrn.toString() || option
                                          }
                                          {...field}
                                          getOptionSelected={(option, value) =>
                                            option.mrn === value.mrn
                                          }
                                          multiple={true}
                                          inputPlaceholder="Enter Patient MRN"
                                          inputValue={
                                            values.patientMrnInputValue
                                          }
                                          onInputChange={(_e, inputValue) => {
                                            setFieldValue(
                                              "patientMrnInputValue",
                                              inputValue
                                            );
                                            if (
                                              inputValue ||
                                              inputValue === 0
                                            ) {
                                              onChangePatientMRN(inputValue);
                                            } else {
                                              setMrnOptions([]);
                                            }
                                          }}
                                          onChange={(_e, value) => {
                                            setFieldValue("patientMRN", value);
                                          }}
                                          textFieldProps={{
                                            inputProps: {
                                              name: "patientMRN",
                                            },
                                          }}
                                        />
                                      </>
                                    )}
                                  </Field>
                                </span>
                              </Tooltip>
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Patient First Name</FormLabel>
                              <Tooltip
                                title={
                                  ceId === "" || ceId === "0" || !ceId
                                    ? "Please select a Covered Entity to enable this"
                                    : ""
                                }
                              >
                                <span>
                                  <Field as="select" name="patientFirstName">
                                    {({ field }) => (
                                      <AutoComplete
                                        disabled={!ceId}
                                        loading={patientFnListLoading}
                                        options={patientFnList}
                                        getOptionLabel={(option) =>
                                          option.firstName || option
                                        }
                                        multiple={false}
                                        disableCloseOnSelect={false}
                                        inputPlaceholder="Enter Patient First Name"
                                        inputValue={
                                          values.firstNameInputVal || ""
                                        }
                                        onInputChange={(_e, inputValue) => {
                                          setAutoCompleteInputVal({
                                            value: inputValue,
                                            callback: (newValue) => {
                                              setFieldValue(
                                                "firstNameInputVal",
                                                newValue
                                              );
                                              if (newValue) {
                                                handleChangePatientFn(newValue);
                                              } else {
                                                setPatientFnList([]);
                                              }
                                            },
                                          });
                                        }}
                                        {...field}
                                        onChange={(_e, value) => {
                                          setFieldValue(
                                            "patientFirstName",
                                            value && value.firstName
                                              ? value.firstName
                                              : ""
                                          );
                                        }}
                                        textFieldProps={{
                                          inputProps: {
                                            name: "patientFirstName",
                                          },
                                        }}
                                      />
                                    )}
                                  </Field>
                                </span>
                              </Tooltip>
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Patient Last Name</FormLabel>
                              <Tooltip
                                title={
                                  ceId === "" || ceId === "0" || !ceId
                                    ? "Please select a Covered Entity to enable this"
                                    : ""
                                }
                              >
                                <span>
                                  <Field as="select" name="patientLastName">
                                    {({ field }) => (
                                      <AutoComplete
                                        disabled={!ceId}
                                        loading={patientLnListLoading}
                                        options={patientLnList}
                                        getOptionLabel={(option) =>
                                          option.lastName || option
                                        }
                                        multiple={false}
                                        disableCloseOnSelect={false}
                                        inputPlaceholder="Enter Patient Last Name"
                                        inputValue={
                                          values.lastNameInputVal || ""
                                        }
                                        onInputChange={(_e, inputValue) => {
                                          setAutoCompleteInputVal({
                                            value: inputValue,
                                            callback: (newValue) => {
                                              setFieldValue(
                                                "lastNameInputVal",
                                                newValue
                                              );
                                              if (newValue) {
                                                handleChangePatientLn(newValue);
                                              } else {
                                                setPatientLnList([]);
                                              }
                                            },
                                          });
                                        }}
                                        {...field}
                                        onChange={(_e, value) => {
                                          setFieldValue(
                                            "patientLastName",
                                            value && value.lastName
                                              ? value.lastName
                                              : ""
                                          );
                                        }}
                                        textFieldProps={{
                                          inputProps: {
                                            name: "patientLastName",
                                          },
                                        }}
                                      />
                                    )}
                                  </Field>
                                </span>
                              </Tooltip>
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Patient DOB</FormLabel>
                              <DatePicker
                                onChange={(_e, date) => setPatientDOB(date)}
                                value={
                                  patientDOB !== "" ? moment(patientDOB) : ""
                                }
                              />
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Brand/Generic/Both</FormLabel>
                              <Grid container spacing={1}>
                                {brandGenericBothList &&
                                  brandGenericBothList.length > 0 &&
                                  brandGenericBothList.map(
                                    (keysItem, index) => {
                                      return (
                                        <Grid item md key={index}>
                                          <Grid
                                            container
                                            spacing={1}
                                            alignItems="center"
                                          >
                                            <Grid
                                              item
                                              className={
                                                globalClasses.verticalCenter
                                              }
                                            >
                                              <Field
                                                type="radio"
                                                name="brandType"
                                                value={
                                                  keysItem.brandGenericTypeId
                                                }
                                                checked={
                                                  values.brandType === index + 1
                                                }
                                                onChange={(e) =>
                                                  handleChangeForBrandGereicBoth(
                                                    e,
                                                    setFieldValue
                                                  )
                                                }
                                              />
                                            </Grid>
                                            <Grid item>
                                              <FormLabel
                                                className={
                                                  globalClasses.noPaddingForLabels
                                                }
                                              >
                                                {keysItem.brandGenericType}
                                              </FormLabel>
                                            </Grid>
                                          </Grid>
                                        </Grid>
                                      );
                                    }
                                  )}
                              </Grid>
                            </Grid>

                            {/* <Grid item xs={12} sm={4}>
                                <FormLabel>Show Patient Information</FormLabel>
                                <div
                                  role="group"
                                  aria-labelledby="my-radio-group"
                                >
                                  {showPatientInformationList &&
                                    showPatientInformationList.length > 0 &&
                                    showPatientInformationList.map(
                                      (keysItem, index) => {
                                        return (
                                          <label key={index}>
                                            <Field
                                              type="radio"
                                              name="showPatientInformation"
                                              value={keysItem.yesNoType}
                                              checked={
                                                formik.values
                                                  .showPatientInformation ==
                                                yesNo[index]
                                              }
                                              onChange={(e) =>
                                                handleChangeShowPatientInfo(
                                                  e,
                                                  formik
                                                )
                                              }
                                            />
                                            {keysItem.yesNoType}
                                          </label>
                                        );
                                      }
                                    )}
                                </div>
                              </Grid> */}

                            {/* <Grid item xs={12} sm={4}></Grid> */}
                            {/* <Grid item xs={12} sm={4}></Grid> */}
                          </>
                        )}

                        <Grid
                          item
                          xs={12}
                          sm={4}
                          className={globalClasses.verticalCenter}
                        >
                          <Grid container spacing={2} justifyContent="flex-end">
                            <Grid item>
                              <Button
                                type="submit"
                                size="small"
                                variant="contained"
                                className={globalClasses.primaryBtn}
                                title={
                                  showToolTip
                                    ? "Please select the mandatory fields to perform the search"
                                    : ""
                                }
                              >
                                Search
                              </Button>
                            </Grid>
                            <Grid item>
                              <Button
                                type="reset"
                                size="small"
                                variant="outlined"
                                className={globalClasses.secondaryBtn}
                                onClick={() => clearFields(initialValues)}
                              >
                                Clear
                              </Button>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </div>
              ) : (
                <Button
                  variant="contained"
                  className={globalClasses.primaryBtn}
                  onClick={() => {
                    setOpen(true);
                  }}
                >
                  Filters
                </Button>
              )}
            </Form>
          )}
        </Formik>
      </Grid>
      <Grid item md={12}>
        <ClaimsManagementTable
          onChangePagination={onChangePagination}
          onChangeSorting={onChangeSorting}
          onChangeFilter={onChangeFilter}
          page={page}
          setPage={setPage}
          rowsPerPage={rowsPerPage}
          sortBy={sortBy}
          sortOrder={sortorder}
          patientDOB={patientDOB}
          selectedRows={selectedRows}
          resetCheckBox={resetCheckBox}
          formikValues={defaultValues}
          ceId={ceId}
          capturedFromDate={capturedFromDate}
          capturedToDate={capturedToDate}
          defaultFilters={filterValues}
          showFilter={showFilter}
          setShowFilter={setShowFilter}
          internalUser={internalUser}
        />
      </Grid>
    </Grid>
  );
};
export default ClaimsManagement;
