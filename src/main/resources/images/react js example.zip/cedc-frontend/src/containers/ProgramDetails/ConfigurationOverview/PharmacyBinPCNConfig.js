import React, { useState, useRef } from "react";
//Common
import HeaderTitle from "../../../components/common/Typography/HeaderTitle";
//css
import { Collapse } from "reactstrap";
//react-icons
import { BsPencilSquare } from "react-icons/bs";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { Grid, Paper, IconButton } from "@material-ui/core";
import { pagination } from "../../../utils/constants";
import IconDisabled from "../../../components/common/IconDisabled";
import Globalbin from "./BinPcn/Globalbin";
import ClientBin from "./BinPcn/Clientbin";
import PharmacyNbin from "./BinPcn/PharmacyNbin";
import PharmacyCEbin from "./BinPcn/PharmacyCEbin";
import { useDispatch } from "react-redux";
import {
  globalBinBlocks,
  phNetworkBINBlocksDetails,
  ceBinBlocks,
  clientBinBlocks,
} from "../../../context/actions/ConfigOverview";
import { useEffect } from "react";
import LoaderUI from "../../../components/common/Loader/Loader";
import { filterFunctionlaityClientBin } from "../../../utils/common";
import { Formik } from "formik";

const PharmacyBinPCNConfig = ({
  phGroupId,
  PharmacyBinPcnConfigCollapse,
  setPharmacyBinPcnConfigurationcollapse,
  ciId,
  permissionObj,
  isinternaluser,
  clickOnPencil,
  pharmaciesphid,
}) => {
  const dispatch = useDispatch();
  const formRef = useRef();
  const [loader, setloader] = useState(false);
  const [defaultFilters, setDefaultFilters] = useState([]);
  const [phNBinData, setPhNetworkData] = useState(null);
  const [phGBinData, setGlobalBinData] = useState(null);
  const [phCeBinData, setCeBinData] = useState(null);
  const [phClientBinData, setClientBinData] = useState(null);
  // Pharmacy Network
  const [sortPhNBinBy, setsortPhNBinBy] = useState("bin");
  const [sortPhNBinorder, setsortPhNBinOrder] = useState("asc");
  const [pagePhNBin, setPagePhNBin] = useState(pagination.page);
  const [rowsPerPagePhNBin, setRowsPerPagePhNBin] = useState(pagination.limit);
  const pharmacyCallApi = (pharmaciesphid, value = false, payload) => {
    pharmaciesphid !== "" && setloader(true);
    dispatch(
      phNetworkBINBlocksDetails(
        {
          phid: pharmaciesphid,
          ceid: ciId,
          pageNumber: pagePhNBin,
          pageSize: rowsPerPagePhNBin,
          sortBy: sortPhNBinBy,
          sortOrder: sortPhNBinorder,
          filter: value ? payload.filter : [],
        },
        setPhNetworkData,
        setloader
      )
    );
  };
  //Pharmacy Network
  // Global Bin Network
  const [sortGBinBy, setsortGBinBy] = useState("bin");
  const [sortGBinorder, setsortGBinOrder] = useState("asc");
  const [pageGBin, setPageGBin] = useState(pagination.page);
  const [rowsPerPageGBin, setRowsPerPageGBin] = useState(pagination.limit);
  const globalBinCallApi = (pharmaciesphid, value = false, payload) => {
    pharmaciesphid !== "" && setloader(true);
    dispatch(
      globalBinBlocks(
        {
          phid: pharmaciesphid,
          ceid: ciId,
          pageNumber: pageGBin,
          pageSize: rowsPerPageGBin,
          sortBy: sortGBinBy,
          sortOrder: sortGBinorder,
          filter: value ? payload.filter : [],
        },
        setGlobalBinData,
        setloader
      )
    );
  };
  // Global Bin Network
  // CE Bin Blocks
  const [sortCEBinBy, setSortCEBinBy] = useState("phGroupName");
  const [sortCEBinorder, setsortCEBinOrder] = useState("asc");
  const [pageCEBin, setPageCEBin] = useState(pagination.page);
  const [rowsPerPageCEBin, setRowsPerPageCEBin] = useState(pagination.limit);
  const ceBinCallApi = (pharmaciesphid, value = false, payload) => {
    pharmaciesphid !== "" && setloader(true);
    dispatch(
      ceBinBlocks(
        {
          phid: pharmaciesphid,
          ceid: ciId,
          pageNumber: pageCEBin,
          pageSize: rowsPerPageCEBin,
          sortBy: sortCEBinBy,
          sortOrder: sortCEBinorder,
          filter: value ? payload.filter : [],
        },
        setCeBinData,
        setloader
      )
    );
  };
  // CE Bin Blocks

  // Client bin Blocks
  const [sortClientBinBy, setsortClientBinBy] = useState("bin");
  const [sortClientBinorder, setsortClientBinOrder] = useState("asc");
  const [pageClientBin, setPageClientBin] = useState(pagination.page);
  const [rowsPerPageClientBin, setRowsPerPageClientBin] = useState(
    pagination.limit
  );
  const clientCallApi = (pharmaciesphid, phGroupId, value = false, payload) => {
    pharmaciesphid !== "" && setloader(true);
    dispatch(
      clientBinBlocks(
        {
          phid: pharmaciesphid,
          ceid: ciId,
          pageNumber: pageClientBin,
          pageSize: rowsPerPageClientBin,
          sortBy: sortClientBinBy,
          sortOrder: sortClientBinorder,
          phGroupId: phGroupId,
          filter: value ? payload.filter : [],
        },
        setClientBinData,
        setloader
      )
    );
  };

  // Client bin Blocks
  useEffect(() => {
    globalBinCallApi(pharmaciesphid);
  }, [pharmaciesphid, pageGBin, rowsPerPageGBin, sortGBinBy, sortGBinorder]);

  useEffect(() => {
    pharmacyCallApi(pharmaciesphid);
  }, [
    pharmaciesphid,
    pagePhNBin,
    rowsPerPagePhNBin,
    sortPhNBinBy,
    sortPhNBinorder,
  ]);

  useEffect(() => {
    ceBinCallApi(pharmaciesphid);
  }, [
    pharmaciesphid,
    pageCEBin,
    rowsPerPageCEBin,
    sortCEBinBy,
    sortCEBinorder,
  ]);

  useEffect(() => {
    clientCallApi(pharmaciesphid, phGroupId);
  }, [
    pharmaciesphid,
    pageClientBin,
    rowsPerPageClientBin,
    sortClientBinBy,
    sortClientBinorder,
  ]);

  const onChangeFilter = async (value, moduleName) => {
    const payload = {
      pageNumber: 1,
    };

    const responseValue = await filterFunctionlaityClientBin(value);
    if (responseValue && Array.isArray(responseValue)) {
      payload.filter = responseValue;
    } else {
      payload.filter = null;
      // setDefaultFilters([]);
    }
    moduleName === "clientBin" &&
      clientCallApi(pharmaciesphid, phGroupId, true, payload);
    moduleName === "pharmacyNetworkBin" &&
      pharmacyCallApi(pharmaciesphid, true, payload);
    moduleName === "globalBin" &&
      globalBinCallApi(pharmaciesphid, true, payload);
    moduleName === "covernedEntityBin" &&
      ceBinCallApi(pharmaciesphid, true, payload);
  };

  return (
    <Formik innerRef={formRef}>
      {() => (
        <>
          <Paper className="card card-first-level p-20 ">
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <HeaderTitle
                variant="h5"
                component="div"
                title="BIN/PCN Configuration"
              />
              <Grid>
                {isinternaluser ? (
                  permissionObj !== null && !permissionObj.readWriteFlag ? (
                    <IconDisabled />
                  ) : (
                    <IconButton size="small" style={{ marginRight: "15px" }}>
                      <BsPencilSquare
                        onClick={() => {
                          clickOnPencil(5, ciId);
                        }}
                      />
                    </IconButton>
                  )
                ) : (
                  <IconDisabled />
                )}

                <IconButton size="small">
                  {PharmacyBinPcnConfigCollapse ? (
                    <AiOutlineMinus
                      onClick={() =>
                        setPharmacyBinPcnConfigurationcollapse(
                          PharmacyBinPcnConfigCollapse ? false : true
                        )
                      }
                    />
                  ) : (
                    <AiOutlinePlus
                      onClick={() =>
                        setPharmacyBinPcnConfigurationcollapse(
                          PharmacyBinPcnConfigCollapse ? false : true
                        )
                      }
                    />
                  )}
                </IconButton>
              </Grid>
            </div>
            <hr />
            {loader && <LoaderUI />}
            <Collapse isOpen={PharmacyBinPcnConfigCollapse}>
              <div>
                <HeaderTitle
                  variant="h5"
                  component="div"
                  title="Global BIN Blocks"
                />
                <Globalbin
                  defaultFilters={defaultFilters}
                  phGBinData={phGBinData}
                  sortGBinBy={sortGBinBy}
                  setsortGBinBy={setsortGBinBy}
                  sortGBinorder={sortGBinorder}
                  setsortGBinOrder={setsortGBinOrder}
                  pageGBin={pageGBin}
                  setPageGBin={setPageGBin}
                  rowsPerPageGBin={rowsPerPageGBin}
                  setRowsPerPageGBin={setRowsPerPageGBin}
                  onChangeFilter={onChangeFilter}
                />
              </div>
              <div>
                <HeaderTitle
                  variant="h5"
                  component="div"
                  title="Pharmacy Network BIN Blocks"
                />
                <PharmacyNbin
                  phNBinData={phNBinData}
                  sortPhNBinBy={sortPhNBinBy}
                  setsortPhNBinBy={setsortPhNBinBy}
                  sortPhNBinorder={sortPhNBinorder}
                  setsortPhNBinOrder={setsortPhNBinOrder}
                  pagePhNBin={pagePhNBin}
                  setPagePhNBin={setPagePhNBin}
                  rowsPerPagePhNBin={rowsPerPagePhNBin}
                  setRowsPerPagePhNBin={setRowsPerPagePhNBin}
                  onChangeFilter={onChangeFilter}
                  defaultFilters={defaultFilters}
                />
              </div>
              <div>
                <HeaderTitle
                  variant="h5"
                  component="div"
                  title="Covered Entity BIN Blocks"
                />
                <PharmacyCEbin
                  phCeBinData={phCeBinData}
                  sortCEBinBy={sortCEBinBy}
                  setSortCEBinBy={setSortCEBinBy}
                  sortCEBinorder={sortCEBinorder}
                  setsortCEBinOrder={setsortCEBinOrder}
                  pageCEBin={pageCEBin}
                  setPageCEBin={setPageCEBin}
                  rowsPerPageCEBin={rowsPerPageCEBin}
                  setRowsPerPageCEBin={setRowsPerPageCEBin}
                  onChangeFilter={onChangeFilter}
                  defaultFilters={defaultFilters}
                />
              </div>
              <div>
                <HeaderTitle
                  variant="h5"
                  component="div"
                  title="Client BIN Blocks"
                />
                <ClientBin
                  phClientBinData={phClientBinData}
                  sortClientBinBy={sortClientBinBy}
                  setsortClientBinBy={setsortClientBinBy}
                  sortClientBinorder={sortClientBinorder}
                  setsortClientBinOrder={setsortClientBinOrder}
                  pageClientBin={pageClientBin}
                  setPageClientBin={setPageClientBin}
                  rowsPerPageClientBin={rowsPerPageClientBin}
                  setRowsPerPageClientBin={setRowsPerPageClientBin}
                  onChangeFilter={onChangeFilter}
                  defaultFilters={defaultFilters}
                />
              </div>
            </Collapse>
          </Paper>
        </>
      )}
    </Formik>
  );
};

export default PharmacyBinPCNConfig;
