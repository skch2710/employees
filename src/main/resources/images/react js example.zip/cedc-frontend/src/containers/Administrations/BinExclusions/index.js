import React from "react";
import { Grid } from "@material-ui/core";

const BinExclusions = () => {
  return (
    <Grid container spacing={2}>
      Bin Exclusion
    </Grid>
  );
};

export default BinExclusions;
