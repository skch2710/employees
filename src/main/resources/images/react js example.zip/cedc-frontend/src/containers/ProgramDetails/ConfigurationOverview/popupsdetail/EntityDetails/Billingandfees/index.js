import React, { useContext, useEffect, useRef, useState } from "react";
import { Button, FormLabel, Grid, Typography } from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import moment from "moment";
import { COContext } from "../../../../COContext";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import BillingContactTable from "./BillingContactTable";
import {
  editCeAdminBillingAndFees,
  fetchCeFrequency,
  getBillingFeeContacts,
  getCeAdminBillingFees,
  saveCeAdminBillingAndFees,
} from "../../../../../../context/actions/ConfigOverview/EntityConfiguration/CeBillingAndFees";
import { pagination } from "../../../../../../utils/constants";
import AdminFeesTable from "./AdminFeesTable";
import { useAdminFeeStyles } from "./styles";
import { MENUS } from "../../../PopupSidebar/constants";
import { userdata } from "../../../../../../utils/common";
import {
  fetchTermsGridTableData,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import DatePicker from "../../../../../../components/common/DatePicker";

const CeBillingAndFees = (props = {}) => {
  const { clickOnAdd } = props;
  const {
    menusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    messageUuid,
    ceId,
    setMenusStatuses,
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext);
  const { billingAndFee } = menusStatuses;
  const userSessionData = JSON.parse(userdata());
  const dispatch = useDispatch();
  const ceFreqData = useRef("");
  const globalClasses = useGlobalStyles();
  const classes = useAdminFeeStyles();
  const { records: billingContactTableData } = useSelector(
    (state) => state.coBillingContactList
  );
  const { records: adminFeesTableData } =
    useSelector((state) => state.ceAdminBillingFeesList) || {};

  const [defaultValues, setDefaultValues] = useState({
    frequency: "2",
    invoiceEffectiveDate: "",
    firstAdminFeeBillingCycle: "",
  });

  const fetchBillingContactTableData = async (payload = {}, callback) => {
    const resp = await dispatch(
      getBillingFeeContacts({
        ceid: !_isEmpty(messageUuid) ? messageUuid.ceid : ceId,
        pageNumber: 1,
        pageSize: pagination.billingLimit,
        sortBy: "userId",
        sortOrder: "desc",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(resp) && callback && callback(resp);
  };

  const getAdminFeeTableData = async (payload = {}, callback) => {
    const resp = await dispatch(
      getCeAdminBillingFees({
        ceid: !_isEmpty(messageUuid) ? [messageUuid.ceid] : [ceId],
        pageNumber: 1,
        pageSize: pagination.limit,
        sortBy: "",
        sortOrder: "",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(resp) && callback && callback(resp);
  };

  const getFrequency = async () => {
    const freq = await dispatch(fetchCeFrequency(ceId));
    if (!_isEmpty(freq) && _isArray(freq)) {
      ceFreqData.current = freq;
      setDefaultValues({
        frequency: `${freq[0].freqId}`,
        invoiceEffectiveDate: `${freq[0].invoiceEffectiveDate || ""}`,
        firstAdminFeeBillingCycle: `${freq[0].firstAdminFeeBillingCycle || ""}`,
      });
    }
  };

  useEffect(() => {
    if (ceId) {
      getAdminFeeTableData();
      fetchBillingContactTableData();
      getFrequency();
    }
  }, []);

  const handleValidate = (values) => {
    const error = {};
    if (!values.frequency) {
      error.frequency = "Please select the Frequency";
    }
    if (!values.invoiceEffectiveDate) {
      error.invoiceEffectiveDate = "Please select the Invoice Effective Date";
    }
    if (!values.firstAdminFeeBillingCycle) {
      error.firstAdminFeeBillingCycle =
        "Please select the First Admin Fee Billing Cycle";
    }
    return error;
  };

  const handleFormSubmit = async (values) => {
    const ceFreqId = !_isEmpty(ceFreqData.current)
      ? ceFreqData.current[0].ceFreqId
      : "";
    const payload = {
      ...(ceFreqId ? { ceFreqId } : {}),
      ceid: ceId || "",
      freqId: Number(values.frequency),
      invoiceEffectiveDate: values.invoiceEffectiveDate,
      firstAdminFeeBillingCycle: values.firstAdminFeeBillingCycle,
      createdById: userSessionData.userId,
      modifiedById: userSessionData.userId,
    };
    const resp = ceFreqId
      ? await dispatch(editCeAdminBillingAndFees(payload))
      : await dispatch(saveCeAdminBillingAndFees(payload));

    if (resp) {
      if (
        (clickOnAdd || billingAndFee) &&
        adminFeesTableData.totalElements > 0 &&
        billingContactTableData.totalElements > 0
      ) {
        dispatch(
          updateSectionStatus({
            ceId: messageUuid.ceid || ceId,
            sectionId: 2,
            callback: statusCallback,
          })
        );
      }
      values.isStopNavigation
        ? setOpenAddCePopup(false)
        : setPopupActiveMenu(MENUS.CE_ACH_CONFIGURATION);
    }
  };

  const statusCallback = (res) => {
    if (res.statusCode === 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({
        ...prev,
        billingAndFee: false,
      }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };
  const handleKeyDown = (keyEvent) => {
    if ((keyEvent.charCode || keyEvent.keyCode) === 13) {
      keyEvent.preventDefault();
    }
  };

  return (
    <Grid container spacing={4}>
      <Grid item md={12}>
        <BasicTypography
          variant="h4"
          title="Entity Details > 340BDirect+ Admin Billing and Fees"
        />
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={4}>
          <Grid item md={12}>
            <BillingContactTable
              fetchBillingContactTableData={fetchBillingContactTableData}
              isAddUserEnable={true}
            />
          </Grid>
          <Grid item md={12}>
            <Formik
              enableReinitialize={true}
              initialValues={defaultValues}
              onSubmit={handleFormSubmit}
              validate={handleValidate}
            >
              {({ setFieldValue, submitForm, errors, touched, values }) => {
                return (
                  <Form onKeyDown={handleKeyDown}>
                    <Grid container spacing={2} direction="column">
                      <Grid item md={12}>
                        <BasicTypography
                          variant="h5"
                          title={`340BDirect+ Admin Billing and Fees`}
                        />
                      </Grid>
                      <Grid item md={12}>
                        <Grid container spacing={2}>
                          <Grid item md={4} xs={12}>
                            <FormLabel required>
                              340BDirect+ Invoice Billing Frequency
                            </FormLabel>
                            <div className={classes.radioContainer}>
                              <div className={classes.radioAndLabelContainer}>
                                <Field
                                  id="monthly"
                                  name="frequency"
                                  type="radio"
                                  value="1"
                                  className={classes.radioInput}
                                  disabled
                                />
                                <FormLabel
                                  htmlFor="monthly"
                                  className={globalClasses.noPaddingForLabels}
                                >
                                  Monthly
                                </FormLabel>
                              </div>
                              <div className={classes.radioAndLabelContainer}>
                                <Field
                                  id="biMonthly"
                                  name="frequency"
                                  type="radio"
                                  value="2"
                                  className={classes.radioInput}
                                  disabled
                                />
                                <FormLabel
                                  htmlFor="biMonthly"
                                  className={globalClasses.noPaddingForLabels}
                                >
                                  Bi-Monthly
                                </FormLabel>
                              </div>
                            </div>
                            {errors.frequency && touched.frequency && (
                              <Typography color="error" variant="caption">
                                {errors.frequency}
                              </Typography>
                            )}
                          </Grid>
                          <Grid item md={4} xs={12}>
                            <FormLabel required>
                              Invoice Effective Date
                            </FormLabel>
                            <Field as="select" name="invoiceEffectiveDate">
                              {({ field }) => (
                                <DatePicker
                                  {...field}
                                  onChange={(_e, date) => {
                                    if (!date) setFieldValue("endDate", "");
                                    setFieldValue("invoiceEffectiveDate", date);
                                  }}
                                  value={
                                    values.invoiceEffectiveDate
                                      ? moment(
                                          values.invoiceEffectiveDate,
                                          "MM/DD/YYYY"
                                        )
                                      : ""
                                  }
                                />
                              )}
                            </Field>
                            {errors.invoiceEffectiveDate &&
                              touched.invoiceEffectiveDate && (
                                <BasicTypography
                                  color="error"
                                  variant="caption"
                                >
                                  {errors.invoiceEffectiveDate}
                                </BasicTypography>
                              )}
                          </Grid>
                          <Grid item md={4} xs={12}>
                            <FormLabel required>
                              First Admin Fee Billing Cycle
                            </FormLabel>
                            <Field as="select" name="firstAdminFeeBillingCycle">
                              {({ field }) => (
                                <DatePicker
                                  {...field}
                                  onChange={(_e, date) => {
                                    if (!date) setFieldValue("endDate", "");
                                    setFieldValue(
                                      "firstAdminFeeBillingCycle",
                                      date
                                    );
                                  }}
                                  value={
                                    values.firstAdminFeeBillingCycle
                                      ? moment(
                                          values.firstAdminFeeBillingCycle,
                                          "MM/DD/YYYY"
                                        )
                                      : ""
                                  }
                                  disabledDate={(d) =>
                                    !d ||
                                    !d.isSameOrAfter(
                                      values.invoiceEffectiveDate,
                                      "day"
                                    )
                                  }
                                />
                              )}
                            </Field>
                            {errors.firstAdminFeeBillingCycle &&
                              touched.firstAdminFeeBillingCycle && (
                                <BasicTypography
                                  color="error"
                                  variant="caption"
                                >
                                  {errors.firstAdminFeeBillingCycle}
                                </BasicTypography>
                              )}
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item md={12}>
                        <AdminFeesTable
                          getAdminFeeTableData={getAdminFeeTableData}
                          isConfigurable={true}
                        />
                      </Grid>
                      <Grid item md={12}>
                        <Grid container spacing={2} justifyContent="flex-end">
                          <Grid item>
                            <Button
                              color="primary"
                              size="small"
                              variant="contained"
                              className={globalClasses.primaryBtn}
                              onClick={() => {
                                setFieldValue("isStopNavigation", false);
                                submitForm();
                              }}
                            >
                              Next
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              type="reset"
                              size="small"
                              variant="outlined"
                              className={globalClasses.secondaryBtn}
                              onClick={() => {
                                setPopupActiveMenu(MENUS.CE_ACH_CONFIGURATION);
                              }}
                            >
                              Skip
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              type="submit"
                              size="small"
                              variant="outlined"
                              className={globalClasses.secondaryBtn}
                              onClick={() => {
                                setFieldValue("isStopNavigation", true);
                                submitForm();
                              }}
                            >
                              Save and Exit
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              type="reset"
                              size="small"
                              variant="outlined"
                              className={globalClasses.secondaryBtn}
                              onClick={() => {
                                setOpenAddCePopup(false);
                              }}
                            >
                              Cancel
                            </Button>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Form>
                );
              }}
            </Formik>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default CeBillingAndFees;
