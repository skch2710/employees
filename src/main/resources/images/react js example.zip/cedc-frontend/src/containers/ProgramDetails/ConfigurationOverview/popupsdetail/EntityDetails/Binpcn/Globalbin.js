import React, { useState, useEffect } from "react";
import { Paper, Tooltip } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import "antd/dist/antd.css";

//Common
import HeaderTitle from "../../../../../../components/common/Typography/HeaderTitle";
import MaterialTable, { MTableToolbar } from "material-table";
import { useStyles } from "../../../../../../mui-styles/commonTableMuiStyle";
import tableIcons from "./MaterilTableicons";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
//css
import { TiFilter } from "react-icons/ti";
import { LABELS, pagination } from "../../../../../../utils/constants";
import { undefinedArrayContent } from "../../../../../../utils/common";
import {
  Cobinpcndata,
  Cobinpcndatatoggleoff,
} from "../../../../../../context/actions/CoPopupBinpcn";

const ColumnFilterIcon = () => {
  return <TiFilter fontSize="small" />;
};

const Globalbin = ({
  locationCollapse,
  setlocationCollapse,
  ciId,
  toggleglobalbin,
  messageUiid,
}) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [rowsPerPage, setRowsPerPage] = useState(pagination.limit);
  const [page, setPage] = useState(pagination.page);
  const [sortBy, setsortBy] = useState("bin");
  const [sortorder, setOrder] = useState("asc");
  const [data, setData] = useState(columns);

  const onChangeRowsperpage = (pagesize) => {
    const { totalElements = 0 } = Maingetbinpcndata;
    const totalPages = Math.ceil(totalElements / pagesize);
    if (page > totalPages) setPage(pagination.page);
    setRowsPerPage(pagesize);
  };

  const onChangePagination = (data, pagesize) => {
    let currentpage = data + 1;
    if (pagesize === rowsPerPage) setPage(currentpage);
  };

  const onChangeSorting = async (orderedColumnId) => {
    setOrder(sortorder === "asc" ? "desc" : "asc");
    setsortBy(columns[orderedColumnId].field);
  };
  useEffect(() => {
    if (toggleglobalbin) {
      dispatch(
        Cobinpcndata({
          pageNumber: page,
          pageSize: rowsPerPage,
          sortBy: sortBy,
          sortOrder: sortorder,
          export: false,
        })
      );
    } else {
      dispatch(
        Cobinpcndatatoggleoff({
          ceid: ciId,
          pageNumber: page,
          pageSize: rowsPerPage,
          sortBy: sortBy,
          sortOrder: sortorder,
          export: false,
        })
      );
    }
  }, [rowsPerPage, page, sortBy, sortorder, toggleglobalbin]);

  let Maingetbinpcndata = useSelector(
    (state) => state.cobinpcngriddata.records
  );
  let cobinpcndatatoggleoff = useSelector(
    (state) => state.cobinpcntoggleoffdata.records
  );
  const columns = [
    {
      title: "BIN Block Group",
      field: "binBlockGroup",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.binBlockGroup}>
            <span>{rowData.binBlockGroup}</span>
          </Tooltip>
        );
      },
      // editComponent: (rowData) => {
      //   return (
      //     <input className="formControl"></input>

      //   );
      // },
    },
    {
      title: "Bin Block Type",
      field: "binBlockType",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.binBlockType}>
            <span>{rowData.binBlockType}</span>
          </Tooltip>
        );
      },
    },
    {
      title: LABELS.PharmacyChain,
      field: "pharmacyGroup",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyGroup}>
            <span>{rowData.pharmacyGroup}</span>
          </Tooltip>
        );
      },
    },
    {
      title: LABELS.PharmacyStore,
      field: "pharmacy",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacy}>
            <span>{rowData.pharmacy}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "BIN",
      field: "bin",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bin}>
            <span>{rowData.bin}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "PCN",
      field: "pcn",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pcn}>
            <span>{rowData.pcn}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Group No",
      field: "groupNumber",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.groupNumber}>
            <span>{rowData.groupNumber}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Start Date",
      field: "startDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "End Date",
      field: "endDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
    },
  ];
  const Actions = [
    // {
    //   icon: tableIcons.AddButton,
    //   tooltip: "Add Provider",
    //   isFreeAction: true,
    // },
    // {
    //   icon: tableIcons.Edit,
    //   tooltip: "Edit",
    //   isFreeAction: false,
    // }
  ];

  return (
    <div>
      {/* <Paper className="card card-first-level p-20 "> */}

      <div className={classes.root}>
        <div className="card card-first-level">
          <MaterialTable
            title={<HeaderTitle variant="h6" title="Data Preview" />}
            columns={columns}
            data={
              toggleglobalbin
                ? undefinedArrayContent(Maingetbinpcndata)
                : undefinedArrayContent(cobinpcndatatoggleoff)
            }
            page={page - 1}
            totalCount={
              toggleglobalbin
                ? Maingetbinpcndata.totalElements
                : cobinpcndatatoggleoff.totalElements
            }
            onChangePage={onChangePagination}
            onOrderChange={onChangeSorting}
            onChangeRowsPerPage={onChangeRowsperpage}
            actions={Actions}
            editable={{
              onRowAdd: (newData) =>
                new Promise((resolve, reject) => {
                  setTimeout(() => {
                    setData([newData, ...data]);

                    resolve();
                  }, 1000);
                }),
              onRowUpdate: (newData, oldData) =>
                new Promise((resolve, reject) => {
                  setTimeout(() => {
                    const dataUpdate = [...data];
                    const index = oldData.tableData.id;
                    dataUpdate[index] = newData;
                    setData([...dataUpdate]);

                    resolve();
                  }, 1000);
                }),
              onRowDelete: (oldData) =>
                new Promise((resolve, reject) => {
                  setTimeout(() => {
                    const dataDelete = [...data];
                    const index = oldData.tableData.id;
                    dataDelete.splice(index, 1);
                    setData([...dataDelete]);

                    resolve();
                  }, 1000);
                }),
            }}
            icons={{
              SortArrow: () => TableCustomSortArrow({ sortOrder: sortorder }),
              Filter: ColumnFilterIcon,
              Edit: tableIcons.Edit,
              Add: tableIcons.AddButton,
              Delete: tableIcons.Delete,
            }}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Toolbar: (props) => (
                <div
                  style={{
                    marginRight: "259px",
                    marginTop: "-48px",
                    marginBottom: "18px",
                  }}
                >
                  <MTableToolbar {...props} />
                </div>
              ),
            }}
            options={{
              search: false,
              searchFieldAlignment: "right",
              searchAutoFocus: true,
              searchFieldVariant: "standard",
              actionsColumnIndex: 0,
              filtering: false,
              paginationType: "stepped",
              paging: "true",
              showFirstLastPageButtons: false,
              paginationPosition: "top",
              exportButton: false,
              exportAllData: false,
              exportFileName: "Locations List",
              headerStyle: {
                background: "#EFF4FA",
                color: "#8F9BB3",
                fontSize: "11px",
                whiteSpace: "nowrap",
              },
              tableLayout: "auto",
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: rowsPerPage,
              draggable: false,
            }}
          />
        </div>
      </div>
      {/* </Paper> */}
    </div>
  );
};

export default Globalbin;
