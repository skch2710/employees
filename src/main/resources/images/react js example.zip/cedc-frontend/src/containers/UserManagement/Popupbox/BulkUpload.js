import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button, FormLabel, Grid, Typography } from "@material-ui/core";
import DragDropFile from "../../../components/common/DragDropFile";
import Excel from "../../../assets/excel.png";
import {
  bulkUpload,
  validateUsersFile,
} from "../../../context/actions/Usermanagement";
import LoaderUI from "../../../components/common/Loader/Loader";
import { ALLOWED_FILE_TYPES } from "../constant";
import { useUserManagementStyles } from "../style";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { getUserSession } from "../../../utils/helper";
import BasicTypography from "../../../components/common/Typography/BasicTypography";

const BulkUpload = ({ setBulkUploadPopup, loadUserData }) => {
  const dispatch = useDispatch();
  const classes = useUserManagementStyles();
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();
  const { isInternalUser } = userSession;
  const [progress, setProgress] = useState(0);
  const [progressBarOpen, setProgressBarOpen] = useState(false);
  const [internal, setInternal] = useState(isInternalUser);
  const [external, setExternal] = useState(isInternalUser ? false : true);
  const [fileData, setFileData] = useState(null);
  const [ceId, setCeId] = useState(
    isInternalUser ? null : userSession.coveredEntityDTOs[0].ceID
  );
  const [ceName, setCeName] = useState(
    isInternalUser ? null : userSession.coveredEntityDTOs[0].ceName
  );
  const [errorMessage, setErrorMessage] = useState([]);
  const loader = useSelector((state) => state.usermanagement.loading);
  const isFilesSelected = fileData && fileData.length;

  const handleChange = (type) => {
    setErrorMessage([]);
    if (type === "internal") {
      setInternal(true);
      setExternal(false);
    } else {
      setInternal(false);
      setExternal(true);
    }
  };

  const handleSubmit = () => {
    let data = new FormData();
    fileData.forEach((file) => {
      data.append("file", file);
    });
    const { roleId } = userSession.userRole.role;

    let json = {
      ceId: internal ? -1 : ceId,
      internalUser: internal ? internal : false,
      roleId,
    };
    dispatch(
      bulkUpload(data, json, (res) => {
        if (res.statusCode === 200) {
          loadUserData();
          setBulkUploadPopup(false);
        }
        if (res.statusCode === 404 && res.errorMessage) {
          setBulkUploadPopup(false);
        }
      })
    );
  };

  const handleFileSelectEvent = (e) => {
    const chosenFiles = Array.prototype.slice.call(e.target.files);
    uploadFile(chosenFiles, external, ceId);
    e.target.value = null;
  };

  const uploadFile = (files, isExternal, ceID) => {
    if (files.length > 1) {
      setErrorMessage(["Multiple files not allowed please select one."]);
      return;
    }
    if (isExternal && !ceID) {
      setErrorMessage(["Please Select Covered Entity"]);
      return;
    }
    setErrorMessage([]);
    setProgressBarOpen(true);
    let data = new FormData();
    files.forEach((file) => {
      data.append("file", file);
    });

    dispatch(
      validateUsersFile(
        data,
        // success callback
        (res) => {
          if (res.errorMessage && res.data) {
            setErrorMessage([...res.data]);
          } else if (res.errorMessage) {
            setErrorMessage([res.errorMessage]);
          }
          setFileData(files);
          setProgressBarOpen(false);
        },
        // failed callback
        () => {
          setFileData([]);
          setProgressBarOpen(false);
        },
        setProgress
      )
    );
  };

  const handleCEChange = (e) => {
    if (!e.target.value) return;
    setErrorMessage([]);
    setCeId(+e.target.value);
    const selectedCe = userSession.coveredEntityDTOs.find(
      (item) => item.ceID === +e.target.value
    );
    setCeName(selectedCe.ceName);
  };

  return (
    <Grid container spacing={2}>
      {loader && <LoaderUI />}
      <Grid item md={12}>
        <Grid container alignItems="center" spacing={2}>
          <Grid item>
            <BasicTypography variant="h5">
              Don't have the template?
            </BasicTypography>
          </Grid>
          <Grid item>
            <a
              href={
                internal
                  ? "/templates/Internal_User_Management_Template.xlsx"
                  : "/templates/External_User_Management_Template.xlsx"
              }
              download="User Management Template"
            >
              <Button
                variant="outlined"
                color="primary"
                size="small"
                className={globalClasses.secondaryBtn}
              >
                <img src={Excel} className={classes.bulkUploadIcon} />
                Download Template
              </Button>
            </a>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        {isFilesSelected ? (
          <BasicTypography variant="h5">
            {internal ? "Internal User" : `External User - ${ceName} `}
          </BasicTypography>
        ) : (
          <>
            {isInternalUser && (
              <BasicTypography variant="h5">Choose User Type</BasicTypography>
            )}
            <div className={classes.radioContainer}>
              <div className={classes.radioAndLabelContainer}>
                <input
                  id="internal"
                  value="internal"
                  name="selectUser"
                  type="radio"
                  onChange={() => handleChange("internal")}
                  checked={internal}
                />
                <FormLabel
                  htmlFor="internal"
                  className={globalClasses.radioLabel}
                >
                  Internal
                </FormLabel>
              </div>
              <div className={classes.radioAndLabelContainer}>
                <input
                  id="external"
                  value="external"
                  name="selectUser"
                  type="radio"
                  onChange={() => handleChange("external")}
                  checked={external}
                />
                <FormLabel
                  htmlFor="external"
                  className={globalClasses.radioLabel}
                >
                  External
                </FormLabel>
              </div>
            </div>
          </>
        )}
        {external && !isFilesSelected ? (
          <Grid xs={12} style={{ margin: "10px 0" }}>
            <select
              className={globalClasses.formControl}
              onChange={handleCEChange}
              defaultValue={
                userSession.coveredEntityDTOs.length === 1
                  ? userSession.coveredEntityDTOs[0].ceID
                  : ""
              }
              disabled={
                userSession.coveredEntityDTOs.length === 1 ? true : false
              }
            >
              <option value={""} disabled>
                Select Covered Entity
              </option>
              {userSession.coveredEntityDTOs &&
                userSession.coveredEntityDTOs.length > 0 &&
                userSession.coveredEntityDTOs.map((keysItem) => {
                  return (
                    <option
                      key={keysItem.ceID}
                      name={keysItem.ceName}
                      value={keysItem.ceID}
                    >
                      {keysItem.ceName}
                    </option>
                  );
                })}
            </select>
          </Grid>
        ) : null}
        {errorMessage.length ? (
          <div className={classes.headerErrorsContainer}>
            {errorMessage.map((msg) => {
              return (
                <BasicTypography variant="caption" color="error">
                  {msg}
                </BasicTypography>
              );
            })}
          </div>
        ) : null}
      </Grid>
      <Grid item md={12}>
        <DragDropFile
          progressBarOpen={progressBarOpen}
          uploadPercentage={progress}
          fileData={fileData}
          uploadFile={(file) => uploadFile(file, external, ceId)}
        />
      </Grid>
      {!isFilesSelected ? (
        <Grid item md={12}>
          <Grid container alignItems="center" justifyContent="center">
            <BasicTypography variant="h5">(OR)</BasicTypography>
          </Grid>
        </Grid>
      ) : null}
      <Grid item md={12}>
        <Grid container spacing={2} justifyContent="flex-end">
          <Grid item>
            {isFilesSelected ? (
              <Button
                type="submit"
                color="primary"
                size="small"
                variant="contained"
                onClick={handleSubmit}
                className={globalClasses.primaryBtn}
                disabled={errorMessage.length}
              >
                Upload
              </Button>
            ) : (
              <>
                <input
                  style={{ display: "none" }}
                  id="contained-button-file"
                  multiple
                  type="file"
                  accept={ALLOWED_FILE_TYPES}
                  onChange={handleFileSelectEvent}
                />

                <FormLabel htmlFor="contained-button-file">
                  <Button
                    color="primary"
                    size="small"
                    variant="contained"
                    className={globalClasses.primaryBtn}
                    component="span"
                  >
                    Choose File
                  </Button>
                </FormLabel>
              </>
            )}
          </Grid>
          <Grid item>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className={globalClasses.secondaryBtn}
              onClick={() => setBulkUploadPopup(false)}
            >
              Close
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default BulkUpload;
