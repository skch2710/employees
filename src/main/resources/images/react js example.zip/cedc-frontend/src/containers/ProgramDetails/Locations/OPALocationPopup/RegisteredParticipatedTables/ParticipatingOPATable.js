import React, {
  forwardRef,
  memo,
  useCallback,
  useContext,
  useState,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { TiFilter } from "react-icons/ti";
import { useSelector } from "react-redux";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../Styles/useGlobalStyles";
import { pagination } from "../../../../../utils/constants";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../components/common/DataNotFound";
import { getTableHeaderCount, isEmptyGrid } from "../../../../../utils/helper";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import BasicPopup from "../../../../../components/Popup/BasicPopup";
import NdcDetailsTable from "./RegisteredOPATable";
import { useOPALocationsTablesStyles } from "./styles";
import { COContext } from "../../../COContext";
import pass from "../../../../../assets/pass.png";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import Pagination from "../../../../../components/common/Pagination";
import FileSaver from "file-saver";
import * as XLSX from "xlsx";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";

const ParticipatingOPATable = memo(
  forwardRef((_props = {}, ref) => {
    const { selectedSearchResults } = _props;
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const iconsAndButtons = useTableIconsAndButtons();
    const { participatingLocationsData = {}, setParticipatingLocationsData } =
      useContext(COContext) || {};
    const { loading } = useSelector(
      (state) => state.ndcSelectionDraftListLoading
    );

    const [enableFilters, setEnableFilters] = useState(false);
    const [showNdcDetailsPopup, setShowNdcDetailsPopup] = useState(false);
    const [ndcDetailsRowData, setNdcDetailsRowData] = useState({});
    const [pageData, setPageData] = useState({
      key: Date.now(),
      pageIndex: 0,
      pageSize: pagination.limit,
    });
    const classes = useOPALocationsTablesStyles({
      totalElements:
        !_isEmpty(participatingLocationsData) &&
        participatingLocationsData.totalElements,
    });

    const PARTICIPATING_COLUMNS = [
      {
        title: "Provider Location HRSA ID",
        field: "locHrsaid",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.locHrsaid}>
              <span>{rowData.locHrsaid}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Provider Location HRSA ID" />
        ),
      },
      {
        title: "Address Line 1",
        field: "address1",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.address1}>
              <span>{rowData.address1 || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Address Line 1" />
        ),
      },
      {
        title: "Address Line 2",
        field: "address2",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.address2}>
              <span>{rowData.address2}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Address Line 2" />
        ),
      },
      {
        title: "City",
        field: "city",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.city}>
              <span>{rowData.city}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="City" />
        ),
      },
      {
        title: "State",
        field: "state",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.state || ""}>
              <span>{rowData.state || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="State" />
        ),
      },
      {
        title: "Zip",
        field: "zip",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.zip || ""}>
              <span>{rowData.zip || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Zip" />
        ),
      },
    ];

    const handleNdcDetailsPopup = useCallback(
      (prop = {}) =>
        () => {
          const { state, rowData } = prop;
          if (state) {
            setNdcDetailsRowData(rowData);
          }
          setShowNdcDetailsPopup(state);
        },
      []
    );
    const handleDraftExport = (data = []) => {
      const filteredData = data.map((row = {}) => ({
        "HRSA ID": row.locHrsaid || "",
        "Address Line 1": row.address1 || "",
        "Address Line 2": row.address2 || "",
        City: row.city || "",
        State: row.state || "",
        Zip: row.zip || "",
      }));
      const ws = XLSX.utils.json_to_sheet(filteredData);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "340B Participating Locations.xlsx");
    };

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        isFreeAction: true,
        disabled: isEmptyGrid(participatingLocationsData),
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(participatingLocationsData),
        isFreeAction: true,
        onClick: () => handleDraftExport(ref.current.dataManager.pagedData),
      },
    ];

    return (
      <>
        <MaterialTable
          title={
            <div className={classes.successContainer}>
              <BasicTypography
                variant="h5"
                title={`340B Participating Locations (${getTableHeaderCount(
                  participatingLocationsData.totalElements
                )})`}
              />
              {selectedSearchResults.participating.length > 0 && (
                <span className={classes.uploadSuccess}>
                  <img src={pass} alt="passed" />
                  <p>{`${selectedSearchResults.participating.length} ${
                    selectedSearchResults.participating.length === 1
                      ? "Location"
                      : "Locations"
                  } added successfully`}</p>
                </span>
              )}
            </div>
          }
          tableRef={ref}
          columns={PARTICIPATING_COLUMNS}
          data={participatingLocationsData.content}
          totalCount={participatingLocationsData.totalElements}
          key={pageData.key}
          icons={{
            SortArrow: () => TableCustomSortArrow(),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            Pagination: (props) => <Pagination {...props} />,
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            selection: true,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: pagination.limit,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(participatingLocationsData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
        <BasicPopup
          title="NDC Details"
          show={showNdcDetailsPopup}
          disableFooter={true}
          dialogProps={{
            maxWidth: "md",
          }}
          handleClose={handleNdcDetailsPopup({ state: false })}
        >
          <NdcDetailsTable ndcDetailsRowData={ndcDetailsRowData} />
        </BasicPopup>
      </>
    );
  })
);

export default ParticipatingOPATable;
