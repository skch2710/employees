import { makeStyles } from "@material-ui/core";

export const useCeTermDetailsStyle = makeStyles((_theme) => {
  return {};
});
