import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { InvoiceClientLevelExport } from "../../../../context/actions/Invoice";
import { LABELS, notNull } from "../../../../utils/constants";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const {
      phGroupId,
      billingPeriod,
      invoicePeriodStartDate,
      invoicePeriodEndDate,
      ceid,
      controller,
      columnFilters,
    } = props;
    dispatch(
      InvoiceClientLevelExport(
        {
          phGroupId: phGroupId,
          billPeriod: billingPeriod,
          invoicePeriodStartDate: invoicePeriodStartDate,
          invoicePeriodEndDate: invoicePeriodEndDate,
          ceId: [ceid],
          export: true,
          pageNumber: 1,
          pageSize: 20,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
        },
        (result) => {
          var data = result.content.map(
            ({
              ceName,
              phGroupName,
              phName,
              invoicePeriodStartDate,
              invoicePeriodEndDate,
              totalInvoiced,
              dispensingFee,
              trueUp
            }) => ({
              "Covered Entity" : (ceName),
              [LABELS.PharmacyChain]: notNull(phGroupName),
              [LABELS.PharmacyStore]: notNull(phName),
              "Billing Period":  `${invoicePeriodStartDate} - ${invoicePeriodEndDate}` ,
              "Total Invoiced": notNull(totalInvoiced),
              "Dispensing Fees": notNull(dispensingFee),
              "True Up Fees": notNull(trueUp)
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Client level details" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
