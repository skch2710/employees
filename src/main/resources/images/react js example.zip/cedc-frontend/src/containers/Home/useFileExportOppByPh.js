import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { ViewFullreportdonut1falloutexport } from "../../context/actions/Home";
import { LABELS, notNull } from "../../utils/constants";

const useFileExportOppByPh = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const {
      ceid,
      phid,
      phGroupId,
      processedStartDate,
      processedEndDate,
      controller,
      columnFilters,
    } = props;

    dispatch(
      ViewFullreportdonut1falloutexport(
        {
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
          ceid: ceid,
          phid: phid,
          phGroupId: phGroupId,
          processedStartDate: processedStartDate,
          processedEndDate: processedEndDate,
        },
        (result) => {
          var data = result.content.map(({ ceName, phName, savings }) => ({
            [LABELS.CoveredEntity]: notNull(ceName),
            "Pharmacy Store": notNull(phName),
            "Estimated Savings": notNull(savings),
          }));
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(
            fileData,
            "Opportunity by Pharmacy (Fallout).xlsx"
          );
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExportOppByPh;
