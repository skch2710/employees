import React, { useContext, useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import DatePicker from "../../../../../../components/common/DatePicker";
import {
  Button,
  Grid,
  FormLabel,
  FormControlLabel,
  Typography,
} from "@material-ui/core";
import { useDispatch } from "react-redux";
import moment from "moment";
import _debounce from "lodash/debounce";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import { COContext } from "../../../../COContext";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { basicDetailsFormDefaultValues } from "./constants";
import { useBasicDetailsStyles } from "./styles";
import {
  fetchPhBasicDetails,
  getDistricts,
  getDivisions,
  getPharmacyNetworks,
  getRegions,
  getStates,
  validateNABP,
} from "../../../../../../context/actions/Common";
import {
  createPhPayload,
  getDefaultValuesFromResponse,
  getContextCurrentPharmacyData,
} from "../helper";
import {
  basicDetailsMessageUuidTest,
  fetchPhNPIOptions,
  savePhBasicDetails,
} from "../../../../../../context/actions/PharmacyConfiguration";
import AutoComplete from "../../../../../../components/common/AutoComplete";
import { MENUS } from "../../../PopupSidebar/constants";
// import UploadedDocumentsTable from "./UploadedDocumentsTable";
// import FileUploadDroppable from "./FileUploadDroppable";
import { updatePharmacySectionStatus } from "../../../../../../context/actions/ConfigOverview";
import { userdata } from "../../../../../../utils/common";
import { checkIsNPIPresentInList, checkIsPhNamePresentInList } from "./helper";
import { fetchPharmaciesTableData } from "../../../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { GLOBAL_LOADING } from "../../../../../../context/constants";
import {
  ERROR,
  LABELS,
  POLLING_COUNT,
  REGEX,
} from "../../../../../../utils/constants";
import Toggle from "../../../../../../components/common/Toggle";

const PharmacyBasicDetails = () => {
  const classes = useBasicDetailsStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    messageUuid,
    currentPharmacy,
    phConfigSectionStatus,
    setPhConfigSectionStatus,
    setOpenAddCePopup,
    setPopupActiveMenu,
    setCurrentPharmacy,
    phConfigStatusPercent,
    setPhConfigStatusPercent,
    isNewPharmacy,
    setIsNewPharmacy,
    phGridPayload,
  } = useContext(COContext) || {};
  const { phBasicDetails } = phConfigSectionStatus;
  const { ceid: ceId } = messageUuid || {};
  const userSessionData = JSON.parse(userdata());
  const [defaultValues, setDefaultValues] = useState(
    basicDetailsFormDefaultValues()
  );

  const [phGroupsOptions, setPhGroupsOptions] = useState([]);
  const [regionOptions, setRegionOptions] = useState([]);
  const [divisionOptions, setDivisionOptions] = useState([]);
  const [districtOptions, setDistrictOptions] = useState([]);
  const [states, setStates] = useState([]);
  const [npiOptions, setNpiOptions] = useState([]);
  const [npiIsLoading, setNpiIsLoading] = useState(false);
  const [npiExistError, setNPIExistError] = useState(false);
  const [isNabpUnique, setIsNabpUnique] = useState(true);
  const [phNameOptions, setPhNameOptions] = useState([]);
  const [phNameIsLoading, setPhNameIsLoading] = useState(false);
  const [isEmptyData, setIsEmptyData] = useState(false);
  //TODO MVP R2
  // const [docList, setDocList] = useState([]);
  // const [uploadProgress, setUploadProgress] = useState(0);
  // const [isUploading, setIsUploading] = useState(false);

  const sectionUpdateCallback = (res) => {
    if (res.statusCode === 200) {
      const phConfigPercentage =
        (res.data && res.data.configPercentage) || phConfigStatusPercent;
      if (phConfigPercentage) {
        setPhConfigStatusPercent(phConfigPercentage);
      }
      setPhConfigSectionStatus((prev) => ({ ...prev, phBasicDetails: false }));
      dispatch(fetchPharmaciesTableData(phGridPayload));
    }
  };

  const handleFormSubmit = async (values) => {
    const payload = createPhPayload({
      ...values,
      ceId,
      phId: !_isEmpty(currentPharmacy)
        ? currentPharmacy.phid
        : values.phId || "",
      createdBy: userSessionData.userId,
      modifiedBy: userSessionData.userId,
      clientConfigId: !_isEmpty(currentPharmacy)
        ? currentPharmacy.clientConfigId
        : "",
    });
    const resp = await dispatch(savePhBasicDetails(payload));
    if (!_isEmpty(resp)) {
      if (resp.data) {
        handlePolling({
          messageUUid: resp.data,
          stopNavigation: values.stopNavigation,
          currentCount: POLLING_COUNT,
        });
      }
    }
  };

  const handlePolling = async ({
    messageUUid,
    currentCount,
    stopNavigation,
  }) => {
    const count = currentCount;
    const resp = await dispatch(
      basicDetailsMessageUuidTest(messageUUid, count)
    );
    if (resp && resp.statusCode === 200) {
      const contextPayload = getContextCurrentPharmacyData(resp.data);
      setCurrentPharmacy(contextPayload);
      !isNewPharmacy && dispatch(fetchPhBasicDetails(contextPayload.clientId));
      if (isNewPharmacy || phBasicDetails) {
        dispatch(
          updatePharmacySectionStatus({
            ceId,
            clientId: contextPayload.clientId,
            sectionId: 12,
            callback: sectionUpdateCallback,
          })
        );
      }
      if (stopNavigation) setOpenAddCePopup(false);
      else setPopupActiveMenu(MENUS.PH_BILLING_AND_FEES);
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({ messageUUid, currentCount: count - 1, stopNavigation });
    }
  };

  const getPhBasicDetails = async (clientId) => {
    const resp = await dispatch(fetchPhBasicDetails(clientId));
    !_isEmpty(resp) &&
      setDefaultValues(getDefaultValuesFromResponse(resp || {}));
  };

  //TODO MVP R2
  // const fetchDocumentsList = () => {};

  const checkPromiseFulfilled = (object) => {
    return object.status === "fulfilled" && _isArray(object.value);
  };

  const fetchDropdownOptions = () => {
    const functionProps = { disableLoader: true };
    dispatch({ type: GLOBAL_LOADING, data: true });
    const groupsPromise = dispatch(getPharmacyNetworks(true));
    const statesPromise = getStates();
    const regionsPromise = dispatch(getRegions(functionProps));
    const divisionsPromise = dispatch(getDivisions(functionProps));
    const districtsPromise = dispatch(getDistricts(functionProps));
    const promises = [
      groupsPromise,
      statesPromise,
      regionsPromise,
      divisionsPromise,
      districtsPromise,
    ];
    Promise.allSettled(promises)
      .then((resp) => {
        const [groups, states, regions, divisions, districts] = resp;
        checkPromiseFulfilled(groups) && setPhGroupsOptions(groups.value);
        checkPromiseFulfilled(states) && setStates(states.value);
        checkPromiseFulfilled(regions) && setRegionOptions(regions.value);
        checkPromiseFulfilled(divisions) && setDivisionOptions(divisions.value);
        checkPromiseFulfilled(districts) && setDistrictOptions(districts.value);
        if (!_isEmpty(currentPharmacy)) {
          getPhBasicDetails(currentPharmacy.clientId);
        } else {
          if (!isNewPharmacy) setIsNewPharmacy(true);
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      })
      .catch(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };

  useEffect(() => {
    fetchDropdownOptions();
  }, []);

  //TODO MVP R2
  // const handleDocUpload = (files) => {
  //   console.log(files);
  //   let count = 0;
  //   setIsUploading(true);
  //   const interval = setInterval(() => {
  //     if (count >= 100) {
  //       clearInterval(interval);
  //       setUploadProgress(0);
  //       setIsUploading(false);
  //     } else {
  //       setUploadProgress(count);
  //       count += 10;
  //     }
  //   }, 500);
  // };

  const checkPhNameNpi = _debounce(async ({ payload, isNPI }) => {
    const npiOrPhLoading = isNPI ? setNpiIsLoading : setPhNameIsLoading;
    const resp = await fetchPhNPIOptions(payload, npiOrPhLoading);
    if (resp.statusCode === 200) {
      if (isNPI) {
        if (resp.data.length > 0) {
          setIsEmptyData(true);
        } else {
          setIsEmptyData(false);
        }
        setNpiOptions(resp.data);
        setNPIExistError(false);
      } else setPhNameOptions(resp.data);
    } else if (resp.statusCode === 404) {
      setNPIExistError(true);
    } else {
      setNPIExistError(false);
      setPhNameOptions([]);
    }
  }, 500);

  const setDependentFields = ({ setFieldValue, value = {} } = {}) => {
    setFieldValue("phId", value.phid || "");
    setFieldValue("nabp", value.nabp || "");
    setFieldValue("isCentralFillStore", isEmptyData);
    setFieldValue("npi", value.npi || "");
    setFieldValue("phName", value.phName || "");
    setFieldValue("storeNumber", value.storeNumber || "");
    setFieldValue(
      "region",
      value.phRegionId === null ? null : value.phRegionId || ""
    );
    setFieldValue(
      "division",
      value.phDivisionId === null ? null : value.phDivisionId || ""
    );
    setFieldValue(
      "district",
      value.phDistrictId === null ? null : value.phDistrictId || ""
    );
    setFieldValue("iCode", value.icode === null ? null : value.icode || "");
    setFieldValue("address1", value.address1 || "");
    setFieldValue("address2", value.address2 || "");
    setFieldValue("city", value.city || "");
    setFieldValue("stateId", value.stateId || "");
    setFieldValue("zipCode", value.zipCode || "");
    setFieldValue("emailId", value.email || "");
    setFieldValue("phContactFN", value.pharmacyContactFirstName || "");
    setFieldValue("phContactLN", value.pharmacyContactLastName || "");
    setFieldValue("phone", value.phone || "");
  };

  const handleNabpChange = _debounce(async (payload) => {
    const isUnique = await dispatch(validateNABP(payload));
    setIsNabpUnique(isUnique);
  }, 500);

  const handleValidate = async (values) => {
    let error = {};
    if (!values.phGroupId) {
      error.phGroupId = ERROR.emptyPharmacyChainErrorMessage;
    }
    if (!values.npi) {
      error.npi = "Please enter the NPI";
    }
    if (values.npi && npiExistError) {
      error.npi = "NPI already exist";
    }
    if (!values.phName) {
      error.phName = ERROR.emptyPharmacyStoreErrorMessage;
    }
    if (!values.storeNumber) {
      error.storeNumber = "Please enter the Store #";
    }
    if (!values.nabp) {
      error.nabp = "Please enter the NABP";
    }
    if (values.nabp && !isNabpUnique) {
      error.nabp = "NABP already exist";
    }
    if (!values.city) {
      error.city = "Please enter the City";
    }
    if (!values.stateId) {
      error.stateId = "Please select the State";
    }
    if (!values.address1) {
      error.address1 = "Please enter the Address Line 1";
    }
    if (values.zipCode.length < 5) {
      error.zipCode = "Please enter the 5 digit Zip Code only";
    }
    if (!values.cecontractDate) {
      error.cecontractDate = "Please select the Covered Entity Contract Date";
    }
    if (!values.phContactFN) {
      error.phContactFN = "Please enter the Pharmacy Contact First Name";
    }
    if (!values.phContactLN) {
      error.phContactLN = "Please enter the Pharmacy Contact Last Name";
    }
    if (!values.phone) {
      error.phone = "Please enter the Phone Number";
    }
    if (!values.emailId) {
      error.emailId = "Please enter the Email";
    } else if (
      !/^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(values.emailId)
    ) {
      error.emailId = "Please enter valid Email";
    }
    return error;
  };

  return (
    <Formik
      enableReinitialize={true}
      initialValues={defaultValues}
      onSubmit={handleFormSubmit}
      validate={handleValidate}
    >
      {({
        values,
        setFieldValue,
        errors,
        touched,
        handleSubmit,
        initialValues,
      }) => {
        return (
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                <BasicTypography
                  variant="h4"
                  title={`${
                    currentPharmacy.pharmacyName || "Pharmacy Name"
                  } > Basic Details`}
                />
              </Grid>
              <Grid item md={12}>
                <BasicTypography variant="h5" title="Pharmacy Basic Details" />
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>{LABELS.PharmacyChain}</FormLabel>
                    <Field as="select" name="phGroupId">
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          options={
                            _isArray(phGroupsOptions) ? phGroupsOptions : []
                          }
                          inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                          disableCloseOnSelect={false}
                          disabled={!_isEmpty(currentPharmacy)}
                          onChange={(e, newValue) => {
                            const value = newValue ? newValue.phGroupId : "";
                            setFieldValue("phGroupId", value);
                            if (value && initialValues.phGroupId !== value) {
                              setDependentFields({ setFieldValue, value: {} });
                            }
                            setFieldValue("npi", "");
                          }}
                          getOptionLabel={(option) => option.phGroupName || ""}
                          value={
                            phGroupsOptions.find(
                              (e) => e.phGroupId == values.phGroupId
                            ) || ""
                          }
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.phGroupName}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                          textFieldProps={{
                            inputProps: {
                              name: "phGroupId",
                            },
                          }}
                        />
                      )}
                    </Field>
                    {errors.phGroupId && touched.phGroupId && (
                      <Typography color="error" variant="caption">
                        {errors.phGroupId}
                      </Typography>
                    )}
                  </Grid>

                  {/* Intelligent Text Field */}
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>NPI</FormLabel>
                    <Field name="npi">
                      {({ field }) => (
                        <AutoComplete
                          disabled={!values.phGroupId}
                          loading={npiIsLoading}
                          options={npiOptions}
                          getOptionLabel={(option) => option.npi || option}
                          multiple={false}
                          disableCloseOnSelect={false}
                          inputPlaceholder="Enter NPI"
                          onInputChange={(_e, inputValue) => {
                            setFieldValue("npi", inputValue);
                            if (values.phId) {
                              const isSame = checkIsNPIPresentInList({
                                npi: inputValue,
                                options:
                                  npiOptions.length < 1
                                    ? phNameOptions
                                    : npiOptions,
                                phId: values.phId,
                              });
                              if (!isSame)
                                setDependentFields({
                                  setFieldValue,
                                  value: { npi: inputValue },
                                });
                            }
                            if (inputValue === "") {
                              setNpiOptions([]);
                              setIsEmptyData(!isEmptyData);
                              return;
                            }
                            checkPhNameNpi({
                              payload: {
                                npi: inputValue,
                                phGroupId: values.phGroupId,
                                ceid: ceId,
                              },
                              isNPI: true,
                            });
                          }}
                          {...field}
                          textFieldProps={{
                            inputProps: {
                              maxLength: 11,
                              name: "npi",
                            },
                          }}
                          onChange={(_e, value) => {
                            setFieldValue("isCentralFillStore", false);
                            setFieldValue("emailId", "");
                            setFieldValue("phContactFN", "");
                            setFieldValue("phContactLN", "");
                            setFieldValue("phone", "");
                            if (!_isEmpty(value) && value.npi) {
                              setDependentFields({
                                setFieldValue,
                                value,
                              });
                              setNpiOptions([value]);
                            }
                          }}
                        />
                      )}
                    </Field>
                    {errors.npi && touched.npi && (
                      <Typography color="error" variant="caption">
                        {errors.npi}
                      </Typography>
                    )}
                  </Grid>

                  {/* Intelligent Text Field */}
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>{LABELS.PharmacyStore}</FormLabel>
                    <Field name="phName">
                      {({ field }) => (
                        <AutoComplete
                          disabled={!values.phGroupId}
                          loading={phNameIsLoading}
                          options={phNameOptions}
                          getOptionLabel={(option) => option.phName || option}
                          multiple={false}
                          disableCloseOnSelect={false}
                          inputPlaceholder={`Enter ${LABELS.PharmacyStore}`}
                          onInputChange={(_e, inputValue) => {
                            setFieldValue("phName", inputValue);
                            if (inputValue === "") {
                              setPhNameOptions([]);
                              return;
                            }
                            if (values.phId) {
                              const isSame = checkIsPhNamePresentInList({
                                phName: inputValue,
                                options:
                                  phNameOptions.length < 1
                                    ? npiOptions
                                    : phNameOptions,
                                phId: values.phId,
                              });
                              if (!isSame)
                                setDependentFields({
                                  setFieldValue,
                                  value: { phName: inputValue },
                                });
                            }
                            checkPhNameNpi({
                              payload: {
                                pharmacyName: inputValue,
                                phGroupId: values.phGroupId,
                                ceid: ceId,
                              },
                              isNPI: false,
                            });
                          }}
                          {...field}
                          onChange={(_e, value) => {
                            setFieldValue("phName", value);
                            if (!_isEmpty(value) && value.npi) {
                              setDependentFields({
                                setFieldValue,
                                value,
                              });
                              setPhNameOptions([value]);
                            }
                          }}
                          textFieldProps={{
                            inputProps: {
                              maxLength: 150,
                              name: "phName",
                            },
                          }}
                        />
                      )}
                    </Field>
                    {errors.phName && touched.phName && (
                      <Typography color="error" variant="caption">
                        {errors.phName}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Store #</FormLabel>
                    <Field
                      name="storeNumber"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Store #"
                      maxLength={25}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("storeNumber", value);
                      }}
                    />
                    {errors.storeNumber && touched.storeNumber && (
                      <Typography color="error" variant="caption">
                        {errors.storeNumber}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>NABP</FormLabel>
                    <Field
                      name="nabp"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter NABP"
                      maxLength={10}
                      disabled={!values.phGroupId || !ceId}
                      onChange={(e) => {
                        const { value } = e.target;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("nabp", value);
                        if (value && initialValues.nabp !== value) {
                          handleNabpChange({
                            nabp: value,
                            ceid: ceId,
                            phGroupId: values.phGroupId,
                          });
                        }
                      }}
                    />
                    {errors.nabp && touched.nabp && (
                      <Typography color="error" variant="caption">
                        {errors.nabp}
                      </Typography>
                    )}
                  </Grid>

                  {values.region !== null && (
                    <Grid item xs={12} sm={4}>
                      <FormLabel>Region</FormLabel>
                      <Field as="select" name="region">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={
                              _isArray(regionOptions) ? regionOptions : []
                            }
                            inputPlaceholder={"Select Region"}
                            disableCloseOnSelect={false}
                            onChange={(e, value) => {
                              setFieldValue(
                                "region",
                                value ? value.phRegionId : ""
                              );
                            }}
                            getOptionLabel={(option) => option.regionDesc || ""}
                            value={
                              regionOptions.find(
                                (e) => e.phRegionId == values.region
                              ) || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.regionDesc}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                          />
                        )}
                      </Field>
                    </Grid>
                  )}

                  {values.division !== null && (
                    <Grid item xs={12} sm={4}>
                      <FormLabel>Division</FormLabel>
                      <Field as="select" name="division">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={
                              _isArray(divisionOptions) ? divisionOptions : []
                            }
                            inputPlaceholder={"Select Division"}
                            disableCloseOnSelect={false}
                            onChange={(e, value) => {
                              setFieldValue(
                                "division",
                                value ? value.phDivisionId : ""
                              );
                            }}
                            getOptionLabel={(option) => option.phDivision || ""}
                            value={
                              divisionOptions.find(
                                (e) => e.phDivisionId == values.division
                              ) || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.phDivision}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                          />
                        )}
                      </Field>
                    </Grid>
                  )}

                  {values.district !== null && (
                    <Grid item xs={12} sm={4}>
                      <FormLabel>District</FormLabel>
                      <Field as="select" name="district">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={
                              _isArray(districtOptions) ? districtOptions : []
                            }
                            inputPlaceholder={"Select District"}
                            disableCloseOnSelect={false}
                            onChange={(e, value) => {
                              setFieldValue(
                                "district",
                                value ? value.phDistrictId : ""
                              );
                            }}
                            getOptionLabel={(option) =>
                              option.phDistrictName || ""
                            }
                            value={
                              districtOptions.find(
                                (e) => e.phDistrictId == values.district
                              ) || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.phDistrictName}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                          />
                        )}
                      </Field>
                    </Grid>
                  )}

                  {values.iCode !== null && (
                    <Grid item xs={12} sm={4}>
                      <FormLabel>I-Code</FormLabel>
                      <Field
                        name="iCode"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter I-Code"
                        maxLength={100}
                        onChange={(e) => {
                          const value = e.target.value;
                          if (
                            value &&
                            !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                          )
                            return;
                          setFieldValue("iCode", value);
                        }}
                      />
                    </Grid>
                  )}

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Address Line 1</FormLabel>
                    <Field
                      name="address1"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Address Line 1"
                      maxLength={100}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("address1", value);
                      }}
                    />
                    {errors.address1 && touched.address1 && (
                      <Typography color="error" variant="caption">
                        {errors.address1}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>Address Line 2</FormLabel>
                    <Field
                      name="address2"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Address Line 2"
                      maxLength={100}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("address2", value);
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}></Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>City</FormLabel>
                    <Field
                      name="city"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter City"
                      maxLength={100}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("city", value);
                      }}
                    />
                    {errors.city && touched.city && (
                      <Typography color="error" variant="caption">
                        {errors.city}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>State</FormLabel>
                    <Field as="select" name="stateId">
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          options={_isArray(states) ? states : []}
                          inputPlaceholder={"Select State"}
                          disableCloseOnSelect={false}
                          onChange={(e, value) => {
                            setFieldValue(
                              "stateId",
                              value ? value.stateId : ""
                            );
                          }}
                          getOptionLabel={(option) => option.stateName || ""}
                          value={
                            states.find((e) => e.stateId == values.stateId) ||
                            ""
                          }
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.stateName}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                          textFieldProps={{
                            inputProps: {
                              name: "stateId",
                            },
                          }}
                        />
                      )}
                    </Field>
                    {errors.stateId && touched.stateId && (
                      <Typography color="error" variant="caption">
                        {errors.stateId}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Zip</FormLabel>
                    <Field
                      name="zipCode"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Zip"
                      maxLength={5}
                      onChange={(e) => {
                        const { value } = e.target;
                        const regEx = /^[0-9]*$/g;
                        if (value && !regEx.test(value)) return;
                        setFieldValue("zipCode", value.toString());
                      }}
                    />
                    {errors.zipCode && touched.zipCode && (
                      <Typography color="error" variant="caption">
                        {errors.zipCode}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>Parent Association</FormLabel>
                    <Field
                      name="parentAssociation"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Parent Association"
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("parentAssociation", value);
                      }}
                    />
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    sm={4}
                    className={classes.switchGridContainer}
                  >
                    <div className={classes.switchContainer}>
                      <FormControlLabel
                        control={
                          <Field
                            name="network"
                            type="checkbox"
                            component={Toggle}
                            checked={values.network}
                            onChange={(e) =>
                              setFieldValue("network", e.target.checked)
                            }
                          />
                        }
                        label="Network"
                        classes={{
                          label: classes.switchLabel,
                        }}
                      />

                      <FormControlLabel
                        control={
                          <Field
                            name="isSpecialtyStore"
                            type="checkbox"
                            component={Toggle}
                            checked={values.isSpecialtyStore}
                            onChange={(e) =>
                              setFieldValue(
                                "isSpecialtyStore",
                                e.target.checked
                              )
                            }
                          />
                        }
                        label="Specialty Pharmacy"
                        classes={{
                          label: classes.switchLabel,
                        }}
                      />
                    </div>
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    sm={4}
                    className={classes.switchGridContainer}
                  >
                    <div className={classes.switchContainer}>
                      <FormControlLabel
                        control={
                          <Field
                            name="isCentralFillStore"
                            type="checkbox"
                            component={Toggle}
                            checked={values.isCentralFillStore}
                            onChange={(e) =>
                              setFieldValue(
                                "isCentralFillStore",
                                e.target.checked
                              )
                            }
                          />
                        }
                        label="Central Fill Location"
                        classes={{
                          label: classes.switchLabel,
                        }}
                      />
                    </div>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Covered Entity Contract Date</FormLabel>
                    <Field as="select" name="cecontractDate">
                      {({ field }) => (
                        <DatePicker
                          disabled={initialValues.cecontractDate}
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("cecontractDate", date);
                          }}
                          value={
                            values.cecontractDate
                              ? moment(values.cecontractDate, "MM/DD/YYYY")
                              : ""
                          }
                          getPopupContainer={(triggerNode) => {
                            return triggerNode.parentNode;
                          }}
                        />
                      )}
                    </Field>
                    {errors.cecontractDate && touched.cecontractDate && (
                      <Typography color="error" variant="caption">
                        {errors.cecontractDate}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>PSA Start Date</FormLabel>
                    <Field as="select" name="pharmacyLiveDate">
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("pharmacyLiveDate", date);
                          }}
                          value={
                            values.pharmacyLiveDate
                              ? moment(values.pharmacyLiveDate, "MM/DD/YYYY")
                              : ""
                          }
                          disabledDate={(d) =>
                            !d ||
                            (values.pharmacyTerminationDate &&
                              !d.isBefore(values.pharmacyTerminationDate))
                          }
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>Pharmacy Go-Live Date</FormLabel>
                    <Field as="select" name="productionDate">
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("productionDate", date);
                          }}
                          value={
                            values.productionDate
                              ? moment(values.productionDate, "MM/DD/YYYY")
                              : ""
                          }
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>PSA Termination Date</FormLabel>
                    <Field as="select" name="pharmacyTerminationDate">
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("pharmacyTerminationDate", date);
                          }}
                          value={
                            values.pharmacyTerminationDate
                              ? moment(
                                  values.pharmacyTerminationDate,
                                  "MM/DD/YYYY"
                                )
                              : ""
                          }
                          disabledDate={(d) =>
                            !d || !d.isAfter(values.pharmacyLiveDate)
                          }
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>OPA Effective Date</FormLabel>
                    <Field as="select" name="opaeffectiveDate">
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("opaeffectiveDate", date);
                          }}
                          value={
                            values.opaeffectiveDate
                              ? moment(values.opaeffectiveDate, "MM/DD/YYYY")
                              : ""
                          }
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>340BDirect+ Fee Start Date</FormLabel>
                    <Field as="select" name="feeEffectiveDate">
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("feeEffectiveDate", date);
                          }}
                          value={
                            values.feeEffectiveDate
                              ? moment(values.feeEffectiveDate, "MM/DD/YYYY")
                              : ""
                          }
                        />
                      )}
                    </Field>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <BasicTypography
                  variant="h5"
                  title="Pharmacy Contact Information"
                />
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Pharmacy Contact First Name</FormLabel>
                    <Field
                      name="phContactFN"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Pharmacy Contact First Name"
                      maxLength={50}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (value && !REGEX.alphabetsAndHypen.test(value))
                          return;
                        setFieldValue("phContactFN", value);
                      }}
                    />
                    {errors.phContactFN && touched.phContactFN && (
                      <Typography color="error" variant="caption">
                        {errors.phContactFN}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Pharmacy Contact Last Name</FormLabel>
                    <Field
                      name="phContactLN"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Pharmacy Contact Last Name"
                      maxLength={50}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (value && !REGEX.alphabetsAndHypen.test(value))
                          return;
                        setFieldValue("phContactLN", value);
                      }}
                    />
                    {errors.phContactLN && touched.phContactLN && (
                      <Typography color="error" variant="caption">
                        {errors.phContactLN}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Phone</FormLabel>
                    <Field
                      id="phone"
                      name="phone"
                      type="text"
                      placeholder="Enter Phone Number"
                      className={globalClasses.formControl}
                      maxLength={10}
                      onChange={(e) => {
                        const { value } = e.target;
                        const regEx = /^[0-9]*$/g;
                        if (value && !regEx.test(value)) return;
                        setFieldValue("phone", value.toString());
                      }}
                    />
                    {errors.phone && touched.phone && (
                      <Typography color="error" variant="caption">
                        {errors.phone}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Email</FormLabel>
                    <Field
                      name="emailId"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Email"
                      maxLength={50}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          value &&
                          !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                        )
                          return;
                        setFieldValue("emailId", value);
                      }}
                    />
                    {errors.emailId && touched.emailId && (
                      <Typography color="error" variant="caption">
                        {errors.emailId}
                      </Typography>
                    )}
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    sm={4}
                    className={classes.switchGridContainer}
                  >
                    <div className={classes.switchContainer}>
                      <FormControlLabel
                        control={
                          <Field
                            name="primaryContactIndicator"
                            type="checkbox"
                            component={Toggle}
                            checked={values.primaryContactIndicator}
                            onChange={(e) =>
                              setFieldValue(
                                "primaryContactIndicator",
                                e.target.checked
                              )
                            }
                          />
                        }
                        label="Primary Contact Indicator"
                        classes={{
                          label: classes.switchLabel,
                        }}
                      />
                    </div>
                  </Grid>
                </Grid>
                {/* //TODO MVP R2 */}
                {/*<Grid container spacing={2}>
                    <Grid item>
                      <BasicTypography
                        variant="h4"
                        title="Uploaded Documents"
                        styleProps={{ padding: "20px 0 10px" }}
                      />
                    </Grid>
                  </Grid>
                    <Grid container spacing={2}>
                    <Grid item style={{ width: "100%" }}>
                      <UploadedDocumentsTable
                        docList={docList}
                        fetchDocumentsList={fetchDocumentsList}
                      />
                    </Grid>
                  </Grid>

                  <Grid container spacing={2}>
                    <Grid item>
                      <BasicTypography
                        variant="h4"
                        title="Upload"
                        styleProps={{ padding: "20px 0 10px" }}
                      />
                    </Grid>
                  </Grid> */}
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2} justifyContent={"flex-end"}>
                  {/* //TODO MVP R2 */}
                  {/* <Grid item xs={12} md={6}>
                      <FileUploadDroppable
                        onUpload={handleDocUpload}
                        uploadProgress={uploadProgress}
                        isUploading={isUploading}
                      />
                    </Grid> */}
                  <Grid item>
                    <Button
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", false);
                        handleSubmit();
                      }}
                    >
                      Next
                    </Button>
                  </Grid>
                  {/* <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() =>
                        setPopupActiveMenu(MENUS.PH_BILLING_AND_FEES)
                      }
                    >
                      Skip
                    </Button>
                  </Grid> */}
                  <Grid item>
                    <Button
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", true);
                        handleSubmit();
                      }}
                    >
                      Save and Exit
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => setOpenAddCePopup(false)}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        );
      }}
    </Formik>
  );
};

export default PharmacyBasicDetails;
