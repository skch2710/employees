import React, { useState, useEffect, useCallback, useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button, Grid, FormLabel } from "@material-ui/core";
import Tooltip from "@mui/material/Tooltip";
import excel from "../../../../../../assets/excel.png";
import { Formik, Form, Field } from "formik";
import { pagination } from "../../../../../../utils/constants";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import { PROVIDER_COLUMNS } from "../../../../../../components/common/Table/TableHeadCells";
import { filterFunctionality } from "../../../../../../utils/common";
import { getUserSession } from "../../../../../../utils/helper";
import {
  ProvidersSearch,
  saveProviderDropVal,
  fetchProviderConfigFile,
  getDropdownValue,
} from "../../../../../../context/actions/providers";
import _get from "lodash/get";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useCeProviderStyles } from "./styles";
import ProvidersMaterialTable from "../../../../../Eligibility/Providers/ProvidersMaterialTable";
import _isEmpty from "lodash/isEmpty";
import classNames from "classnames";
import AutoComplete from "../../../../../../components/common/AutoComplete";
import _isArray from "lodash/isArray";

const CEProviders = ({
  ciId,
  permissionObj,
  providerPermissionObj,
  clickOnAdd,
}) => {
  const globalClasses = useGlobalStyles();
  const classes = useCeProviderStyles();
  const dispatch = useDispatch();
  const userSessionData = getUserSession();
  const {
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    messageUuid,
  } = useContext(COContext);
  const { provider } = menusStatuses;
  const providerDropdownList = useSelector(
    (state) => state.ceFileTypeDropdownList.ceProviderDropdownList
  );
  const {
    dm: deliveryMethods=[],
    ft: fileTypes=[],
    ff: fileFrequencies=[],
  } = providerDropdownList;
  const [openPopup, setOpenPopup] = useState(false);
  const [actionTitle, setActionTitle] = useState("");
  const [submitActionType, setSubmitActionType] = useState("");
  const [filterValues, setFilterValues] = useState([]);
  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "lastName, firstName",
  });
  const [initialValues, setInitialValues] = useState({
    id: null,
    fileTypeId: "",
    deliveryMethodId: "",
    fileFrequencyId: "",
  });
  const providerSearchdata = {
    providerNPI: "",
    firstName: "",
    lastName: "",
    startDate: "",
    endDate: "",
    providerType: "",
    status: "Active",
  };

  const { records: providersAllData } = useSelector(
    (state) => state.providersalldata
  );

  useEffect(() => {
    if (fileTypes.length === 1) {
      setInitialValues((prev) => ({
        ...prev,
        fileTypeId: fileTypes[0].id,
      }));
    }
  }, [fileTypes]);

  const onChangePagination = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const { totalElements = 0 } = providersAllData;
      const totalPages = Math.ceil(totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchProvider({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: filterValues,
      });
    },
    [filterValues, controller]
  );

  const onChangeSorting = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PROVIDER_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchProvider({ sortBy, sortOrder });
    },
    [controller, filterValues]
  );

  const onChangeFilter = async (value) => {
    const payload = {
      pageNumber: pagination.page,
      pageSize: controller.pageSize,
    };
    if (value.length) {
      const responseValue = await filterFunctionality(value, "Providers");
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setFilterValues(responseValue);
    } else {
      payload.filter = null;
      setFilterValues([]);
    }
    fetchProvider(payload);
  };

  const geProviderConfigOptions = async (ceId) => {
    const providerConfigFile = await dispatch(
      fetchProviderConfigFile(ceId, false)
    );
    if (!_isEmpty(providerConfigFile)) {
      setInitialValues(providerConfigFile);
    }
  };

  useEffect(() => {
    dispatch(getDropdownValue("Providers"));
    geProviderConfigOptions(ciId);
  }, []);

  const fetchProvider = (payload = {}) => {
    dispatch(
      ProvidersSearch(
        {
          ceid: [
            messageUuid && messageUuid.ceid !== null ? messageUuid.ceid : ciId,
          ],
          pageNumber: controller.page || 1,
          pageSize: controller.pageSize || 25,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          providerNPI: _get(providerSearchdata, "providerNPI", ""),
          firstName: _get(providerSearchdata, "firstName", ""),
          lastName: _get(providerSearchdata, "lastName", ""),
          endDate: _get(providerSearchdata, "endDate", ""),
          startDate: _get(providerSearchdata, "startDate", ""),
          providerType: _get(providerSearchdata, "providerType", ""),
          filter: filterValues || [],
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo || controller.page,
            pageSize: data.pageSize || controller.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    fetchProvider();
    return () => {
      dispatch({ type: "PROVIDER_SEARCH", data: [] });
    };
  }, []);

  const numberConversion = (value) => {
    return value ? parseInt(value) : 0;
  };

  const handleSubmit = (values) => {
    let payload = {
      ...values,
      ceid: messageUuid && messageUuid.ceid !== null ? messageUuid.ceid : ciId,
      fileTypeId: numberConversion(values.fileTypeId),
      deliveryMethodId: numberConversion(values.deliveryMethodId),
      fileFrequencyId: numberConversion(values.fileFrequencyId),
      createdById: userSessionData.userId,
      modifiedById: userSessionData.userId,
    };
    dispatch(
      saveProviderDropVal(payload, (response) => {
        if (response.statusCode == 200 && response.data != "")
          if (values.stopNavigation) setOpenAddCePopup(false);
      })
    );
  };
  const formValidate = () => {};

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={initialValues}
        onSubmit={handleSubmit}
        validate={formValidate}
      >
        {({ values, setFieldValue, handleSubmit }) => {
          return (
            <Form>
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={6}>
                      <BasicTypography
                        variant="h4"
                        title="Covered Entity Configuration > Provider"
                      />
                    </Grid>
                    <Grid item md={6} className={classes.downloadLink}>
                      <Tooltip
                        title={
                          providerPermissionObj !== null &&
                          !providerPermissionObj.readWriteFlag
                            ? "You don't have Permission."
                            : ""
                        }
                      >
                        <a
                          href={`/templates/AddceproviderTemplate.xlsx`}
                          download="AddceproviderTemplate"
                          className={classNames(
                            globalClasses.iconPlusClickableLink,
                            !_isEmpty(providerPermissionObj) &&
                              providerPermissionObj.readWriteFlag
                              ? null
                              : globalClasses.disabledDownloadTemp
                          )}
                          disabled={
                            providerPermissionObj !== null &&
                            providerPermissionObj.readWriteFlag
                              ? false
                              : true
                          }
                        >
                          <img src={excel} alt="Active" />
                          <span>Download Template</span>
                        </a>
                      </Tooltip>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={4}>
                      <FormLabel>File Type</FormLabel>

                      <Field
                        as="select"
                        name="fileTypeId"
                        className={globalClasses.formControl}
                      >
                        {(props) => {
                          const { field } = props;
                          return (
                            <AutoComplete
                              {...field}
                              disabled={fileTypes.length === 1}
                              disableCloseOnSelect={false}
                              options={_isArray(fileTypes) ? fileTypes : []}
                              inputPlaceholder={"Select Delivery Method"}
                              value={
                                (_isArray(fileTypes) &&
                                  fileTypes.find(
                                    (e) => e.id == values.fileTypeId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue ? newValue.id : "";
                                setFieldValue("fileTypeId", value);
                              }}
                              getOptionLabel={(option) => option.lkpValue || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.lkpValue}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                              textFieldProps={{
                                inputProps: {
                                  name: "fileTypeId",
                                },
                              }}
                            />
                          );
                        }}
                      </Field>
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel>Delivery Method</FormLabel>
                      <Field
                        as="select"
                        name="deliveryMethodId"
                        className={globalClasses.formControl}
                      >
                        {(props) => {
                          const { field } = props;
                          return (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(deliveryMethods) ? deliveryMethods : []
                              }
                              inputPlaceholder={"Select Delivery Method"}
                              value={
                                (_isArray(deliveryMethods) &&
                                  deliveryMethods.find(
                                    (e) => e.id == values.deliveryMethodId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue ? newValue.id : "";
                                setFieldValue("deliveryMethodId", value);
                              }}
                              getOptionLabel={(option) => option.lkpValue || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.lkpValue}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                              textFieldProps={{
                                inputProps: {
                                  name: "deliveryMethodId",
                                },
                              }}
                            />
                          );
                        }}
                      </Field>
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel>File Delivery Frequency</FormLabel>
                      <Field
                        as="select"
                        name="fileFrequencyId"
                        className={globalClasses.formControl}
                      >
                        {(props) => {
                          const { field } = props;
                          return (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(fileFrequencies) ? fileFrequencies : []
                              }
                              inputPlaceholder={"Select File Delivery Frequency"}
                              value={
                                (_isArray(fileFrequencies) &&
                                  fileFrequencies.find(
                                    (e) => e.id == values.fileFrequencyId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue ? newValue.id : "";
                                setFieldValue("fileFrequencyId", value);
                              }}
                              getOptionLabel={(option) => option.lkpValue || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.lkpValue}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                              textFieldProps={{
                                inputProps: {
                                  name: "deliveryMethodId",
                                },
                              }}
                            />
                          );
                        }}
                      </Field>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <ProvidersMaterialTable
                    ciId={ciId}
                    ceProvider={true}
                    searchData={providerSearchdata}
                    controller={controller}
                    defaultFilters={filterValues}
                    providersAllData={providersAllData}
                    providersexportdata={[]}
                    onChangePagination={onChangePagination}
                    onChangeSorting={onChangeSorting}
                    onChangeFilter={onChangeFilter}
                    permissionObj={permissionObj}
                    providerPermissionObj={providerPermissionObj}
                    messageUuid={messageUuid}
                    clickOnAdd={clickOnAdd}
                    setMenusStatuses={setMenusStatuses}
                    provider={provider}
                    openPopup={openPopup}
                    submitActionType={submitActionType}
                    actionTitle={actionTitle}
                    setOpenPopup={setOpenPopup}
                    setActionTitle={setActionTitle}
                    setSubmitActionType={setSubmitActionType}
                  />
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2} justifyContent="flex-end">
                    <Grid item>
                      <Button
                        type={
                          providerPermissionObj !== null &&
                          !providerPermissionObj.readWriteFlag
                            ? "submit"
                            : "button"
                        }
                        color="primary"
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                        onClick={() => {
                          setPopupActiveMenu(MENUS.CE_MEMBERS);
                          handleSubmit();
                        }}
                      >
                        Next
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() => setPopupActiveMenu(MENUS.CE_MEMBERS)}
                      >
                        Skip
                      </Button>
                    </Grid>
                    <Grid item>
                      <Tooltip
                        placement="top"
                        title={
                          providerPermissionObj !== null &&
                          !providerPermissionObj.readWriteFlag
                            ? "You don't have Permission."
                            : "Save"
                        }
                      >
                        <span>
                          <Button
                            type="submit"
                            size="small"
                            variant="outlined"
                            className={globalClasses.secondaryBtn}
                            disabled={
                              providerPermissionObj !== null &&
                              providerPermissionObj.readWriteFlag
                                ? false
                                : true
                            }
                            onClick={() => {
                              setFieldValue("stopNavigation", true);
                              handleSubmit();
                            }}
                          >
                            Save and Exit
                          </Button>
                        </span>
                      </Tooltip>
                    </Grid>
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() => setOpenAddCePopup(false)}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Form>
          );
        }}
      </Formik>
    </>
  );
};
export default CEProviders;
