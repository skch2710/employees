import React, { useEffect, useContext, useState } from "react";
import { useDispatch } from "react-redux";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Grid, Button } from "@material-ui/core";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import AddAchPopupFooter from "./AddAchPopupFooter";
import AddAchForm from "./AddAchForm";
import { useAchTableStyles } from "./style";
import _isEmpty from "lodash/isEmpty";
import {
  fetchTermsGridTableData,
  getCeAchConfig,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";
import { COContext } from "../../../../COContext";
import {
  getAddAchFormDefaultValues,
  getEditAchFormDefaultValues,
  getSaveAchPayload,
} from "./helpers";
import { MENUS } from "../../../PopupSidebar/constants";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import { getUserPermissionOnModuleName } from "../../../../../../utils/helper";
import {
  achMessageUUID,
  saveAchConfiguration,
} from "../../../../../../context/actions/AchConfiguration";
import AchGrid from "./AchGrid";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { POLLING_COUNT } from "../../../../../../utils/constants";

const CEAchConfiguration = ({ clickOnAdd }) => {
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const classes = useAchTableStyles();
  const dispatch = useDispatch();
  const achPermissionObj =
    getUserPermissionOnModuleName("ACH Configuration") || {};

  const {
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    messageUuid,
    ceConfigStatusPercent,
    setCeConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext);
  const { achConfiguration } = menusStatuses;

  const [defaultValues, setDefaultValues] = useState(
    getAddAchFormDefaultValues()
  );
  const [showAddAchPopup, setShowAddAchPopup] = useState(false);
  const [isUniqueAcNo, setIsUniqueAcNo] = useState(true);
  const [isUniqueRoutingNo, setIsUniqueRoutingNo] = useState(true);
  const [popupTitle, setPopupTitle] = useState("");

  const ACTIONS = [
    /* don't remove this commented code it will be used in future as per the client requirement*/
    // {
    //   icon: iconsAndButtons.Edit(),
    //   tooltip:
    //     achPermissionObj && achPermissionObj.readWriteFlag
    //       ? "Edit"
    //       : "You don't have Permission.",
    //   isFreeAction: false,
    //   disabled: achPermissionObj && !achPermissionObj.readWriteFlag,
    //   onClick: (_event, rowData) => {
    //     setShowAddAchPopup(true);
    //     setPopupTitle("Edit ACH Account");
    //     setDefaultValues(getEditAchFormDefaultValues(rowData));
    //   },
    // },
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add ACH Account" }),
      tooltip:
        achPermissionObj && achPermissionObj.readWriteFlag
          ? ""
          : "You don't have Permission.",
      disabled: achPermissionObj && !achPermissionObj.readWriteFlag,
      isFreeAction: true,
      onClick: () => {
        setShowAddAchPopup(true);
        setPopupTitle("Add ACH Account");
        setDefaultValues(getAddAchFormDefaultValues());
      },
    },
  ];

  const handleSubmit = async (values, { resetForm }) => {
    const payload = getSaveAchPayload({
      ...values,
      ceId: !_isEmpty(messageUuid) && messageUuid.ceid,
    });
    const payloadObj = { achConfigurationDTOList: [payload] };
    dispatch(
      saveAchConfiguration(payloadObj, (saveApiRes) => {
        if (saveApiRes.statusCode === 200 && saveApiRes.data != null) {
          handlePolling({
            messageUUid: saveApiRes.data,
            currentCount: POLLING_COUNT,
            isExit: values.isExit,
            resetForm,
          });
        }
      })
    );
  };

  const handlePolling = async ({
    messageUUid,
    currentCount,
    isExit,
    resetForm,
  }) => {
    const count = currentCount;
    const res = await dispatch(achMessageUUID(messageUUid, count));
    if (res && res.statusCode === 200) {
      dispatch(getCeAchConfig(messageUuid.ceid));
      if (clickOnAdd || achConfiguration) {
        dispatch(
          updateSectionStatus({
            ceId: messageUuid.ceid,
            sectionId: 3,
            callback: statusCallback,
          })
        );
      }
      if (isExit) setShowAddAchPopup(false);
      else {
        resetForm({
          values: getAddAchFormDefaultValues(),
        });
        setPopupTitle("Add ACH Account");
      }
    } else if (res && res.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
        isExit,
        resetForm,
      });
    }
  };

  const statusCallback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({ ...prev, achConfiguration: false }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  const handleValidate = async (values) => {
    const error = {};
    if (values.accountNumber === "") {
      error.accountNumber = "Please enter the Account Number";
    }
    if (values.accountNumber && !isUniqueAcNo) {
      error.accountNumber = "Account Number already exists";
    }
    if (values.routingNumber === "") {
      error.routingNumber = "Please enter the Routing Number";
    } else if (values.routingNumber.length < 9) {
      error.routingNumber = "Routing Number must be 9 digits long";
    } else if (values.routingNumber && !isUniqueRoutingNo) {
      error.routingNumber = "Routing Number already exists";
    }
    if (values.bankName === "") {
      error.bankName = "Please enter the Bank Name";
    }
    if (values.percentageOfRemittance === "") {
      error.percentageOfRemittance = "Please enter % of Remittance";
    }
    if (
      values.pennyTestCompleted === true &&
      values.pennyTestCompletionDate === ""
    ) {
      error.pennyTestCompletionDate =
        "Please select the penny test completion date";
    }

    return error;
  };

  useEffect(() => {
    const ceId = !_isEmpty(messageUuid) && messageUuid.ceid;
    ceId && dispatch(getCeAchConfig(ceId));
  }, []);

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={12}>
          <BasicTypography
            variant="h4"
            title="Entity Details > ACH Configuration"
          />
        </Grid>
        <Grid item md={12}>
          <Grid container spacing={4}>
            <Grid item md={12}>
              <AchGrid wizard={true} achActions={ACTIONS} />
            </Grid>
            <Grid item xs={12}>
              <Grid container spacing={2} justifyContent="flex-end">
                <Grid item>
                  <Button
                    color="primary"
                    size="small"
                    variant="contained"
                    className={globalClasses.primaryBtn}
                    onClick={() => setPopupActiveMenu(MENUS.CE_ELIGIBILITY)}
                  >
                    Next
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={() => setPopupActiveMenu(MENUS.CE_ELIGIBILITY)}
                  >
                    Skip
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={() => setOpenAddCePopup(false)}
                  >
                    Save and Exit
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={() => setOpenAddCePopup(false)}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      {showAddAchPopup && (
        <BasicPopup
          show={showAddAchPopup}
          title={popupTitle}
          disableFooter={true}
          isCustomFooter={true}
          footerActionElement={
            <AddAchPopupFooter setShowAddAchPopup={setShowAddAchPopup} />
          }
          handleClose={() => setShowAddAchPopup(false)}
          dialogProps={{
            maxWidth: "md",
            classes: {
              paper: classes.dialogPaper,
            },
          }}
          withFormik={true}
          formikProps={{
            initialValues: defaultValues,
            onSubmit: handleSubmit,
            validate: handleValidate,
          }}
        >
          <AddAchForm
            setIsUniqueAcNo={setIsUniqueAcNo}
            setIsUniqueRoutingNo={setIsUniqueRoutingNo}
          />
        </BasicPopup>
      )}
    </>
  );
};
export default CEAchConfiguration;
