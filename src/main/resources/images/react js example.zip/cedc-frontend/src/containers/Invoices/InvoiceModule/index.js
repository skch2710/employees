import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import _isEqual from "lodash/isEqual";
import { Grid } from "@material-ui/core";
import { getInvoiceGridData } from "../../../context/actions/Invoice";
import InvoiceSearchForm from "./InvoiceSearchForm";
import { userdata } from "../../../utils/common";
import InvoiceMainList from "./InvoiceMainList";
import { GET_INVOICE_LIST } from "../../../context/constants";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { getDefaultInvoiceListPayload } from "./constants";
import _get from "lodash/get";
import { pagination } from "../../../utils/constants";

const InvoiceFilters = () => {
  const dispatch = useDispatch();
  const formRef = useRef(null);
  const actionRef = useRef(null);
  const { ceList = [] } = useSelector((state) => state.coveredEntities) || {};

  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [enableFilters, setEnableFilters] = useState(false);
  const [filtersValues, setFiltersValues] = useState(false);
  const [InvoiceControllers, setInvoiceControllers] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const {
    loading,
    records: InvoiceMainListData,
    count,
  } = useSelector((state) => state.getInvoiceList);

  const fetchInvoicedetails = (payload = {}, callback) => {
    const payloadJson = {
      ...getDefaultInvoiceListPayload(),
      ...payload,
    };
    dispatch(
      getInvoiceGridData(payloadJson, (resp) => callback && callback(resp))
    );
  };

  const handleSubmit = (values) => {
    const submitPayload = {
        ceId: values.ceId,
        invoicePeriodStartDate: values.invoicePeriodStartDate,
        invoicePeriodEndDate: values.invoicePeriodEndDate,
        phID: _get(values, "phID.phid", 0),
        phGroupId : values.phGroupId.phGroupId,
    }
    setFiltersValues(submitPayload);
    fetchInvoicedetails(
      { ...submitPayload, pageSize: InvoiceControllers.pageSize },
      (resp) => {
        actionRef.current && actionRef.current.submitForm(resp);
      }
    );
    setFormSubmittedValues(submitPayload);
    setEnableFilters(false);
  };

  useEffect(() => {
    if (ceList.length) {
      fetchInvoicedetails({ ceId: [ceList[0].ceID] });
    }
    return () => {
      dispatch({ type: GET_INVOICE_LIST, data: {} });
    };
  }, [ceList]);

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="h1" title="Invoices" />
      </Grid>
      <Grid item md={12}>
        <InvoiceSearchForm
          handleSubmit={handleSubmit}
          ceList={ceList}
          formRef={formRef}
          handleClear={(values) =>
            actionRef.current && actionRef.current.clearForm(values)
          }
          enableFilters={enableFilters}
          setEnableFilters={setEnableFilters}
        />
      </Grid>
      <Grid item md={12}>
        <InvoiceMainList
          InvoiceMainListData={InvoiceMainListData}
          count={count}
          fetchInvoicedetails={fetchInvoicedetails}
          formRef={formRef}
          ref={actionRef}
          loading={loading}
          formSubmittedValues={formSubmittedValues}
          enableFilters={enableFilters}
          setEnableFilters={setEnableFilters}
          InvoiceControllers={InvoiceControllers}
          setInvoiceControllers={setInvoiceControllers}
          filtersValues={filtersValues}
        />
      </Grid>
    </Grid>
  );
};

export default InvoiceFilters;
