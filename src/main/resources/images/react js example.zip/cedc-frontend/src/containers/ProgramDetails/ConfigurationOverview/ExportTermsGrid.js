import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { getConfigSearchexport } from "../../../context/actions/ConfigOverview";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { notNull } from "../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver"; 
const fileName = "Covered Entities List"; 
const ExportTermsGrid = ({
  ceid,
  phGroupID,
  phID,
  sortBy,
  sortOrder,
  golivedate,
  endDate,
  startDate,
 
}) => {
  const dispatch = useDispatch();
  const [values, setValues] = useState("");
  const classes = useStyles();

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const dataa = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8" });
    FileSaver.saveAs(dataa, fileName + ".xlsx");
  };
  let heads = [];
  let rows = [];

  const ExportTOPDF = (data) => {
    const listheads = data.map((i) => {
      let keys_heads = {};
      keys_heads[LABELS.CoveredEntity] = Object.keys(i)[0];
      keys_heads["Go-Live Date"] = Object.keys(i)[1];
      keys_heads["Start Date"] = Object.keys(i)[2];
      keys_heads["End Date"] = Object.keys(i)[3];
      keys_heads["Primary Contact Name"] = Object.keys(i)[4];
      keys_heads["Primary Email"] = Object.keys(i)[5];
      keys_heads["Primary PhoneNo"] = Object.keys(i)[6];
      keys_heads["Active Providers"] = Object.keys(i)[7];
      keys_heads["Active Members"] = Object.keys(i)[8];
      keys_heads["Active Pharmacies"] = Object.keys(i)[9];
      keys_heads["Flat Fee Per Client"] = Object.keys(i)[13];
      keys_heads["Flat Monthly Fee Minimum"] = Object.keys(i)[15];
      keys_heads["Configuration Status"] = Object.keys(i)[16];
      keys_heads["Flat Monthly Fee Maximum"] = Object.keys(i)[17];
      heads.push(keys_heads);
    });

    const listrows = data.map((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };
  const handleChange = (e) => {
    setValues(e.target.value);
    let json = {
        ceid: ceid,
        contractEndDate:endDate,
        pageNumber:1,
        pageSize:1000,
        filter: [], 
        goliveDate: golivedate,
        phGroupid: phGroupID,
        phid: phID,
        sortBy: sortBy,
        sortOrder:sortOrder,
        contractStartDate: startDate,
        export: true,
    }; 
    dispatch(
      getConfigSearchexport(json, function (result) {
        var data = result.content.map(
          ({
            ceName,
            goLiveDate,
            startDate,
            endDate,
            fullname,
            emailAddress,
            contactNumber,
            activeProviders,
            activeMembers,
            activePharmacies,
            flatFeePerClient,
            flatFeePerLocation,
            flatMontlyFeeMinimum,
            configStatus
          }) => ({
            [LABELS.CoveredEntity]: notNull(ceName),
            "Go-Live Date": notNull(goLiveDate),
            "Start Date": notNull(startDate),
            "End Date": notNull(endDate),
            "Primary Contact Name": notNull(fullname),
            "Primary Email": notNull(emailAddress),
            "Primary PhoneNo": notNull(contactNumber),
            "Active Providers": notNull(activeProviders),
            "Active Members": notNull(activeMembers),
            "Active Pharmacies": notNull(activePharmacies),
            "Flat Fee Per Client": notNull(flatFeePerClient),
            "Flat Fee Per Location": notNull(flatFeePerLocation),
            "Flat Montly Fee Minimum": notNull(flatMontlyFeeMinimum),
            "Configuration Status": notNull(configStatus),
            "Flat Montly Fee Minimum": notNull(flatMontlyFeeMinimum),
          })
        );

        if (e.target.value == "excel") {
          setTimeout(ExportToExcel(data), 5000);
          setValues("");
        }
        if (e.target.value == "pdf") {
          setTimeout(ExportTOPDF(data), 5000);
          const doc = new jsPDF();
          doc.autoTable({
            head: [heads[0]],
            columnStyles: {
              0: { columnWidth: 11 },
              1: { columnWidth: 11 },
              2: { columnWidth: 11 },
              3: { columnWidth: 11 },
              4: { columnWidth: 11 },
              5: { columnWidth: 11 },
              6: { columnWidth: 11 },
              7: { columnWidth: 11 },
              8: { columnWidth: 11 },
              9: { columnWidth: 11 },
              10: { columnWidth: 11 },
              11: { columnWidth: 11 },
              12: { columnWidth: 11 },
              13: { columnWidth: 11 },
              14: { columnWidth: 11 },
              15: { columnWidth: 11 },
              16: { columnWidth: 11 },
            },
            theme: "grid",
            tableWidth: "auto",
            fontStyle: "normal",
            body: [...rows],
          });
          doc.save("pharmacies_sheet.pdf");
          setValues("");
        }
      })
    );
  };

  return (
    <form>
      <fieldset  className={classes.exportAlign}>
        <select onChange={handleChange} value={values}>
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default ExportTermsGrid;
