import React, { useEffect, useState, useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  Button,
  FormLabel,
  Typography,
  Checkbox,
  Tooltip,
} from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import DatePicker from "../../../../../../components/common/DatePicker";
import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import _get from "lodash/get";
import _isArray from "lodash/isArray";
import _unionBy from "lodash/unionBy";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import {
  checkProviderType,
  ProvidersSearch,
  saveProvider,
  saveProviderMessageUuid,
} from "../../../../../../context/actions/providers";
import { getProviderDefaultPayload } from "../../../../../Eligibility/Providers/constants";
import {
  fetchProvidersTableData,
  fetchTermsGridTableData,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";
import { useCeProviderStyles } from "./styles";
import { COContext } from "../../../../COContext";
import AutoComplete from "../../../../../../components/common/AutoComplete";
import {
  ALL_LOCATION_OPTION,
  POLLING_COUNT,
  setAutoCompleteInputVal,
} from "../../../../../../utils/constants";
import { getProvidersPayloadJson } from "../../../CeSummary/CeProviders/helper";
import { addProviderPayload } from "./constant";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { getUserSession } from "../../../../../../utils/helper";
import MultiSelectDropdown from "../../../../../../components/common/MultiSelectDropdown";
import {
  endDateValidation,
  startDateValidation,
} from "../../../../../../utils/common";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;

const AddProviderdetails = ({
  setOpenPopup,
  setFormData,
  formData,
  messageUuid,
  ceSelected,
  view,
  rowData,
  editProvider,
  setMenusStatuses,
  searchData,
  defaultFilters,
  formRef,
  spiExist,
  deaExist,
  npiExist,
}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const providerClasses = useCeProviderStyles();
  const userSessionData = getUserSession();
  const [providerError, setProviderError] = useState(false);
  const [providerLocations, setProviderLocations] = useState([]);
  const [locationHrsaIds, setLocationHrsaIds] = useState(
    (providerInnerGridList &&
      providerInnerGridList.map((x) => x.locationHrsaId).join(", ")) ||
      ""
  );
  const [providerTypeError, setProviderTypeError] = useState("");
  const [providerTypeAlert, setProviderTypeAlert] = useState(false);
  const [exclusiveTypeError, setExclusiveTypeError] = useState("");
  const {
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    coveredEntityName,
    termsGridPayload,
  } = useContext(COContext) || {};
  const locationsList =
    useSelector((state) => state.getLocationListValues.records) || [];
  const providerInnerGridList =
    useSelector((state) => state.providersLocationsGridData.records.content) ||
    [];

  const isAllLocation =
    locationsList.length != 0 &&
    locationsList.length !== 1 &&
    locationsList.length === providerInnerGridList.length;

  const isSelectedLocation = useSelector(
    (state) => state.providersLocationsGridData.isSelectedLocation
  );
  const providerTypeValues = useSelector((state) => state.getProvidertype.data);

  useEffect(() => {
    if (isSelectedLocation) {
      const selectedLocation = providerInnerGridList.map((itm) =>
        locationsList.find((el) => el.entityLocationId == itm.entityLocationId)
      );
      setProviderLocations(isAllLocation ? locationsList : selectedLocation);
      getLocationHrsaIds(selectedLocation);
    }
  }, [isSelectedLocation]);

  const getLocationHrsaIds = (data = {}) => {
    const allLocations =
      data &&
      data.length > 0 &&
      !_isEmpty(data[0]) &&
      data[0].locationName === "All"
        ? locationsList
        : data;

    if (_isArray(allLocations)) {
      setLocationHrsaIds(
        allLocations
          .map((x = {}) => x.locationHrsaId && x.locationHrsaId)
          .join(", ") || ""
      );
    }
  };

  useEffect(() => {
    if (_get(formRef, "current.values.providerLocations.length", 0)) {
      const selectedLocations = _get(
        formRef,
        "current.values.providerLocations",
        []
      );
      setProviderLocations(selectedLocations);
      getLocationHrsaIds(selectedLocations);
    }
  }, [_get(formRef, "current.values.providerLocations", [])]);

  const getFormatedLocationPayload = (data) => {
    let providerLocations = data;
    // data.length > 0 && data[0].locationName === "All" ? locationsList : data;
    if (providerInnerGridList.length > 0) {
      providerInnerGridList.forEach((itm = {}) => {
        providerLocations.forEach((el = {}) => {
          el.activeFlag = "Y";
          if (el.entityLocationId === itm.entityLocationId) {
            el.prescriberLocMapId = itm.prescriberLocMapId || 0;
          }
        });
      });

      providerLocations = _unionBy(
        providerLocations,
        providerInnerGridList,
        "entityLocationId"
      );
      providerLocations.forEach((data = {}) => {
        if (!data.activeFlag) {
          data.activeFlag = "N";
        }
      });
    } else {
      providerLocations.forEach((element = {}) => {
        element.activeFlag = "Y";
      });
    }

    return providerLocations.map((obj = {}) => {
      if (obj.prescriberLocMapId) {
        return {
          entityLocationId: obj.entityLocationId,
          prescriberLocMapId: obj.prescriberLocMapId,
          activeFlag: obj.activeFlag,
        };
      } else {
        return {
          entityLocationId: obj.entityLocationId,
          activeFlag: obj.activeFlag,
        };
      }
    });
  };

  const handleSubmit = async (value) => {
    let error = false;
    if (
      !value.npi ||
      value.npi.length < 10 ||
      !value.firstName ||
      !value.lastName ||
      spiExist ||
      deaExist ||
      npiExist
    )
      error = true;
    setFormData(value);
    setProviderError(error);
    if (!error) {
      const payload = {
        ...addProviderPayload(value),
        ceid:
          (messageUuid && messageUuid.ceid !== null && messageUuid.ceid) ||
          (ceSelected && ceSelected.ceID) ||
          (rowData && rowData.ceid),
        startDate: value.startDate.split(",")[0],
        prescriberPanelTypeId: value.prescriberPanelTypeId,
        providerLocations: getFormatedLocationPayload(providerLocations),
        createdById: userSessionData.userId,
        modifiedById: userSessionData.userId,
        ...(editProvider &&
          rowData && {
            providerId: rowData.prescriberId,
            providerCeId: rowData.providerCeId,
            providerCeId: rowData.prescriberCeid,
            prescriberDeaId: rowData.prescriberDeaId,
          }),
      };

      const resp = await dispatch(saveProvider(payload));
      if (!_isEmpty(resp) && resp.data) {
        handlePolling({ messageUUid: resp.data, currentCount: POLLING_COUNT });
      }
    }
  };

  const handlePolling = async ({ messageUUid, currentCount }) => {
    const count = currentCount;
    const resp = await dispatch(
      saveProviderMessageUuid(messageUUid, count, editProvider)
    );
    if (resp && resp.statusCode === 200) {
      dispatch(
        fetchProvidersTableData(
          getProvidersPayloadJson({
            ceId:
              (messageUuid && messageUuid.ceid) ||
              (ceSelected && ceSelected.ceID) ||
              (rowData && rowData.ceid),
          })
        )
      );
      dispatch(
        updateSectionStatus({
          ceId: resp.data.ceid,
          sectionId: 7,
          callback,
        })
      );
      fetchProviderList();
      setOpenPopup(false);
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    }
  };

  const callback = (res) => {
    if (res.statusCode == 200 && messageUuid) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({ ...prev, provider: false }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  const fetchProviderList = () => {
    const ceid =
      (messageUuid && messageUuid.ceid !== null && messageUuid.ceid) ||
      (ceSelected && ceSelected.ceID) ||
      (rowData && rowData.ceid);
    dispatch(
      ProvidersSearch({
        ...getProviderDefaultPayload(searchData),
        ceid: [ceid],
        filter: defaultFilters,
      })
    );
  };

  const onDateChange = (name, value, formik) => {
    if (name === "startDate" && value === "")
      formik.setTouched({ startDate: true });
    formik.setFieldValue(name, value);
  };

  const formValidate = (values) => {
    const errors = {};
    if (values.startDate === "") {
      errors.startDate = "Please select the Provider Start Date";
    }
    if (values.prescriberPanelTypeId === 0) {
      errors.prescriberPanelTypeId = "Please select the Program Type";
    }
    if (exclusiveTypeError) {
      errors.prescriberPanelTypeId = exclusiveTypeError;
    }
    if (values.prescriberPanelTypeId === 1) {
      setExclusiveTypeError("");
    }
    return errors;
  };

  const getCoveredEntityName = () => {
    const ceName = editProvider
      ? rowData && rowData.ceName
      : (messageUuid && messageUuid.ceName) ||
        (ceSelected && ceSelected.ceName);
    return (
      <div className={providerClasses.coveredEntityNameWrapper}>
        <Tooltip title={ceName}>
          <div className={providerClasses.coveredEntityName}>
            <BasicTypography variant="subtitle2">
              {ceName || coveredEntityName}
            </BasicTypography>
          </div>
        </Tooltip>
      </div>
    );
  };

  const getHrsaIDs = (data) => {
    const hrsaIds = data.map((el = {}) => el.locationHrsaId) || [];
    return hrsaIds.length <= 3 ? (
      <Tooltip title={hrsaIds} placement="bottom">
        <span>{hrsaIds}</span>
      </Tooltip>
    ) : (
      <Tooltip title={hrsaIds} placement="bottom">
        <span>{hrsaIds.slice(0, 2) + "..."}</span>
      </Tooltip>
    );
  };

  const getLocationName = (data) => {
    const locations = data.map((el = {}) => el.locationName) || [];
    return locations.length <= 3 ? (
      <Tooltip title={locations} placement="bottom">
        <span>{locations}</span>
      </Tooltip>
    ) : (
      <Tooltip title={locations} placement="bottom">
        <span>{locations.slice(0, 2) + "..."}</span>
      </Tooltip>
    );
  };

  const handleProviderTypeChange = async (value, formik) => {
    const { setFieldValue, initialValues } = formik;
    if (initialValues.prescriberPanelTypeId != Number(value)) {
      if (initialValues.prescriberPanelTypeId == 1 && Number(value) == 2) {
        const resp = await dispatch(checkProviderType(initialValues.npi));
        if (resp.statusCode == 200) {
          setProviderTypeError(resp.errorMessage);
          setProviderTypeAlert(true);
        } else if (resp.statusCode == 404)
          setExclusiveTypeError(resp.errorMessage);
        else {
          setProviderTypeError("");
          setExclusiveTypeError("");
        }
      } else if (
        initialValues.prescriberPanelTypeId == 2 &&
        Number(value) == 1
      ) {
        setFieldValue("startDate", "");
        setFieldValue("endDate", "");
        setFieldValue("prescriberPanelTypeChanged", "Y");
      }
    } else {
      setFieldValue("startDate", initialValues.startDate);
      setFieldValue("endDate", initialValues.endDate);
      setFieldValue(
        "prescriberPanelTypeChanged",
        initialValues.prescriberPanelTypeChanged
      );
    }
    setFieldValue("prescriberPanelTypeId", Number(value));
  };

  const handleSubmitProviderType = (formik) => {
    formik.setFieldValue("startDate", "");
    formik.setFieldValue("endDate", "");
    formik.setFieldValue("prescriberPanelTypeChanged", "Y");
    setProviderTypeAlert(false);
  };

  const cancelConfirmationPopup = (formik) => {
    formik.setFieldValue(
      "prescriberPanelTypeId",
      formik.initialValues.prescriberPanelTypeId
    );
    setProviderTypeAlert(false);
  };

  return (
    <Formik
      enableReinitialize={true}
      initialValues={formData}
      onSubmit={handleSubmit}
      validate={formValidate}
      innerRef={formRef}
    >
      {(formik) => (
        <>
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                <BasicTypography variant="h4">Details</BasicTypography>
                {providerError && (
                  <Typography color="error" variant="caption">
                    Please fill the provider overview required fields.
                  </Typography>
                )}
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Covered Entity</FormLabel>
                    {view ? (
                      <BasicTypography variant="subtitle2">
                        {rowData && rowData.ceName}
                      </BasicTypography>
                    ) : (
                      getCoveredEntityName()
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>HRSA ID</FormLabel>
                    {view ? (
                      <BasicTypography variant="subtitle2">
                        {rowData && rowData.ceCode}
                      </BasicTypography>
                    ) : (
                      <Field
                        name="fn"
                        id="fn"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter HRSA ID"
                        disabled
                        value={
                          editProvider
                            ? rowData && rowData.ceCode
                            : (messageUuid &&
                                (messageUuid.hrsaId || messageUuid.ceCode)) ||
                              (ceSelected && ceSelected.ceCode)
                        }
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Provider Location</FormLabel>
                    {view ? (
                      <BasicTypography variant="subtitle2">
                        {isAllLocation
                          ? "All"
                          : getLocationName(providerInnerGridList)}
                      </BasicTypography>
                    ) : (
                      <Field as="select" multiple name="ci">
                        {({ field }) => (
                          <MultiSelectDropdown
                            inputPlaceholder="Select Provider Locations"
                            options={locationsList}
                            getOptionLabel={(option = {}) =>
                              `${option.locationName}-${option.locationHrsaId}`
                            }
                            {...field}
                            //may require in future
                            // inputValue={
                            //   formik.values.providerLocationInput || ""
                            // }
                            onChange={(_e, val) => {
                              setProviderLocations(val);
                              getLocationHrsaIds(val);
                              formik.setFieldValue("providerLocations", val);
                            }}
                            //may require in future
                            // onInputChange={(_e, value) =>
                            //   setAutoCompleteInputVal({
                            //     value,
                            //     callback: (newValue) => {
                            //       formik.setFieldValue(
                            //         "providerLocationInput",
                            //         newValue
                            //       );
                            //     },
                            //   })
                            // }
                            value={providerLocations}
                            tooltipProps={{
                              title: _get(
                                providerLocations,
                                "0.locationName",
                                ""
                              ),
                            }}
                          />
                        )}
                      </Field>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Provider Location HRSA ID</FormLabel>
                    {view ? (
                      <BasicTypography variant="subtitle2">
                        {getHrsaIDs(providerInnerGridList)}
                      </BasicTypography>
                    ) : (
                      <Field
                        value={locationHrsaIds}
                        title={locationHrsaIds}
                        name="locationHrsaId"
                        disabled
                        id="locationHrsaId"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Provider Location HRSA ID"
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!view}>Program Type</FormLabel>
                    {view ? (
                      providerTypeValues &&
                      providerTypeValues.length > 0 &&
                      providerTypeValues.map(
                        ({ prescriberPanelType, prescriberPanelTypeId }) => {
                          return (
                            formik.values.prescriberPanelTypeId ===
                              prescriberPanelTypeId && (
                              <BasicTypography variant="subtitle2">
                                {prescriberPanelType}
                              </BasicTypography>
                            )
                          );
                        }
                      )
                    ) : (
                      <Field
                        as="select"
                        className={globalClasses.formControl}
                        name="prescriberPanelTypeId"
                      >
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            disableCloseOnSelect={false}
                            options={
                              _isArray(providerTypeValues)
                                ? providerTypeValues
                                : []
                            }
                            inputPlaceholder={"Select Program Type"}
                            onChange={(_e, value) => {
                              formik.setFieldValue(
                                "prescriberPanelTypeId",
                                value ? value.prescriberPanelTypeId : ""
                              );
                              if (!_isEmpty(value))
                                handleProviderTypeChange(
                                  value.prescriberPanelTypeId,
                                  formik
                                );
                            }}
                            getOptionLabel={(option) =>
                              option.prescriberPanelType || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.prescriberPanelType}
                                </BasicTypography>
                              );
                            }}
                            value={
                              (_isArray(providerTypeValues) &&
                                providerTypeValues.find(
                                  (e) =>
                                    e.prescriberPanelTypeId ==
                                    formik.values.prescriberPanelTypeId
                                )) ||
                              ""
                            }
                            multiple={false}
                          />
                        )}
                      </Field>
                    )}
                    {formik.touched.prescriberPanelTypeId &&
                      formik.errors.prescriberPanelTypeId && (
                        <Typography color="error" variant="caption">
                          {formik.errors.prescriberPanelTypeId}
                        </Typography>
                      )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!view}>Provider Start Date</FormLabel>
                    {view ? (
                      <BasicTypography variant="subtitle2">
                        {formik.values.startDate}
                      </BasicTypography>
                    ) : (
                      <DatePicker
                        onChange={(_e, date) => {
                          if (!date) onDateChange("endDate", "", formik);
                          onDateChange("startDate", date, formik);
                        }}
                        disabledDate={(d) =>
                          startDateValidation(d, formik.values.endDate)
                        }
                        value={
                          formik.values.startDate !== ""
                            ? moment(formik.values.startDate)
                            : ""
                        }
                        disabled={
                          moment(formik.values.startDate) <
                            moment().startOf("day") ||
                          (formData.lastModifiedDate &&
                            moment(formik.values.startDate).format(
                              "MM/DD/YYYY"
                            ) === moment().format("MM/DD/YYYY"))
                        }
                      />
                    )}
                    {formik.touched.startDate && formik.errors.startDate && (
                      <Typography color="error" variant="caption">
                        {formik.errors.startDate}
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Provider End Date</FormLabel>
                    {view ? (
                      <BasicTypography variant="subtitle2">
                        {formik.values.endDate ? formik.values.endDate : "_"}
                      </BasicTypography>
                    ) : (
                      <DatePicker
                        onChange={(e, date) =>
                          onDateChange("endDate", date, formik)
                        }
                        disabledDate={(d) =>
                          endDateValidation(d, formik.values.startDate)
                        }
                        value={
                          formik.values.endDate !== "" &&
                          formik.values.endDate !== null
                            ? moment(formik.values.endDate)
                            : ""
                        }
                        disabled={
                          moment(formik.values.endDate) <
                          moment().startOf("day")
                        }
                      />
                    )}
                  </Grid>
                </Grid>
              </Grid>

              <Grid item md={12}>
                <Grid container spacing={2} justifyContent="flex-end">
                  {!view && (
                    <Grid item>
                      <Button
                        type="submit"
                        color="primary"
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                      >
                        {rowData ? "Save" : "Add Provider"}
                      </Button>
                    </Grid>
                  )}
                  {!view && (
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        color="default"
                        className={globalClasses.secondaryBtn}
                        onClick={() => {
                          setOpenPopup(false);
                        }}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  )}
                </Grid>
              </Grid>
            </Grid>
          </Form>
          <BasicPopup
            title={"Alert"}
            show={providerTypeAlert}
            handleClose={() => {
              cancelConfirmationPopup(formik);
            }}
            submitProps={{
              buttonTitle: "Ok",
              handleSubmit: () => {
                handleSubmitProviderType(formik);
              },
            }}
            cancelProps={{
              buttonTitle: "Cancel",
              handleCancel: () => {
                cancelConfirmationPopup(formik);
              },
            }}
            disableFooter={false}
            dialogProps={{
              maxWidth: "xs",
              classes: {
                paper: providerClasses.dialogPaper,
              },
            }}
          >
            {providerTypeError}
          </BasicPopup>
        </>
      )}
    </Formik>
  );
};

export default AddProviderdetails;
