export const checkIsNPIPresentInList = ({ npi, phId, options = [] } = {}) => {
  return options.some(
    (option) =>
      Number(option.npi) === Number(npi) && Number(option.phid) === Number(phId)
  );
};

export const checkIsPhNamePresentInList = ({
  phName,
  phId,
  options = [],
} = {}) => {
  return options.some(
    (option) => option.phName === phName && Number(option.phid) === Number(phId)
  );
};
