import { makeStyles } from "@material-ui/core";

export const useCeBasicDetailsStyle = makeStyles((_theme) => {
  return {};
});
