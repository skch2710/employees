import React, { useCallback, useContext, useRef, useState } from "react";
import { Checkbox, Tooltip, useTheme } from "@material-ui/core";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import _isEmpty from "lodash/isEmpty";
import DatePicker from "../../../../../../../components/common/DatePicker";
import moment from "moment";
import TableCustomSortArrow from "../../../../../../../components/common/TableCustomSortArrow";
import { LABELS, pagination } from "../../../../../../../utils/constants";
import { useAdminFeesTableStyles } from "../styles";
import DataNotFound from "../../../../../../../components/common/DataNotFound";
import BasicTypography from "../../../../../../../components/common/Typography/BasicTypography";
import {
  getAdminFeeSavePayload,
  getAdminFeesFiltersObject,
  getDefaultFormValues,
  getEditAdminFeeDefaultFormValues,
} from "../helper";
import BasicPopup from "../../../../../../../components/Popup/BasicPopup";
import { COContext } from "../../../../../COContext";
import AdminFeePopupFooter from "./AdminFeePopupFooter";
import AddAdminFees from "./AddAdminFees";
import { saveAdminFeeData } from "../../../../../../../context/actions/PharmacyConfiguration";
import { isEmptyGrid } from "../../../../../../../utils/helper";
import TableProgressBar from "../../../../../../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../../../../../../components/common/TableIcons";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../../../../components/common/Pagination";

const AdminFeesTable = (props = {}) => {
  const { getAdminFeeTableData, isConfigurable } = props;
  const theme = useTheme();
  const dispatch = useDispatch();
  const { currentPharmacy = {} } = useContext(COContext);
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();

  const [defaultValues, setDefaultValues] = useState(getDefaultFormValues());
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [showAddFee, setShowAddFee] = useState(false);
  const [addAdminFeePopupTitle, setAddAdminFeePopupTitle] = useState("");
  const columnFiltersRef = useRef({});
  const getFeeTypesRef = useRef(null);
  const { loading, records: adminFeesTableData } =
    useSelector((state) => state.phAdminFeesList) || {};
  const classes = useAdminFeesTableStyles({
    totalElements:
      !_isEmpty(adminFeesTableData) && adminFeesTableData.totalElements,
    pageSize: controllers.pageSize,
    pageNumber: controllers.pageNumber,
  });

  const handleSubmit = async (values, { resetForm }) => {
    const payload = getAdminFeeSavePayload({
      ...values,
      clientId: currentPharmacy.clientId,
    });
    const resp = await dispatch(saveAdminFeeData(payload));
    if (resp) getAdminFeeTableData({ filter: columnFilters });
    if (resp && values.isExit) setShowAddFee(false);
    else if (resp) {
      resetForm();
      getFeeTypesRef.current && getFeeTypesRef.current.fetchFeeTypes();
    }
  };

  const ADMIN_FEES = [
    {
      title: LABELS.CoveredEntity,
      field: "entityName",
      defaultFilter: enableFilters && columnFiltersRef.current.entityName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.entityName}>
            <span>{rowData.entityName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.entityName}
          placeholder={LABELS.CoveredEntity}
        />
      ),
    },
    {
      title: "340BDirect+ Fee Type",
      field: "feeType",
      defaultFilter: enableFilters && columnFiltersRef.current.feeType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeType}>
            <span>{rowData.feeType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.feeType}
          placeholder="340BDirect+ Fee Type"
        />
      ),
    },
    {
      title: "340BDirect+ Fee Value",
      field: "flatFee",
      defaultFilter: enableFilters && columnFiltersRef.current.flatFee,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.flatFee}>
            <span>{rowData.flatFee}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.flatFee}
          placeholder="340BDirect+ Fee Value"
        />
      ),
    },
    {
      title: "Percentage",
      field: "percentage",
      defaultFilter: enableFilters && columnFiltersRef.current.percentage,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.percentage}>
            <span>{rowData.percentage}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.percentage}
          placeholder="Percentage"
        />
      ),
    },
    {
      title: "Basis Of",
      field: "basisOf",
      defaultFilter: enableFilters && columnFiltersRef.current.basisOf,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.basisOf}>
            <span>{rowData.basisOf}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.basisOf}
          placeholder="Basis Of"
        />
      ),
    },
    {
      title: "Claim Type",
      field: "claimType",
      defaultFilter: enableFilters && columnFiltersRef.current.claimType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimType}>
            <span>{rowData.claimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimType}
          placeholder="Claim Type"
        />
      ),
    },
    {
      title: "Covered Entity Admin Fee Model",
      field: "addlClaimType",
      defaultFilter: enableFilters && columnFiltersRef.current.addlClaimType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addlClaimType}>
            <span>{rowData.addlClaimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addlClaimType}
          placeholder="Covered Entity Admin Fee Model"
        />
      ),
    },
    {
      title: "Switch",
      field: "switchType",
      defaultFilter: enableFilters && columnFiltersRef.current.switchType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.switchType}>
            <span>{rowData.switchType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.switchType}
          placeholder="Switch"
        />
      ),
    },
    {
      title: "340BDirect+ Fee Start Date",
      field: "feeStartDate",
      defaultFilter: enableFilters && columnFiltersRef.current.feeStartDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeStartDate}>
            <span>{rowData.feeStartDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.feeStartDate
                ? moment(columnFiltersRef.current.feeStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "340BDirect+ Fee End Date",
      field: "feeEndDate",
      defaultFilter: enableFilters && columnFiltersRef.current.feeEndDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeEndDate}>
            <span>{rowData.feeEndDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.feeEndDate
                ? moment(columnFiltersRef.current.feeEndDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Fee Applied",
      field: "applied",
      filtering: false,
      sorting: false,
      render: () => {
        return (
          <Checkbox
            name="appliedFeesStatus"
            color="default"
            checked
            classes={{
              root: classes.checkbox,
            }}
          />
        );
      },
    },
  ];

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(adminFeesTableData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;

      getAdminFeeTableData(
        {
          ...controllers,
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          filter: columnFilters,
        },
        (resp) => {
          setControllers((prev) => ({
            ...prev,
            pageNumber: resp.pageNo || pagination.page,
            pageSize: resp.pageSize || pagination.limit,
          }));
        }
      );
    },
    [columnFilters, adminFeesTableData, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = ADMIN_FEES[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      getAdminFeeTableData({
        ...controllers,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controllers, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getAdminFeesFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    getAdminFeeTableData({
      ...controllers,
      filter: filterPayload,
    });
  };

  const FILTER_BUTTON = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(adminFeesTableData),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    // {
    //   icon: iconsAndButtons.ExportButton(),
    //   isFreeAction: true,
    //   disabled: isEmptyGrid(adminFeesTableData),
    //   onClick: () =>
    //     exportToExcel({
    //       controllers,
    //       columnFilters,
    //       clientId: currentPharmacy.clientId,
    //     }),
    // },
  ];

  const ADD_BUTTON = [
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add Admin Fees" }),
      tooltip: "Add Admin Fees",
      isFreeAction: true,
      onClick: () => {
        setShowAddFee(true);
        setAddAdminFeePopupTitle("Add Admin Fees");
        setDefaultValues(getDefaultFormValues());
      },
    },
    (row) => ({
      icon: iconsAndButtons.Edit(),
      tooltip: "Edit",
      isFreeAction: false,
      disabled:
        moment(moment(row.feeStartDate).format("MM/DD/YYYY")).isBefore(
          moment(),
          "day"
        ) || row.adminFeeTypeNewId === 9,
      onClick: (_event, rowData) => {
        setShowAddFee(true);
        setAddAdminFeePopupTitle("Edit Admin Fees");
        setDefaultValues(
          getEditAdminFeeDefaultFormValues({ ...rowData, isEdit: true })
        );
      },
    }),
  ];

  const handleValidate = async (values) => {
    const error = {};
    if (Number(values.feesType) === 0) {
      error.feesType = "Please select the Fee Type";
    }
    if (values.startDate === "") {
      error.startDate = "Please select the 340BDirect+ Fee Start Date";
    }
    if (
      (Number(values.feesType) === 3 ||
        Number(values.feesType) === 5 ||
        Number(values.feesType) === 6) &&
      !values.adminFee
    ) {
      error.adminFee = "Please enter the Flat Fee";
    }
    if (
      (Number(values.feesType) === 3 || Number(values.feesType) === 5) &&
      (!values.claimType || Number(values.claimType) === 0)
    ) {
      error.claimType = "Please select the Claim Type";
    }
    if (
      (Number(values.feesType) === 3 || Number(values.feesType) === 5) &&
      (!values.addClaimType || Number(values.addClaimType) === 0)
    ) {
      error.addClaimType = "Please select the Additional Claim Type";
    }
    if (
      (Number(values.feesType) === 4 || Number(values.feesType) === 5) &&
      !values.adminFeePercentage
    ) {
      error.adminFeePercentage = "Please enter Percentage Only";
    }
    return error;
  };

  return (
    <>
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Admin Fees (${adminFeesTableData.totalElements || 0})`}
            />
          }
          columns={ADMIN_FEES}
          data={adminFeesTableData.content}
          page={controllers.pageNumber - 1}
          totalCount={adminFeesTableData.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={
            isConfigurable ? [...FILTER_BUTTON, ...ADD_BUTTON] : FILTER_BUTTON
          }
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            detailPanelType: "single",
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(adminFeesTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>

      {showAddFee && (
        <BasicPopup
          show={showAddFee}
          title={`${
            currentPharmacy.phName || "Pharmacy Name"
          } / ${addAdminFeePopupTitle}`}
          disableFooter={true}
          isCustomFooter={true}
          footerActionElement={
            <AdminFeePopupFooter setShowAddFee={setShowAddFee} />
          }
          handleClose={() => setShowAddFee(false)}
          dialogProps={{
            maxWidth: "md",
            classes: {
              paper: classes.dialogPaper,
            },
          }}
          withFormik={true}
          formikProps={{
            initialValues: defaultValues,
            onSubmit: handleSubmit,
            validate: handleValidate,
          }}
        >
          <AddAdminFees ref={getFeeTypesRef} />
        </BasicPopup>
      )}
    </>
  );
};

export default AdminFeesTable;
