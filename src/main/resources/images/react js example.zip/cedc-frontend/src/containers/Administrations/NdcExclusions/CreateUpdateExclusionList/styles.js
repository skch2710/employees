import { makeStyles } from "@material-ui/core/styles";

export const useNdcCreateStyles = makeStyles((theme) => ({
  tabsContainer: {
    borderBottom: `1px solid ${theme.colors.monochrome.border}`,
  },
  tabsIndicator: {
    background: theme.colors.blue[800],
  },
  tabsLabel: {
    textTransform: "capitalize",
    color: theme.colors.blue[800],
  },
  selectedTab: { color: theme.colors.blue[800] },
  tabPanelContainer: {
    padding: "0 12px",
    height: "100%",
  },
  disabledTab: {
    color: theme.colors.monochrome.placeholder,
  },
}));
