import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { LABELS, notNull } from "../../../../../utils/constants";
import {
  getPharmaciesexport,
  getPharmaciesMainExport,
} from "../../../../../context/actions/Pharmacies";

const usePharmacyExport = () => {
  const dispatch = useDispatch();
  let statusValue = true;
  const exportToExcel = (props) => {
    const {
      defaultPharmacyFilters,
      sortorder,
      sortBy,
      ciId,
      Pgroup,
      Pstore,
      endDate,
      phMainGroupId,
      phMainId,
      startDate,
      phMain,
      phMainCeIds,
      phMainCstatus,
      phMainEdate,
      phMainSdate,
    } = props;
    let callApi = "";
    const json = {
      endDate: phMain ? phMainEdate == null ? "" : phMainEdate : endDate,
      phGroupId: phMain ? phMainGroupId == null ? 0 : Number(phMainGroupId) : Number(Pgroup),
      phid: phMain ? phMainId == null ? 0 : Number(phMainId) : Number(Pstore),
      sortBy: sortBy,
      sortOrder: sortorder,
      startDate: phMain ? phMainSdate == null ? "" : phMainSdate : startDate,
      status: phMain ? phMainCstatus == null ? "" : phMainCstatus : "",
      filter: defaultPharmacyFilters,
      export: true,
    };
    if (phMain) {
      json.ceid = phMainCeIds();
      callApi = getPharmaciesMainExport;
    } else {
      json.ceId = ciId;
      callApi = getPharmaciesexport;
    }
    if (phMain) {
      json.ceid === false ? (statusValue = false) : (statusValue = true);
    }
    statusValue &&
      dispatch(
        callApi(json, (result) => {
          var data = result.content.map(
            ({
              coveredEntity,
              pharmacyName,
              pharmacyNetwork,
              goLiveDate,
              startDate,
              endDate,
              brandDispensingFeeThirdParty,
              brandDispensingFeeTCash,
              genericDispensingFeeThirdParty,
              genericDispensingFeeCash,
              specialityDispensingFeeThirdParty,
              specialityDispensingFeeCash,
              programType,
              billingModel,
              wholesaler,
              participatingInCashProgram,
              configStatus,
            }) => ({
              [LABELS.CoveredEntity]: notNull(coveredEntity),
              [LABELS.PharmacyStore]: notNull(pharmacyName),
              [LABELS.PharmacyChain]: notNull(pharmacyNetwork),
              "Go-Live Date": notNull(goLiveDate),
              "Start Date": notNull(startDate),
              "End Date": notNull(endDate),
              "Brand Dispensing Fee Third Party $+%": notNull(
                brandDispensingFeeThirdParty
              ),
              "Brand Dispensing Fee Cash $+%": notNull(brandDispensingFeeTCash),
              "Generic Dispensing Fee Third Party $+%": notNull(
                genericDispensingFeeThirdParty
              ),
              "Generic Dispensing Fee Cash $+%": notNull(
                genericDispensingFeeCash
              ),
              "Specialty Dispensing Fee Third Party $+%": notNull(
                specialityDispensingFeeThirdParty
              ),
              "Specialty Dispensing Fee Cash $+%": notNull(
                specialityDispensingFeeCash
              ),
              "Program Type": notNull(programType),
              "Billing Model": notNull(billingModel),
              Wholesaler: notNull(wholesaler),
              "Participating in Cash Program": notNull(
                participatingInCashProgram
              ),
              "Configuration Status": notNull(configStatus),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "pharmacies" + ".xlsx");
        })
      );
  };

  return { exportToExcel };
};

export default usePharmacyExport;
