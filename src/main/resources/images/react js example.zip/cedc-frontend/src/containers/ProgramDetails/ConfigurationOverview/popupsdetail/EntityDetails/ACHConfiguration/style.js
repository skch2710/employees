import { makeStyles } from "@material-ui/core";

export const useAchTableStyles = makeStyles((theme) => {
  return {
    tableHeader: () => {
      return {
        marginRight: "10px",
        marginTop: "7px",
        marginBottom: "8px",
        paddingLeft: "6px",
      };
    },
    tableActionButtonRoot: {
      height: "30px",
      fontSize: "13px",
      textTransform: "capitalize",
    },
    btnLabelContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    pennyTestGrid: {
      display: "flex",
      alignItems: "center",
      height: "68px",
    },
    pennyTestCheckboxDiv: {
      display: "flex",
      alignItems: "center",
    },
    pennyTestCheckbox: {
      marginRight: "6px",
    },
    pennyTestCheckboxLabel: {
      paddingBottom: "0px",
    },
    addAchPopupFooterBtnContainer: {
      display: "flex",
      gap: "15px",
      justifyContent: "flex-end",
    },
  };
});
