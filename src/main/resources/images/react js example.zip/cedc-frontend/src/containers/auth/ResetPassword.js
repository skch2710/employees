import React from "react";
import { Paper, Typography, Grid, Button } from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import { useHistory } from "react-router-dom";
import LockIcon from "../../assets/icon-set-password.png";

import { useStyles } from "../../mui-styles/createpasswordStyle";
import { getResetQuestionsDefaultValue } from "../../utils/constants";
import Notfound from "../../components/common/Notfound";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import classNames from "classnames";

const ResetPassword = () => {
  const classes = useStyles();
  const history = useHistory();
  const defaultValues = getResetQuestionsDefaultValue();
  const globalClasses = useGlobalStyles();

  let userData = localStorage.getItem("userData");
  let validateUUIDStorage = localStorage.getItem("validateUUID");

  const handleSubmit = (values) => {
    history.push("/login");
  };

  const formValidate = (values) => {
    let error = {};
    if (values.currentpw.trim() === "") {
      error.currentpw = "Please enter the Current Password";
    }
    if (values.newpw.trim() === "") {
      error.newpw = "Please enter the New Password";
    } else if (values.newpw.length <= 12) {
      error.newpw = "Must be at least 12 characters in length";
    }
    if (values.cnp.trim() === "") {
      error.cnp = "Please enter the Confirm Password";
    }
    if (values.cnp !== values.newpw) {
      error.cnp = "Password mismatch";
    }
    return error;
  };

  const firstNameAndLastName = (user) => {
    return user ? user.firstName + " " + user.lastName : "";
  };

  return (
    <>
      {JSON.parse(validateUUIDStorage) === true || true ? (
        <Formik
          initialValues={defaultValues}
          onSubmit={handleSubmit}
          validate={formValidate}
        >
          {({ errors }) => (
            <>
              <div>
                <Paper elevation={0} className={classes.paper}>
                  <Typography component="span" className="form-text m-b-30">
                    Welcome :{" "}
                  </Typography>{" "}
                  <strong>{firstNameAndLastName(JSON.parse(userData))}</strong>
                  <Grid className={classes.subtitle}>
                    <Grid>
                      <img
                        alt="LockIcon"
                        src={LockIcon}
                        className={classes.iconStyle}
                      />
                    </Grid>
                    <Grid>
                      <Typography variant="h6" className={classes.subtitle2}>
                        Reset Your Password
                      </Typography>
                      <Typography variant="body2" className="form-text m-b-30">
                        Please answer two questions from the list..
                      </Typography>
                    </Grid>
                  </Grid>
                  <Form>
                    <Grid xs={12} sm={12}>
                      <Typography variant="body1" className="mb-3">
                        <strong>Answer the following security questions</strong>
                      </Typography>
                      <Grid container spacing={3}>
                        <Grid item xs={12} sm={6}>
                          <Typography variant="body2">
                            Question 1 - what is your Preffered airline?
                          </Typography>
                          <br />
                          <Field
                            name="ans1"
                            id="ans1"
                            type="text"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Answer of your question"
                            style={{ marginTop: "-10px" }}
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <Typography variant="body2">
                            Question 2 - what is your Childhood Nickname?
                          </Typography>
                          <br />
                          <Field
                            name="ans2"
                            id="ans2"
                            type="text"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Answer of your question"
                            style={{ marginTop: "-10px" }}
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid className={classes.spacing}>
                      <Typography variant="body1">
                        <strong> Reset your Password </strong>
                      </Typography>
                      <Grid container spacing={3} style={{ marginTop: "5px" }}>
                        <Grid item xs={12} sm={4}>
                          <Field
                            name="currentpw"
                            id="currentpassword"
                            type="password"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Enter Current Password"
                            maxLength={50}
                          />
                          {errors.currentpw && (
                            <Typography color="error" variant="caption">
                              {errors.currentpw}
                            </Typography>
                          )}
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <Field
                            name="newpw"
                            id="newpassword"
                            type="password"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Enter New Password"
                            maxLength={50}
                          />
                          {errors.newpw && (
                            <Typography color="error" variant="caption">
                              {errors.newpw}
                            </Typography>
                          )}
                        </Grid>

                        <Grid item xs={12} sm={4}>
                          <Field
                            name="cnp"
                            id="confirmnewpassword"
                            type="password"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Confirm New Password"
                            maxLength={50}
                          />
                          {errors.cnp && (
                            <Typography color="error" variant="caption">
                              {errors.cnp}
                            </Typography>
                          )}
                        </Grid>

                        <Typography
                          variant="caption"
                          className="form-text m-b-30"
                          style={{ padding: "20px" }}
                        >
                          Must be at least 12 characters in length
                          <br />
                          Special Characters/Caps/Numbers NOT required
                          <br />
                          Unique password history: 20
                        </Typography>

                        <Grid
                          container
                          justifyContent="flex-end"
                          style={{ marginRight: "40px", marginTop: "-28px" }}
                        >
                          <Button
                            type="submit"
                            color="primary"
                            size="small"
                            variant="contained"
                            className="btn btn-primary"
                          >
                            Save
                          </Button>
                          <Button
                            type="reset"
                            size="small"
                            variant="outlined"
                            color="default"
                            className="btn btn-secondary m-l-20"
                          >
                            {" "}
                            cancel
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Form>
                </Paper>
              </div>
            </>
          )}
        </Formik>
      ) : (
        <div>
          <Notfound
            value={"Oops, there was a problem with your link"}
            linkType={
              "Your reset link has expired or has already been used. Please contact admin."
            }
            nameOfUser={firstNameAndLastName(JSON.parse(userData))}
          />
        </div>
      )}
    </>
  );
};

export default ResetPassword;
