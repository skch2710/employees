import { makeStyles } from "@material-ui/core";

export const useCeAchConfigStyle = makeStyles((_theme) => {
  return {};
});
