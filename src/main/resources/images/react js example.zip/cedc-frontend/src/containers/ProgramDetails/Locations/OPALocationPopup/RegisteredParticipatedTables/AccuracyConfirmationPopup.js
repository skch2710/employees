import React, { memo } from "react";
import {
  Checkbox,
  Divider,
  FormControlLabel,
  FormLabel,
  Grid,
} from "@material-ui/core";
import { useFormikContext } from "formik";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import { useOPALocationsTablesStyles } from "./styles";
import CESameLocationTable from "./CESameLocationTable";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import { useEffect } from "react";
import { getUserSession } from "../../../../../utils/helper";
import _isArray from "lodash/isArray";

const AccuracyConfirmationPopup = memo((props = {}) => {
  const { selectedRows, ceSelected, cesWithSameAddress, isAddLocationFlow } =
    props;

  const { values, setFieldValue, errors, touched } = useFormikContext();
  const classes = useOPALocationsTablesStyles();
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();
  const internalUser = userSession.isInternalUser;

  useEffect(() => {
    if (_isArray(cesWithSameAddress)) {
      const selectedData = selectedRows
        .map((row) => {
          const obj = cesWithSameAddress.find((ele) =>
            isAddLocationFlow
              ? ele
              : ele.standardAddrHashKey == row.standardAddrHashKey ||
                ele.addrHashKey == row.nonStandardAddrHashKey
          );

          if (obj)
            return (
              obj && {
                ...obj,
                ...row,
                tableData: { checked: false },
              }
            );
        })
        .filter((val) => val !== undefined);
      setFieldValue("confirmedData", selectedData);
    }
  }, [selectedRows, cesWithSameAddress]);

  const onChangeCheckBox = (event, index) => {
    const data = values.confirmedData;
    data[index] = {
      ...data[index],
      tableData: {
        checked: event.target.checked,
      },
    };
    setFieldValue("confirmedData", data);
  };
  return (
    <Grid container spacing={2}>
      {internalUser && (
        <Grid item md={12} className={classes.accuracySubTitle}>
          <BasicTypography variant="h3">
            Multiple Covered Entities Associated to Selected Address
          </BasicTypography>
          <BasicTypography variant="h5" component="div">
            Please acknowledge that the address selected has been reviewed with
            the Covered Entity for accuracy.
          </BasicTypography>
        </Grid>
      )}
      <Grid item md={12}>
        <BasicTypography variant="h4" component="div">
          {(ceSelected && ceSelected.ceName) || ""}
        </BasicTypography>
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2} direction="column">
          {_isArray(values.confirmedData) &&
            values.confirmedData.map((address, index) => (
              <Grid item>
                <Grid
                  spacing={2}
                  direction="column"
                  container
                  className={classes.accuracySubTitle}
                >
                  <Grid item>
                    {!isAddLocationFlow && internalUser && (
                      <FormControlLabel
                        name="confirmedData"
                        control={
                          <Checkbox
                            name="locationName"
                            color="primary"
                            size="small"
                            onClick={(e) => {
                              onChangeCheckBox(e, index);
                            }}
                          />
                        }
                        label={
                          <BasicTypography variant="h5" component="div">
                            {`${
                              (address.locName && address.locName + ",") || ""
                            } ${address.locHrsaid}`}
                          </BasicTypography>
                        }
                      />
                    )}
                    {isAddLocationFlow && internalUser && (
                      <BasicTypography variant="h5">
                        {`${address.locationName || ""}, ${
                          address.locationHrsaId
                        }`}
                      </BasicTypography>
                    )}
                    <BasicTypography
                      variant="h6"
                      className={!isAddLocationFlow && classes.addressMargin}
                    >{`${address.addressLine1 || ""},  ${
                      address.addressLine2 || ""
                    }${address.addressLine2 && ","}`}</BasicTypography>
                    <BasicTypography
                      variant="h6"
                      className={!isAddLocationFlow && classes.addressMargin}
                    >{`${address.city}, ${address.state}, ${address.zip}`}</BasicTypography>
                  </Grid>

                  {internalUser ? (
                    <Grid item>
                      <CESameLocationTable ceList={address.coveredEntities} />
                    </Grid>
                  ) : (
                    <Grid item>
                      <BasicTypography variant="h3">
                        Address already exists for other CE, please contact
                        Customer Support to resolve this!
                      </BasicTypography>
                    </Grid>
                  )}
                  {!isAddLocationFlow && selectedRows.length != index + 1 && (
                    <Grid item>
                      <Divider
                        orientation="horizontal"
                        classes={{ root: globalClasses.divider }}
                      />
                    </Grid>
                  )}
                </Grid>
              </Grid>
            ))}
        </Grid>
      </Grid>
    </Grid>
  );
});

export default AccuracyConfirmationPopup;
