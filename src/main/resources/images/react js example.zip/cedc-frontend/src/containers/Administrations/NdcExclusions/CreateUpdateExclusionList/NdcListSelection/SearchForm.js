import React, { useEffect, useState } from "react";
import { Field, Form, Formik } from "formik";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { useDispatch } from "react-redux";
import { Button, FormLabel, Grid, IconButton } from "@material-ui/core";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import { getPhDrugManufacturers } from "../../../../../context/actions/Common";
import _isArray from "lodash/isArray";
import { getSearchFormDefaultValues } from "./helper";
import AutoComplete from "../../../../../components/common/AutoComplete";

const SearchForm = (props = {}) => {
  const { handleSubmit, handleClear } = props;
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const defaultValues = getSearchFormDefaultValues();

  const [enableFilters, setEnableFilter] = useState(true);
  const [manufacturers, setManufacturers] = useState([]);

  const fetchManufacturer = async () => {
    const options = await dispatch(getPhDrugManufacturers());
    if (_isArray(options)) {
      setManufacturers(options);
    }
  };

  useEffect(() => {
    fetchManufacturer();
  }, []);

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      enableReinitialize={true}
    >
      {({ setFieldValue, initialValues, errors }) => {
        return (
          <Form>
            {enableFilters ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2} direction="column">
                  <Grid item>
                    <Grid container spacing={2} justifyContent="space-between">
                      <Grid item>
                        <BasicTypography variant="h5">
                          NDC Search Criteria
                        </BasicTypography>
                      </Grid>
                      <Grid item>
                        <IconButton>
                          <IoIosCloseCircleOutline
                            onClick={() => {
                              setEnableFilter(false);
                            }}
                          />
                        </IconButton>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={3}>
                        <FormLabel>Manufacturer</FormLabel>
                        <Field
                            as="select"
                            className={globalClasses.formControl}
                            name="drugManufacturerId"
                          >
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(manufacturers)
                                    ? manufacturers
                                    : []
                                }
                                inputPlaceholder={"Select Manufacturer"}
                                disableCloseOnSelect={false}
                                onChange={(e, value) => {
                                  setFieldValue("drugManufacturerId", value);
                                }}
                                getOptionLabel={(option) =>{
                                 return option.drugManufacturerName || ""
                                }
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.drugManufacturerName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <FormLabel>GCN</FormLabel>
                        <Field
                          name="gcn"
                          type="text"
                          placeholder="Enter GCN"
                          className={globalClasses.formControl}
                          maxLength={15}
                        />
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <FormLabel>NDC</FormLabel>
                        <Field
                          name="ndc"
                          type="text"
                          placeholder="Enter NDC"
                          className={globalClasses.formControl}
                          maxLength={15}
                        />
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <FormLabel>Drug name</FormLabel>
                        <Field
                          name="drugName"
                          type="text"
                          placeholder="Enter Drug Name"
                          className={globalClasses.formControl}
                          maxLength={15}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item>
                    <Grid container>
                      <Grid item xs={12} sm={9}>
                        {errors.ndcSearchCriteriaError && (
                          <BasicTypography color="error" variant="caption">
                            {errors.ndcSearchCriteriaError}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <Grid container spacing={2} justifyContent="flex-end">
                          <Grid item>
                            <Button
                              type="submit"
                              size="small"
                              variant="contained"
                              className={globalClasses.primaryBtn}
                            >
                              Search
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              type="reset"
                              size="small"
                              variant="outlined"
                              className={globalClasses.secondaryBtn}
                              onClick={() => {
                                handleClear(initialValues);
                              }}
                            >
                              Clear
                            </Button>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            ) : (
              <Button
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setEnableFilter(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default SearchForm;
