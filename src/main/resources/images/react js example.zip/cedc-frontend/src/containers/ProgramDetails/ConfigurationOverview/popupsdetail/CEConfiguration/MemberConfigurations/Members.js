import React, { useContext, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Button, Grid, FormLabel } from "@material-ui/core";
import Tooltip from "@mui/material/Tooltip";
import { Formik, Form, Field } from "formik";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import PatientFilters from "../../../../../Eligibility/Patients";
import excel from "../../../../../../assets/excel.png";
import {
  saveMemberDropVal,
  fetchMemberConfigFile,
} from "../../../../../../context/actions/Patients";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import {
  getDeliveryMethodDropdownOptions,
  getFrequencyDropdownOptions,
} from "./helper";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useCeMembersStyles } from "./styles";
import { REGEX } from "../../../../../../utils/constants";
import { getMemberConfigValuesDefault } from "../../../../../ProgramDetails/ConfigurationOverview/helper";
import classNames from "classnames";
import Toggle from "../../../../../../components/common/Toggle";
import AutoComplete from "../../../../../../components/common/AutoComplete";
import { getDropdownValue } from "../../../../../../context/actions/providers";

const Members = ({ patpermissionObj, ciId, permissionObj, clickOnAdd }) => {
  const classes = useCeMembersStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const { menusStatuses, setPopupActiveMenu, setOpenAddCePopup, messageUuid } =
    useContext(COContext);

  const [defaultFormValues, setDefaultFormValues] = useState(
    getMemberConfigValuesDefault({})
  );

  const getMemberConfigOptions = async (ceId) => {
    const memberConfigFile = await dispatch(fetchMemberConfigFile(ceId, false));
    if (!_isEmpty(memberConfigFile)) {
      setDefaultFormValues(memberConfigFile);
    }
  };

  useEffect(() => {
    dispatch(getDropdownValue("Members"));
    getMemberConfigOptions(ciId);
  }, []);

  const memberDropdownList = useSelector(
    (state) => state.ceFileTypeDropdownList.ceMemberDropdownList
  );
  const { dm, ft, ff } = memberDropdownList;

  const [deliveryMethodOptions, setDeliveryMethodOptions] = useState(
    _isArray(dm) ? dm : []
  );
  const [frequencyOptions, setFrequencyOptions] = useState(
    _isArray(ff) ? ff : []
  );

  const numberConversion = (value) => {
    return value ? parseInt(value) : 0;
  };

  const handleFormSubmit = (values) => {
    let payload = {
      ...values,
      id: numberConversion(values.id || 0),
      ceid: messageUuid && messageUuid.ceid !== null ? messageUuid.ceid : ciId,
      fileTypeId: numberConversion(values.fileTypeId),
      deliveryMethodId: numberConversion(values.deliveryMethodId),
      fileFrequencyId: numberConversion(values.fileFrequencyId),
      eligibilityPeriod: numberConversion(values.eligibilityPeriod),
    };
    dispatch(
      saveMemberDropVal(payload, (response) => {
        if (response.statusCode == 200 && response.data != "") {
          if (values.stopNavigation) setOpenAddCePopup(false);
          else setPopupActiveMenu(MENUS.CE_SERVICE_AREA);
        }
      })
    );
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={defaultFormValues}
        onSubmit={handleFormSubmit}
      >
        {({ setFieldValue, values, handleSubmit }) => (
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={6}>
                    <BasicTypography
                      variant="h4"
                      title="Covered Entity Configuration > Patient"
                    />
                  </Grid>
                  <Grid item md={6} container justifyContent="flex-end">
                    <Tooltip
                      title={
                        patpermissionObj !== null &&
                        !patpermissionObj.readWriteFlag
                          ? "You don't have Permission."
                          : ""
                      }
                    >
                      <a
                        href={`/templates/CO_Patients_Template.xlsx`}
                        download="CO_Patients_Template"
                        className={classNames(
                          globalClasses.iconPlusClickableLink,
                          !_isEmpty(patpermissionObj) &&
                            patpermissionObj.readWriteFlag
                            ? null
                            : globalClasses.disabledDownloadTemp
                        )}
                        disabled={
                          patpermissionObj !== null &&
                          patpermissionObj.readWriteFlag
                            ? false
                            : true
                        }
                      >
                        <img src={excel} alt="Sheet" />
                        <span>Download Template</span>
                      </a>
                    </Tooltip>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>File Type</FormLabel>
                    <Field
                      as="select"
                      name="fileTypeId"
                      className={globalClasses.formControl}
                    >
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          disableCloseOnSelect={false}
                          options={_isArray(ft) ? ft : []}
                          inputPlaceholder={"Select File Type"}
                          onChange={(e, newValue) => {
                            const value = newValue ? newValue.id : "";
                            setFieldValue(
                              "fileTypeId",
                              value ? Number(value) : ""
                            );
                            const updatedDeliveryOptions =
                              getDeliveryMethodDropdownOptions({
                                options: dm,
                                id: value,
                              });
                            setDeliveryMethodOptions(updatedDeliveryOptions);
                            if (updatedDeliveryOptions.length === 1) {
                              setFieldValue(
                                "deliveryMethodId",
                                updatedDeliveryOptions[0].id
                              );
                            } else setFieldValue("deliveryMethodId", "");
                            const updatedFreqOptions =
                              getFrequencyDropdownOptions({
                                options: ff,
                                id: value,
                              });
                            setFrequencyOptions(updatedFreqOptions);
                            if (updatedFreqOptions.length === 1) {
                              setFieldValue(
                                "fileFrequencyId",
                                updatedFreqOptions[0].id
                              );
                            } else setFieldValue("fileFrequencyId", "");
                          }}
                          value={
                            (_isArray(ft) &&
                              ft.find((e) => e.id === values.fileTypeId)) ||
                            ""
                          }
                          getOptionLabel={(option) => option.lkpValue || ""}
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.lkpValue}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>Delivery Method</FormLabel>
                    <Field
                      as="select"
                      name="deliveryMethodId"
                      className={globalClasses.formControl}
                    >
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          disableCloseOnSelect={false}
                          options={
                            _isArray(deliveryMethodOptions)
                              ? deliveryMethodOptions
                              : []
                          }
                          inputPlaceholder={"Select Delivery Method"}
                          onChange={(e, value) => {
                            console.log(value, "valuesssss");
                            setFieldValue(
                              "deliveryMethodId",
                              value ? value.id : ""
                            );
                          }}
                          value={
                            (_isArray(deliveryMethodOptions) &&
                              deliveryMethodOptions.find(
                                (e) => e.id === values.deliveryMethodId
                              )) ||
                            ""
                          }
                          getOptionLabel={(option) => option.lkpValue || ""}
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.lkpValue}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>File Delivery Frequency</FormLabel>
                    <Field
                      as="select"
                      name="fileFrequencyId"
                      className={globalClasses.formControl}
                    >
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          disableCloseOnSelect={false}
                          options={
                            _isArray(frequencyOptions) ? frequencyOptions : []
                          }
                          inputPlaceholder={"Select File Delivery Frequency"}
                          onChange={(e, value) => {
                            setFieldValue(
                              "fileFrequencyId",
                              value ? value.id : ""
                            );
                          }}
                          value={
                            (_isArray(frequencyOptions) &&
                              frequencyOptions.find(
                                (e) => e.id === values.fileFrequencyId
                              )) ||
                            ""
                          }
                          getOptionLabel={(option) => option.lkpValue || ""}
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.lkpValue}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                        />
                      )}
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel>Patient Eligibility Period</FormLabel>
                    <Field
                      name="eligibilityPeriod"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Patient Eligibility Period"
                      onKeyPress={(e) => {
                        if (!REGEX.onlyNumbers.test(e.key)) e.preventDefault();
                      }}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (value <= 365 && value >= 0) {
                          if (
                            value &&
                            !REGEX.excludeLeadingAndTrailingSpaces.test(value)
                          )
                            return;
                          setFieldValue("eligibilityPeriod", value);
                        }
                      }}
                    />
                  </Grid>

                  <Grid item xs={6} md={4}>
                    <div className={globalClasses.switchContainer}>
                      <Field
                        name="loadAllEncountersFlag"
                        component={Toggle}
                        type="checkbox"
                        checked={values.loadAllEncountersFlag}
                        onChange={() =>
                          setFieldValue(
                            "loadAllEncountersFlag",
                            !values.loadAllEncountersFlag
                          )
                        }
                      />
                      <FormLabel className={globalClasses.noPaddingForLabels}>
                        Load all Encounters
                      </FormLabel>
                    </div>
                  </Grid>

                  <Grid item xs={6} md={4}>
                    <div className={globalClasses.switchContainer}>
                      <Field
                        name="loadOnlyEligibleEncounters"
                        component={Toggle}
                        type="checkbox"
                        checked={values.loadOnlyEligibleEncounters}
                        onChange={() =>
                          setFieldValue(
                            "loadOnlyEligibleEncounters",
                            !values.loadOnlyEligibleEncounters
                          )
                        }
                      />
                      <FormLabel className={globalClasses.noPaddingForLabels}>
                        Load only Eligible Encounters
                      </FormLabel>
                    </div>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <PatientFilters
                  Co={true}
                  messageUuid={messageUuid}
                  permissionObj={permissionObj}
                />
              </Grid>
              <Grid item md={12}>
                <Grid container justifyContent="flex-end" spacing={2}>
                  <Grid item>
                    <Button
                      type={
                        permissionObj !== null && !permissionObj.readWriteFlag
                          ? "submit"
                          : "button"
                      }
                      color="primary"
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", false);
                        handleSubmit();
                      }}
                    >
                      Next
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => setPopupActiveMenu(MENUS.CE_SERVICE_AREA)}
                    >
                      Skip
                    </Button>
                  </Grid>
                  <Grid item>
                    <Tooltip
                      placement="top"
                      title={
                        patpermissionObj !== null &&
                        !patpermissionObj.readWriteFlag
                          ? "You don't have Permission."
                          : "Save"
                      }
                    >
                      <span>
                        <Button
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          disabled={
                            patpermissionObj !== null &&
                            patpermissionObj.readWriteFlag
                              ? false
                              : true
                          }
                          onClick={() => {
                            setFieldValue("stopNavigation", true);
                            handleSubmit();
                          }}
                        >
                          Save and Exit
                        </Button>
                      </span>
                    </Tooltip>
                  </Grid>
                  <Grid item>
                    <Button
                      type="submit"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => setOpenAddCePopup(false)}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    </>
  );
};
export default Members;
