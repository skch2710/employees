import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { getPOInfoExport } from "../../../../context/actions/PurchaseOrders";
import { notNull } from "../../../../utils/constants";
import { PO_ITEM_INFO_EXPORT_FILE_NAME } from "../constants";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { poID, poItemID, controller, columnFilters } = props;
    dispatch(
      getPOInfoExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          poItemID: poItemID,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              ndc,
              drugName,
              itemStatus,
              orderedQty,
              acknowledgedQty,
              invoicedQty,
              orderedPackageCost,
              acknowledgedPackageCost,
              invoicedPackageCost,
            }) => ({
              "NDC 11": notNull(ndc),
              "Drug Name": notNull(drugName),
              "Item Status": notNull(itemStatus),
              "Ordered Qty": notNull(orderedQty),
              "Acknowledged Qty": notNull(acknowledgedQty),
              "Invoiced Qty": notNull(invoicedQty),
              "Ordered Package Cost": notNull(orderedPackageCost),
              "Acknowledged Package Cost": notNull(acknowledgedPackageCost),
              "Invoiced Package Cost": notNull(invoicedPackageCost),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, PO_ITEM_INFO_EXPORT_FILE_NAME + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
