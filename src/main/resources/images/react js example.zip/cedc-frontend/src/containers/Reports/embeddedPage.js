import React, { useEffect, useState } from "react";
import { PowerBIEmbed } from "powerbi-client-react";
import { models } from "powerbi-client";
import { Grid } from "@material-ui/core";
import { useReportRenderingStyles } from "./styles";
import { useSelector } from "react-redux";
import get from "lodash/get";

const EmbeddedReport = (props) => {
  const classes = useReportRenderingStyles();
  const location = get(props, "location.pathname", "");
  const powerBiData = useSelector((state) => state.powerBiReportDetails);
  const [repIndex, setIndex] = useState(0);

  // useEffect(() => {
  //   const reports = get(powerBiData, "embedReports", []);
  //   const id = location.split("/")[3];
  //   let index = reports.findIndex((rep) => rep.id === id);
  //   setIndex(index);
  // }, [location]);

  // PowerBi Report Variables
  const REPORT_ID = "";
  const EMBED_URL = "";
  const EMBED_OR_ACCESS_TOKEN = "";

  // PowerBi Client Component Configs
  const EVENT_HANDLERS = new Map([
    [
      "loaded",
      function () {
        return "Report loaded";
      },
    ],
    [
      "rendered",
      function () {
        return "Report rendered";
      },
    ],
    [
      "error",
      function (event) {
        return event.detail;
      },
    ],
  ]);

  const EMBED_CONFIG = {
    type: "report", // Supported types: report, dashboard, tile, visual and qna
    id: get(powerBiData, `embedReports.${repIndex}.reportId`, REPORT_ID), // <Report Id>
    //<Embed Url>
    embedUrl: get(powerBiData, `embedReports.${repIndex}.embedUrl`, EMBED_URL),
    //<Access Token> or <Embed Token>
    accessToken: get(powerBiData, "embedToken", EMBED_OR_ACCESS_TOKEN),
    tokenType: models.TokenType.Embed,
    settings: {
      panes: {
        filters: {
          visible: false,
        },
        pageNavigation: {
          visible: true,
        },
      },
    },
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <PowerBIEmbed
          embedConfig={EMBED_CONFIG}
          eventHandlers={EVENT_HANDLERS}
          cssClassName={classes.powerBiReportContainer}
        />
      </Grid>
    </Grid>
  );
};

export default EmbeddedReport;
