import { useDispatch } from "react-redux";
import { claimsManagementExport } from "../../context/actions/ClaimsManagement";
import "jspdf-autotable";

const Export = () => {
  const dispatch = useDispatch();

  const exportClaims = (props) => {
    const {
      ceId,
      sortBy,
      sortOrder,
      patientDOB,
      capturedFromDate,
      capturedToDate,
      formikValues,
      defaultFilters,
      internalUser,
    } = props;

    dispatch(
      claimsManagementExport({
        ceID: internalUser ? [Number(formikValues.ceID)] : [Number(ceId)],
        entityLocationID: formikValues.locations.map((i) => i.entityLocationId),
        phGroupID: formikValues.pGroup.map((i) => i.phGroupId),
        phID: formikValues.pharmacy.map((i) => i.phid),
        sortBy: sortBy,
        sortOrder: sortOrder,
        mrn: formikValues.patientMRN.map((i) => i.mrn),
        patientDOB: patientDOB,
        rxNumber: formikValues.rxNumber.map((i) => i.rxNumber),
        status: formikValues.claimStatus.map((i) => i.claimStatus),
        claimTypeID: formikValues.claimType.map((i) => i.claimTypeId),
        reasonID: formikValues.falloutReason.map((i) => i.reasonID),
        binID: formikValues.BIN.map((i) => i.binID),
        savingsMin: formikValues.savingsMin,
        savingsMax: formikValues.savingsMax,
        providerNPI: formikValues.providerNPI,
        brandGenericTypeID: formikValues.brandType,
        ndc: formikValues.NDC,
        patientFirstName: formikValues.patientFirstName,
        patientLastName: formikValues.patientLastName,
        provider: formikValues.provider,
        capturedFromDate: capturedFromDate,
        capturedToDate: capturedToDate,
        dosFromDate: formikValues.dosFromDate,
        dosToDate: formikValues.dosToDate,
        filter: defaultFilters,
        patientInfo: formikValues.showPatientInformation,
        export: true,
        externalUser: !internalUser,
      })
    );
  };

  return { exportClaims };
};

export default Export;
