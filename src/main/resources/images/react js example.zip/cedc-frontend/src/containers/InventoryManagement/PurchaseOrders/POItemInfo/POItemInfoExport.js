import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { getPOInfoExport } from "../../../../context/actions/PurchaseOrders";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { notNull } from "../../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { PO_ITEM_INFO_EXPORT_FILE_NAME } from "../constants";
import { usePOStyles } from "../styles";

const POItemInfoExport = ({ po, controller, count, columnFilters }) => {
  const { poID, poItemID } = po || {};
  const dispatch = useDispatch();
  const classes = usePOStyles();
  const [values, setValues] = useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    FileSaver.saveAs(fileData, PO_ITEM_INFO_EXPORT_FILE_NAME + ".xlsx");
  };

  const ExportToPDF = (data) => {
    const headers = data.map((items) => {
      return {
        "NDC 11": Object.keys(items)[0],
        "Drug Name": Object.keys(items)[1],
        "Item Status": Object.keys(items)[2],
        "Ordered Qty": Object.keys(items)[3],
        "Acknowledged Qty": Object.keys(items)[4],
        "Invoiced Qty": Object.keys(items)[5],
        "Ordered Package Cost": Object.keys(items)[6],
        "Acknowledged Package Cost": Object.keys(items)[7],
        "Invoiced Package Cost": Object.keys(items)[8],
      };
    });
    const dataRows = data.map((i) => Object.values(i));
    return { headers, dataRows };
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
      getPOInfoExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          poItemID: poItemID,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              ndc,
              drugName,
              itemStatus,
              orderedQty,
              acknowledgedQty,
              invoicedQty,
              orderedPackageCost,
              acknowledgedPackageCost,
              invoicedPackageCost,
            }) => ({
              "NDC 11": notNull(ndc),
              "Drug Name": notNull(drugName),
              "Item Status": notNull(itemStatus),
              "Ordered Qty": notNull(orderedQty),
              "Acknowledged Qty": notNull(acknowledgedQty),
              "Invoiced Qty": notNull(invoicedQty),
              "Ordered Package Cost": notNull(orderedPackageCost),
              "Acknowledged Package Cost": notNull(acknowledgedPackageCost),
              "Invoiced Package Cost": notNull(invoicedPackageCost),
            })
          );
          if (e.target.value == "excel") {
            ExportToExcel(data);
            setValues("");
          }
          if (e.target.value == "pdf") {
            const { headers, dataRows } = ExportToPDF(data);
            const doc = new jsPDF();
            doc.autoTable({
              head: [headers[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...dataRows],
            });
            doc.save(`${PO_ITEM_INFO_EXPORT_FILE_NAME}.pdf`);
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset
        disabled={count > 0 ? false : true}
        className={classes.exportContainer}
      >
        <select
          className={classes.exportSelect}
          onChange={handleChange}
          value={values}
        >
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default POItemInfoExport;
