import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Grid, Button, FormLabel, Typography } from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import {
  savePatient,
  savePatientMessageUuid,
  getPatientSearchData,
  fetchSlidingScaleValues,
} from "../../../../context/actions/Patients";
import {
  addPatientPayload,
  fetchPatientDefaultValues,
  patientVisitPayload,
  validationMessages,
} from "../constant";
import { updateSectionStatus } from "../../../../context/actions/ConfigOverview";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import {
  POLLING_COUNT,
  SLIDING_SCALE_TEXT_ELLIPSIS_MAX_LENGTH,
  TEXT_ELLIPSIS_MAX_LENGTH,
} from "../../../../utils/constants";
import { CustomTextRenderer } from "../../../../components/common/CustomTextRenderer";
import AutoComplete from "../../../../components/common/AutoComplete";
import _isArray from "lodash/isArray";
const CashPlanConfig = (patientProps) => {
  const {
    setOpenPopup,
    submitActionType,
    formData,
    setFormData,
    viewPatient,
    editPatient,
    patientSearchData,
    defaultFilters,
    formRef,
    title,
    isVisitDateExist,
    isMRNExist,
    isSlidingScaleExist,
    setIsSlidingScaleExist,
  } = patientProps || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();

  const { records: patientVisitInfoList } = useSelector(
    (state) => state.getPatientInnerGrid
  );

  const [patientError, setPatientError] = useState(false);
  const [slidingScaleOptions, setSlidingScaleOptions] = useState([]);

  const formValidate = (values) => {
    const errors = {};
    if (values.slidingScale === "") {
      errors.slidingScale = "Please select the Sliding Scale Indicator";
    }
    if (values.newSlidingScale === "" && values.slidingScale === "Other") {
      setIsSlidingScaleExist("");
      errors.newSlidingScale = "Please enter the Sliding Scale Indicator";
    }
    if (isSlidingScaleExist && values.slidingScale === "Other") {
      errors.newSlidingScale =
        "This value already exists.Please enter a unique value.";
    }
    if (values.slidingScaleEffectiveDate === "") {
      errors.slidingScaleEffectiveDate =
        "Please select the Sliding Scale Effective Date";
    }
    return errors;
  };

  const handleSubmit = async (value) => {
    let error = false;
    if (
      !value.ceid ||
      value.firstName === "" ||
      value.lastName === "" ||
      value.mrn === "" ||
      value.dateOfBirth === "" ||
      value.gender === "" ||
      value.effectiveDate === "" ||
      (title === "Add Patient" && value.visitDate === "") ||
      isVisitDateExist !== "" ||
      isMRNExist !== ""
    )
      error = true;
    setFormData(value);
    setPatientError(error);
    if (!error) {
      const payload = {
        ...addPatientPayload(value),
        ...(editPatient && {
          personId: value.personId,
          patientVisitDTO: patientVisitPayload(patientVisitInfoList),
        }),
      };
      if (editPatient)
        payload.patientEligibilityDTO = {
          ...payload.patientEligibilityDTO,
          personEligibilityId: value.personEligibilityId,
        };
      const resp = await dispatch(savePatient(payload));
      if (!_isEmpty(resp) && resp.data) {
        handlePolling({ messageUUid: resp.data, currentCount: POLLING_COUNT });
      }
    }
  };

  const handlePolling = async ({ messageUUid, currentCount }) => {
    const count = currentCount;
    const resp = await dispatch(
      savePatientMessageUuid(messageUUid, count, editPatient)
    );
    if (resp && resp.statusCode === 200) {
      dispatch(
        updateSectionStatus({
          ceId: resp.data.patientDTO.ceid,
          sectionId: 8,
        })
      );
      setOpenPopup(false);
      fetchPatientsList();
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    }
  };

  const fetchPatientsList = (payload = {}) => {
    dispatch(
      getPatientSearchData(
        {
          ...fetchPatientDefaultValues(patientSearchData),
          ...payload,
          filter: defaultFilters || [],
        },
        false
      )
    );
  };

  const getSlidingScaleValues = async () => {
    const ceIdForSlicdingScale =
      formRef &&
      formRef.current &&
      formRef.current.values &&
      formRef.current.values.ceid;
    const slidingScales = await dispatch(
      fetchSlidingScaleValues(ceIdForSlicdingScale)
    );
    slidingScales && setSlidingScaleOptions(slidingScales);
  };

  useEffect(() => {
    getSlidingScaleValues();
  }, []);

  const handleSlidingScale = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    let { name, value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue(name, value);
    const slidingScaleExist =
      slidingScaleOptions &&
      slidingScaleOptions.some(({ slidingScale }) => {
        return slidingScale === value.trim();
      });
    setIsSlidingScaleExist(slidingScaleExist);
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={formData}
        validate={formValidate}
        onSubmit={handleSubmit}
        innerRef={formRef}
      >
        {({ values, errors, touched, setFieldValue }) => (
          <Grid container spacing={2}>
            <Grid item>
              <BasicTypography variant="h5" title="Cash Plan Configuration" />
              {patientError && (
                <Typography color="error" variant="caption">
                  {` ${validationMessages(values, title)}`}
                </Typography>
              )}
            </Grid>
            <Grid item xs={12}>
              <Form>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <FormLabel required>Sliding Scale Indicator</FormLabel>
                    {viewPatient ? (
                      slidingScaleOptions.map(({ slidingScale }) => {
                        return (
                          values.slidingScale === slidingScale && (
                            <CustomTextRenderer
                              value={slidingScale}
                              variant={"subtitle2"}
                              maxLength={SLIDING_SCALE_TEXT_ELLIPSIS_MAX_LENGTH}
                            />
                          )
                        );
                      })
                    ) : (
                      <Field as="select" name="slidingScale">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={
                              _isArray(slidingScaleOptions)
                                ? slidingScaleOptions
                                : []
                            }
                            inputPlaceholder={" Select Sliding Scale Indicator"}
                            disableCloseOnSelect={false}
                            onChange={(_e, value) => {
                              setFieldValue(
                                "slidingScale",
                                value ? value.slidingScale : ""
                              );
                            }}
                            value={
                              (_isArray(slidingScaleOptions) &&
                                slidingScaleOptions.find(
                                  (e) => e.slidingScale === values.slidingScale
                                )) ||
                              ""
                            }
                            getOptionLabel={(option) =>
                              option.slidingScale || ""
                            }
                            textFieldProps={{
                              inputProps: {
                                name: "slidingScale",
                              },
                            }}
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.slidingScale}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                          />
                        )}
                      </Field>
                    )}
                    {touched.slidingScale && errors.slidingScale && (
                      <Typography color="error" variant="caption">
                        {errors.slidingScale}
                      </Typography>
                    )}
                  </Grid>
                  {values.slidingScale === "Other" && (
                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Sliding Scale Indicator</FormLabel>
                      <Field
                        name="newSlidingScale"
                        value={values.newSlidingScale}
                        type="text"
                        maxLength={15}
                        className={globalClasses.formControl}
                        onChange={(e) => {
                          handleSlidingScale(e, setFieldValue);
                        }}
                        placeholder="Enter Sliding Scale Indicator"
                      />
                      {((touched.newSlidingScale && errors.newSlidingScale) ||
                        isSlidingScaleExist) && (
                        <Typography color="error" variant="caption">
                          {errors.newSlidingScale}
                        </Typography>
                      )}
                    </Grid>
                  )}
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Sliding Scale Effective Date</FormLabel>
                    {viewPatient ? (
                      <div>{values.slidingScaleEffectiveDate}</div>
                    ) : (
                      <Field as="select" name="slidingScaleEffectiveDate">
                        {({ field }) => (
                          <DatePicker
                            {...field}
                            onChange={(_e, date) => {
                              setFieldValue("slidingScaleEffectiveDate", date);
                            }}
                            value={
                              values && values.slidingScaleEffectiveDate
                                ? moment(
                                    values.slidingScaleEffectiveDate,
                                    "MM/DD/YYYY"
                                  )
                                : ""
                            }
                          />
                        )}
                      </Field>
                    )}
                    {touched.slidingScaleEffectiveDate &&
                      errors.slidingScaleEffectiveDate && (
                        <Typography color="error" variant="caption">
                          {errors.slidingScaleEffectiveDate}
                        </Typography>
                      )}
                  </Grid>
                  <Grid item md={12}>
                    <Grid container justifyContent="flex-end" spacing={2}>
                      {!viewPatient && (
                        <Grid item>
                          <Button
                            type="submit"
                            color="primary"
                            size="small"
                            variant="contained"
                            className={globalClasses.primaryBtn}
                          >
                            {submitActionType}
                          </Button>
                        </Grid>
                      )}
                      {!viewPatient && (
                        <Grid item>
                          <Button
                            type="reset"
                            size="small"
                            variant="outlined"
                            color="default"
                            className={globalClasses.secondaryBtn}
                            onClick={() => {
                              setOpenPopup(false);
                            }}
                          >
                            Cancel
                          </Button>
                        </Grid>
                      )}
                    </Grid>
                  </Grid>
                </Grid>
              </Form>
            </Grid>
          </Grid>
        )}
      </Formik>
    </>
  );
};

export default CashPlanConfig;
