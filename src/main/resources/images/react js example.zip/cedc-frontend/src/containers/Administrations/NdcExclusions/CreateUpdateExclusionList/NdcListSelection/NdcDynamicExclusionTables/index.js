import { Button, Grid } from "@material-ui/core";
import moment from "moment";
import React, {
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { BsChevronLeft, BsChevronRight } from "react-icons/bs";
import { useDispatch, useSelector } from "react-redux";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import {
  getAppliedNdcExclusions,
  getDynamicNdcExceptions,
  saveDynamicExclusionsAndExceptions,
} from "../../../../../../context/actions/NdcExclusions";
import {
  getExcludedData,
  getSelectedRows,
  getUserSession,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import { NdcContext } from "../../../NdcContext";
import EditNdcDates from "../../EditNdcDates";
import EditNdcDatesPopupFooter from "../../EditNdcDatesPopupFooter";
import NdcDetailsTable from "../DraftCreationTables/NdcDetailsTable";
import AppliedNdcExclusionsTable from "./AppliedNdcExclusionsTable";
import DynamicNdcExceptionsTable from "./DynamicNdcExceptionsTable";
import {
  getAppliedExclusionsSavePayload,
  getDynamicExceptionsSavePayload,
  getDynamicExclusionsMinDate,
} from "./helper";
import { useNdcDynamicExclusionTablesStyles } from "./styles";

const NdcDynamicExclusionTables = ({ handleClose, dlpRowData = {} }) => {
  const globalClasses = useGlobalStyles();
  const classes = useNdcDynamicExclusionTablesStyles();
  const userSession = getUserSession();
  const dispatch = useDispatch();
  const exclusionsTableRef = useRef(null);
  const exceptionsTableRef = useRef(null);
  const { ndcData, setDynamicParamsTb } = useContext(NdcContext) || {};
  const { startDate, endDate } = ndcData || {};
  const defaultFormValues = {
    startDate: startDate || "",
    endDate: endDate || "",
  };
  const { loading: ndcExclusionsTableLoading } =
    useSelector((state) => state.ndcDynamicExclusionTables) || {};

  const [ndcDetailsPopupData, setNdcDetailsPopupData] = useState({
    show: false,
    ndcData: {},
  });
  const [showEditNdcDatesPopup, setShowEditNdcDatesPopup] = useState({
    show: false,
    action: "",
  });
  const [appliedNdcExclusionsData, setAppliedNdcExclusionsData] = useState({
    content: [],
    totalElements: 0,
  });
  const [dynamicNdcExceptionsData, setDynamicNdcExceptionsData] = useState({
    content: [],
    totalElements: 0,
  });
  const [loading, setLoading] = useState(false);

  const isDynamicListTerminated = dlpRowData.dynamicListEffecEndDate
    ? moment(dlpRowData.dynamicListEffecEndDate).isSameOrBefore(moment(), "day")
    : false;

  useEffect(() => {
    fetchAppliedNdcExclusionsTableData();
    fetchDynamicExceptionsTableData();
  }, []);

  const fetchAppliedNdcExclusionsTableData = async () => {
    const payload = {
      pageNumber: 1,
      pageSize: 25,
      sortBy: "",
      sortOrder: "",
      filter: [],
      export: true,
      dynamicListId: dlpRowData.dynamicListId || 0,
    };
    const res = await dispatch(getAppliedNdcExclusions(payload));
    !isEmptyGrid(res) && setAppliedNdcExclusionsData(res);
  };

  const fetchDynamicExceptionsTableData = async () => {
    const payload = {
      pageNumber: 1,
      pageSize: 25,
      sortBy: "",
      sortOrder: "",
      filter: [],
      export: true,
      dynamicListId: dlpRowData.dynamicListId || 0,
    };
    const res = await dispatch(getDynamicNdcExceptions(payload));
    !isEmptyGrid(res) && setDynamicNdcExceptionsData(res);
  };

  const handleEditNdcDatesPopup = (state, action = "") => {
    if (state) {
      const leftSelectedRows = getSelectedRows(exclusionsTableRef);
      const rightSelectedRows = getSelectedRows(exceptionsTableRef);
      if (action === "add" && leftSelectedRows.length) {
        setShowEditNdcDatesPopup({ show: true, action });
      }
      if (action === "remove" && rightSelectedRows.length) {
        setShowEditNdcDatesPopup({ show: true, action });
      }
    } else {
      setShowEditNdcDatesPopup({ show: false });
    }
  };

  const handleAddToExceptions = (values = {}) => {
    const selectedExclusionRows = getSelectedRows(exclusionsTableRef);
    if (selectedExclusionRows.length) {
      const afterAddingDates = selectedExclusionRows.map((row) => ({
        ...row,
        ndcEffecStartDate: values.startDate || row.ndcEffecStartDate,
        ndcEffecEndDate: values.endDate || row.ndcEffecEndDate,
      }));
      const totalNdcExceptionsRows = [
        ...dynamicNdcExceptionsData.content,
        ...afterAddingDates,
      ];
      setDynamicNdcExceptionsData({
        content: totalNdcExceptionsRows,
        totalElements: totalNdcExceptionsRows.length,
      });
      const leftGridData = getExcludedData({
        originalList: appliedNdcExclusionsData.content,
        draftList: selectedExclusionRows,
        identifierKey: "id",
      });

      setAppliedNdcExclusionsData({
        content: leftGridData,
        totalElements: leftGridData.length,
      });
      setShowEditNdcDatesPopup({ show: false });
    }
  };

  const handleValidate = (values = {}) => {
    const error = {};
    if (!values.startDate) {
      error.startDate = "Please select the NDC Exception Start Date";
    }
    return error;
  };

  const handleRemoveFromException = (values = {}) => {
    const selectedNdcExceptionsRows = getSelectedRows(exceptionsTableRef);
    if (selectedNdcExceptionsRows.length) {
      const updatedRowData = getExcludedData({
        originalList: dynamicNdcExceptionsData.content,
        draftList: selectedNdcExceptionsRows,
        identifierKey: "id",
      });
      setDynamicNdcExceptionsData({
        content: updatedRowData,
        totalElements: updatedRowData.length,
      });
      const exclusionsAfterAddingDates = selectedNdcExceptionsRows.map(
        (row) => ({
          ...row,
          ndcEffecStartDate:
            values.startDate || dlpRowData.dynamicListEffecStartDate,
          ndcEffecEndDate: values.endDate || dlpRowData.dynamicListEffecEndDate,
        })
      );
      const originalAppliedExclusionsList = [
        ...appliedNdcExclusionsData.content,
        ...exclusionsAfterAddingDates,
      ];
      setAppliedNdcExclusionsData({
        content: originalAppliedExclusionsList,
        totalElements: originalAppliedExclusionsList.length,
      });
      setShowEditNdcDatesPopup({ show: false });
    }
  };

  const handleSaveDynamicExclusionsAndExceptions = async () => {
    setLoading(true);
    const payload = {
      createdById: userSession.userId,
      modifiedById: userSession.userId,
      dynamicListId: dlpRowData.dynamicListId || 0,
      listHistoryId: dlpRowData.listHistoryId || 0,
      appliedNdcExclusionDTOs: getAppliedExclusionsSavePayload({
        list: appliedNdcExclusionsData.content,
      }),
      ndcExceptionDTOs: getDynamicExceptionsSavePayload({
        list: dynamicNdcExceptionsData.content,
      }),
    };

    const res = await dispatch(
      saveDynamicExclusionsAndExceptions(payload, setLoading)
    );
    if (res) {
      setDynamicParamsTb(true);
      handleClose();
    }
  };

  const handleNdcDetailsPopup = useCallback(
    (prop = {}) =>
      () => {
        const { state = false, rowData = {} } = prop;
        setNdcDetailsPopupData({
          show: state,
          ndcData: rowData,
        });
      },
    []
  );

  const isSaveEnabled =
    appliedNdcExclusionsData.content.length > 0 ||
    dynamicNdcExceptionsData.content.length > 0
      ? true
      : false;

  return (
    <>
      {loading && <LoaderUI />}
      <Grid container spacing={2} justifyContent="space-between">
        <Grid item className={classes.gridTableContainer}>
          <div className={globalClasses.tableCardPrimary}>
            <AppliedNdcExclusionsTable
              appliedNdcExclusions={appliedNdcExclusionsData}
              loading={ndcExclusionsTableLoading}
              handleNdcDetailsPopup={handleNdcDetailsPopup}
              ref={exclusionsTableRef}
              isDynamicListTerminated={isDynamicListTerminated}
            />
          </div>
        </Grid>
        <Grid item className={classes.gridActionBtnContainer}>
          <Grid
            container
            spacing={2}
            direction="column"
            alignItems="center"
            className={classes.actionButtonContainer}
          >
            <Grid item>
              <Button
                endIcon={<BsChevronRight size={14} />}
                variant="contained"
                size="small"
                className={globalClasses.primaryBtn}
                onClick={() => handleEditNdcDatesPopup(true, "add")}
                disabled={isDynamicListTerminated}
              >
                Add
              </Button>
            </Grid>
            <Grid item>
              <Button
                startIcon={<BsChevronLeft size={14} />}
                variant="contained"
                size="small"
                className={globalClasses.redBtn}
                onClick={() => handleEditNdcDatesPopup(true, "remove")}
                disabled={isDynamicListTerminated}
              >
                Remove
              </Button>
            </Grid>
          </Grid>
        </Grid>
        <Grid item className={classes.gridTableContainer}>
          <div className={globalClasses.tableCardPrimary}>
            <DynamicNdcExceptionsTable
              dynamicNdcExceptions={dynamicNdcExceptionsData}
              handleNdcDetailsPopup={handleNdcDetailsPopup}
              ref={exceptionsTableRef}
              isDynamicListTerminated={isDynamicListTerminated}
            />
          </div>
        </Grid>
      </Grid>
      <Grid container spacing={2} justifyContent="flex-end">
        <Grid item>
          <Button
            type="button"
            size="small"
            variant="contained"
            className={globalClasses.primaryBtn}
            onClick={() => handleSaveDynamicExclusionsAndExceptions()}
            disabled={isDynamicListTerminated || !isSaveEnabled}
          >
            Save
          </Button>
        </Grid>
        <Grid item>
          <Button
            type="button"
            size="small"
            variant="contained"
            className={globalClasses.grayButton}
            onClick={handleClose}
          >
            Cancel
          </Button>
        </Grid>
      </Grid>
      <BasicPopup
        title={
          showEditNdcDatesPopup.action === "remove"
            ? "NDC Effective Date"
            : "NDC Exception Date"
        }
        show={showEditNdcDatesPopup.show}
        disableFooter={true}
        isCustomFooter={true}
        footerActionElement={
          <EditNdcDatesPopupFooter
            handleEditNdcDatesPopup={handleEditNdcDatesPopup}
          />
        }
        dialogProps={{
          maxWidth: "md",
        }}
        withFormik={true}
        formikProps={{
          initialValues: defaultFormValues,
          onSubmit: (values) => {
            showEditNdcDatesPopup.action === "add"
              ? handleAddToExceptions(values)
              : handleRemoveFromException(values);
          },
          validate: handleValidate,
        }}
        handleClose={() => handleEditNdcDatesPopup(false)}
      >
        <EditNdcDates
          startDateProps={{
            minDate:
              showEditNdcDatesPopup.action === "remove"
                ? moment()
                : getDynamicExclusionsMinDate(
                    getSelectedRows(exclusionsTableRef)
                  ) || moment(),
            label:
              showEditNdcDatesPopup.action === "remove"
                ? "NDC Effective Start Date"
                : "NDC Exception Start Date",
          }}
          endDateProps={{
            label:
              showEditNdcDatesPopup.action === "remove"
                ? "NDC Effective End Date"
                : "NDC Exception End Date",
            maxDate:
              showEditNdcDatesPopup.action === "remove"
                ? dlpRowData.dynamicListEffecEndDate
                : "",
          }}
          selectedRows={getSelectedRows(
            showEditNdcDatesPopup.action === "remove"
              ? exceptionsTableRef
              : exclusionsTableRef
          )}
        />
      </BasicPopup>
      <BasicPopup
        title="NDC History"
        show={ndcDetailsPopupData.show}
        disableFooter={true}
        dialogProps={{
          maxWidth: "md",
        }}
        handleClose={handleNdcDetailsPopup({ state: false })}
      >
        <NdcDetailsTable ndcDetailsRowData={ndcDetailsPopupData.ndcData} />
      </BasicPopup>
    </>
  );
};

export default NdcDynamicExclusionTables;
