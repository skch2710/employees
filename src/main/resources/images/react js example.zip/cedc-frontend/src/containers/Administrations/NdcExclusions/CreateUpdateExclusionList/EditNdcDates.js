import React, { memo } from "react";
import { FormLabel, Grid } from "@material-ui/core";
import { Field, useFormikContext } from "formik";
import moment from "moment";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import DatePicker from "../../../../components/common/DatePicker";
import { startDateValidation } from "../../../../utils/common";

const EditNdcDates = memo((props = {}) => {
  const { selectedRows, startDateProps = {}, endDateProps = {} } = props;
  const { values, setFieldValue, errors, touched } = useFormikContext();
  const {
    minDate: startMinDate,
    maxDate: startMaxDate,
    label: startDateLabel,
  } = startDateProps || {};
  const {
    minDate: endMinDate,
    maxDate: endMaxDate,
    label: endDateLabel,
  } = endDateProps || {};

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="h4">{`${selectedRows.length} NDC's selected`}</BasicTypography>
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item md={4}>
            <FormLabel required>
              {startDateLabel || "NDC Effective Start Date"}
            </FormLabel>
            <Field as="select" name="startDate">
              {({ field }) => (
                <DatePicker
                  {...field}
                  onChange={(_e, date) => {
                    setFieldValue("startDate", date);
                  }}
                  value={
                    values.startDate
                      ? moment(values.startDate, "MM/DD/YYYY")
                      : ""
                  }
                  disabledDate={(d) =>
                    !d ||
                    (startMinDate && !d.isSameOrAfter(startMinDate, "day")) ||
                    startDateValidation(d, values.endDate) ||
                    (startMaxDate && !d.isSameOrBefore(startMaxDate, "day"))
                  }
                />
              )}
            </Field>
            {errors.startDate && touched.startDate && (
              <BasicTypography color="error" variant="caption">
                {errors.startDate}
              </BasicTypography>
            )}
          </Grid>
          <Grid item md={4}>
            <FormLabel>{endDateLabel || "NDC Effective End Date"}</FormLabel>
            <Field as="select" name="endDate">
              {({ field }) => (
                <DatePicker
                  {...field}
                  onChange={(_e, date) => {
                    setFieldValue("endDate", date);
                  }}
                  value={
                    values.endDate ? moment(values.endDate, "MM/DD/YYYY") : ""
                  }
                  disabledDate={(d) =>
                    !d ||
                    (endMinDate && !d.isAfter(endMinDate, "day")) ||
                    (values.startDate && !d.isAfter(values.startDate, "day")) ||
                    (endMaxDate && !d.isBefore(endMaxDate, "day"))
                  }
                />
              )}
            </Field>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
});

export default EditNdcDates;
