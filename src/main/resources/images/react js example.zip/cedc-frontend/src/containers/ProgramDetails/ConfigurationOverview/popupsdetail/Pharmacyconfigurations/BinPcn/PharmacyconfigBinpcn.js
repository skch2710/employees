import React, { useContext } from "react";
import { Grid, Switch, Button } from "@material-ui/core";
import { Formik, Field } from "formik";
import HeaderTitle from "../../../../../../components/common/Typography/HeaderTitle";
import Globalbin from "../../EntityDetails/Binpcn/Globalbin";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";

const PharmacyconfigBinpcn = () => {
  const { setPopupActiveMenu, setOpenAddCePopup } = useContext(COContext);

  return (
    <Formik enableReinitialize={true} initialValues="" onSubmit="">
      {() => (
        <>
          <Grid>
            <HeaderTitle
              variant="h1"
              title="Covered Entity Configuration > BIN/PCN Configuration"
            />
          </Grid>
          <Grid className="applyglobalbins">
            {" "}
            <Field
              label="Entity Details/BIN/PCN Configuration"
              name="la"
              component={Switch}
              type="checkbox"
              checked="true"
              // onChange={(e)=>setLocationToggle(e.target.checked)}
              size="small"
              color="primary"
            />
            <label>Apply Global Bin Blocks</label>{" "}
          </Grid>

          <Grid>
            {" "}
            <Globalbin />{" "}
          </Grid>

          <Grid
            xs={12}
            container
            justifyContent="flex-end"
            style={{ padding: "12px" }}
          >
            <Button
              type="submit"
              color="primary"
              size="small"
              variant="contained"
              className="btn btn-primary text-capitalize"
              onClick={() => {
                setPopupActiveMenu(MENUS.CE_BASIC_DETAILS);
              }}
            >
              Next
            </Button>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className="btn btn-secondary m-l-20 text-capitalize"
              onClick={() => {
                // setOpenPopup(false);
              }}
            >
              Skip
            </Button>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className="btn btn-secondary m-l-20 text-capitalize"
              onClick={() => {
                // setOpenPopup(false);
              }}
            >
              Save
            </Button>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className="btn btn-secondary m-l-20 text-capitalize"
              onClick={() => {
                setOpenAddCePopup(false);
              }}
            >
              Cancel
            </Button>
          </Grid>
        </>
      )}
    </Formik>
  );
};

export default PharmacyconfigBinpcn;
