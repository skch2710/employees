import React, { lazy, useState, useEffect, useContext, Suspense } from "react";
import { useDispatch } from "react-redux";
import { Grid } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import PreferredUser from "../../UserManagement/PreferredUser";
import {
  getPhSectionStatus,
  getSectionStatusByCEID,
} from "../../../context/actions/ConfigOverview";
import ProgressBar from "./Progressbar/Progressbar.js";
import Notabletoaccess from "./popupsdetail/NotAbleToAccess";
import LoaderUI from "../../../components/common/Loader/Loader";
import { getUserPreveleges } from "../../../utils/common";
import PopupSidebar from "./PopupSidebar";
import {
  getFirstIncompleteSection,
  getUpdatedPhSectionStatus,
  getUpdatedSectionStatus,
} from "./helper";
import { COContext } from "../COContext";
import { MENUS, MENUS_ID_TO_NAME } from "./PopupSidebar/constants";
import { useAddCEStyles } from "./styles";
import BasicPopup from "../../../components/Popup/BasicPopup";
import { PrimaryContactdetails } from "../../../context/actions/CoCebasicdetails";
import { getCOBasicDetails } from "../../../context/actions/ConfigOverview";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../utils/helper";
import { getBillingFeeContacts } from "../../../context/actions/ConfigOverview/EntityConfiguration/CeBillingAndFees";
import {
  MODULE_PERMISSIONS_REMOVED_MESSAGE,
  pagination,
} from "../../../utils/constants";

const BasicDetails = lazy(() =>
  import("./popupsdetail/EntityDetails/CEBasicDetails/BasicDetails")
);
const CeBillingAndFees = lazy(() =>
  import("./popupsdetail/EntityDetails/Billingandfees")
);
const CeAchConfiguration = lazy(() =>
  import("./popupsdetail/EntityDetails/ACHConfiguration")
);
const CeEligibilityRules = lazy(() =>
  import("./popupsdetail/EntityDetails/CeEligibilityRules")
);
const Binandpcndata = lazy(() =>
  import("./popupsdetail/EntityDetails/Binpcn/Binandpcn")
);
const Locations = lazy(() =>
  import("./popupsdetail/CEConfiguration/CeLocations/Locations")
);
const CEProviders = lazy(() =>
  import("./popupsdetail/CEConfiguration/CEProviders/CEProviders")
);
const Members = lazy(() =>
  import("./popupsdetail/CEConfiguration/MemberConfigurations/Members")
);
const Servicearea = lazy(() =>
  import("./popupsdetail/CEConfiguration/ServiceArea/Servicearea")
);
const Visitwindow = lazy(() =>
  import("./popupsdetail/CEConfiguration/CEvisitwindow/Visitwindow")
);
const ViewPharmacies = lazy(() =>
  import("./popupsdetail/Pharmacyconfigurations/ViewPharmacies/ViewPharmacies")
);
const PharmacyBasicDetails = lazy(() =>
  import(
    "./popupsdetail/Pharmacyconfigurations/PharmacyBasicDetails/PharmacyBasicDetails"
  )
);
const PhBillingAndFees = lazy(() =>
  import("./popupsdetail/Pharmacyconfigurations/PhBillingAndFees")
);
const PharmacyEligibility = lazy(() =>
  import(
    "./popupsdetail/Pharmacyconfigurations/PhEligibility/PharmacyEligibility"
  )
);
const OrderingAndReplenishment = lazy(() =>
  import(
    "./popupsdetail/Pharmacyconfigurations/OrderingAndReplenishment/OrderingAndReplenishment"
  )
);
const PharmacyconfigBinpcn = lazy(() =>
  import("./popupsdetail/Pharmacyconfigurations/BinPcn/PharmacyconfigBinpcn")
);

const CeOrderingConfiguration = lazy(() =>
  import("./popupsdetail/EntityDetails/CeOrderingConfiguration")
);

const AddCoveredEntity = ({ clickOnAdd, setclickOnAdd }) => {
  const dispatch = useDispatch();
  const classes = useAddCEStyles();
  const {
    openAddCePopup,
    currentPharmacy,
    setMenusStatuses,
    popupActiveMenu,
    openAddUserPopup,
    setOpenAddUserPopup,
    messageUuid,
    ceId,
    ceConfigStatusPercent,
    setCeConfigStatusPercent,
    phConfigStatusPercent,
    setPopupActiveMenu,
    clickedOnPartial,
    setPhConfigSectionStatus,
    setPhConfigStatusPercent,
    fetchCeSectionStatuses,
    fetchPhSectionStatuses,
  } = useContext(COContext) || {};
  const userSession = getUserSession();
  const isInternalUser = userSession.isInternalUser;
  const pharmacyReadWritePermission =
    getUserPermissionOnModuleName("Pharmacies").readWriteFlag;
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};

  const [achpermissionObj, setachpermissionObj] = useState(null);
  const [locatPermissionObj, setLocatPermissionObj] = useState({});
  const [providerPermissionObj, setProviderPermissionObj] = useState(null);
  const [patpermissionObj, setpatpermissionObj] = useState(null);
  const [basicDetailsGetData, setBasicDetailsGetData] = useState(null);
  const [primaryState, setPrimarystate] = useState(false);

  const [basicDetailsAndContactsGetData, setBasicDetailsAndContactsGetData] =
    useState(null);

  const handleAddUserPopUp = (value) => {
    setOpenAddUserPopup(value);
    fetchBasicDetails();
  };

  const handleUserAdd = (_user) => {
    dispatch(
      getBillingFeeContacts({
        ceid: !_isEmpty(messageUuid) ? messageUuid.ceid : ceId,
        pageNumber: 1,
        pageSize: pagination.billingLimit,
        sortBy: "userId",
        sortOrder: "desc",
        filter: [],
        export: false,
      })
    );
  };

  const fetchBasicDetails = async () => {
    const payload = {
      ceID: ceId,
    };
    const basicDetails = await dispatch(getCOBasicDetails(payload));
    const primaryContact = await dispatch(PrimaryContactdetails(ceId));
    if (primaryContact) {
      setPrimarystate(true);
    } else {
      setPrimarystate(false);
    }
    const res = { ...basicDetails, ...primaryContact };
    if (res) setBasicDetailsAndContactsGetData(setBasicDetailsGetData(res));
  };

  useEffect(() => {
    setachpermissionObj(getUserPreveleges("ACH Configuration"));
    setLocatPermissionObj(getUserPreveleges("Covered Entity Locations"));
    setProviderPermissionObj(getUserPreveleges("Providers"));
    setpatpermissionObj(getUserPreveleges("Patients"));

    if (ceId && popupActiveMenu < MENUS.PH_VIEW_PHARMACIES) {
      fetchCeSectionStatuses({ ceId, shouldNavigate: clickedOnPartial });
    } else if (!_isEmpty(currentPharmacy)) {
      fetchPhSectionStatuses({
        ceId,
        clientId: currentPharmacy.clientId,
        shouldNavigate: clickedOnPartial,
      });
    }
  }, []);

  return (
    <>
      <Grid container spacing={1}>
        <Grid item xs={12} sm={12}>
          <ProgressBar
            progressBarValue={
              popupActiveMenu > 10
                ? phConfigStatusPercent
                : ceConfigStatusPercent
            }
          />
        </Grid>
        <Grid item xs={12} sm={12}>
          <Grid container spacing={4}>
            <Grid item xs={2} md={3}>
              <PopupSidebar />
            </Grid>
            <Grid item xs={10} md={9}>
              <div className={classes.content}>
                <Suspense fallback={<LoaderUI />}>
                  {isInternalUser ? (
                    <>
                      {popupActiveMenu === MENUS.CE_BASIC_DETAILS && (
                        <BasicDetails
                          basicDetailsGetData={basicDetailsGetData}
                          setclickOnAdd={setclickOnAdd}
                          clickOnAdd={clickOnAdd}
                          primaryState={primaryState}
                          setPrimarystate={setPrimarystate}
                        />
                      )}

                      {popupActiveMenu > MENUS.CE_BASIC_DETAILS &&
                        messageUuid === false && <Notabletoaccess />}

                      {popupActiveMenu === MENUS.CE_BILLING_AND_FEES &&
                        messageUuid !== false && (
                          <CeBillingAndFees clickOnAdd={clickOnAdd} />
                        )}

                      {popupActiveMenu === MENUS.CE_ACH_CONFIGURATION &&
                        messageUuid !== false &&
                        (achpermissionObj !== null &&
                        !achpermissionObj.readOnlyFlag ? (
                          <Notabletoaccess
                            text={MODULE_PERMISSIONS_REMOVED_MESSAGE}
                          />
                        ) : (
                          <CeAchConfiguration clickOnAdd={clickOnAdd} />
                        ))}

                      {popupActiveMenu === MENUS.CE_ELIGIBILITY &&
                        messageUuid !== false && (
                          <CeEligibilityRules clickOnAdd={clickOnAdd} />
                        )}

                      {popupActiveMenu === MENUS.CE_ORDERING_CONFIGURATION &&
                        messageUuid !== false && (
                          <CeOrderingConfiguration isFromWizard={true} />
                        )}

                      {popupActiveMenu === MENUS.CE_BIN_PCN &&
                        messageUuid !== false && (
                          <Binandpcndata
                            ciId={ceId}
                            messageUiid={messageUuid}
                          />
                        )}

                      {popupActiveMenu === MENUS.CE_LOCATIONS &&
                        messageUuid !== false &&
                        (locatPermissionObj !== null &&
                        !locatPermissionObj.readOnlyFlag ? (
                          <Notabletoaccess text="You do not have the access to configure this section." />
                        ) : (
                          <Locations
                            locatPermissionObj={locatPermissionObj}
                            isConfigOverview={true}
                            clickOnAdd={clickOnAdd}
                          />
                        ))}

                      {popupActiveMenu === MENUS.CE_PROVIDERS &&
                        messageUuid !== false &&
                        (providerPermissionObj !== null &&
                        !providerPermissionObj.readOnlyFlag ? (
                          <Notabletoaccess text="You do not have the access to configure this section." />
                        ) : (
                          <CEProviders
                            ciId={ceId}
                            providerPermissionObj={providerPermissionObj}
                            permissionObj={coPermissions}
                            clickOnAdd={clickOnAdd}
                          />
                        ))}

                      {popupActiveMenu === MENUS.CE_MEMBERS &&
                        messageUuid !== false &&
                        (patpermissionObj !== null &&
                        !patpermissionObj.readOnlyFlag ? (
                          <Notabletoaccess text="You do not have the access to configure this section." />
                        ) : (
                          <Members
                            patpermissionObj={patpermissionObj}
                            ciId={ceId}
                            permissionObj={coPermissions}
                            clickOnAdd={clickOnAdd}
                          />
                        ))}

                      {popupActiveMenu === MENUS.CE_SERVICE_AREA &&
                        messageUuid !== false && (
                          <Servicearea
                            messageUiid={messageUuid}
                            clickOnAdd={clickOnAdd}
                          />
                        )}

                      {popupActiveMenu === MENUS.CE_VISIT_WINDOW &&
                        messageUuid !== false && (
                          <Visitwindow
                            value={false}
                            messageUiid={messageUuid}
                            clickOnAdd={clickOnAdd}
                          />
                        )}
                    </>
                  ) : (
                    popupActiveMenu < MENUS.PH_BASIC_DETAILS && (
                      <Notabletoaccess text="You do not have the access to configure this section." />
                    )
                  )}

                  {messageUuid &&
                  popupActiveMenu > MENUS.PH_BASIC_DETAILS &&
                  popupActiveMenu <= MENUS.PH_BIN_PCN &&
                  _isEmpty(currentPharmacy) &&
                  pharmacyReadWritePermission ? (
                    <Notabletoaccess />
                  ) : null}

                  {popupActiveMenu === MENUS.PH_VIEW_PHARMACIES &&
                    messageUuid !== false &&
                    isInternalUser && <ViewPharmacies />}

                  {isInternalUser && pharmacyReadWritePermission ? (
                    <>
                      {popupActiveMenu === MENUS.PH_BASIC_DETAILS &&
                        messageUuid !== false && <PharmacyBasicDetails />}
                      {popupActiveMenu === MENUS.PH_BILLING_AND_FEES &&
                        !_isEmpty(currentPharmacy) && <PhBillingAndFees />}
                      {popupActiveMenu === MENUS.PH_ELIGIBILITY &&
                        !_isEmpty(currentPharmacy) && <PharmacyEligibility />}
                      {popupActiveMenu ===
                        MENUS.PH_ORDERING_AND_REPLENISHMENT &&
                        !_isEmpty(currentPharmacy) && (
                          <OrderingAndReplenishment />
                        )}
                      {popupActiveMenu === MENUS.PH_BIN_PCN &&
                        !_isEmpty(currentPharmacy) && <PharmacyconfigBinpcn />}
                    </>
                  ) : pharmacyReadWritePermission ? (
                    popupActiveMenu > MENUS.PH_BASIC_DETAILS && (
                      <Notabletoaccess text="You do not have the access to configure this section." />
                    )
                  ) : isInternalUser ? (
                    popupActiveMenu > MENUS.PH_VIEW_PHARMACIES && (
                      <Notabletoaccess text="You do not have the access to configure this section." />
                    )
                  ) : (
                    popupActiveMenu > MENUS.PH_BASIC_DETAILS && (
                      <Notabletoaccess text="You do not have the access to configure this section." />
                    )
                  )}
                </Suspense>
              </div>
            </Grid>

            <BasicPopup
              title="Add User"
              show={openAddUserPopup}
              handleClose={() => {
                setOpenAddUserPopup(false);
              }}
              disableFooter={true}
              dialogProps={{
                maxWidth: "lg",
                classes: {
                  paper: classes.dialogPaper,
                },
              }}
            >
              <PreferredUser
                Co={true}
                messageUiid={messageUuid}
                setAddUserPopupOfCo={handleAddUserPopUp}
                primaryState={primaryState}
                setPrimarystate={setPrimarystate}
                ciId={ceId}
                onUserAdd={handleUserAdd}
              />
            </BasicPopup>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default AddCoveredEntity;
