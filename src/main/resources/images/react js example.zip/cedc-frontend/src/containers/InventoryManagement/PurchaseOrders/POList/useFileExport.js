import FileSaver from "file-saver";
import moment from "moment";
import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import { getPurchaseListExport } from "../../../../context/actions/PurchaseOrders";
import { LABELS, notNull } from "../../../../utils/constants";
import { PO_ORDER_EXPORT_FILE_NAME, getPOListPayload } from "../constants";
import { getScheduleTypeIds, getTodayDatePayload } from "../helper";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const {
      poControllers,
      columnFilters,
      formSubmittedValues: payload,
    } = props;

    const { poDateFilter, drugDEAClassID } = payload;
    const payloadJson = {
      ...getPOListPayload(payload),
      ...getTodayDatePayload(poDateFilter),
      ...getScheduleTypeIds(drugDEAClassID),
    };

    dispatch(
      getPurchaseListExport(
        {
          ...payloadJson,
          sortBy: poControllers.sortBy,
          sortOrder: poControllers.sortOrder,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data =
            result.content &&
            result.content.map(
              ({
                poID,
                poDate,
                pharmacy,
                wholesalerAccountID,
                poStatus,
                totalOrderAmount,
                totalBilledAmount,
                wholesaler,
              }) => ({
                "PO#": notNull(poID),
                "PO Date": notNull(poDate),
                [LABELS.PharmacyStore]: notNull(pharmacy),
                "Wholesaler Account Number": notNull(wholesalerAccountID),
                "Wholesaler Name": notNull(wholesaler),
                "PO Status": notNull(poStatus),
                "PO Total Order Amount": notNull(totalOrderAmount),
                "PO Total Billed Amount": notNull(totalBilledAmount),
              })
            );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, PO_ORDER_EXPORT_FILE_NAME + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
