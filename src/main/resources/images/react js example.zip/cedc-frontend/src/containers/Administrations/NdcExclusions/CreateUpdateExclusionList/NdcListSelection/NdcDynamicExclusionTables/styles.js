import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../../../utils/helper";

export const useNdcDynamicExclusionTablesStyles = makeStyles((_theme) => ({
  actionButtonContainer: {
    paddingTop: "70px",
  },
  gridTableContainer: {
    width: "43%",
  },
  gridActionBtnContainer: {
    width: "12%",
  },
}));