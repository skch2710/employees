import React from "react";
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  Typography,
  DialogActions,
  IconButton,
} from "@material-ui/core";
import { IoIosCloseCircleOutline } from "react-icons/io";

const ErrorFileDiscardPopupBody = (props) => {
  const { showPrompt, handleClose, handleCancel, handleOK } = props;

  return (
    <Dialog open={showPrompt} style={{ height: "600px" }}>
      <DialogTitle>
        <div style={{ display: "flex" }}>
          <Typography variant="body2" component="div" style={{ flexGrow: 1 }}>
            Error File Discard Warning
          </Typography>
          <IconButton onClick={handleClose} size="small">
            <IoIosCloseCircleOutline />
          </IconButton>
        </div>
      </DialogTitle>

      <DialogContent dividers>
        <Typography variant="body2" component="div">
          Please view the error file before navigating to a different screen.
          Else, the error file will no longer be available
        </Typography>
      </DialogContent>
      <DialogActions style={{ padding: "16px 24px" }}>
        <Button
          type="submit"
          color="primary"
          size="small"
          variant="contained"
          onClick={handleCancel}
          className="btn btn-primary text-capitalize"
        >
          View Errors
        </Button>
        <Button
          type="submit"
          color="primary"
          size="small"
          variant="contained"
          onClick={handleOK}
          className="btn btn-secondary m-l-20 text-capitalize"
        >
          Cancel Errors
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ErrorFileDiscardPopupBody;
