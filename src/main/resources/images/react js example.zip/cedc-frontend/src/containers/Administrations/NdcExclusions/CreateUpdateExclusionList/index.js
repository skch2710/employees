import { Grid, Tab, Tabs } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import React, { useContext, useEffect } from "react";
import { useDispatch } from "react-redux";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import HorizontalProgressBar from "../../../../components/common/HorizontalProgressBar";
import { TabPanel, a11yProps } from "../../../../components/common/Tabs";
import { fetchNdcSectionStatus } from "../../../../context/actions/NdcExclusions";
import { getFirstIncompleteSection } from "../../../../utils/helper";
import { NdcContext } from "../NdcContext";
import { NDC_TABS } from "../constants";
import NdcListApplication from "./NdcListApplication";
import NdcListBasicDetails from "./NdcListBasicDetails";
import NdcListReview from "./NdcListReview";
import NdcListSelection from "./NdcListSelection";
import { useNdcCreateStyles } from "./styles";

const CreateUpdateExclusionList = () => {
  const {
    progress,
    activeNdcConfigTab,
    setActiveNdcConfigTab,
    activeInactiveTabs,
    setNdcSelectionBulkUploadReport,
    ndcSelectionBulkUploadReport,
    setProgress,
    setActiveInactiveTabs,
    ndcData,
  } = useContext(NdcContext) || {};
  const dispatch = useDispatch();
  const classes = useNdcCreateStyles();
  const globalClasses = useGlobalStyles();
  const { bulkUploaded = false, confirmBulkUploaded = false } =
    ndcSelectionBulkUploadReport;

  const handleChangeTab = (_e, newValue) => {
    if (
      bulkUploaded &&
      activeNdcConfigTab === NDC_TABS.NDC_SELECTION &&
      !confirmBulkUploaded
    ) {
      setNdcSelectionBulkUploadReport({
        ...ndcSelectionBulkUploadReport,
        confirmBulkUploaded: true,
      });
      return;
    }
    setActiveNdcConfigTab(newValue);
  };

  useEffect(() => {
    const element = document.getElementById("content");
    if (!_isEmpty(element)) {
      element.scrollIntoView(true);
    }
  }, [activeNdcConfigTab]);

  const getNdcSectionStatus = async (listId) => {
    const res = await dispatch(fetchNdcSectionStatus(listId));
    if (!_isEmpty(res)) {
      setProgress(res);
      const firstInCompleteTab =
        getFirstIncompleteSection(res.ndcSectionStatus) || {};
      const tabsStatusObj = {
        [NDC_TABS.NDC_SELECTION]:
          NDC_TABS.NDC_SELECTION > firstInCompleteTab.sectionId ? false : true,
        [NDC_TABS.NDC_LIST_APPLICATION]:
          NDC_TABS.NDC_LIST_APPLICATION > firstInCompleteTab.sectionId
            ? false
            : true,
        [NDC_TABS.NDC_LIST_REVIEW]:
          NDC_TABS.NDC_LIST_REVIEW > firstInCompleteTab.sectionId
            ? false
            : true,
      };
      setActiveInactiveTabs((prev) => ({ ...prev, ...tabsStatusObj }));
    }
  };

  useEffect(() => {
    if (!_isEmpty(ndcData) && !ndcData.isCopy) {
      getNdcSectionStatus(ndcData.listId);
    }
  }, []);

  return (
    <Grid container spacing={2} direction="column" id="content">
      <Grid item>
        <HorizontalProgressBar
          value={progress.configPercentage || 0}
          showValueOnTooltip
        />
      </Grid>
      <Grid item md>
        <Grid container spacing={2} direction="column">
          <Grid item>
            <Tabs
              value={activeNdcConfigTab}
              onChange={handleChangeTab}
              indicatorColor="primary"
              classes={{
                indicator: classes.tabsIndicator,
                flexContainer: classes.tabsContainer,
              }}
            >
              <Tab
                label="NDC List Basic Details"
                value={NDC_TABS.NDC_BASIC_DETAILS}
                disabled={!activeInactiveTabs[NDC_TABS.NDC_BASIC_DETAILS]}
                classes={{
                  root: classes.tabsLabel,
                  selected: classes.selectedTab,
                  disabled: classes.disabledTab,
                }}
                {...a11yProps(NDC_TABS.NDC_BASIC_DETAILS)}
              />
              <Tab
                label="NDC Selection"
                value={NDC_TABS.NDC_SELECTION}
                disabled={!activeInactiveTabs[NDC_TABS.NDC_SELECTION]}
                classes={{
                  root: classes.tabsLabel,
                  selected: classes.selectedTab,
                  disabled: classes.disabledTab,
                }}
                {...a11yProps(NDC_TABS.NDC_SELECTION)}
              />
              <Tab
                label="NDC List Application"
                value={NDC_TABS.NDC_LIST_APPLICATION}
                disabled={!activeInactiveTabs[NDC_TABS.NDC_LIST_APPLICATION]}
                classes={{
                  root: classes.tabsLabel,
                  selected: classes.selectedTab,
                  disabled: classes.disabledTab,
                }}
                {...a11yProps(NDC_TABS.NDC_LIST_APPLICATION)}
              />
              <Tab
                label="NDC List Review"
                value={NDC_TABS.NDC_LIST_REVIEW}
                disabled={!activeInactiveTabs[NDC_TABS.NDC_LIST_REVIEW]}
                classes={{
                  root: classes.tabsLabel,
                  selected: classes.selectedTab,
                  disabled: classes.disabledTab,
                }}
                {...a11yProps(NDC_TABS.NDC_LIST_REVIEW)}
              />
            </Tabs>
          </Grid>
          <Grid item md>
            <div className={classes.tabPanelContainer}>
              <TabPanel
                value={activeNdcConfigTab}
                index={NDC_TABS.NDC_BASIC_DETAILS}
                className={globalClasses.fullHeight}
              >
                <NdcListBasicDetails />
              </TabPanel>
              <TabPanel
                value={activeNdcConfigTab}
                index={NDC_TABS.NDC_SELECTION}
                className={globalClasses.fullHeight}
              >
                <NdcListSelection />
              </TabPanel>
              <TabPanel
                value={activeNdcConfigTab}
                index={NDC_TABS.NDC_LIST_APPLICATION}
                className={globalClasses.fullHeight}
              >
                <NdcListApplication />
              </TabPanel>
              <TabPanel
                value={activeNdcConfigTab}
                index={NDC_TABS.NDC_LIST_REVIEW}
                className={globalClasses.fullHeight}
              >
                <NdcListReview />
              </TabPanel>
            </div>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default CreateUpdateExclusionList;
