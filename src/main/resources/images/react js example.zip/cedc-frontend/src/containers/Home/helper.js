export const getOppByPhFiltersObject = (filters) => {
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: "startWith",
      value: filter.value,
    };
  });
};

export const getUnrepInvFiltersObj = (filters) => {
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: "startWith",
      value: filter.value,
    };
  });
};