import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../../utils/helper";

export const useOPALocationsTablesStyles = makeStyles((theme) => ({
  muiToolbar: (props) => {
    return {
      marginRight: getGridActionButtonsMarginRight(props),
      marginTop: "-38px",
      marginBottom: "6px",
      paddingLeft: "6px",
      minHeight: "30px",
    };
  },
  actionButtonContainer: {
    paddingTop: "110px",
  },
  gridTableContainer: {
    width: "45%",
  },
  gridActionBtnContainer: {
    width: "10%",
  },
  dialogTitle:{
    background:theme.colors.pink.bg
  },
  uploadSuccess: {
    margin: "0 8px",
    color: theme.colors.green[400],
    display: "flex",
    alignItems: "center",
    columnGap: "5px",
    "& > p": {
      margin: 0,
      fontWeight:600,
      fontSize:"12px"
    },
    "& img": {
      width: "14px",
      height: "14px",
    },
  },
  successContainer: {
    display: "flex",
    alignItems: "center",
    columnGap: "10px",
  },

  accuracySubTitle: {
    display: "flex",
    flexDirection:"column",
    gap: "5px",
  },
  addressMargin:{
    marginLeft:"8px"
  }
}));

export const useNdcDetailsTablesStyles = makeStyles((_theme) => ({
  muiToolbar: (props) => {
    return {
      marginRight: getGridActionButtonsMarginRight(props),
      marginTop: "-38px",
      marginBottom: "6px",
      paddingLeft: "6px",
      minHeight: "30px",
    };
  },
}));
