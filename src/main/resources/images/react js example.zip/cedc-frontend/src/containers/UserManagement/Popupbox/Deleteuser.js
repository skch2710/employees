import React from 'react';
import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
import {Typography } from '@material-ui/core';


const Deleteuser = ({sendname}) => {

  return (
    <div >   
     <Typography variant="h6" align="center"> <DeleteOutlineOutlinedIcon/> &nbsp;{sendname}</Typography> 
    </div>
  )
}

export default Deleteuser