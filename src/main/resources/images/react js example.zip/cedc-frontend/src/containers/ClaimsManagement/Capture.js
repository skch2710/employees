import React from "react";
import { Button, Grid, TextField } from "@material-ui/core";

const Capture = ({ setOpenCapturePopup }) => {
  const onClickCancel = () => {
    setOpenCapturePopup(false);
  };

  return (
    <Grid style={{ display: "flex", flexDirection: "column", padding: "10px" }}>
      <label style={{ marginBottom: "6px" }}>Notes</label>
      <TextField
        variant="outlined"
        multiline
        minRows={10}
        placeholder="Enter Notes"
        fullWidth
        style={{ width: "560px", marginBottom: "30px" }}
      />
      <Grid
        container
        xs={12}
        justifyContent="flex-end"
        style={{ padding: "12px" }}
      >
        <Button
          type="submit"
          color="primary"
          size="small"
          variant="contained"
          className="btn btn-primary text-capitalize"
        >
          Confirm
        </Button>
        <Button
          type="reset"
          size="small"
          variant="outlined"
          color="default"
          className="btn btn-secondary m-l-20 text-capitalize"
          onClick={onClickCancel}
        >
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};
export default Capture;
