import React from "react";
import { useCeEligibilityStyles } from "./styles";

const DividerWithText = ({ children }) => {
  const classes = useCeEligibilityStyles();
  return (
    <div className={classes.dividerContainer}>
      <div className={classes.dividerBorder} />
      <span className={classes.dividerContent}>{children}</span>
      <div className={classes.dividerBorder} />
    </div>
  );
};

export default DividerWithText;
