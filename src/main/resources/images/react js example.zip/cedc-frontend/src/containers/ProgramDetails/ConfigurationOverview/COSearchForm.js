import React, { memo, useContext, useEffect, useState } from "react";
import { Field, Form, Formik } from "formik";
import {
  Button,
  Checkbox,
  FormLabel,
  Grid,
  IconButton,
} from "@material-ui/core";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import _isEqual from "lodash/isEqual";
import { useDispatch, useSelector } from "react-redux";
import { IoIosCloseCircleOutline } from "react-icons/io";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import { getCoDefaultValues } from "./helper";
import AutoComplete from "../../../components/common/AutoComplete";
import {
  ALL_CE_OPTION,
  LABELS,
  setAutoCompleteInputVal,
} from "../../../utils/constants";
import {
  getCeIdsArray,
  getCeListWithoutAllOption,
  getPhGroupIdArray,
  getUserSession,
  isAllCeSelected,
} from "../../../utils/helper";
import {
  getPharmacyGroups,
  getPharmacyStore,
} from "../../../context/actions/Common";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { useCoFiltersStyles } from "./styles";
import {
  getCeListAndPhChainListOnPhId,
  getCeListOnPhGroupId,
} from "../../../context/actions/Pharmacies";
import { COContext } from "../COContext";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import MultiSelectDropdown from "../../../components/common/MultiSelectDropdown";
import { endDateValidation, startDateValidation } from "../../../utils/common";

const COSearchForm = memo((props = {}) => {
  const { handleSubmit, handleClear } = props;
  const dispatch = useDispatch();
  const userSession = getUserSession();
  const { ceList } = useSelector((state) => state.coveredEntities);
  const { openAddCePopup } = useContext(COContext);

  const [defaultValues, setDefaultValues] = useState(getCoDefaultValues());
  const globalClasses = useGlobalStyles();
  const classes = useCoFiltersStyles();

  const [coveredEntityOptions, setCoveredEntityOptions] = useState([]);
  const [showFilters, setShowFilters] = useState(true);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);
  const [pharmaciesList, setPharmaciesList] = useState([]);

  const fetchPharmacyGroups = async (ceIds = []) => {
    const ceIdsWithoutAll = getCeListWithoutAllOption({
      ceList: ceIds,
      defaultCeList: ceList,
    });
    const ceIdArray = getCeIdsArray(ceIdsWithoutAll);
    const resp = await dispatch(getPharmacyGroups(ceIdArray));
    if (_isArray(resp)) {
      setPharmacyGroups(resp);
      fetchPharmacies(ceIdsWithoutAll, getPhGroupIdArray(resp));
    }
  };

  const fetchPharmacies = async (ceIds, phGroupIds) => {
    const ceIdArray = getCeIdsArray(ceIds);
    const resp = await dispatch(
      getPharmacyStore({
        phGroupId: phGroupIds,
        ceid: ceIdArray,
      })
    );
    _isArray(resp) && setPharmaciesList(resp);
  };

  const setCeListAndPhChainList = async ({ phId, setFieldValue }) => {
    const resp = await dispatch(getCeListAndPhChainListOnPhId(phId));
    if (!_isEmpty(resp)) {
      const { CoveredEntities, pharmacyGroups } = resp || {};
      setPharmacyGroups(pharmacyGroups);
      if (userSession.isInternalUser) {
        setFieldValue("ceId", CoveredEntities);
      }
      fetchPharmacies(CoveredEntities, getPhGroupIdArray(pharmacyGroups));
    }
  };

  const setCeAllDropdownOptions = () => {
    setCoveredEntityOptions(userSession.isInternalUser ? [...ceList] : ceList);
  };

  useEffect(() => {
    setCeAllDropdownOptions();
    setDefaultValues((prev) => ({
      ...prev,
      ceId: userSession.isInternalUser ? [...ceList] : ceList,
    }));
    if (ceList.length && !openAddCePopup) {
      fetchPharmacyGroups(ceList);
    }
  }, [ceList]);

  const fetchCoveredEntityDropdownOptions = async ({
    phGroupId,
    setFieldValue,
  }) => {
    const resp = await dispatch(
      getCeListOnPhGroupId({
        phGroupId: [phGroupId],
      })
    );
    if (_isArray(resp)) {
      setFieldValue("ceId", resp);
    }
  };

  const handleValidate = (values = {}) => {
    const errors = {};
    if (values.ceId.length < 1) {
      errors.ceId = "Please select the Covered Entity";
    }
    return errors;
  };

  const handleFormSubmit = (values = {}) => {
    const payloadToFetch = {
      ...values,
      ceList: getCeListWithoutAllOption({
        ceList: coveredEntityOptions,
        defaultCeList: ceList,
      }),
    };
    handleSubmit(payloadToFetch);
  };

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleFormSubmit}
      enableReinitialize={true}
      validate={handleValidate}
    >
      {({ values, setFieldValue, initialValues, touched, errors }) => {
        return (
          <Form>
            {showFilters ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2}>
                  <Grid item md={12} className={classes.filterHeader}>
                    <BasicTypography variant="h4" title="Filters" />
                    <IconButton
                      onClick={() => {
                        setShowFilters(false);
                      }}
                    >
                      <IoIosCloseCircleOutline />
                    </IconButton>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>{LABELS.CoveredEntity}</FormLabel>
                        <Field as="select" multiple name="ceId">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disabled={ceList.length <= 1}
                              inputPlaceholder={
                                userSession.isInternalUser
                                  ? "Select Covered Entity"
                                  : ""
                              }
                              options={coveredEntityOptions}
                              getOptionSelected={(option, value) =>
                                option.ceID === value.ceID
                              }
                              getOptionLabel={(option) => option.ceName}
                              textFieldProps={{
                                inputProps: {
                                  name: "ceId",
                                },
                              }}
                              onChange={(_e, value) => {
                                setFieldValue("ceId", value);
                                if (value.length) {
                                  fetchPharmacyGroups(value);
                                }
                                setFieldValue("phGroupId", "");
                                setFieldValue("pharmacy", "");
                              }}
                              inputValue={values.coveredEntityInput || ""}
                              onInputChange={(_e, value) =>
                                setAutoCompleteInputVal({
                                  value,
                                  callback: (newValue) => {
                                    setFieldValue(
                                      "coveredEntityInput",
                                      newValue
                                    );
                                  },
                                })
                              }
                              tooltipProps={{
                                title:
                                  !userSession.isInternalUser &&
                                  values.ceId.length
                                    ? values.ceId[0].ceName
                                    : "",
                              }}
                            />
                          )}
                        </Field>
                        {errors.ceId && touched.ceId && (
                          <BasicTypography color="error" variant="caption">
                            {errors.ceId}
                          </BasicTypography>
                        )}
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="phGroupId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(pharmacyGroups) ? pharmacyGroups : []
                              }
                              inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                              value={
                                (_isArray(pharmacyGroups) &&
                                  pharmacyGroups.find(
                                    (e) => e.phGroupId == values.phGroupId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? newValue.phGroupId
                                  : "";
                                setFieldValue("pharmacy", "");
                                setFieldValue(
                                  "phGroupId",
                                  value ? Number(value) : ""
                                );
                                if (value) {
                                  fetchPharmacies(
                                    getCeListWithoutAllOption({
                                      ceList: values.ceId,
                                      defaultCeList: ceList,
                                    }),
                                    [Number(value)]
                                  );
                                  if (
                                    userSession.isInternalUser &&
                                    values.ceId &&
                                    (values.ceId.length === ceList.length ||
                                      !touched.ceId)
                                  ) {
                                    fetchCoveredEntityDropdownOptions({
                                      phGroupId: Number(value),
                                      setFieldValue,
                                    });
                                  }
                                } else {
                                  if (userSession.isInternalUser) {
                                    setCeAllDropdownOptions();
                                    fetchPharmacyGroups(values.ceId);
                                  }
                                }
                              }}
                              getOptionLabel={(option) =>
                                option.phGroupName || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.phGroupName}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="pharmacy"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(pharmaciesList) ? pharmaciesList : []
                              }
                              inputPlaceholder={`Select ${LABELS.PharmacyStore}`}
                              value={
                                (_isArray(pharmaciesList) &&
                                  pharmaciesList.find(
                                    (e) => e.phid == values.pharmacy
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? Number(newValue.phid)
                                  : "";
                                setFieldValue("pharmacy", value);
                                if (value) {
                                  if (!values.phGroupId) {
                                    const pharmacy = pharmaciesList.find(
                                      (ph) => ph.phid === value
                                    );
                                    setFieldValue(
                                      "phGroupId",
                                      pharmacy.phGroupId
                                    );
                                    setCeListAndPhChainList({
                                      phId: value,
                                      setFieldValue,
                                    });
                                  }
                                }
                              }}
                              getOptionLabel={(option) => option.phName || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.phName}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>

                      {userSession.isInternalUser && (
                        <>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>Start Date/Registration Date</FormLabel>
                            <Field as="select" name="startDate">
                              {({ field }) => (
                                <DatePicker
                                  {...field}
                                  onChange={(_e, date) => {
                                    if (!date) setFieldValue("endDate", "");
                                    setFieldValue("startDate", date);
                                  }}
                                  placeholder="Select Start Date/Registration Date"
                                  value={
                                    values.startDate !== ""
                                      ? moment(values.startDate, "MM/DD/YYYY")
                                      : ""
                                  }
                                  disabledDate={(date) =>
                                    startDateValidation(date, values.endDate)
                                  }
                                />
                              )}
                            </Field>
                          </Grid>

                          <Grid item xs={12} sm={2}>
                            <FormLabel>Termination Date</FormLabel>
                            <Field as="select" name="endDate">
                              {({ field }) => (
                                <DatePicker
                                  {...field}
                                  onChange={(_e, date) => {
                                    setFieldValue("endDate", date);
                                  }}
                                  placeholder="Select Termination Date"
                                  value={
                                    values.endDate !== ""
                                      ? moment(values.endDate, "MM/DD/YYYY")
                                      : ""
                                  }
                                  disabledDate={(d) =>
                                    endDateValidation(d, values.startDate)
                                  }
                                />
                              )}
                            </Field>
                          </Grid>

                          <Grid item xs={12} sm={4}>
                            <FormLabel>Effective Date</FormLabel>
                            <Field as="select" name="effectiveDate">
                              {({ field }) => (
                                <DatePicker
                                  {...field}
                                  onChange={(_e, date) => {
                                    setFieldValue("effectiveDate", date);
                                  }}
                                  placeholder="Select Effective Date"
                                  value={
                                    values.effectiveDate !== ""
                                      ? moment(
                                          values.effectiveDate,
                                          "MM/DD/YYYY"
                                        )
                                      : ""
                                  }
                                  disabledDate={(date) =>
                                    !date ||
                                    (values.startDate &&
                                      !date.isSameOrAfter(
                                        values.startDate,
                                        "day"
                                      )) ||
                                    (values.endDate &&
                                      !date.isSameOrBefore(
                                        values.endDate,
                                        "day"
                                      ))
                                  }
                                />
                              )}
                            </Field>
                          </Grid>
                        </>
                      )}
                      {!userSession.isInternalUser && (
                        <>
                          <Grid item xs={12} sm={4}></Grid>
                          <Grid item xs={12} sm={4}></Grid>
                        </>
                      )}
                      <Grid item xs={12} sm={4}>
                        <div className={classes.actionBtnContainer}>
                          <Button
                            type="submit"
                            color="primary"
                            size="small"
                            variant="contained"
                            className={globalClasses.primaryBtn}
                          >
                            Search
                          </Button>
                          <Button
                            type="reset"
                            size="small"
                            variant="outlined"
                            color="default"
                            className={globalClasses.secondaryBtn}
                            onClick={() => {
                              if (!_isEqual(initialValues, values)) {
                                fetchPharmacyGroups(ceList);
                                userSession.isInternalUser &&
                                  setCeAllDropdownOptions();
                              }
                              handleClear({ ...initialValues, ceList });
                            }}
                          >
                            Clear
                          </Button>
                        </div>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            ) : (
              <Button
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setShowFilters(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
});

export default COSearchForm;
