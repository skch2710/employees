import { Box, Collapse, Divider } from "@material-ui/core";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import { ExpandLess, ExpandMore } from "@material-ui/icons";
import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";
import classNames from "classnames";
import React, { useCallback, useContext, useEffect, useState } from "react";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import { COContext } from "../../COContext";
import Icons from "./Icons";
import { MENUS, collapseItemParentMapping, getPopupMenus } from "./constants";
import { usePopupSidebarStyles } from "./styles";

const PopupSideBar = () => {
  const classes = usePopupSidebarStyles();
  const globalClasses = useGlobalStyles();
  const {
    popupActiveMenu,
    setPopupActiveMenu,
    menusStatuses = {},
    phConfigSectionStatus = {},
    activeInactiveCOMenus,
    ceId,
    currentPharmacy,
    fetchCeSectionStatuses,
    fetchPhSectionStatuses,
    setCurrentPharmacy,
    setActiveInactiveCOMenus,
    setPhConfigSectionStatus,
    setPhConfigStatusPercent,
    setCeConfigStatusPercent,
  } = useContext(COContext) || {};
  const menus = getPopupMenus(
    menusStatuses,
    phConfigSectionStatus,
    activeInactiveCOMenus
  );
  const [collapsedMenu, setCollapsedMenu] = useState(
    collapseItemParentMapping[1]
  );

  useEffect(() => {
    setCollapsedMenu(collapseItemParentMapping[popupActiveMenu]);
  }, [popupActiveMenu]);

  const handleMenuClick = useCallback(
    (menu) => () => {
      if (
        popupActiveMenu < MENUS.PH_VIEW_PHARMACIES &&
        menu.id >= MENUS.PH_BASIC_DETAILS
      ) {
        // *Switching from CE config to PH config
        setCeConfigStatusPercent(0);
        fetchPhSectionStatuses({ ceId, clientId: currentPharmacy.clientId });
      } else if (
        popupActiveMenu >= MENUS.PH_VIEW_PHARMACIES &&
        menu.id < MENUS.PH_VIEW_PHARMACIES
      ) {
        // *Switching from PH config to CE config
        setPhConfigSectionStatus({});
        setPhConfigStatusPercent(0);
        setCurrentPharmacy({});
        setActiveInactiveCOMenus((prev) => ({
          ...prev,
          [MENUS.PH_BASIC_DETAILS]: false,
          [MENUS.PH_BILLING_AND_FEES]: false,
          [MENUS.PH_ELIGIBILITY]: false,
          [MENUS.PH_ORDERING_AND_REPLENISHMENT]: false,
        }));
        fetchCeSectionStatuses({ ceId });
      }
      setPopupActiveMenu(menu.id);
    },
    [popupActiveMenu]
  );

  const getMenuItem = ({ menu, isSubMenu }) => {
    const dynamicClassName = isSubMenu ? "subMenuTitle" : "mainMenuTitle";
    const { isPartialCompleted } = menu || {};
    return (
      <Box
        id="test"
        className={classNames(classes[dynamicClassName], classes.menuTitle)}
      >
        {menu.icon ? <Icons menu={menu.id} /> : null}
        <span>{menu.title}</span>
        {isPartialCompleted ? (
          <FiberManualRecordIcon className={classes.partiallyCompleteIcon} />
        ) : null}
      </Box>
    );
  };

  return (
    <>
      <List>
        {menus.map((menu, index) => {
          return (
            <>
              <Divider classes={{ root: globalClasses.divider }} />
              <ListItem
                button
                key={menu.id}
                selected={popupActiveMenu === menu.id}
                onClick={() => {
                  if (menu.subNav && menu.subNav.length) {
                    setCollapsedMenu((prev) =>
                      prev === menu.id ? 0 : menu.id
                    );
                  } else {
                    setPopupActiveMenu(menu.id);
                  }
                }}
                className={classes.mainMenuListItem}
                disabled={!activeInactiveCOMenus[menu.id]}
              >
                <ListItemText
                  primary={getMenuItem({ menu, isSubMenu: false })}
                />
                {menu.subNav &&
                  menu.subNav.length &&
                  (collapsedMenu === menu.id ? (
                    <ExpandLess className={classes.expandCollapseIcons} />
                  ) : (
                    <ExpandMore className={classes.expandCollapseIcons} />
                  ))}
              </ListItem>
              {menu.subNav && menu.subNav.length && (
                <Collapse
                  in={collapsedMenu === menu.id ? true : false}
                  timeout="auto"
                  unmountOnExit
                >
                  <Divider classes={{ root: globalClasses.divider }} />
                  <List component="div" classes={{ root: classes.subList }}>
                    {menu.subNav.map((elem = {}) => {
                      return (
                        <ListItem
                          button
                          key={elem.id}
                          onClick={handleMenuClick(elem)}
                          selected={popupActiveMenu === elem.id}
                          className={classes.subMenuListItem}
                          disabled={elem.disabled}
                        >
                          <ListItemText
                            primary={getMenuItem({
                              menu: elem,
                              isSubMenu: true,
                            })}
                          />
                        </ListItem>
                      );
                    })}
                  </List>
                </Collapse>
              )}
              {menus.length === index + 1 ? (
                <Divider classes={{ root: globalClasses.divider }} />
              ) : null}
            </>
          );
        })}
      </List>
    </>
  );
};

export default PopupSideBar;
