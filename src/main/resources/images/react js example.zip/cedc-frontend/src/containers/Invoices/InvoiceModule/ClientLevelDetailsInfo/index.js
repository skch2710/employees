import React, {
  memo,
  useEffect,
  useState,
  useRef,
  useCallback,
  forwardRef,
} from "react";
import MaterialTable, { MTablePagination, MTableToolbar } from "material-table";
import { Paper, Tooltip } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import moment from "moment";
import { DatePicker } from "antd";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
} from "../../../../Styles/useGlobalStyles";
import { LABELS, pagination } from "../../../../utils/constants";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import { isEmptyGrid } from "../../../../utils/helper";
import { getInoiceInnerSubGridList } from "../../../../context/actions/Invoice";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { tableCellGlobalJson } from "../../../../components/common/Table/usetableStyle";
import { useInvoiceInfoStyle } from "./styles";
import { getInvoiceInnerSubgridFiltersObject } from "../helper";
import { TABLE_CELL_STYLE } from "../constants";
import { GET_INVOICE_INNER_SUBGRID_LIST } from "../../../../context/constants";
import LoaderUI from "../../../../components/common/Loader/Loader";
import DataNotFound from "../../../../components/common/DataNotFound";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import tableIcons from "../MaterialTableIcons";
import useFileExport from "./useFileExport";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const ClientLevelDetailsInfo = ({ InnerGridRowdata }) => {
  const {
    phGroupId,
    billingPeriod,
    invoicePeriodStartDate,
    invoicePeriodEndDate,
    ceid,
  } = InnerGridRowdata || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const iconsAndButtons = useTableIconsAndButtons();
  const [controller, setController] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });

  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);

  const { records: InvsubgridList, loading } = useSelector(
    (state) => state.getInvoiceSubInnerGrid
  );

  const classes = useInvoiceInfoStyle({
    totalElements: InvsubgridList.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.page,
  });

  const fetchInvSubGridItemInfo = (payload = {}) => {
    dispatch(
      getInoiceInnerSubGridList(
        {
          phGroupId: phGroupId,
          billingPeriod: billingPeriod,
          invoicePeriodStartDate: invoicePeriodStartDate,
          invoicePeriodEndDate: invoicePeriodEndDate,
          ceId: [ceid],
          pageNumber: controller.pageNumber,
          pageSize: controller.pageSize,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            pageNumber: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (billingPeriod) {
      fetchInvSubGridItemInfo();
    }
    return () => {
      dispatch({ type: GET_INVOICE_INNER_SUBGRID_LIST, data: {} });
    };
  }, []);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setController((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(InvsubgridList.totalElements / rowsPerPage) || 1;
      if (controller.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.pageNumber;
      fetchInvSubGridItemInfo(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controller.sortOrder,
          sortBy: controller.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, InvsubgridList, controller]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = INVENTORY_INNERSUB_TABLE[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchInvSubGridItemInfo(
        {
          pageNumber: controller.pageNumber,
          pageSize: controller.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getInvoiceInnerSubgridFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchInvSubGridItemInfo({
      ...controller,
      filter: filterPayload,
    });
  };

  const actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      disabled: isEmptyGrid(InvsubgridList),
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(InvsubgridList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(InvsubgridList),
      onClick: () =>
        exportToExcel({
          phGroupId,
          billingPeriod,
          invoicePeriodStartDate,
          invoicePeriodEndDate,
          ceid,
          controller,
          columnFilters,
        }),
    },
  ];
  const INVENTORY_INNERSUB_TABLE = [
    {
      title: LABELS.PharmacyStore,
      field: "phName",
      defaultFilter: enableFilters && columnFiltersRef.current.phName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.phName}>
            <span>{rowData.phName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.phName}
          placeholder="Pharmacy Store"
        />
      ),
    },
    {
      title: "Billing Period",
      field: "invoicePeriodStartDate",
      render: (InvoiceMainListData) => {
        return (
          <Tooltip
            title={`${InvoiceMainListData.invoicePeriodStartDate} - ${InvoiceMainListData.invoicePeriodEndDate}`}
          >
            <span>{`${InvoiceMainListData.invoicePeriodStartDate} - ${InvoiceMainListData.invoicePeriodEndDate}`}</span>
          </Tooltip>
        );
      },
      defaultFilter: enableFilters && columnFiltersRef.current.billingPeriod,
      customFilterAndSearch: () => true,
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            className={classes.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placement="topLeft"
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.invoicePeriodStartDate
                ? moment(columnFiltersRef.current.invoicePeriodStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Total Invoiced",
      field: "totalInvoiced",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.totalInvoiced,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.totalInvoiced}>
            <span>{rowData.totalInvoiced}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalInvoiced}
          placeholder="Total Invoiced"
        />
      ),
    },
    {
      title: "Dispensing Fees",
      field: "dispensingFee",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensingFee,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingFee}>
            <span>{rowData.dispensingFee}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingFee}
          placeholder="Dispensing Fees"
        />
      ),
    },
    {
      title: "True Up Fees",
      field: "trueUp",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUp,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUp}>
            <span>{rowData.trueUp}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUp}
          placeholder="True Up Fees"
        />
      ),
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title=""
        columns={INVENTORY_INNERSUB_TABLE}
        data={InvsubgridList.content}
        page={controller.pageNumber - 1}
        totalCount={InvsubgridList.totalElements || 0}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        tableRef={tableRef}
        icons={{
          SortArrow: () => TableCustomSortArrow(controller),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={actions}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controller.pageSize,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          pageSizeOptions: isEmptyGrid(InvsubgridList)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default memo(ClientLevelDetailsInfo);
