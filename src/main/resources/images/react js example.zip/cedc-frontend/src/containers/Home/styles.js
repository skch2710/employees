import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => {
  return {
    cardContainer: {
      padding: "20px",
    },
    cardContent: {
      padding: "15px",
      textAlign: "left",
    },
    cardBgImg: {
      backgroundRepeat:"no-repeat",
      backgroundPosition:"right 30px"
    },
    filterHeading: {
      color: theme.colors.monochrome.title,
      fontFamily: theme.fontFamily,
    },
    selectedCheckBox: {
      color: theme.colors.blue[500],
    },
    closeFilterIcon: {
      padding: "5px",
    },
    formActionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
    },
    exportContainer: {
      textAlign: "right",
      padding: "8px 10px 0 0",
    },
    exportSelect: {
      height: "30px",
      padding: "0 6px",
      borderRadius: "4px",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
    activeCounts: {
      color: theme.colors.blue.default,
      cursor: "pointer",
    },
    exportBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
    },
    cardIcon: {
      width: "30%",
      float: "right",
      paddingLeft: "15px",
    },
    count: {
      width: "70%",
      float: "left",
      margin: "4px 0px 0px 0px",
    },
    countFull: {
      margin: "4px 0px 0px 0px",
    },
    cogsValues: {
      margin: "4px 0px 0px 0px",
      fontSize: "12px",
      fontWeight: "800",
    },
    cardText: {
      fontWeight: "800",
      fontSize: "19px",
    },
    cardSecondary: {
      border: `${theme.colors.secondary.default} solid 1px`,
      boxShadow: "none",
      borderRadius: "8px",
      padding: "10px",
      cursor: "pointer",
      "&:hover": {
        borderColor: theme.colors.monochrome.secondaryCardHoverBorder,
        boxShadow: `0 0 0 0 ${theme.colors.monochrome.cardBoxShadow},0 2px 3px 0 ${theme.colors.monochrome.cardBoxShadow}`,
        backgroundColor: theme.colors.monochrome.secondaryCardHoverBoxShadow,
      },
    },
    cardSecondaryContainer: {
      marginTop: "20px",
    },
    cardDateHalf: {
      color: theme.colors.monochrome.label,
      fontSize: "12px",
      fontWeight: "100",
      lineHeight: "3.5",
      width:"70%"
    },
    cardDate: {
      color: theme.colors.monochrome.label,
      fontSize: "12px",
      fontWeight: "100",
      lineHeight: "3.5",
    },
    toolTip: {
      backgroundColor: theme.colors.monochrome.offWhite,
      border: `1px solid ${theme.colors.grey[200]}`,
      padding: "6px",
    },
    phStoreTable: {
      width: "100%",
    },
    cardViewFullReport: {
      borderTop: `1px solid ${theme.colors.secondary.default}`,
      textAlign: "center",
    },
    viewFullReportBtn: {
      textTransform: "capitalize",
      color: theme.colors.blue.default,
    },
    dotTIC: {
      height: "9px",
      width: "9px",
      backgroundColor: theme.colors.graphColors.green,
      borderRadius: "50%",
      display: "inline-block",
      margin: "3px 8px 0px 5px",
    },
    dotCgs: {
      height: "9px",
      width: "9px",
      backgroundColor: theme.colors.graphColors.blue,
      borderRadius: "50%",
      display: "inline-block",
      margin: "3px 8px 0px 5px",
    },
    dotSavings: {
      height: "9px",
      width: "9px",
      backgroundColor: theme.colors.graphColors.dark,
      borderRadius: "50%",
      display: "inline-block",
      margin: "3px 8px 0px 5px",
    },
    barCharToolTip: {
      backgroundColor: theme.colors.monochrome.offWhite,
      border: `1px solid ${theme.colors.grey[200]}`,
      fontSize: "13px",
      width: "250px",
      padding: "5px",
    },
    onHoverValues: {
      padding: "5px 5px 5px 5px",
    },
    pharmacyName: {
      fontWeight: "600",
      fontSize: "12px",
      padding: "5px 0 ",
    },
    barchartLables: {
      fontSize: "12px",
      padding: "0 4px",
    },
    chartValues: {
      fontWeight: "600",
      fontSize: "12px",
    },
    recharts: {
      "& .recharts-pie-labels": {
        display: "none",
      },
      "& .recharts-cartesian-axis-ticks": {
        fontSize: "11px",
      },
      "& .recharts-legend-item-text": {
        fontSize: "13px",
      },
    },
    headerRefreshText: {
      "&.MuiGrid-item": {
        fontSize: "12px",
        color: theme.colors.monochrome.input,
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-end",
        paddingRight: "15px",
      },
    },
    programStats: {
      margin:"10px 0",
      color: "#5a607f",
      letterSpacing: "0.5px",
      fontWeight:600,
      fontSize: "13px",
      lineHeight: "initial",
      display: "flex",
      alignItems: "center",
      "& svg":{
        color:"#F78D25",
        fontSize:"22px",
        margin: "0 6px",
      },
    },
    programStatsTooltip: {
      padding: "6px",
      fontSize: "11px",
      marginLeft: "0px !important",
      marginTop: "-2px",
    }
  };
});
