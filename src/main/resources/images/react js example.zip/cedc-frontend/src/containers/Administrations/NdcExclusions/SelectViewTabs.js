import React, { useState } from "react";
import { useNdcSearchFormStyles } from "./styles";
import ToggleButton from "@material-ui/lab/ToggleButton";
import ToggleButtonGroup from "@material-ui/lab/ToggleButtonGroup";

const SelectViewTabs = ({ handleSelectedTab }) => {
  const classes = useNdcSearchFormStyles();
  const [tabSelected, setTabSelected] = useState("ndc");

  const handleChange = (_event, tab) => {
    if (tab === null) return;
    setTabSelected(tab);
    handleSelectedTab(tab);
  };

  return (
    <ToggleButtonGroup
      size="small"
      value={tabSelected}
      exclusive
      onChange={handleChange}
      className={classes.ToggleButtonGroup}
    >
      <ToggleButton className={classes.ToggleButton} value="ndc">
        NDC Lists
      </ToggleButton>
      <ToggleButton className={classes.ToggleButton} value="coveredEntity">
        Covered Entity
      </ToggleButton>
      <ToggleButton className={classes.ToggleButton} value="phStore">
        Pharmacy Store
      </ToggleButton>
    </ToggleButtonGroup>
  );
};

export default SelectViewTabs;
