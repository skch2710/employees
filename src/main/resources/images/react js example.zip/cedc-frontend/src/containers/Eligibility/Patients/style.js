import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const usePatientStyles = makeStyles((theme) => ({
  dialogPaper: {
    height: "75vh",
  },
  noContentDialog: {
    height: "27vh",
  },
  AddVisitDialogPaper: {
    height: "70vh",
  },
  enableFilterForInnerFrid: {
    marginRight: "225px",
    marginTop: "-37px",
    paddingBottom: "13px",
  },
  coveredEntityNameWrapper: {
    width: "100%",
    height: "30px",
    display: "flex",
    alignItems: "center",
  },
  coveredEntityName: {
    width: "100%",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    color: theme.colors.monochrome.disabledText,
  },
  verticalTabs: {
    display: "flex",
  },
  tabLabel: {
    fontSize: "14px",
    textTransform: "capitalize",
    alignItems: "flex-start",
  },
  templateLink: {
    display: "flex",
    gap: "5px",
    justifyContent: "flex-end",
    alignItems: "center",
  },
}));
