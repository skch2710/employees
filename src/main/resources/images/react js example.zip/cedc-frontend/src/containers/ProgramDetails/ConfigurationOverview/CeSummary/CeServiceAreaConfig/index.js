import React, {
  useCallback,
  useContext,
  useEffect,
  useState,
  useMemo,
} from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { useCeSummaryStyle } from "../styles";
import { getCoServiceAreaConfig } from "../../../../../context/actions/ConfigOverview";
import { getServices } from "./helper";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";

const CeServiceAreaConfig = (props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};

  const { loading: _serviceAreaConfigLoading, serviceAreaConfig = [] } =
    useSelector((state) => state.coServiceAreaConfig) || {};

  const {
    hospitalServices,
    admitTypes,
    servicingFacilities,
    patientLocations,
    patientTypes,
  } = useMemo(() => getServices(serviceAreaConfig), [serviceAreaConfig]);

  const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      dispatch(getCoServiceAreaConfig(selectedCeForOverview.ceid));
    }
  }, [selectedCeForOverview]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Service Area Configurations" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={
                  !userSession.isInternalUser || !coPermissions.readWriteFlag
                }
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(
                      MENUS.CE_SERVICE_AREA,
                      selectedCeForOverview.ceid
                    );
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <Grid container spacing={2}>
                <Grid item md xs={12}>
                  <Grid container direction="column" spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5">
                        Hospital Service
                      </BasicTypography>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container direction="column" spacing={1}>
                        {hospitalServices.map((hospitalService, index) => {
                          if (hospitalService.inactiveFlag === "N") {
                            return (
                              <Grid
                                item
                                md={12}
                                key={"hospitalService" + index}
                              >
                                <BasicTypography variant="subtitle2">
                                  {hospitalService.configurationType}
                                </BasicTypography>
                              </Grid>
                            );
                          } else return null;
                        })}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md xs={12}>
                  <Grid container direction="column" spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5">Admit Type</BasicTypography>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container direction="column" spacing={1}>
                        {admitTypes.map((admitType, index) => {
                          if (admitType.inactiveFlag === "N") {
                            return (
                              <Grid item md={12} key={"admitType" + index}>
                                <BasicTypography variant="subtitle2">
                                  {admitType.configurationType}
                                </BasicTypography>
                              </Grid>
                            );
                          } else return null;
                        })}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md xs={12}>
                  <Grid container direction="column" spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5">
                        Servicing Facility
                      </BasicTypography>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container direction="column" spacing={1}>
                        {servicingFacilities.map((servicingFacility, index) => {
                          if (servicingFacility.inactiveFlag === "N") {
                            return (
                              <Grid
                                item
                                md={12}
                                key={"servicingFacility" + index}
                              >
                                <BasicTypography variant="subtitle2">
                                  {servicingFacility.configurationType}
                                </BasicTypography>
                              </Grid>
                            );
                          } else return null;
                        })}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md xs={12}>
                  <Grid container direction="column" spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5">
                        Patient Location
                      </BasicTypography>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container direction="column" spacing={1}>
                        {patientLocations.map((patientLocation, index) => {
                          if (patientLocation.inactiveFlag === "N") {
                            return (
                              <Grid
                                item
                                md={12}
                                key={"patientLocation" + index}
                              >
                                <BasicTypography variant="subtitle2">
                                  {patientLocation.configurationType}
                                </BasicTypography>
                              </Grid>
                            );
                          } else return null;
                        })}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md xs={12}>
                  <Grid container direction="column" spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5">
                        Patient Type
                      </BasicTypography>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container direction="column" spacing={1}>
                        {patientTypes.map((patientType, index) => {
                          if (patientType.inactiveFlag === "N") {
                            return (
                              <Grid item md={12} key={"patientType" + index}>
                                <BasicTypography variant="subtitle2">
                                  {patientType.configurationType}
                                </BasicTypography>
                              </Grid>
                            );
                          } else return null;
                        })}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CeServiceAreaConfig;
