export const basicDetailsFormDefaultValues = () => {
  return {
    phId: "",
    phGroupId: "",
    npi: "",
    phName: "",
    storeNumber: "",
    nabp: "",
    division: "",
    region: "",
    iCode: "",
    district: "",
    address1: "",
    address2: "",
    city: "",
    stateId: "",
    zipCode: "",
    parentAssociation: "",
    network: false,
    isSpecialtyStore: false,
    isCentralFillStore: false,
    cecontractDate: "",
    feeEffectiveDate: "",
    pharmacyLiveDate: "",
    pharmacyTerminationDate: "",
    opaeffectiveDate: "",
    productionDate: "",
    phContactFN: "",
    phContactLN: "",
    phone: "",
    emailId: "",
    primaryContactIndicator: false,
  };
};

export const TABLE_CELL_STYLE = {
  fontSize: "11px",
  whiteSpace: "nowrap",
  padding: "12px",
  textAlign: "left",
};

export const ALLOWED_FILE_TYPES = "*";
