import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form, Field } from "formik";
import { Grid, IconButton, Button, FormLabel } from "@material-ui/core";
import _isArray from "lodash/isArray";
import {
  getPreferredUserDefaultValue,
  REGEX,
  setAutoCompleteInputVal,
  LABELS
} from "../../utils/constants";
import AutoComplete from "../../components/common/AutoComplete";
import Userlist from "./Userlist";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { USER_MANAGEMENT } from "../../components/common/Table/TableHeadCells";
import { pagination } from "../../utils/constants";
import {
  DownloadErrorFile,
  getUserList,
} from "../../context/actions/Usermanagement";
import { searchUserDropDown, filterFunctionality } from "../../utils/common";
import { getCeIdsArray, getUserSession } from "../../utils/helper";
import excel from "../../assets/excel.png";
import pass from "../../assets/pass.png";
import fail from "../../assets/fail.png";
import ErrorFileDiscardWarning from "./Popupbox/ErrorFileDiscardWarning";
import { GLOBAL_FILTERS_MAP } from "./constant";
import { getFilteredUsersRoles } from "./helper";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import { useContext } from "react";
import { COContext } from "../ProgramDetails/COContext";
import { getAllCoveredEntities } from "../../context/actions/Common";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import { useUserManagementStyles } from "./style";
import Tooltip from "@mui/material/Tooltip";
import MultiSelectDropdown from "../../components/common/MultiSelectDropdown";

const PreferredUser = ({
  Co = false,
  setAddUserPopupOfCo,
  setshowfieldsvalues,
  showfieldsvalues,
  primarystate,
  setprimarystate,
  onUserAdd,
}) => {
  const { messageUuid } = useContext(COContext) || {};
  const dispatch = useDispatch();
  const classes = useUserManagementStyles();
  const formRef = useRef();
  const userSession = getUserSession();
  const usersRoles = useSelector((state) => state.getUserrole.records) || [];
  const { loading } = useSelector((state) => state.globalLoader);
  const { externalUsersRoles } = getFilteredUsersRoles(usersRoles);
  const allowedUserRoles =
    userSession.isInternalUser && !Co ? usersRoles : externalUsersRoles;
  const [showFilters, setShowFilters] = useState(true);
  const defaultValues = getPreferredUserDefaultValue(userSession);
  const [page, setPage] = useState(pagination.page);
  const [sortBy, setsortBy] = useState("firstName, lastName, emailID");
  const [sortorder, setOrder] = useState("asc");
  const [rowsPerPage, setRowsPerPage] = useState(
    Co ? pagination.billingLimit : pagination.limit
  );
  const [filter, setFilter] = useState(false);
  const [clearButton, setclearButton] = useState(false);
  const [searchClicked, setsearchClicked] = useState(false);
  const [errorFileDiscardPopup, setErrorFileDiscardPopup] = useState(false);
  const [searchBy, setSerachBy] = useState("");
  const [globalFilterValue, setGlobalFilterValue] = useState("");
  const [filterValues, setFilterValues] = useState([]);
  const [rowdatauserlist, setrowdatauserlist] = useState(null);
  const coCeid = Co
    ? [messageUuid !== null && messageUuid.ceid !== null ? messageUuid.ceid : 2]
    : [];

  const [ceSelected, setCeSelected] = useState(
    userSession.isInternalUser ? [] : [userSession.coveredEntityDTOs[0]]
  );
  const [cEList, secEList] = useState([]);
  const [ceListLoading, setCeListLoading] = useState(true);
  const globalClasses = useGlobalStyles();

  useEffect(() => {
    setCeSelected(cEList);
  }, [cEList]);

  const fetchUsers = (payload = {}, otherProps = {}) => {
    const { clearAll, ceList = cEList } = otherProps;
    const isNotClearedAndSearched = !clearAll && searchClicked;
    const json = {
      ceID: Co ? coCeid : getCeIds(ceList || userSession.coveredEntityDTOs),
      pageNumber: page,
      pageSize: rowsPerPage,
      sortBy: sortBy,
      sortOrder: sortorder,
      ...(isNotClearedAndSearched && searchBy && globalFilterValue
        ? { [GLOBAL_FILTERS_MAP[searchBy]]: globalFilterValue }
        : {}),
      ...(clearAll ? {} : { filter: filterValues }),
      ...payload,
    };
    dispatch(getUserList(json));
    setCeListLoading(false);
  };

  const fetchCoveredEntities = async () => {
    const ces = await dispatch(getAllCoveredEntities());
    if (_isArray(ces)) {
      secEList(ces);
      fetchUsers({}, { ceList: ces });
    }
  };

  useEffect(() => {
    if (userSession.isInternalUser) {
      fetchCoveredEntities();
    } else {
      secEList(userSession.coveredEntityDTOs);
      fetchUsers({}, { ceList: userSession.coveredEntityDTOs });
    }
    return () => {
      dispatch({ type: "GET_USER_LIST", data: [] });
    };
  }, []);

  const onChangePagination = (newPage, pageSize) => {
    let currentPage = newPage + 1;
    const rowsPerPageNew = Number(pageSize);
    const totalPages = Math.ceil(userlist.totalElements / rowsPerPageNew) || 1;
    const pages = totalPages === 0 ? 1 : totalPages;
    if (page > totalPages) currentPage = totalPages;
    else if (newPage === 0 && rowsPerPageNew !== rowsPerPage)
      currentPage = page;
    setRowsPerPage(rowsPerPageNew);
    setPage(currentPage);
    fetchUsers({
      pageSize: rowsPerPageNew,
      pageNumber: currentPage,
    });
  };

  const onChangeSorting = async (orderedColumnId) => {
    setOrder(sortorder === "asc" ? "desc" : "asc");
    setsortBy(USER_MANAGEMENT[orderedColumnId].field);
    fetchUsers({
      sortOrder: sortorder === "asc" ? "desc" : "asc",
      sortBy: USER_MANAGEMENT[orderedColumnId].field,
    });
  };

  // To Get CE Ids to based on User type and selection
  // if All selected append -1 too, along with selected CE Ids in the array
  const getCeIds = (ceList = cEList) => {
    return !userSession.isInternalUser
      ? getCeIdsArray(ceSelected)
      : ceSelected.length < 1
        ? [...getCeIdsArray(ceList), -1]
        : ceSelected.length === ceList.length
          ? [...getCeIdsArray(ceSelected), -1]
          : getCeIdsArray(ceSelected);
  };

  const onChangeFilter = async (value) => {
    setPage(1);
    const formValues = formRef.current.values;
    const payload = {
      pageNumber: 1,
    };
    if (formValues.by)
      payload[GLOBAL_FILTERS_MAP[formValues.by]] = globalFilterValue;
    if (value.length) {
      const responseValue = await filterFunctionality(value, "User");
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setFilterValues(responseValue);
    } else {
      payload.filter = null;
      setFilterValues([]);
    }
    fetchUsers(payload);
  };

  const placeValue = (value, type) => {
    let data;
    if (type === 1) {
      if (value.value !== "un") {
        data = searchUserDropDown.filter((x) => x.value === value);
        data = data[0].field;
      } else {
        data = searchUserDropDown.filter((x) => x.value === value)[0].field;
      }
    } else {
      if (value.value !== "un") {
        data = searchUserDropDown.filter((x) => x.value === value.value);
        data = "User " + data[0].displayname;
      } else {
        data = searchUserDropDown.filter((x) => x.value === value)[0]
          .displayname;
      }
    }
    return data;
  };

  // Get Data From Reducer
  let userlist = useSelector((state) => state.usermanagement.records);
  const bulkUpload = useSelector((state) => state.usermanagement.bulkUpload);

  useEffect(() => {
    if (bulkUpload && bulkUpload.failureMessage) {
      setErrorFileDiscardPopup(true);
    } else {
      setErrorFileDiscardPopup(false);
    }
  }, [bulkUpload]);


  const handleSubmit = (values) => {
    setFilterValues([]);
    setsearchClicked(true);
    setPage(pagination.page);
    setclearButton(false);
    setGlobalFilterValue(values.globalFilterValue);
    fetchUsers({
      ...(values.by && {
        [GLOBAL_FILTERS_MAP[values.by.value]]: values.globalFilterValue,
      }),
      pageNumber: 1,
      filter: [],
      sortBy: values.sortBy || sortBy,
    });
  };

  const handleChange = (value) => {
    setSerachBy(value.value);
  };

  const handleCeChange = (props) => {
    setSerachBy(props.field && props.field.value);
  };

  useEffect(() => {
    setGlobalFilterValue("");
  }, [searchBy]);

  const clearFunction = () => {
    const ceSelectedDefaultValue = cEList;
    const res = cEList.map((item) => item.ceID);
    if (userSession.isInternalUser) res.push(-1);
    setFilterValues([]);
    setGlobalFilterValue("");
    setclearButton(Math.random());
    setPage(pagination.page);
    setsearchClicked(false);
    setOrder("asc");
    setsortBy("firstName");
    setCeSelected(ceSelectedDefaultValue);
    fetchUsers(
      {
        pageNumber: 1,
        sortBy: "firstName",
        sortOrder: "asc",
      },
      { clearAll: true }
    );
  };

  return (
    <Grid container spacing={2}>
      {!Co && (
        <Grid item md={12}>
          <BasicTypography variant="h1" title="User Management" />
        </Grid>
      )}
      <Grid item md={12}>
        <Formik
          initialValues={defaultValues}
          onSubmit={handleSubmit}
          innerRef={formRef}
        >
          {({ values, setFieldValue }) => (
            <Form>
              {showFilters ? (
                <div className={globalClasses.cardPrimary}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <Grid
                        container
                        spacing={2}
                        justifyContent="space-between"
                      >
                        <Grid item>
                          <BasicTypography variant="h4" title="Filters" />
                        </Grid>
                        <Grid item>
                          <IconButton
                            onClick={() => {
                              setShowFilters(false);
                            }}
                          >
                            <IoIosCloseCircleOutline />
                          </IconButton>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        {Co ? (
                          <Grid item xs={12} sm={4}>
                            <FormLabel>Covered Entity</FormLabel>
                            <Field
                              as="select"
                              name="by"
                              className={globalClasses.formControl}
                            >
                              {(props) => {
                                const { field } = props;
                                return (
                                  <select
                                    onChange={handleCeChange(props)}
                                    {...field}
                                    className={globalClasses.formControl}
                                    disabled={true}
                                  >
                                    <option value={""} selected>
                                      {messageUuid !== null &&
                                        messageUuid.ceName
                                        ? messageUuid.ceName
                                        : messageUuid.ceName === undefined
                                          ? messageUuid.coveredEntityName
                                          : "----"}
                                    </option>
                                  </select>
                                );
                              }}
                            </Field>
                          </Grid>
                        ) : (
                          <Grid item xs={12} sm={4}>
                            <FormLabel required>Covered Entity</FormLabel>
                            <Field multiple name="ci">
                              {({ field }) => (
                                <MultiSelectDropdown
                                  {...field}
                                  inputPlaceholder={
                                    userSession.isInternalUser
                                      ? "Select Covered Entity"
                                      : ""
                                  }
                                  options={cEList}
                                  getOptionLabel={(option) => option.ceName}
                                  value={ceSelected}
                                  onChange={(_e, val) => {
                                    setCeSelected(val);
                                  }}
                                  inputValue={values.coveredEntityInput || ""}
                                  onInputChange={(_e, value) =>
                                    setAutoCompleteInputVal({
                                      value,
                                      callback: (newValue) => {
                                        setFieldValue(
                                          "coveredEntityInput",
                                          newValue
                                        );
                                      },
                                    })
                                  }
                                  disabled={
                                    userSession.coveredEntityDTOs.length < 2
                                  }
                                  tooltipProps={{
                                    title:
                                      !userSession.isInternalUser &&
                                        ceSelected.length
                                        ? ceSelected[0].ceName
                                        : "",
                                  }}
                                />
                              )}
                            </Field>
                            {!loading &&
                              !ceListLoading &&
                              ceSelected.length < 1 ? (
                              <BasicTypography color="error" variant="caption">
                                Please select the Covered Entity
                              </BasicTypography>
                            ) : null}
                          </Grid>
                        )}
                        <Grid item xs={12} sm={4}>
                        <FormLabel >Search By</FormLabel>
                          <FormLabel>{LABELS.by}</FormLabel>
                          {
                            <Field as="select" name="by">
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  disableCloseOnSelect={false}
                                  options={
                                    _isArray(searchUserDropDown) ? searchUserDropDown : []
                                  }
                                  inputPlaceholder="Search user by"
                                  onChange={(e, value) => {
                                    handleChange(value ? value : "");
                                    setFieldValue(
                                      "by",
                                      value ? value : ""
                                    );
                                    setFieldValue("globalFilterValue", "");

                                  }}
                                  getOptionLabel={(option) =>
                                    option.displayname || ""
                                  }
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.displayname}
                                      </BasicTypography>
                                    );
                                  }}
                                  multiple={false}
                                />
                              )}
                            </Field>
                          }
                        </Grid>
                        {values.by !== "" &&
                          values.by !== "st" &&
                          values.by !== "ut" && (
                            <Grid item xs={12} sm={4}>
                              <FormLabel>{`${placeValue(
                                values.by,
                                0
                              )}`}</FormLabel>
                              <Field
                                name="globalFilterValue"
                                type="text"
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (values.by !== "em") {
                                    if (
                                      value &&
                                      !REGEX.alphabetsAndHypen.test(value)
                                    )
                                      return;
                                  }
                                  setFieldValue("globalFilterValue", value);
                                }}
                                className={globalClasses.formControl}
                                placeholder={`Enter ${placeValue(values.by)}`}
                              />
                            </Grid>
                          )}
                        {values.by !== "" && values.by === "st" && (
                          <Grid item xs={12} sm={4}>
                            <FormLabel>Select By Status</FormLabel>
                            <Field
                              as="select"
                              name="globalFilterValue"
                              className={globalClasses.formControl}
                            >
                              {({ field }) => (
                                <select
                                  className={globalClasses.formControl}
                                  {...field}
                                >
                                  <option value={""}>Search user status</option>
                                  <option value="1">Activated</option>
                                  <option value="2">DeActivated</option>
                                </select>
                              )}
                            </Field>
                          </Grid>
                        )}
                        {values.by !== "" && values.by === "ut" && (
                          <Grid item xs={12} sm={4}>
                            <FormLabel>Select By User Type</FormLabel>
                            <Field
                              as="select"
                              name="globalFilterValue"
                              className={globalClasses.formControl}
                            >
                              {({ field }) => (
                                <select
                                  className={globalClasses.formControl}
                                  {...field}
                                >
                                  <option value={""}>Search user type</option>
                                  {allowedUserRoles.map((role) => {
                                    return (
                                      <option
                                        key={role.roleID}
                                        value={role.roleID}
                                      >
                                        {role.roleName}
                                      </option>
                                    );
                                  })}
                                </select>
                              )}
                            </Field>
                          </Grid>
                        )}
                      </Grid>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2} justifyContent="flex-end">
                        <Grid item>
                          <Button
                            type="submit"
                            color="primary"
                            size="small"
                            variant="contained"
                            className={globalClasses.primaryBtn}
                            disabled={ceSelected.length < 1}
                          >
                            Search
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            type="reset"
                            size="small"
                            variant="outlined"
                            color="default"
                            className={globalClasses.secondaryBtn}
                            onClick={clearFunction}
                          >
                            Clear
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </div>
              ) : (
                <Button
                  type="submit"
                  variant="contained"
                  className={globalClasses.primaryBtn}
                  onClick={() => {
                    setShowFilters(true);
                  }}
                >
                  Filters
                </Button>
              )}
            </Form>
          )}
        </Formik>
      </Grid>
      <Grid item md={12}>
        {!Co && (
          <Grid item md={12} className={classes.downloadLinkContainer}>
            <Tooltip title={"Download Template"}>
              <span>
                <a
                  className={globalClasses.iconPlusClickableLink}
                  download="User Management Template"
                  disabled
                >
                  <img src={excel} alt="Template" />
                  <span>Download Template</span>
                </a>
              </span>
            </Tooltip>
            {bulkUpload ? (
              <span className={classes.successErrorContainer}>
                {bulkUpload.successMessage && (
                  <span className={classes.uploadSuccess}>
                    <img src={pass} alt="passed" />
                    <p>{bulkUpload.successMessage}</p>
                  </span>
                )}
                {bulkUpload.failureMessage && (
                  <span className={classes.uploadError}>
                    <img src={fail} alt="failed" />
                    <p
                      onClick={() =>
                        dispatch(DownloadErrorFile(bulkUpload.failFilePath))
                      }
                    >
                      {bulkUpload.failureMessage}
                    </p>
                  </span>
                )}
              </span>
            ) : null}
          </Grid>
        )}
      </Grid>
      <Grid item md={12}>
        <Userlist
          Co={Co}
          userExportData={[]}
          coveredentity={cEList}
          userlist={userlist}
          sortBy={sortBy}
          sortorder={sortorder}
          clearButton={clearButton}
          searchClicked={searchClicked}
          searchBy={searchBy}
          globalFilterValue={globalFilterValue}
          filter={filter}
          setFilter={setFilter}
          onChangePagination={onChangePagination}
          onChangeSorting={onChangeSorting}
          onChangeFilter={onChangeFilter}
          page={page}
          setPage={setPage}
          coCeid={coCeid}
          rowsPerPage={rowsPerPage}
          getCeIds={getCeIds}
          defaultFilters={filterValues}
          setAddUserPopupOfCo={setAddUserPopupOfCo}
          setshowfieldsvalues={setshowfieldsvalues}
          showfieldsvalues={showfieldsvalues}
          rowdatauserlist={rowdatauserlist}
          setrowdatauserlist={setrowdatauserlist}
          primarystate={primarystate}
          setprimarystate={setprimarystate}
          onUserAdd={onUserAdd}
        />
      </Grid>
      <Grid item md={12}></Grid>
      <ErrorFileDiscardWarning
        when={errorFileDiscardPopup}
        onOK={() => true}
        onCancel={() => false}
      />
    </Grid>
  );
};

export default PreferredUser;
