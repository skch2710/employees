import React, { useMemo } from "react";
import { useDropzone } from "react-dropzone";
import { CircularBar } from "../../../../../../components/common/ProgressBar/CircularBar";
import DragDropUpload from "../../../../../../assets/dragdropupload.png";
import { ALLOWED_FILE_TYPES } from "./constants";
import { Button, useTheme } from "@material-ui/core";
import { getDroppableStyle, useUploadDocumentStyles } from "./styles";

const FileUploadDroppable = ({ uploadProgress, onUpload, isUploading }) => {
  const theme = useTheme();
  const classes = useUploadDocumentStyles();
  const onDrop = (acceptedFiles) => {
    acceptedFiles.length && onUpload && onUpload(acceptedFiles);
  };

  const {
    getRootProps,
    getInputProps,
    isDragActive,
    isDragAccept,
    isDragReject,
    open,
  } = useDropzone({
    onDrop,
    noClick: true,
    // accept: ALLOWED_FILE_TYPES,
  });

  const style = useMemo(
    () =>
      getDroppableStyle({ isDragActive, isDragReject, isDragAccept, theme }),
    [isDragActive, isDragReject, isDragAccept]
  );

  return (
    <>
      {isUploading ? (
        <div className={classes.progressContainer}>
          <CircularBar
            value={uploadProgress}
            active
            label={`${uploadProgress}%`}
            style={{ color: theme.colors.green[500] }}
          />
        </div>
      ) : (
        <div {...getRootProps({ style })}>
          <input {...getInputProps()} />
          <div className={classes.uploadPlaceholderContainer}>
            <div className={classes.iconContainer}>
              <img src={DragDropUpload} />
              <div>Drag and drop a file here</div>
            </div>
            <span>(OR)</span>
            <div>
              <Button
                className="btn btn-primary text-capitalize"
                color="primary"
                size="small"
                variant="contained"
                onClick={open}
              >
                Choose File
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default FileUploadDroppable;
