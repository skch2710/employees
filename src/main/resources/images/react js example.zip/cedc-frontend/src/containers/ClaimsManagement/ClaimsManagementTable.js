import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import MaterialTable, { MTableToolbar } from "material-table";
import { Button, Grid, Paper, Tooltip, Typography } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { TiFilter } from "react-icons/ti";
import Popup from "../../components/common/DialogBox/Dialogbox";
import TableCustomSortArrow from "../../components/common/TableCustomSortArrow";
import Capture from "./Capture";
import CapturePlusRefills from "./CapturePlusRefills";
import Reprocess from "./Reprocess";
import Uncapture from "./Uncapture";
import UncapturePlusRefills from "./UncapturePlusRefills";
import RxNumberPopup from "./RxNumberPopup";
import Export from "./Export";
import { getUserPreveleges } from "../../utils/common";
import { getRxNumberDetails } from "../../context/actions/ClaimsManagement";
import _isEqual from "lodash/isEqual";
import moment from "moment";
import { LABELS, pagination } from "../../utils/constants";
import { getTableHeaderCount, isEmptyGrid } from "../../utils/helper";
import { useClaimsStyles } from "./style";
import DataNotFound from "../../components/common/DataNotFound";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import useTableIconsAndButtons from "../../components/common/TableIcons";
import TableProgressBar from "../../components/common/TableProgressBar";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../components/common/DatePicker";
import BasicPopup from "../../components/Popup/BasicPopup";
import Pagination from "../../components/common/Pagination";

const ClaimsManagementTable = ({
  patientDOB,
  resetCheckBox,
  selectedRows,
  ceId,
  rowsPerPage,
  onChangePagination,
  onChangeSorting,
  onChangeRowsperpage,
  page,
  sortBy,
  sortOrder,
  capturedFromDate,
  capturedToDate,
  formikValues,
  onChangeFilter,
  defaultFilters,
  showFilter,
  setShowFilter,
  internalUser,
}) => {
  const theme = useTheme();
  const globalClasses = useGlobalStyles();

  const dispatch = useDispatch();
  const { exportClaims } = Export();
  const phiAccess = getUserPreveleges("PHI Access");
  const iconsAndButtons = useTableIconsAndButtons();

  const { loading, records: claimsTableData = {} } =
    useSelector((state) => state.getClaimsListTableData) || {};
  const popupInfo =
    useSelector((state) => state.rxNumberPopupDetails.details) || {};

  const [popupTitle, setPopupTitle] = useState("");
  const [openCapturePopup, setOpenCapturePopup] = useState(false);
  const [openCapturePlusRefillsPopup, setOpenCapturePlusRefillsPopup] =
    useState(false);
  const [openReprocessPopup, setOpenReprocessPopup] = useState(false);
  const [openUncapturePopup, setOpenUncapturePopup] = useState(false);
  const [openUncapturePlusRefillsPopup, setOpenUncapturePlusRefillsPopup] =
    useState(false);
  const [rxNumberPopup, setRxNumberPopup] = useState(false);
  const filterValues = useRef({});
  const classes = useClaimsStyles({
    totalElements: claimsTableData.totalElements,
    pageSize: rowsPerPage,
    pageNumber: page,
  });

  useEffect(() => {
    if (!_isEqual(defaultFilters, filterValues.current)) {
      const updatedObj = {};
      defaultFilters.forEach((eachVal) => {
        updatedObj[eachVal.column.field] = eachVal.value;
      });
      filterValues.current = { ...updatedObj };
    }
  }, [defaultFilters]);

  const setFilterValues = (filterVal) => {
    const updatedObj = {};
    filterVal.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    filterValues.current = { ...updatedObj };
    onChangeFilter(filterVal);
  };

  const handleChangeSelection = (rows) => {
    resetCheckBox(rows);
  };

  const onClickCapture = () => {
    setOpenCapturePopup(true);
    setPopupTitle("Capture");
  };

  const onClickCapturePlusRefills = () => {
    setOpenCapturePlusRefillsPopup(true);
    setPopupTitle("Capture + Refills");
  };

  const onClickReprocess = () => {
    setOpenReprocessPopup(true);
    setPopupTitle("Reprocess");
  };

  const onClickUncapture = () => {
    setOpenUncapturePopup(true);
    setPopupTitle("Uncapture");
  };

  const onClickUncapturePlusRefills = () => {
    setOpenUncapturePlusRefillsPopup(true);
    setPopupTitle("Uncapture + Refills");
  };

  const handleClickRxNumber = (rowData) => {
    setRxNumberPopup(true);
    setPopupTitle("Rx Details");
    dispatch(
      getRxNumberDetails({
        ceId: rowData.ceID,
        claimId: rowData.claimID,
        rxNumber: rowData.rxNumber,
      })
    );
  };

  const handleClickClose = () => {
    dispatch({ type: "RX_NUMBER_DETAILS", data: {} });
    setRxNumberPopup(false);
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const columns = [
    {
      title: "Rx Number",
      field: "rxNumber",
      defaultFilter: showFilter && filterValues.current.rxNumber,
      customFilterAndSearch: () => true,
      cellStyle: {
        ...getTableCellStyles(theme),
        cursor: formikValues.showPatientInformation == "No" ? "" : "pointer",
        color:
          phiAccess.readOnlyFlag && phiAccess.readOnlyFlag
            ? theme.colors.yellow.default
            : theme.colors.blue[500],
      },
      render: (rowData) => {
        return formikValues.showPatientInformation == "No" ? (
          <Tooltip title={rowData.rxNumber}>
            <u>{rowData.rxNumber}</u>
          </Tooltip>
        ) : (
          <Tooltip title={rowData.rxNumber}>
            <u disabled={true} onClick={() => handleClickRxNumber(rowData)}>
              {rowData.rxNumber}
            </u>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.rxNumber}
          placeholder="Rx Number"
        />
      ),
    },
    {
      title: "NDC",
      field: "ndc",
      defaultFilter: showFilter && filterValues.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.ndc}
          placeholder="NDC"
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: showFilter && filterValues.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.drugName}
          placeholder="Drug Name"
        />
      ),
    },
    {
      title: "Savings",
      field: "ceSavings",
      type: "numeric",
      defaultFilter: showFilter && filterValues.current.ceSavings,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceSavings}>
            <span>{rowData.ceSavings}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.ceSavings}
          placeholder="Savings"
        />
      ),
    },
    {
      title: "Patient Name",
      field: "patientName",
      defaultFilter: showFilter && filterValues.current.patientName,
      customFilterAndSearch: () => true,
      cellStyle: {
        ...getTableCellStyles(theme),
        color:
          phiAccess.readOnlyFlag && phiAccess.readOnlyFlag
            ? theme.colors.yellow.default
            : "",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientName}>
            <span>{rowData.patientName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.patientName}
          placeholder="Patient Name"
        />
      ),
    },
    {
      title: "Provider",
      field: "provider",
      defaultFilter: showFilter && filterValues.current.provider,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.provider}>
            <span>{rowData.provider}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.provider}
          placeholder="Provider"
        />
      ),
    },
    {
      title: "Provider NPI",
      field: "providerNPI",
      defaultFilter: showFilter && filterValues.current.providerNPI,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerNPI}>
            <span>{rowData.providerNPI}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerNPI}
          placeholder="Provider NPI"
        />
      ),
    },
    {
      title: "Pharmacy Store",
      field: "pharmacy",
      defaultFilter: showFilter && filterValues.current.pharmacy,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacy}>
            <span>{rowData.pharmacy}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.pharmacy}
          placeholder="Pharmacy Store"
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "pharmacyNPI",
      defaultFilter: showFilter && filterValues.current.pharmacyNPI,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNPI}>
            <span>{rowData.pharmacyNPI}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.pharmacyNPI}
          placeholder="Pharmacy NPI"
        />
      ),
    },
    {
      title: "DOS",
      field: "dos",
      defaultFilter: showFilter && filterValues.current.dos,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dos}>
            <span>{rowData.dos}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.dos ? moment(filterValues.current.dos) : ""
            }
          />
        );
      },
    },
    {
      title: "Captured",
      field: "claimCaptured",
      defaultFilter: showFilter && filterValues.current.claimCaptured,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimCaptured}>
            <span>{rowData.claimCaptured}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.claimCaptured
                ? moment(filterValues.current.claimCaptured)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Claim Status",
      field: "status",
      defaultFilter: showFilter && filterValues.current.status,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.status}>
            <span>{rowData.status}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={filterValues.current.status || ""}
          >
            <option value={""}>Select option</option>
            <option value="Captured">Captured</option>
            <option value="Non-Captured">Non-Captured</option>
          </select>
        );
      },
    },
    {
      title: "Fallout Reason",
      field: "reasons",
      defaultFilter: showFilter && filterValues.current.reasons,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.reasons}>
            <span>{rowData.reasons}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.reasons}
          placeholder="Fallout Reason"
        />
      ),
    },
    {
      title: "Score",
      field: "score",
      defaultFilter: showFilter && filterValues.current.score,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.score}>
            <span>{rowData.score}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.score}
          placeholder="Score"
        />
      ),
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${showFilter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      onClick: () => {
        setShowFilter((prev) => !prev);
      },
      disabled: isEmptyGrid(claimsTableData),
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(claimsTableData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(claimsTableData),
      onClick: () => {
        exportClaims({
          ceId: ceId,
          sortBy: sortBy,
          sortOrder: sortOrder,
          patientDOB: patientDOB,
          capturedFromDate: capturedFromDate,
          capturedToDate: capturedToDate,
          formikValues: formikValues,
          defaultFilters: defaultFilters,
          internalUser: internalUser,
        });
      },
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <Grid container>
        <Grid item md={12}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Data Preview (${getTableHeaderCount(
                  claimsTableData.totalElements
                )})`}
              />
            }
            columns={columns}
            data={claimsTableData.content || []}
            page={page - 1}
            totalCount={claimsTableData.totalElements}
            onChangePage={onChangePagination}
            onOrderChange={onChangeSorting}
            onSelectionChange={(rows) => handleChangeSelection(rows)}
            onFilterChange={(val) => {
              setFilterValues(val);
            }}
            actions={Actions}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
              },
            }}
            icons={{
              SortArrow: () => TableCustomSortArrow({ sortOrder }),
              Filter: ColumnFilterIcon,
            }}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  color="primary"
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: showFilter,
              paginationType: "stepped",
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableActionCellStyles(theme),
              tableLayout: "auto",
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: rowsPerPage,
              selection: true,
              showTextRowsSelected: false,
              draggable: false,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              doubleHorizontalScroll: false,
              pageSizeOptions: isEmptyGrid(claimsTableData)
                ? []
                : pagination.pageSizeOptions,
            }}
          />
        </Grid>
        {selectedRows.length > 0 ? (
          <Grid item md={12}>
            <div className={classes.claimsTableFooterActionsContainer}>
              <Grid container spacing={2} alignItems="center">
                <Grid item>
                  <Typography>
                    {`
                    ${selectedRows.length} ${
                      selectedRows.length === 1 ? "record" : "records"
                    } selected from listed 
                    ${claimsTableData.content.length}`}
                  </Typography>
                </Grid>
                <Grid item>
                  <Grid container spacing={2}>
                    <Grid item>
                      <Button
                        disabled
                        className={globalClasses.secondaryBtn}
                        variant="outlined"
                        size="small"
                        onClick={onClickCapture}
                      >
                        Capture
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        disabled
                        className={globalClasses.secondaryBtn}
                        variant="outlined"
                        size="small"
                        onClick={onClickCapturePlusRefills}
                      >
                        Capture + Refills
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        disabled
                        className={globalClasses.secondaryBtn}
                        variant="outlined"
                        size="small"
                        onClick={onClickReprocess}
                      >
                        Reprocess
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        disabled
                        className={globalClasses.secondaryBtn}
                        variant="outlined"
                        size="small"
                        onClick={onClickUncapture}
                      >
                        Uncapture
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        disabled
                        className={globalClasses.secondaryBtn}
                        variant="outlined"
                        size="small"
                        onClick={onClickUncapturePlusRefills}
                      >
                        Uncapture + Refills
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </div>
          </Grid>
        ) : null}
      </Grid>

      {rxNumberPopup && (
        <BasicPopup
          show={rxNumberPopup}
          title={popupTitle}
          disableFooter={true}
          handleClose={() => handleClickClose()}
          dialogProps={{
            maxWidth: "lg",
            classes: {
              paper: classes.rxPopupPaper,
            },
          }}
        >
          <RxNumberPopup handleClose={handleClickClose} popupInfo={popupInfo} />
        </BasicPopup>
      )}

      <Popup
        title={popupTitle}
        openPopup={openCapturePopup}
        setOpenPopup={setOpenCapturePopup}
        maxWidth="lg"
      >
        <Capture setOpenCapturePopup={setOpenCapturePopup} />
      </Popup>

      {/*  Capture plus Refills popup */}
      <Popup
        title={popupTitle}
        openPopup={openCapturePlusRefillsPopup}
        setOpenPopup={setOpenCapturePlusRefillsPopup}
        maxWidth="lg"
      >
        <CapturePlusRefills
          setOpenCapturePlusRefillsPopup={setOpenCapturePlusRefillsPopup}
        />
      </Popup>

      {/*  Reprocess popup */}
      <Popup
        title={popupTitle}
        openPopup={openReprocessPopup}
        setOpenPopup={setOpenReprocessPopup}
        maxWidth="lg"
      >
        <Reprocess setOpenReprocessPopup={setOpenReprocessPopup} />
      </Popup>

      {/*  Uncapture popup */}
      <Popup
        title={popupTitle}
        openPopup={openUncapturePopup}
        setOpenPopup={setOpenUncapturePopup}
        maxWidth="lg"
      >
        <Uncapture setOpenUncapturePopup={setOpenUncapturePopup} />
      </Popup>

      {/*  Uncapture plus Refills popup */}
      <Popup
        title={popupTitle}
        openPopup={openUncapturePlusRefillsPopup}
        setOpenPopup={setOpenUncapturePlusRefillsPopup}
        maxWidth="lg"
      >
        <UncapturePlusRefills
          setOpenUncapturePlusRefillsPopup={setOpenUncapturePlusRefillsPopup}
        />
      </Popup>
    </div>
  );
};
export default ClaimsManagementTable;
