import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip } from "@material-ui/core";
import { usePatientStyles } from "./style";
import { useTheme } from "@material-ui/core/styles";
import AddPatientForm from "../Patients/AddEditPatient/AddPatientForm";
import PatientVisitInfoTable from "./PatientVisitInfoTable";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import LoaderUI from "../../../components/common/Loader/Loader";
import BasicPopup from "../../../components/Popup/BasicPopup";
import VisitInformation from "./AddEditPatient/VisitInformation";
import ExportPatient from "./ExportPatient";
import { getEditPatientData } from "../../../context/actions/Patients";
import { POLLING_COUNT, pagination } from "../../../utils/constants";
import { getUserPreveleges, userdata } from "../../../utils/common";
import { addPatientDefaultValues } from "./constant";
import _ from "lodash";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import { getServiceConfigLookup } from "../../../context/actions/ConfigOverview";
import {
  deletePatient,
  deletePatientMessageUUID,
  getPatientSearchData,
} from "../../../context/actions/Patients";
import { GET_PATIENT_INNER_LIST } from "../../../context/reducers/Patients/constants";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
  getTableActionCellStyles,
} from "../../../Styles/useGlobalStyles";
import { getTableHeaderCount, isEmptyGrid } from "../../../utils/helper";
import TableProgressBar from "../../../components/common/TableProgressBar";
import DataNotFound from "../../../components/common/DataNotFound";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../components/common/Pagination";

const PatientslistTable = ({
  searchFormRef,
  controller,
  patientSearchData,
  patients,
  onChangePagination,
  onChangeSorting,
  onChangeFilter,
  Co,
  permissionObj,
  ceList,
  defaultFilters,
  patientPermission,
  openPopup,
  setOpenPopup,
  setActionTitle,
  setSubmitActionType,
  submitActionType,
  actionTitle,
}) => {
  const globalClasses = useGlobalStyles();
  const phiAccess = getUserPreveleges("PHI Access");
  const classes = usePatientStyles({
    totalElements: !_isEmpty(patients) && patients.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.pageNumber,
  });
  const theme = useTheme();
  const dispatch = useDispatch();
  const iconsAndButtons = useTableIconsAndButtons();
  const filterValues = useRef({});
  const userRole = JSON.parse(userdata());
  const { exportMemberToExcel } = ExportPatient();
  const [filter, setFilter] = useState(false);
  const [openPatientInfoPopup, setOpenPatientInfoPopup] = useState(false);
  const [openAddVisitPopup, setOpenAddVisitPopup] = useState(false);
  const [recordForEdit, setRecordForEdit] = useState(null);
  const [isVisitDateExist, setIsVisitDateExist] = useState("");

  const addPatientLoading = useSelector((state) => state.addPatient.loading);
  const patientsLoading = useSelector((state) => state.patients.loading);
  const membersLoading = useSelector((state) => state.coMembers.loading);

  const closePopup = () => {
    setOpenPopup(false);
    setOpenAddVisitPopup(false);
    setIsVisitDateExist("");
  };

  useEffect(() => {
    if (!_.isEqual(defaultFilters, filterValues.current)) {
      const updatedObj = {};
      defaultFilters &&
        defaultFilters.forEach((eachVal) => {
          updatedObj[eachVal.column.field] = eachVal.value;
        });
      filterValues.current = { ...updatedObj };
    }
  }, [defaultFilters]);

  const setFilterValues = (filterVal) => {
    const updatedObj = {};
    filterVal.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    filterValues.current = { ...updatedObj };
    onChangeFilter(filterVal);
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const columns = [
    {
      title: "Patient Status",
      field: "status",
      defaultFilter: filter && filterValues.current.status,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.status}>
            <span>{rowData.status}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={filterValues.current.status || ""}
          >
            <option value={""}>Select option</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        );
      },
    },
    {
      title: "MRN",
      field: "mrn",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.mrn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.mrn}>
            <span>{rowData.mrn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.mrn}
          placeholder="MRN"
        />
      ),
    },
    {
      title: "Patient First Name",
      field: "firstName",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.firstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.firstName}>
            <span>{rowData.firstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.firstName}
          placeholder="Patient First Name"
        />
      ),
    },

    {
      title: "Patient Middle Name",
      field: "middleName",
      defaultFilter: filter && filterValues.current.middleName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.middleName}>
            <span>{rowData.middleName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.middleName}
          placeholder="Patient Middle Name"
        />
      ),
    },
    {
      title: "Patient Last Name",
      field: "lastName",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.lastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastName}>
            <span>{rowData.lastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.lastName}
          placeholder="Patient Last Name"
        />
      ),
    },

    {
      title: "Suffix",
      field: "suffix",
      defaultFilter: filter && filterValues.current.suffix,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.suffix}>
            <span>{rowData.suffix}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.suffix}
          placeholder="Suffix"
        />
      ),
    },
    {
      title: "Patient DOB",
      field: "dob",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.dob,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dob}>
            <span>{rowData.dob}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.dob ? moment(filterValues.current.dob) : ""
            }
          />
        );
      },
    },
    {
      title: "Gender",
      field: "gender",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter: filter && filterValues.current.gender,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.gender}>
            <span>{rowData.gender}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.gender}
          placeholder="Gender"
        />
      ),
    },
    {
      title: "Exclude",
      field: "patientType",
      defaultFilter: filter && filterValues.current.patientType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientType}>
            <span>{rowData.patientType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={filterValues.current.patientType || ""}
          >
            <option value={""}>Select option</option>
            <option value="Excluded">Yes</option>
            <option value="Included">No</option>
          </select>
        );
      },
    },
    {
      title: "Sliding Fee Scale Category",
      field: "slidingScaleIndicator",
      defaultFilter: filter && filterValues.current.slidingScaleIndicator,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.slidingScaleIndicator}>
            <span>{rowData.slidingScaleIndicator}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.slidingScaleIndicator}
          placeholder="Sliding Fee Scale Category"
        />
      ),
    },

    {
      title: "Sliding Fee Scale Effective Date",
      field: "slidingScaleEffectiveDate",
      defaultFilter: filter && filterValues.current.slidingScaleEffectiveDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.slidingScaleEffectiveDate}>
            <span>{rowData.slidingScaleEffectiveDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.slidingScaleEffectiveDate
                ? moment(filterValues.current.slidingScaleEffectiveDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Admit/Visit Date",
      field: "startDate",
      defaultFilter: filter && filterValues.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.startDate
                ? moment(filterValues.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Recent Visit Date",
      field: "recentVisitDate",
      defaultFilter: filter && filterValues.current.recentVisitDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.recentVisitDate}>
            <span>{rowData.recentVisitDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.recentVisitDate
                ? moment(filterValues.current.recentVisitDate)
                : ""
            }
          />
        );
      },
    },

    {
      title: "Eligibility Termination Date",
      field: "endDate",
      defaultFilter: filter && filterValues.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.endDate
                ? moment(filterValues.current.endDate)
                : ""
            }
          />
        );
      },
    },

    {
      title: "Last Modified Date",
      field: "lastModifiedDate",
      defaultFilter: filter && filterValues.current.lastModifiedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastModifiedDate}>
            <span>{rowData.lastModifiedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.lastModifiedDate
                ? moment(filterValues.current.lastModifiedDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const coColumns = [
    {
      title: "Covered Entity",
      field: "coveredEntity",
      defaultFilter: filter && filterValues.current.coveredEntity,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity}>
            <span>{rowData.coveredEntity}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.coveredEntity}
          placeholder="Covered Entity"
        />
      ),
    },
    {
      title: "HRSA ID",
      field: "id340b",
      defaultFilter: filter && filterValues.current.id340b,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.id340b}>
            <span>{rowData.id340b}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.id340b}
          placeholder="HRSA ID"
        />
      ),
    },
    {
      title: "MRN",
      field: "mrn",
      defaultFilter: filter && filterValues.current.mrn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.mrn}>
            <span>{rowData.mrn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.mrn}
          placeholder="MRN"
        />
      ),
    },
    {
      title: "Patient First Name",
      field: "firstName",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.firstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.firstName}>
            <span>{rowData.firstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.firstName}
          placeholder="Patient First Name"
        />
      ),
    },
    {
      title: "Patient Middle Name",
      field: "middleName",
      defaultFilter: filter && filterValues.current.middleName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.middleName}>
            <span>{rowData.middleName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.middleName}
          placeholder="Patient Middle Name"
        />
      ),
    },

    {
      title: "Patient Last Name",
      field: "lastName",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.lastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastName}>
            <span>{rowData.lastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.lastName}
          placeholder="Patient Last Name"
        />
      ),
    },

    {
      title: "Suffix",
      field: "suffix",
      defaultFilter: filter && filterValues.current.suffix,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.suffix}>
            <span>{rowData.suffix}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.suffix}
          placeholder="Suffix"
        />
      ),
    },

    {
      title: "Patient DOB",
      field: "dob",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },
      defaultFilter: filter && filterValues.current.dob,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dob}>
            <span>{rowData.dob}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.dob ? moment(filterValues.current.dob) : ""
            }
          />
        );
      },
    },
    {
      title: "Gender",
      field: "gender",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: theme.colors.yellow.default,
      },

      defaultFilter: filter && filterValues.current.gender,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.gender}>
            <span>{rowData.gender}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.gender}
          placeholder="Gender"
        />
      ),
    },
    {
      title: "Admit/Visit Date",
      field: "visitDate",
      defaultFilter: filter && filterValues.current.visitDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.visitDate}>
            <span>{rowData.visitDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.visitDate}
          placeholder="Visit Date"
        />
      ),
    },
    {
      title: "Hospital Service",
      field: "hospitalService",
      defaultFilter: filter && filterValues.current.hospitalService,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.hospitalService}>
            <span>{rowData.hospitalService}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.hospitalService}
          placeholder="Hospital Service"
        />
      ),
    },
    {
      title: "Admit Type",
      field: "admitType",
      defaultFilter: filter && filterValues.current.admitType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.admitType}>
            <span>{rowData.admitType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.admitType}
          placeholder="Admit Type"
        />
      ),
    },
    {
      title: "Servicing Facility",
      field: "servicingFacility",
      defaultFilter: filter && filterValues.current.servicingFacility,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.servicingFacility}>
            <span>{rowData.servicingFacility}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.servicingFacility}
          placeholder="Servicing Facility"
        />
      ),
    },
    {
      title: "Assigned Patient Location",
      field: "assignedPatientLocation",
      defaultFilter: filter && filterValues.current.assignedPatientLocation,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.assignedPatientLocation}>
            <span>{rowData.assignedPatientLocation}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.assignedPatientLocation}
          placeholder="Assigned Patient Location"
        />
      ),
    },
    {
      title: "Sliding Scale Category",
      field: "slidingScaleIndicator",
      defaultFilter: filter && filterValues.current.slidingScaleIndicator,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.slidingScaleIndicator}>
            <span>{rowData.slidingScaleIndicator}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.slidingScaleIndicator}
          placeholder="Sliding Scale Category"
        />
      ),
    },

    {
      title: "Sliding Scale Effective Date",
      field: "slidingScaleEffectiveDate",
      defaultFilter: filter && filterValues.current.slidingScaleEffectiveDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.slidingScaleEffectiveDate}>
            <span>{rowData.slidingScaleEffectiveDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.slidingScaleEffectiveDate
                ? moment(filterValues.current.slidingScaleEffectiveDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Provider FN",
      field: "providerFn",
      defaultFilter: filter && filterValues.current.providerFn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerFn}>
            <span>{rowData.providerFn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerFn}
          placeholder="Provider FN"
        />
      ),
    },
    {
      title: "Provider LN",
      field: "providerLn",
      defaultFilter: filter && filterValues.current.providerLn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerLn}>
            <span>{rowData.providerLn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerLn}
          placeholder="Provider LN"
        />
      ),
    },
    {
      title: "Provider DEA",
      field: "prescriberDea",
      defaultFilter: filter && filterValues.current.prescriberDea,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.prescriberDea}>
            <span>{rowData.prescriberDea}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.prescriberDea}
          placeholder="Provider DEA"
        />
      ),
    },
    {
      title: "Provider NPI",
      field: "providerNpi",
      defaultFilter: filter && filterValues.current.providerNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerNpi}>
            <span>{rowData.providerNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerNpi}
          placeholder="Provider NPI"
        />
      ),
    },
    {
      title: "Provider SPI",
      field: "providerSpi",
      defaultFilter: filter && filterValues.current.providerSpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerSpi}>
            <span>{rowData.providerSpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerSpi}
          placeholder="Provider SPI"
        />
      ),
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(patients),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(patients),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(patients),
      onClick: () => {
        const exportPayload = getPatientListPayload();
        dispatch(
          getPatientSearchData({ ...exportPayload, export: true }, false)
        );
      },
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip:
        patientPermission !== undefined &&
        patientPermission !== null &&
        !patientPermission.readWriteFlag
          ? "You don't have Permission."
          : "",
      isFreeAction: true,
      disabled: true,
    },
    {
      icon: iconsAndButtons.Plus(),
      tooltip: "Patient Visit Info",
      isFreeAction: false,
      onClick: (_e, rowData) => {
        setRecordForEdit(rowData);
        setActionTitle("Patient Visit Details");
        setOpenPatientInfoPopup(true);
      },
    },
    {
      icon: iconsAndButtons.HandShakeIcon(),
      tooltip:
        patientPermission &&
        patientPermission !== null &&
        !patientPermission.readWriteFlag
          ? "You don't have Permission."
          : "Add Visit",
      isFreeAction: false,
      disabled:
        patientPermission &&
        patientPermission !== null &&
        patientPermission.readWriteFlag
          ? false
          : true,
      onClick: (_e, rowData) => {
        setActionTitle("Add Visit");
        setRecordForEdit({ ...addPatientDefaultValues(), ...rowData });
        setOpenAddVisitPopup(true);
        dispatch(getServiceConfigLookup({ ceid: rowData.ceid }));
      },
    },
    {
      icon: iconsAndButtons.View(),
      tooltip:
        patientPermission !== null && !patientPermission.readOnlyFlag
          ? "You don't have Permission."
          : "View",
      isFreeAction: false,
      disabled:
        patientPermission !== null && patientPermission.readOnlyFlag
          ? false
          : true,
      onClick: (_e, rowData) => {
        setOpenPopup(true);
        dispatch(
          getEditPatientData(rowData.patientId, (res) => {
            if (res.statusCode === 200 && res.data != null) {
              setRecordForEdit({ ...res.data, status: rowData.status });
            }
          })
        );
        setActionTitle("View Patient");
        setSubmitActionType("View Patient");
      },
    },
    {
      icon: iconsAndButtons.Edit(),
      tooltip:
        patientPermission &&
        patientPermission !== null &&
        !patientPermission.readWriteFlag
          ? "You don't have Permission."
          : "Edit",
      isFreeAction: false,
      disabled:
        patientPermission &&
        patientPermission !== null &&
        patientPermission.readWriteFlag
          ? false
          : true,
      onClick: (_e, rowData) => {
        setOpenPopup(true);
        dispatch(
          getEditPatientData(rowData.patientId, (res) => {
            if (res.statusCode === 200 && res.data != null) {
              setRecordForEdit({ ...res.data, status: rowData.status });
            }
          })
        );
        setActionTitle(`Edit Patient`);
        setSubmitActionType("Save");
      },
    },

    (rowData) => {
      const isTerminated =
        moment(rowData.endDate).isAfter(new Date()) || rowData.endDate === null
          ? false
          : true;
      const payload = {
        ...rowData,
        modifiedBy: userRole.userId,
      };
      return {
        icon: iconsAndButtons.Block({ isBlocked: isTerminated }),
        tooltip:
          patientPermission &&
          patientPermission !== null &&
          patientPermission.terminateFlag
            ? "You don't have Permission."
            : isTerminated
            ? "Terminated"
            : "Terminate",
        isFreeAction: false,
        disabled:
          !isTerminated &&
          patientPermission &&
          patientPermission !== null &&
          !patientPermission.terminateFlag
            ? false
            : true,
        onClick: async (_e, rowData) => {
          const resp = await dispatch(deletePatient(payload));
          if (!_isEmpty(resp) && resp.data) {
            handlePolling({
              messageUUid: resp.data,
              currentCount: POLLING_COUNT,
              rowData,
            });
          }
        },
      };
    },
  ];

  const handlePolling = async ({ messageUUid, currentCount, rowData }) => {
    const count = currentCount;
    const resp = await dispatch(deletePatientMessageUUID(messageUUid, count));
    if (resp && resp.statusCode === 200) {
      setOpenPopup(false);
      fetchPatientsList(rowData);
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    }
  };
  const getPatientListPayload = () => {
    const {
      ceid,
      dob,
      firstName,
      lastName,
      startDate,
      endDate,
      mrn,
      patientType,
      sortBy,
      sortOrder,
      pageNumber,
      pageSize,
      status
    } = patientSearchData || {};
    return {
      ceid: ceid,
      dob: dob,
      endDate: endDate,
      firstName: firstName,
      lastName: lastName,
      export: false,
      mrn: mrn,
      sortBy: sortBy,
      sortOrder: sortOrder,
      pageNumber: pageNumber,
      pageSize: pageSize,
      startDate: startDate,
      patientType: patientType,
      filter: defaultFilters,
      status: status
    };
  };

  const fetchPatientsList = () => {
    const patientPayload = getPatientListPayload();
    dispatch(getPatientSearchData(patientPayload, false));
  };

  const ActionsCo = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(patients),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(patients),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(patients),
      onClick: () =>
        exportMemberToExcel({
          patientSearchData: patientSearchData,
          defaultFilters: defaultFilters,
          Co: Co,
        }),
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip:
        permissionObj !== undefined &&
        permissionObj !== null &&
        !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : "",
      isFreeAction: true,
      disabled: true,
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      {addPatientLoading ? <LoaderUI /> : ""}
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`${Co ? "Patients" : "Patients"} List (${getTableHeaderCount(
              patients.totalElements
            )})`}
          />
        }
        columns={Co ? coColumns : columns}
        data={patients.content || []}
        page={controller.pageNumber - 1}
        totalCount={patients.totalElements}
        onChangePage={(page, pageSize) =>
          onChangePagination(page, pageSize, controller)
        }
        onOrderChange={onChangeSorting}
        onFilterChange={(val) => {
          setFilterValues(val);
        }}
        actions={Co ? ActionsCo : Actions}
        icons={{
          SortArrow: () => TableCustomSortArrow(controller),
          Filter: ColumnFilterIcon,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              {...props}
              classes={{ root: globalClasses.gridMuiToolbar }}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: !Co && "Actions",
          },
          body: {
            emptyDataSourceMessage: !(patientsLoading || membersLoading) ? (
              <DataNotFound />
            ) : (
              ""
            ),
          },
        }}
        isLoading={patientsLoading || membersLoading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: filter,
          paginationType: "stepped",
          paging: "true",
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controller && controller.pageSize,
          draggable: false,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          doubleHorizontalScroll: false,
          pageSizeOptions: isEmptyGrid(patients)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
      <BasicPopup
        title={`${actionTitle}`}
        show={openPatientInfoPopup}
        handleClose={() => {
          setOpenPatientInfoPopup(false);
          dispatch({
            type: GET_PATIENT_INNER_LIST,
            data: [],
          });
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
      >
        <PatientVisitInfoTable patientRowData={recordForEdit} />
      </BasicPopup>
      <BasicPopup
        title={`${actionTitle}`}
        show={openAddVisitPopup}
        handleClose={() => {
          closePopup();
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper: classes.AddVisitDialogPaper,
          },
        }}
      >
        <VisitInformation
          title={actionTitle}
          formData={recordForEdit}
          setOpenPopup={(val) => {
            if (!val) {
              setIsVisitDateExist("");
            }
            setOpenAddVisitPopup(val);
          }}
          recordForEdit={recordForEdit}
          isVisitDateExist={isVisitDateExist}
          setIsVisitDateExist={setIsVisitDateExist}
          patientSearchData={patientSearchData}
          defaultFilters={defaultFilters}
        />
      </BasicPopup>
      <BasicPopup
        title={`${actionTitle}`}
        show={openPopup}
        handleClose={() => {
          closePopup();
          dispatch({
            type: GET_PATIENT_INNER_LIST,
            data: [],
          });
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
      >
        <AddPatientForm
          searchFormRef={searchFormRef}
          ceList={ceList}
          submitActionType={submitActionType}
          setOpenPopup={setOpenPopup}
          recordForEdit={recordForEdit}
          title={actionTitle}
          patientSearchData={patientSearchData}
          defaultFilters={defaultFilters}
          isVisitDateExist={isVisitDateExist}
          setIsVisitDateExist={setIsVisitDateExist}
        />
      </BasicPopup>
    </div>
  );
};
export default PatientslistTable;
