import moment from "moment";
import {
  ALL_ADDITIONAL_DATE_FILTER_OPTION,
  LIMITED_ADDITIONAL_DATE_FILTER_OPTION,
  QUARTER_OPTIONS,
} from "./constants";

export const getAdditionalDateFilterOptions = (year) => {
  const currentYear = new Date().getFullYear();
  if (Number(year) === currentYear) {
    return ALL_ADDITIONAL_DATE_FILTER_OPTION;
  }
  return LIMITED_ADDITIONAL_DATE_FILTER_OPTION;
};

export const getMonthsList = (selectedYear = "") => {
  const months = moment.months();
  let monthsOptions = months.map((month, index) => ({
    month: month,
    value: index + 1,
  }));
  const currentYear= moment().year();
  if (Number(selectedYear) === Number(currentYear)) {
    const currentMonth = moment().month() + 1;
    monthsOptions = monthsOptions.filter((month) => month.value <= currentMonth);
  }
  return monthsOptions || [];
};

export const getQuartersList = (selectedYear = "") => {
  let quarters = QUARTER_OPTIONS;
  const currentYear = moment().year();
  if (Number(selectedYear) === currentYear) {
    const currentQuarter = moment().quarter();
    quarters = quarters.slice(0, currentQuarter);
  }
  return quarters || [];
};

export const getPoInfoFiltersObject = (filters) => {
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: filter.column.field === "ndc" ? "contains" : "startWith",
      value: filter.value,
    };
  });
};
export const getPoHistoryFiltersObject = (filters) => {
  const equalsToFields = ["poDate", "poStatusDate", "createdDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: equalsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getPoClaimsFiltersObject = (filters) => {
  const equalToFields = ["invoiceDate340BDirect", "dateOfService"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: equalToFields.includes(filter.column.field)
        ? "="
        : filter.column.field === "ndc"
        ? "contains"
        : "startWith",
      value: filter.value,
    };
  });
};

export const getPoItemHistoryFiltersObject = (filters) => {
  const dateFieldsArray = [
    "itemOrderedDate",
    "itemAcknowledgedDate",
    "itemInvoicedDate",
    "itemReconciledDate",
    "createdDate",
  ];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFieldsArray.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getPoFiltersObject = (filters) => {
  const numericFieldsArray = ["poDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: numericFieldsArray.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getTodayDatePayload = (option) => {
  return option && option.value === "today"
    ? {
        poStartDate: moment().format("MM/DD/YYYY"),
        poEndDate: moment().format("MM/DD/YYYY"),
      }
    : {};
};

export const getScheduleTypeIds = (values) => {
  return values && values.length
    ? { drugDEAClassID: values.map((drug) => drug.drugDEAClassID) }
    : {};
};
