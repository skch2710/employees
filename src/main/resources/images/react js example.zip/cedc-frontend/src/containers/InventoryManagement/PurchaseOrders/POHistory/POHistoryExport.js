import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { getPOHistoryExport } from "../../../../context/actions/PurchaseOrders";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { notNull } from "../../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { PO_HISTORY_EXPORT_FILE_NAME } from "../constants";
import { usePOStyles } from "../styles";

const POHistoryExport = ({ po, controller, count, columnFilters }) => {
  const { poID, poItemID } = po || {};
  const dispatch = useDispatch();
  const classes = usePOStyles();
  const [values, setValues] = useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    FileSaver.saveAs(fileData, PO_HISTORY_EXPORT_FILE_NAME + ".xlsx");
  };

  const ExportToPDF = (data) => {
    const headers = data.map((items) => {
      return {
        "PO Date": Object.keys(items)[0],
        "PO Status": Object.keys(items)[1],
        Reason: Object.keys(items)[2],
        "PO Status Date": Object.keys(items)[3],
        "810 Invoice Number": Object.keys(items)[4],
        "EDI 855 File Count": Object.keys(items)[5],
        "EDI 810 File Count": Object.keys(items)[6],
        "Created Date": Object.keys(items)[7],
        "Created By": Object.keys(items)[8],
      };
    });
    const dataRows = data.map((i) => Object.values(i));
    return { headers, dataRows };
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
      getPOHistoryExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          poItemID: poItemID,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              poDate,
              poStatus,
              reasonDesc,
              poStatusDate,
              invoiceNumber,
              edi855FileCount,
              edi810FileCount,
              createdDate,
              createdByID,
            }) => ({
              "PO Date": notNull(poDate),
              "PO Status": notNull(poStatus),
              Reason: notNull(reasonDesc),
              "PO Status Date": notNull(poStatusDate),
              "810 Invoice Number": notNull(invoiceNumber),
              "EDI 855 File Count": notNull(edi855FileCount),
              "EDI 810 File Count": notNull(edi810FileCount),
              "Created Date": notNull(createdDate),
              "Created By": notNull(createdByID),
            })
          );
          if (e.target.value == "excel") {
            ExportToExcel(data);
            setValues("");
          }
          if (e.target.value == "pdf") {
            const { headers, dataRows } = ExportToPDF(data);
            const doc = new jsPDF();
            doc.autoTable({
              head: [headers[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...dataRows],
            });
            doc.save(`${PO_HISTORY_EXPORT_FILE_NAME}.pdf`);
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset
        disabled={count > 0 ? false : true}
        className={classes.exportContainer}
      >
        <select
          className={classes.exportSelect}
          onChange={handleChange}
          value={values}
        >
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default POHistoryExport;
