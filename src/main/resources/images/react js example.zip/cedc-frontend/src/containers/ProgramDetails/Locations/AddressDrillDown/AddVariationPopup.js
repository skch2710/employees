import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  Button,
  FormLabel,
  Typography,
  FormControlLabel,
} from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import { getAddVariationPopupDefaultValues } from "../constants";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import {
  addLocation,
  getlocationHrsaIdExist,
  getLocationList,
} from "../../../../context/actions/Locations";
import LoaderUI from "../../../../components/common/Loader/Loader";
import _isEqual from "lodash/isEqual";
import _isArray from "lodash/isArray";
import { REGEX } from "../../../../utils/constants";
import Toggle from "../../../../components/common/Toggle";
import { getUserSession } from "../../../../utils/helper";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import { useLocationStyles } from "../styles";
import {
  endDateValidation,
  startDateValidation,
} from "../../../../utils/common";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import AutoComplete from "../../../../components/common/AutoComplete";

const AddVariationPopup = ({
  setOpenPopup,
  selectedLocation,
  title,
  getSearchTableData,
}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const classes = useLocationStyles();

  const defaultValues = getAddVariationPopupDefaultValues(
    (selectedLocation && selectedLocation) || {}
  );
  const stateList = useSelector((state) => state.ce_states_list.records) || [];
  const stateName =
    stateList &&
    stateList.find((itm) => itm.stateName === defaultValues.stateName);
  const initialValues = stateList && {
    ...defaultValues,
    stateId: stateName && stateName.stateId,
  };
  const coveredentity =
    useSelector((state) => state.getCoveredEntity.records) || [];
  const [ceList, secEList] = useState(coveredentity);
  const [ceHrsaIdExist, setHrsaIdExist] = useState("");
  const [isEdit, setIsEdit] = useState(title === "Edit Address Variation");

  const loader = useSelector(
    (state) => state.getLocationListDataValues.loading
  );

  const userSession = getUserSession();

  const checkInputZipCode = (e, formik) => {
    const { name, value } = e.target;
    const regEx = REGEX.onlyNumbers;
    if (value && !regEx.test(value)) return;
    formik.setFieldValue(name, value);
  };

  const onDateChange = (name, value, formik) => {
    if (name === "startDate" && value === "")
      formik.setTouched({ startDate: true });
    formik.setFieldValue(name, value);
  };

  const handleLoacationName = (e, formik) => {
    const regEx = REGEX.alphabetsAndHypen;
    const { name, value } = e.target;
    if (value && regEx.test(value)) return;
    formik.setFieldValue(name, value);
  };

  const handleLoacationHRSAID = (e, formik) => {
    const regEx = /^\s+|\s{2,}$/g;
    const { name, value } = e.target;
    // let isNewLocationHrsaId =
    //   selectedLocation !== null
    //     ? !_isEqual(selectedLocation.locationHrsaId, value)
    //     : true;
    if (value && regEx.test(value)) return;
    formik.setFieldValue(name, value);
    if (value) {
      dispatch(
        getlocationHrsaIdExist(
          { ceId: selectedLocation.ceid, hrsaId: value },
          (res) => {
            if (res.statusCode == 404) setHrsaIdExist(res.errorMessage);
            if (res.statusCode == 200) setHrsaIdExist("");
          }
        )
      );
    }
  };

  const handleSubmit = (values) => {
    saveLocation(values);
  };

  const saveLocation = (inputValues) => {
    const payload = {
      ceid: inputValues.ceid ? inputValues.ceid : selectedLocation.ceid,
      entityLocationId: 0,
      locationName: inputValues.locationName,
      locationHrsaId: inputValues.locationHrsaId,
      addressLine1: inputValues.addressLine1,
      addressLine2: inputValues.addressLine2,
      city: inputValues.city,
      endDate: inputValues.endDate,
      startDate: inputValues.startDate,
      zipCode: inputValues.zipCode,
      stateId: parseInt(inputValues.stateId),
      is340bSite: true,
      locSourceId: 1,
      modifiedById: userSession.userId,
      modifiedDate: moment(new Date()).format("MM/DD/YYYY"),
      standardAddress1: inputValues.standardPrescriberAddress1 || "",
      standardAddress2: inputValues.standardPrescriberAddress2 || "",
      standardCity: inputValues.standardPrescriberCity || "",
      standardState: inputValues.standardPrescriberState || "",
      standardZip: inputValues.standardPrescriberZip || "",
      addrHashKey: inputValues.nonStandardHashKey || "",
      standardAddrHashKey: inputValues.standardPrescriberAddrHashKey || "",
      parent: selectedLocation.entityLocationId,
      createdById: userSession.userId,
    };
    dispatch(
      addLocation(payload, (res) => {
        if (res.statusCode === 200) {
          getSearchTableData();
          setOpenPopup(false);
        }
      })
    );
  };

  const formValidate = (values) => {
    const errors = {};

    if (values.ceName === "") {
      errors.ceName = "Please select the Covered Entity";
    }
    if (values.locationName === "") {
      errors.locationName = "Please enter the Location Name";
    }
    if (values.locationHrsaId === "") {
      setHrsaIdExist("");
      errors.locationHrsaId = "Please enter the Location HRSA ID";
    }
    if (!(ceHrsaIdExist === "")) {
      errors.locationHrsaId = ceHrsaIdExist;
    }
    if (values.locationHrsaId.length > 15) {
      setHrsaIdExist("");
      errors.locationHrsaId =
        "Location HRSA ID must be less than 15 characters";
    }
    if (values.addressLine1 === "") {
      errors.addressLine1 = "Please enter the Address Line 1";
    }
    if (values.city === "") {
      errors.city = "Please enter the City";
    }
    if (!values.stateId) {
      errors.stateId = "Please select the State";
    }
    if (values.zipCode.length < 5) {
      errors.zipCode = "Please enter the 5 digit Zip Code only";
    }
    if (values.startDate === "") {
      errors.startDate = "Please select the OPA Location Start Date";
    }
    return errors;
  };
  useEffect(() => {
    secEList(userSession.coveredEntityDTOs);
  }, []);

  const handleChange = (e, formik) => {
    const regEx = /^\s+|\s{2,}$/g;
    const { name, value } = e.target;
    if (value && regEx.test(value)) return;
    formik.setFieldValue(name, value);
  };

  return (
    <>
      {loader ? <LoaderUI /> : ""}
      <Formik
        enableReinitialize={true}
        initialValues={initialValues}
        validate={formValidate}
        onSubmit={handleSubmit}
      >
        {(formik) => {
          return (
            <Form>
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={4}>
                      <FormLabel>Covered Entity</FormLabel>

                      <Field
                        name="coveredEntityName"
                        id="coveredEntityName"
                        type="text"
                        className={globalClasses.formControl}
                        disabled
                        value={
                          (selectedLocation &&
                            selectedLocation.coveredEntity) ||
                          formik.values.coveredEntityName
                        }
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <FormLabel>Covered Entity HRSA ID</FormLabel>
                      <Field
                        name="ceCode"
                        id="ceCode"
                        type="text"
                        className={globalClasses.formControl}
                        disabled
                        value={
                          (selectedLocation && selectedLocation.ceCode) ||
                          formik.values.site340b
                        }
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Location Name</FormLabel>
                      <Field
                        name="locationName"
                        type="text"
                        maxLength={150}
                        className={globalClasses.formControl}
                        placeholder="Enter Location Name"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (
                            value &&
                            !REGEX.alphabetsAndHypen.test(e.target.value)
                          )
                            return;
                          formik.setFieldValue("locationName", e.target.value);
                          handleLoacationName(e, formik);
                        }}
                      />
                      {formik.touched.locationName &&
                        formik.errors.locationName && (
                          <Typography color="error" variant="caption">
                            {formik.errors.locationName}
                          </Typography>
                        )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Location HRSA ID</FormLabel>
                      <Field
                        name="locationHrsaId"
                        type="text"
                        maxLength={15}
                        disabled={isEdit}
                        className={globalClasses.formControl}
                        placeholder="Enter Location HRSA ID"
                        onChange={(e) => {
                          handleLoacationHRSAID(e, formik);
                        }}
                      />
                      {formik.touched.locationHrsaId &&
                        formik.errors.locationHrsaId && (
                          <Typography color="error" variant="caption">
                            {formik.errors.locationHrsaId}
                          </Typography>
                        )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Address Line 1</FormLabel>
                      <Field
                        name="addressLine1"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Address Line 1"
                        maxLength={100}
                        onChange={(e) => handleChange(e, formik)}
                      />
                      {formik.touched.addressLine1 &&
                        formik.errors.addressLine1 && (
                          <Typography color="error" variant="caption">
                            {formik.errors.addressLine1}
                          </Typography>
                        )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel>Address Line 2</FormLabel>
                      <Field
                        name="addressLine2"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Address Line 2"
                        maxLength={100}
                        onChange={(e) => handleChange(e, formik)}
                      />
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>City</FormLabel>
                      <Field
                        name="city"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter City"
                        maxLength={100}
                        onChange={(e) => handleChange(e, formik)}
                      />
                      {formik.touched.city && formik.errors.city && (
                        <Typography color="error" variant="caption">
                          {formik.errors.city}
                        </Typography>
                      )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>State</FormLabel>
                      <Field as="select" name="stateId">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={_isArray(stateList) ? stateList : []}
                            inputPlaceholder={"Select State"}
                            disableCloseOnSelect={false}
                            onChange={(e, value) => {
                              formik.setFieldValue(
                                "stateId",
                                value ? value.stateId : ""
                              );
                            }}
                            getOptionLabel={(option) => option.stateName || ""}
                            value={
                              stateList.find(
                                (e) => e.stateId == formik.values.stateId
                              ) || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.stateName}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                            textFieldProps={{
                              inputProps: {
                                name: "stateId",
                              },
                            }}
                          />
                        )}
                      </Field>
                      {formik.touched.stateId && formik.errors.stateId && (
                        <Typography color="error" variant="caption">
                          {formik.errors.stateId}
                        </Typography>
                      )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Zip</FormLabel>
                      <Field
                        name="zipCode"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Zip"
                        maxLength={5}
                        onChange={(e) => checkInputZipCode(e, formik)}
                      />
                      {formik.touched.zipCode && formik.errors.zipCode && (
                        <Typography color="error" variant="caption">
                          {formik.errors.zipCode}
                        </Typography>
                      )}
                    </Grid>

                    <Grid item xs={12} sm={5}>
                      <Grid container spacing={1}>
                        <Grid item xs={12} sm={6}>
                          <FormLabel required>
                            OPA Location Start Date
                          </FormLabel>
                          <DatePicker
                            disabledDate={(date) =>
                              startDateValidation(
                                date,
                                formik.values.endDate
                              ) || date.isBefore(new Date(), "day")
                            }
                            onChange={(e, date) => {
                              if (!date) onDateChange("endDate", "", formik);
                              onDateChange("startDate", date, formik);
                            }}
                            value={
                              formik.values.startDate !== ""
                                ? moment(formik.values.startDate)
                                : ""
                            }
                            disabled={
                              isEdit &&
                              moment(selectedLocation.startDate).isBefore(
                                new Date()
                              )
                            }
                          />
                          {formik.touched.startDate &&
                            formik.errors.startDate && (
                              <Typography color="error" variant="caption">
                                {formik.errors.startDate}
                              </Typography>
                            )}
                        </Grid>

                        <Grid item xs={12} sm={6}>
                          <FormLabel>OPA Location End Date</FormLabel>
                          <DatePicker
                            onChange={(e, date) =>
                              onDateChange("endDate", date, formik)
                            }
                            disabledDate={(d) =>
                              endDateValidation(d, formik.values.startDate)
                            }
                            value={
                              formik.values.endDate !== ""
                                ? moment(formik.values.endDate)
                                : ""
                            }
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid container justifyContent="flex-end" spacing={2}>
                    <Grid item>
                      <Button
                        type="submit"
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                      >
                        Add New Variation
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() => {
                          setOpenPopup(false);
                        }}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Form>
          );
        }}
      </Formik>
    </>
  );
};

export default AddVariationPopup;
