import React, { useEffect, useState } from "react";
import { Paper, Typography, Grid, Button } from "@material-ui/core";
import { useHistory, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form, Field, FieldArray } from "formik";
import LockIcon from "../../assets/icon-set-password.png";
import { getSecurityQuestionsDefaultValue } from "../../utils/constants";
import {
  getSecurityQuestions,
  validateUUID,
  logincreatepassword,
} from "../../context/actions/Auth";
import Notfound from "../../components/common/Notfound";
import LoaderUI from "../../components/common/Loader/Loader";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import classNames from "classnames";
import { useCreatePasswordStyles } from "./styles";
// import { validateLeadingTrailingSpaces } from "../../utils/validation";

const status = {
  200: "active",
  400: "expired",
  404: "used",
};

const firstNameAndLastName = (user) => {
  return user ? user.firstName + " " + user.lastName : "";
};

const formValidate = (values) => {
  let error = {};

  if (!values.qu[0].q1) error.qn1 = "Please select the Security Question";
  if (!values.qu[1].q2) error.qn2 = "Please select the Security Question";

  if (values.pw.trim() === "") {
    error.pw = "Please enter the Password";
  } else if (values.pw.length < 12) {
    error.pw =
      "Password must be at least 12 characters in length. Please try again";
  }
  if (values.cpw.trim() === "") {
    error.cpw = "Please enter the Confirm Password ";
  }
  if (values.cpw !== values.pw) {
    error.cpw = "Password mismatch ";
  }

  if (!values.qu[0].ans1.trim()) error.ans1 = "Required field";
  else if (values.qu[0].ans1.trim().length < 2)
    error.ans1 =
      "The answers must be at least 2 characters in length. Please enter again.";
  else if (/^\s+|\s{2,}$/g.test(values.qu[0].ans1))
    error.ans1 = "The answer should not contain leading or trailing spaces";
  if (!values.qu[1].ans2.trim()) error.ans2 = "Required field";
  else if (values.qu[1].ans2.trim().length < 2)
    error.ans2 =
      "The answers must be at least 2 characters in length. Please enter again.";
  else if (/^\s+|\s{2,}$/g.test(values.qu[1].ans2))
    error.ans2 = "The answer should not contain leading or trailing spaces";
  return error;
};

function getFilteredQns(questions, values, index) {
  return questions.filter((item) => {
    if (index === 0) return item.securityQuestionId !== Number(values.qu[1].q2);
    return item.securityQuestionId !== Number(values.qu[0].q1);
  });
}

const CreatePassword = () => {
  const location = useLocation();
  const classes = useCreatePasswordStyles();
  const history = useHistory();
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const defaultValues = getSecurityQuestionsDefaultValue();
  const id = location.search.split("=") + location.hash;
  const uuid = id.split(",");
  const [linkStatus, setLinkStatus] = useState("loading");

  useEffect(() => {
    dispatch(
      validateUUID({ uuid: uuid[1] }, (res) => {
        setLinkStatus(status[res.statusCode] || "");
        if (res.statusCode === 200) {
          dispatch(getSecurityQuestions());
        }
      })
    );
  }, [questions]);
  const questions = useSelector((state) => state.securityQuestionList) || [];
  let validateUUIDStorage = localStorage.getItem("validateUUID");
  let userData = localStorage.getItem("userData");

  const handleSubmit = (values) => {
    let formData = {};
    formData.password = values.pw;
    formData.userID = JSON.parse(userData).userId;
    formData.userSecurityAnswers = [
      {
        questionID: Number(values.qu[0].q1),
        answer: values.qu[0].ans1.trim(),
        userAnswerID: 0,
        userID: JSON.parse(userData).userId,
      },
      {
        questionID: Number(values.qu[1].q2),
        answer: values.qu[1].ans2.trim(),
        userAnswerID: 0,
        userID: JSON.parse(userData).userId,
      },
    ];
    dispatch(
      logincreatepassword(formData, (result) => {
        if (result.statusCode === 200) {
          history.push("/login");
          localStorage.removeItem("userData");
          localStorage.removeItem("validateUUID");
        }
      })
    );
  };

  return linkStatus === "loading" ? (
    <LoaderUI />
  ) : (
    <>
      {JSON.parse(validateUUIDStorage) === true ? (
        <Formik
          enableReinitialize={true}
          initialValues={defaultValues}
          onSubmit={handleSubmit}
          validate={formValidate}
        >
          {({ values, errors, touched, setFieldValue }) => (
            <>
              <div>
                <Paper elevation={0} className={classes.paper}>
                  <Typography component="span" className="form-text m-b-30">
                    Welcome :{" "}
                  </Typography>{" "}
                  <strong>{firstNameAndLastName(JSON.parse(userData))}</strong>
                  <Grid className={classes.subtitle}>
                    <Grid>
                      <img
                        alt="LockIcon"
                        src={LockIcon}
                        className={classes.iconStyle}
                      />
                    </Grid>
                    <Grid>
                      <Typography variant="h6" className={classes.subtitle2}>
                        Set your security questions and answers
                      </Typography>
                      <Typography variant="body2" className="form-text m-b-30">
                        Please select two questions from the list as your
                        security questions.The answers to these questions should
                        be something you can easily remember,and must be atleast
                        two characters. They may not include space at the
                        beginning or end.
                      </Typography>
                    </Grid>
                  </Grid>
                  <Form>
                    <Grid xs={12} sm={12}>
                      <Typography variant="body1" className="mb-3">
                        <strong>Set the following security questions</strong>
                      </Typography>
                      <FieldArray
                        name="qu"
                        render={() => (
                          <>
                            {values.qu.map((question, index) => (
                              <div>
                                <Typography variant="body2">
                                  Question {index + 1}
                                </Typography>
                                <Grid container spacing={3}>
                                  <Grid item xs={12} sm={6} className="mb-3">
                                    <Field
                                      as="select"
                                      name={`qu.${index}.q${index + 1}`}
                                      className={classNames(
                                        globalClasses.loginScreenInputFields,
                                        globalClasses.formControl,
                                        classes.questionsInputFields
                                      )}
                                      onChange={(e) => {
                                        setFieldValue(
                                          e.target.name,
                                          e.target.value
                                        );
                                        setFieldValue(
                                          `qu.${index}.ans${index + 1}`,
                                          ""
                                        );
                                      }}
                                    >
                                      <option value={""}>
                                        Select your question
                                      </option>
                                      {questions.records &&
                                        getFilteredQns(
                                          questions.records,
                                          values,
                                          index
                                        ).map((keysItem, indexVal) => {
                                          return (
                                            <option
                                              key={indexVal}
                                              value={
                                                keysItem.securityQuestionId
                                              }
                                            >
                                              {keysItem.question}
                                            </option>
                                          );
                                        })}
                                    </Field>
                                    {touched.qu &&
                                      touched.qu[index] &&
                                      touched.qu[index][`q${index + 1}`] &&
                                      errors[`qn${index + 1}`] && (
                                        <Typography
                                          color="error"
                                          variant="caption"
                                        >
                                          {errors[`qn${index + 1}`]}
                                        </Typography>
                                      )}
                                  </Grid>
                                  <Grid item xs={12} sm={6}>
                                    <Field
                                      name={`qu.${index}.ans${index + 1}`}
                                      id="ans"
                                      type="text"
                                      className={classNames(
                                        globalClasses.formControl,
                                        globalClasses.loginScreenInputFields,
                                        classes.questionsInputFields
                                      )}
                                      placeholder="Answer your question"
                                    />
                                    {touched.qu &&
                                      touched.qu[index] &&
                                      touched.qu[index][`ans${index + 1}`] &&
                                      errors[`ans${index + 1}`] && (
                                        <Typography
                                          color="error"
                                          variant="caption"
                                        >
                                          {errors[`ans${index + 1}`]}
                                        </Typography>
                                      )}
                                  </Grid>
                                </Grid>
                              </div>
                            ))}
                          </>
                        )}
                      />
                    </Grid>
                    <Grid>
                      <Typography variant="body1">
                        <strong> Create your Password </strong>
                      </Typography>
                      <Grid container spacing={3}>
                        <Grid item xs={12} sm={6}>
                          <Field
                            name="pw"
                            id="createpassword"
                            type="password"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Create Password"
                            style={{ marginTop: "10px" }}
                            maxLength={50}
                          />
                          {touched.pw && errors.pw && (
                            <Typography color="error" variant="caption">
                              {errors.pw}
                            </Typography>
                          )}
                        </Grid>

                        <Grid item xs={12} sm={6}>
                          <Field
                            name="cpw"
                            id="create-confirm-password"
                            type="password"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.passwordBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            placeholder="Confirm Password"
                            style={{ marginTop: "10px" }}
                            maxLength={50}
                          />
                          {touched.cpw && errors.cpw && (
                            <Typography color="error" variant="caption">
                              {errors.cpw}
                            </Typography>
                          )}
                        </Grid>

                        <Typography
                          variant="caption"
                          className="form-text m-b-30"
                          style={{ padding: "10px" }}
                        >
                          Must be at least 12 characters in length
                          <br />
                          Special Characters/Caps/Numbers NOT required
                          <br />
                          Unique password history: 20
                        </Typography>

                        <Grid
                          container
                          justifyContent="flex-end"
                          style={{ marginRight: "40px", marginTop: "-28px" }}
                        >
                          <Button
                            type="submit"
                            color="primary"
                            size="small"
                            variant="contained"
                            className="btn btn-primary"
                          >
                            Save
                          </Button>
                          <Button
                            size="small"
                            variant="outlined"
                            color="default"
                            className="btn btn-secondary m-l-20"
                            onClick={() => history.replace("/login")}
                          >
                            cancel
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Form>
                </Paper>
              </div>
            </>
          )}
        </Formik>
      ) : (
        <div>
          <Notfound
            value={"Oops, there was a problem with your link"}
            linkType={
              linkStatus === "expired"
                ? "The link has expired."
                : "Your reset link has already been used."
            }
            nameOfUser={firstNameAndLastName(JSON.parse(userData))}
            cp={linkStatus === "expired"}
            usedLink={linkStatus === "used"}
            uuid={uuid[1]}
          />
        </div>
      )}
    </>
  );
};

export default CreatePassword;
