import React, { useState, useEffect, useRef, useContext } from "react";
import { Grid, Button, FormLabel, FormControlLabel } from "@material-ui/core";
import "antd/dist/antd.css";
import { Formik, Form, Field, FieldArray } from "formik";
import { useSelector, useDispatch } from "react-redux";
import {
  getProvidertype,
  getCustomconfigvariable,
  saveVisitWindow,
  getVisitWindow,
  visitWindowConfig,
  updateSectionStatus,
  visitWindowConfigLookup,
  getCeVisitWindowConfig,
  fetchTermsGridTableData,
} from "../../../../../../context/actions/ConfigOverview";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import { getUserSession } from "../../../../../../utils/helper";
import FieldArrayVisitWindow from "./FieldArrayVisitWindow";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import _get from "lodash/get";
import _isArray from "lodash/isArray";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { POLLING_COUNT } from "../../../../../../utils/constants";
import Toggle from "../../../../../../components/common/Toggle";

const Visitwindow = ({ value = false, ceId, clickOnAdd }) => {
  const {
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    messageUuid,
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext);
  const { visitWindow } = menusStatuses;
  const formRef = useRef(null);
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const [loader, setloader] = useState(false);
  const userSession = getUserSession();
  const ceid = ceId || messageUuid.ceid;
  const arr = [
    {
      ceid: ceid,
      customWindowType: "",
      providerTypeValue: "",
      daysBeforeVisit: "0",
      daysAfterVisit: "365",
      enabled: true,
      active: true,
      providerValues: [],
      serviceAreaTypeValues: [],
      visitWindowId: "",
      serviceAreaTypeOptions: [],
      value: value,
      isNew: true,
      serviceAreaType: "",
    },
  ];

  useEffect(() => {
    dispatch(visitWindowConfigLookup());
    dispatch(getProvidertype());
    dispatch(getCustomconfigvariable());
    dispatch(visitWindowConfig({ ceid: ceid }, true, setFormState, arr, value));
  }, [ceid]);

  const serviceAreas = useSelector((state) => state.getVisitLukUp.data || []);
  const visitConfigData = useSelector(
    (state) => state.visitWindowConfig.data || []
  );

  const getServiceAreaTypeValue = (value) => {
    const filterArray = serviceAreas.filter(
      (key) =>
        key.configurationType === value.replace(/\s+/g, " ").trim() ||
        Number(key.configurationTypeId) === Number(value)
    );
    return (
      filterArray &&
      filterArray.length > 0 &&
      filterArray[0].configurationTypeId.toString()
    );
  };

  const inVa = {
    daysBeforeVisit:
      visitConfigData === null || visitConfigData === undefined
        ? "0"
        : visitConfigData.defaultVisitWindow &&
          visitConfigData.defaultVisitWindow.daysBeforeVisitDate,
    daysAfterVisit:
      visitConfigData === null || visitConfigData === undefined
        ? "365"
        : visitConfigData.defaultVisitWindow &&
          visitConfigData.defaultVisitWindow.daysAfterVisitDate,
    navigation: false,
    enabled: !_get(visitConfigData, "defaultVisitWindow.disabled", true),
    customVisitWindows:
      visitConfigData === null || visitConfigData === undefined
        ? arr
        : _isArray(visitConfigData.customVisitWindows) &&
          visitConfigData.customVisitWindows.map(
            (
              {
                customValueType,
                daysAfterVisitDate,
                daysBeforeVisitDate,
                customValueIds,
                inactive,
                disabled,
                serviceAreaConfigurations,
              },
              index
            ) => ({
              ceid: ceid,
              daysBeforeVisit: daysBeforeVisitDate,
              customWindowType:
                customValueType === "Provider Type" ||
                customValueType === "Provider"
                  ? customValueType
                  : "Service Area",
              daysAfterVisit: daysAfterVisitDate,
              providerTypeValue:
                customValueType === "Provider Type"
                  ? customValueIds && customValueIds[0].customValueId
                  : "",
              serviceAreaType:
                customValueType === "Provider Type" ||
                customValueType === "Provider"
                  ? ""
                  : getServiceAreaTypeValue(customValueType),
              visitWindowId: customValueIds && customValueIds[0].visitWindowId,
              providerValues:
                customValueType === "Provider"
                  ? customValueIds[0].customValueId
                  : "",
              serviceAreaTypeValues:
                customValueType === "Provider Type" ||
                customValueType === "Provider"
                  ? ""
                  : customValueIds && customValueIds[0].customValueId,
              active: !inactive,
              enabled: !disabled,
              uid: `cvw${index}`,
              serviceAreaTypeOptions:
                customValueType === "Provider Type" ||
                customValueType === "Provider"
                  ? []
                  : serviceAreaConfigurations,
            })
          ),
  };

  const [formState, setFormState] = useState(inVa);

  const handleSubmit = (values) => {
    let json = {
      ceid: ceid,
      defaultVisitWindow: {
        daysBeforeVisitDate: values.daysBeforeVisit
          ? values.daysBeforeVisit
          : 0,
        daysAfterVisitDate: values.daysAfterVisit ? values.daysAfterVisit : 365,
        createdById: userSession.userId,
        modifiedById: userSession.userId,
        disabled: !values.enabled,
      },
      customVisitWindows: [],
    };
    values.customVisitWindows.map((key) => {
      let serviceAreaArray = [];
      let customValueType;
      let providerArray = [];
      let providerTypeArray = [];

      let removedProviders = [];
      let removedServices = [];

      if (key.customWindowType === "Provider Type") {
        let ptObj = { customValueId: Number(key.providerTypeValue) };
        if (key.visitWindowId) {
          ptObj["visitWindowId"] = key.visitWindowId;
        }
        providerTypeArray = [ptObj];
      }
      if (key.customWindowType === "Provider") {
        if (key.providerValues && key.providerValues.length > 0) {
          if (key.uid) {
            let existingProviders = [];
            let selectedProviderIds = [];
            let index = formState.customVisitWindows.findIndex(
              (item) => item && item.uid && item.uid === key.uid
            );
            if (index >= 0) {
              existingProviders =
                formState.customVisitWindows[index].providerValues || [];
            }
            selectedProviderIds = key.providerValues.map(
              (item) => item.customValueId
            );

            removedProviders = existingProviders.filter(
              (item) => !selectedProviderIds.includes(item.customValueId)
            );
          }

          providerArray = key.providerValues.map(
            ({ customValueId, visitWindowId, prescriberId }) => {
              let pObj = {};
              if (prescriberId) {
                pObj = { customValueId: prescriberId };
              } else {
                pObj = {
                  customValueId: customValueId,
                  visitWindowId: visitWindowId,
                };
              }
              return pObj;
            }
          );
          removedProviders = removedProviders.map((item) => {
            let obj = item;
            obj["inactive"] = true;
            return obj;
          });
        }
      }
      if (key.customWindowType === "Service Area") {
        if (key.serviceAreaTypeValues && key.serviceAreaTypeValues.length > 0) {
          if (key.uid) {
            let existingServices = [];
            let selectedServiceIds = [];
            let index = formState.customVisitWindows.findIndex(
              (item) => item && item.uid && item.uid === key.uid
            );
            if (index >= 0) {
              existingServices =
                formState.customVisitWindows[index].serviceAreaTypeValues || [];
            }
            selectedServiceIds = key.serviceAreaTypeValues.map(
              (item) => item.customValueId
            );

            removedServices = existingServices.filter(
              (item) => !selectedServiceIds.includes(item.customValueId)
            );
          }
          serviceAreaArray = key.serviceAreaTypeValues.map(
            ({ customValueId, visitWindowId, configItemId }) => {
              let saObj = {};
              if (configItemId) {
                saObj = { customValueId: configItemId };
              } else {
                saObj = {
                  customValueId: customValueId,
                  visitWindowId: visitWindowId,
                };
              }
              return saObj;
            }
          );
          removedServices = removedServices.map((item) => {
            let obj = item;
            obj["inactive"] = true;
            return obj;
          });
        }
      }

      if (key.customWindowType === "Service Area") {
        const filteredService = serviceAreas.filter(
          (config) =>
            config.configurationType === key.serviceAreaType ||
            Number(config.configurationTypeId) === Number(key.serviceAreaType)
        );
        if (filteredService && filteredService.length > 0) {
          customValueType = filteredService[0].configurationType;
        } else {
          customValueType = key.serviceAreaType;
        }
      } else {
        customValueType = key.customWindowType;
      }
      let customVisitWindowObj = {
        daysAfterVisitDate: key.daysAfterVisit ? key.daysAfterVisit : 365,
        daysBeforeVisitDate: key.daysBeforeVisit ? key.daysBeforeVisit : 0,
        createdById: userSession.userId,
        modifiedById: userSession.userId,
        customValueType: customValueType,
        customValueIds:
          key.customWindowType === "Provider Type"
            ? providerTypeArray
            : key.customWindowType === "Provider"
            ? [...providerArray, ...removedProviders]
            : key.customWindowType === "Service Area"
            ? [...serviceAreaArray, ...removedServices]
            : [],
        disabled: !key.enabled,
        inactive: !key.active,
      };

      //Remove newly added custom windows if active false
      if (key.isNew) {
        if (key.active) {
          json.customVisitWindows.push(customVisitWindowObj);
        }
      } else {
        json.customVisitWindows.push(customVisitWindowObj);
      }
    });

    // Filter custom windows with valid data
    const validCustomWindows = json.customVisitWindows.filter(
      (key) =>
        key.customValueIds &&
        key.customValueIds.length > 0 &&
        key.customValueType !== ""
    );
    if (validCustomWindows.length === 0) {
      delete json.customVisitWindows;
    } else {
      json.customVisitWindows = [...validCustomWindows];
    }

    setloader(true);
    dispatch(
      saveVisitWindow(json, setloader, (result) => {
        handlePolling({
          messageUUID: result.data,
          currentCount: POLLING_COUNT,
          moveToNext: values.navigation ? true : false,
        });
      })
    );
  };

  const handlePolling = async ({ messageUUID, currentCount, moveToNext }) => {
    const count = currentCount;
    dispatch(
      getVisitWindow({ messageUUID: messageUUID }, (response) => {
        if (response.statusCode === 200) {
          !clickOnAdd && dispatch(getCeVisitWindowConfig(messageUuid.ceid));
          setloader(false);
          if (clickOnAdd || visitWindow) {
            dispatch(
              updateSectionStatus({
                ceId: messageUuid.ceid,
                sectionId: 10,
                callback,
              })
            );
          }
          if (moveToNext) {
            setPopupActiveMenu(MENUS.PH_VIEW_PHARMACIES);
          } else {
            setOpenAddCePopup(false);
          }
        } else if (response && response.statusCode === 102 && count > 1) {
          handlePolling({ messageUUID, currentCount: count - 1, moveToNext });
        } else {
          setloader(false);
        }
      })
    );
  };

  const callback = (res) => {
    if (res.statusCode === 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({
        ...prev,
        visitWindow: false,
      }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
    setloader(false);
  };
  const regex = /^0*([0-9][0-9]?|[12][0-9][0-9]|3[0-5][0-9]|36[0-5])$/;
  return (
    <>
      {loader && <LoaderUI />}
      <Formik
        isSubmitting={true}
        enableReinitialize={true}
        initialValues={formState}
        onSubmit={handleSubmit}
        formRef={formRef}
      >
        {(formik) => (
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                {!value && (
                  <BasicTypography
                    variant="h4"
                    title="Covered Entity Configuration > Visit Window"
                  />
                )}
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        <BasicTypography
                          variant="h5"
                          title="Default Visit Window"
                        />
                      </Grid>
                      <Grid item md={12}>
                        <Grid container spacing={2} alignItems="center">
                          <Grid item xs={12} sm={1}>
                            {value ? (
                              <FormLabel>
                                {formState.daysBeforeVisit
                                  ? formState.daysBeforeVisit
                                  : "0"}
                              </FormLabel>
                            ) : (
                              <Field
                                name="daysBeforeVisit"
                                id="daysBeforeVisit"
                                type="number"
                                disabled={value}
                                className={globalClasses.formControl}
                                placeholder="0"
                                min="0"
                                max="365"
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (value && !regex.test(value)) return;
                                  formik.setFieldValue(
                                    "daysBeforeVisit",
                                    value
                                  );
                                }}
                                onKeyDown={(e) =>
                                  (e.key === "e" ||
                                    e.key === "-" ||
                                    e.key === "+") &&
                                  e.preventDefault()
                                }
                              />
                            )}
                          </Grid>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>Days before visit </FormLabel>
                          </Grid>
                          <Grid item xs={12} sm={1}>
                            {value ? (
                              <FormLabel>
                                {formState.daysAfterVisit
                                  ? formState.daysAfterVisit
                                  : "365"}
                              </FormLabel>
                            ) : (
                              <Field
                                name="daysAfterVisit"
                                id="daysAfterVisit"
                                type="number"
                                className={globalClasses.formControl}
                                placeholder="365"
                                disabled={value}
                                min="0"
                                max="365"
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (value && !regex.test(value)) return;
                                  formik.setFieldValue("daysAfterVisit", value);
                                }}
                                onKeyDown={(e) =>
                                  (e.key === "e" ||
                                    e.key === "-" ||
                                    e.key === "+") &&
                                  e.preventDefault()
                                }
                              />
                            )}
                          </Grid>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>Days after visit </FormLabel>
                          </Grid>
                          <Grid item xs={12} sm={2}>
                            <FormControlLabel
                              control={
                                <Field
                                  label="Primary Contact"
                                  name="enabled"
                                  component={Toggle}
                                  type="checkbox"
                                  checked={formik.values.enabled}
                                  onClick={(e) =>
                                    !value &&
                                    formik.setFieldValue(
                                      "enabled",
                                      e.target.checked
                                    )
                                  }
                                />
                              }
                            />
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        {formState.customVisitWindows.length > 0 && !value && (
                          <BasicTypography
                            variant="h5"
                            title="Select Custom Configuration Variable"
                          />
                        )}
                      </Grid>
                      <Grid item md={12}>
                        <FieldArray
                          name="customVisitWindows"
                          component={FieldArrayVisitWindow}
                          visitConfigData={visitConfigData}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                {!value && (
                  <Grid container justifyContent="flex-end" spacing={2}>
                    <Grid item>
                      <Button
                        type="submit"
                        color="primary"
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                        onClick={() => {
                          formik.setFieldValue("navigation", true);
                        }}
                      >
                        Next
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() => {
                          setPopupActiveMenu(MENUS.PH_VIEW_PHARMACIES);
                        }}
                      >
                        Skip
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        type="submit"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                      >
                        Save and Exit
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() => {
                          setOpenAddCePopup(false);
                        }}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  </Grid>
                )}
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    </>
  );
};

export default Visitwindow;
