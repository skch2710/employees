import { useDispatch } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { fetchAdminFeeTableData } from "../../../../../../../context/actions/PharmacyConfiguration";
import { LABELS} from "../../../../../../../utils/constants";

const useAdminFeeExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = async (props) => {
    const { controllers, columnFilters, clientId } = props;
    const resp = await dispatch(
      fetchAdminFeeTableData({
        clientId: clientId || 0,
        sortBy: controllers.sortBy,
        sortOrder: controllers.sortOrder,
        filter: columnFilters,
        export: true,
      })
    );
    if (!_isEmpty(resp)) {
      const data = resp.content.map(
        ({
          entityName,
          feeType,
          flatFee,
          percentage,
          basisOf,
          claimType,
          addlClaimType,
          switchType,
          feeStartDate,
          feeEndDate,
        }) => ({
          [LABELS.CoveredEntity]: entityName || "",
          "Fee Type": feeType || "",
          "Fee Value": flatFee || "",
          Percentage: percentage || "",
          "Basis Of": basisOf || "",
          "Claim Type": claimType || "",
          "Additional Claim Type Detail": addlClaimType || "",
          Switch: switchType || "",
          "Start Date": feeStartDate || "",
          "End Date": feeEndDate || "",
        })
      );
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "Admin Fee" + ".xlsx");
    }
  };

  return { exportToExcel };
};

export default useAdminFeeExport;
