import React, { useContext, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Formik, Form, Field } from "formik";
import { COContext } from "../../../../COContext";
import { useOrderingReplenishmentStyles } from "./styles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import _isEmpty from "lodash/isEmpty";
import {
  Button,
  Grid,
  Typography,
  FormLabel,
  FormControlLabel,
} from "@material-ui/core";
import _isArray from "lodash/isArray";
import {
  PhBillingModelList,
  InventorySwellProgramLKPList,
  PhOrderingandReplMessageUuid,
  phOrderingAndReplenishmentSave,
} from "../../../../../../context/actions/PhOrderingandReplenishment";
import {
  getOrderingReplenishmentDefaultValues,
  ORDefaultValuesFromResponse,
} from "./constants";
import { getUserSession } from "../../../../../../utils/helper";
import { updatePharmacySectionStatus } from "../../../../../../context/actions/ConfigOverview";
import {
  fetchPharmaciesTableData,
  phGroupOrderingAndReplenishDetails,
} from "../../../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { ORDERING_CONFIG_MODULE, POLLING_COUNT } from "../../../../../../utils/constants";
import Toggle from "../../../../../../components/common/Toggle";
import WholesalersGrid from "../../EntityDetails/CeOrderingConfiguration/WholesalersGrid";
import _get from "lodash/get";

const OrderingAndReplenishment = () => {
  const classes = useOrderingReplenishmentStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    messageUuid,
    phConfigSectionStatus,
    currentPharmacy,
    setPhConfigSectionStatus,
    setOpenAddCePopup,
    phConfigStatusPercent,
    setPhConfigStatusPercent,
    isNewPharmacy,
    phGridPayload,
  } = useContext(COContext);
  const { orderingAndRepl } = phConfigSectionStatus;
  const { ceid: ceId } = messageUuid || {};
  const [defaultValues, setDefaultValues] = useState(
    getOrderingReplenishmentDefaultValues()
  );
  const userSession = getUserSession();
  const [billingModeList, setBillingModeList] = useState([]);
  const [InventorySwellProgramLKPValues, setInventorySwellProgramLKPValues] =
    useState([]);
  const clientId = !_isEmpty(currentPharmacy) ? currentPharmacy.clientId : "";

  const handleFormSubmit = async (values) => {
    const payload = {
      clientId: clientId,
      orderingPharmacy: values.orderingPharmacy,
      generateC2Orders: values.generateC2OrdersOutOfSwell,
      centralReplenishment: values.participateInCentralReplenishment,
      replenishThresholdPercent: "100",
      turnOffTrueUp: values.turnOffTrueUp === true ? false : true,
      turnOffCEInventory: values.turnOffCeOwnedInventory === true ? false : true,
      processUnsolicitated: values.processUnsolicited855and810,
      createdById: userSession.userId,
      modifiedById: userSession.userId,
    };

    const res = await dispatch(PhOrderingandReplMessageUuid(payload));
    if (!_isEmpty(res)) {
      if (res.data) {
        handlePolling({
          messageUUid: res.data,
          stopNavigation: values.stopNavigation,
          currentCount: POLLING_COUNT,
        });
      }
    }
  };

  const handlePolling = async ({
    messageUUid,
    stopNavigation,
    currentCount,
  }) => {
    const count = currentCount;
    const resp = await dispatch(
      phOrderingAndReplenishmentSave(messageUUid, count)
    );
    if (resp && resp.statusCode === 200) {
      !isNewPharmacy && dispatch(phGroupOrderingAndReplenishDetails(clientId));
      if (isNewPharmacy || orderingAndRepl) {
        dispatch(
          updatePharmacySectionStatus({
            ceId,
            clientId,
            sectionId: 15,
            callback,
          })
        );
      }
      if (stopNavigation) setOpenAddCePopup(false);
      // else setPopupActiveMenu(MENUS.PH_BIN_PCN); // May come in future
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({ messageUUid, stopNavigation, currentCount: count - 1 });
    }
  };

  const callback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || phConfigStatusPercent;
      if (ceConfigPercent) {
        setPhConfigStatusPercent(ceConfigPercent);
      }
      setPhConfigSectionStatus((prev) => ({ ...prev, orderingAndRepl: false }));
      dispatch(fetchPharmaciesTableData(phGridPayload));
    }
  };

  const fetchBillingModeList = async () => {
    const res = await dispatch(PhBillingModelList());
    setBillingModeList(res);
  };

  const fetchInventorySwellProgramLKPList = async () => {
    const res = await dispatch(InventorySwellProgramLKPList());
    setInventorySwellProgramLKPValues(res);
  };

  const fetchFormValues = async () => {
    const res = await dispatch(phGroupOrderingAndReplenishDetails(clientId));
    if (res) {
      setDefaultValues(ORDefaultValuesFromResponse(res));
    }
  };

  useEffect(() => {
    fetchBillingModeList();
    fetchInventorySwellProgramLKPList();
    fetchFormValues();
  }, []);

  return (
    <Formik
      enableReinitialize={true}
      initialValues={defaultValues}
      onSubmit={handleFormSubmit}
    >
      {({ values, setFieldValue, errors, touched, handleSubmit }) => {
        return (
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                <BasicTypography
                  variant="h4"
                  title={`${
                    currentPharmacy.pharmacyName ||
                    currentPharmacy.phName +
                      " " +
                      "#" +
                      currentPharmacy.storeNumber ||
                    "Pharmacy Name"
                  } > Ordering and Replenishment`}
                />
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography variant="h5">
                      Pharmacy Chain Order and Replenish
                    </BasicTypography>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Billing Model</FormLabel>
                        <Field
                          as="select"
                          name="billingModelId"
                          className={globalClasses.formControl}
                          onChange={(e) =>
                            setFieldValue("billingModelId", e.target.value)
                          }
                        >
                          {(props) => {
                            const { field } = props;
                            return (
                              <select
                                {...field}
                                className={globalClasses.formControl}
                                disabled
                              >
                                <option value={""}>Select Billing Mode</option>
                                {billingModeList &&
                                  billingModeList.length > 0 &&
                                  billingModeList.map((keysItem, indexVal) => {
                                    return (
                                      <option
                                        key={indexVal}
                                        value={keysItem.billingModelId}
                                      >
                                        {keysItem.billingModel}
                                      </option>
                                    );
                                  })}
                              </select>
                            );
                          }}
                        </Field>
                        {errors.billingModelId && touched.billingModelId && (
                          <Typography color="error" variant="caption">
                            {errors.billingModelId}
                          </Typography>
                        )}
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Inventory Swell Program</FormLabel>
                        <Field
                          as="select"
                          name="inventorySwellProgramId"
                          className={globalClasses.formControl}
                          onChange={(e) =>
                            setFieldValue(
                              "inventorySwellProgramId",
                              e.target.value
                            )
                          }
                        >
                          {(props) => {
                            const { field } = props;
                            return (
                              <select
                                {...field}
                                className={globalClasses.formControl}
                                disabled
                              >
                                <option value={""}>
                                  Select Inventory Swell Program
                                </option>
                                {InventorySwellProgramLKPValues &&
                                  InventorySwellProgramLKPValues.length > 0 &&
                                  InventorySwellProgramLKPValues.map(
                                    (keysItem, indexVal) => {
                                      return (
                                        <option
                                          key={indexVal}
                                          value={
                                            keysItem.inventorySwellProgramId
                                          }
                                        >
                                          {keysItem.inventorySwellProgram}
                                        </option>
                                      );
                                    }
                                  )}
                              </select>
                            );
                          }}
                        </Field>
                        {errors.inventorySwellProgramId &&
                          touched.inventorySwellProgramId && (
                            <Typography color="error" variant="caption">
                              {errors.inventorySwellProgramId}
                            </Typography>
                          )}
                      </Grid>
                      <Grid item xs={12} sm={4}></Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                name={
                                  values.supportMultipleWholesalerForCeNetwork
                                }
                                component={Toggle}
                                checked={
                                  values.supportMultipleWholesalerForCeNetwork
                                }
                                disabled={
                                  values.supportMultipleWholesalerForCeNetwork
                                    .disable
                                }
                              />
                            }
                            label="Support Multiple Wholesaler For Covered Entity Network"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <FormControlLabel
                          control={
                            <Field
                              name={values.sendOrderNotifications}
                              component={Toggle}
                              checked={values.sendOrderNotifications}
                              disabled={values.sendOrderNotifications.disable}
                            />
                          }
                          label="Send Order Notifications"
                          classes={{
                            root: classes.switchRoot,
                            label: classes.switchLabel,
                          }}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography variant="h5">
                      Client Order and Replenish
                    </BasicTypography>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={1}>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.orderingPharmacy}
                                name="orderingPharmacy"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "orderingPharmacy",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Ordering Pharmacy"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.generateC2OrdersOutOfSwell}
                                name="generateC2OrdersOutOfSwell"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "generateC2OrdersOutOfSwell",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Generate C2 Orders Out of Swell"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={
                                  values.participateInCentralReplenishment
                                }
                                name="participateInCentralReplenishment"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "participateInCentralReplenishment",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Participate in Central Replenishment"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid item xs={12} sm={3}>
                        <FormLabel>Replenish Threshold Percent</FormLabel>
                      </Grid>
                      <Grid item xs={12} sm={1}>
                        <Field
                          name="replenishThresholdPercent"
                          id="replenishThresholdPercent"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Replenish Threshold Percent"
                          value="100"
                          disabled
                        />
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.turnOffTrueUp}
                                name="turnOffTrueUp"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "turnOffTrueUp",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Turn Off True-Up"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.turnOffCeOwnedInventory}
                                name="turnOffCeOwnedInventory"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "turnOffCeOwnedInventory",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Turn Off Covered Entity Owned Inventory"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.processUnsolicited855and810}
                                name="processUnsolicited855and810"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "processUnsolicited855and810",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Process Unsolicited 855 and 810"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>
                      <Grid item xs={12} sm={6}></Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <WholesalersGrid
                  module={ORDERING_CONFIG_MODULE.PH}
                  wholesalers={_get(values, "wholesalers", [])}
                />
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2} justifyContent="flex-end">
                  <Grid item>
                    <Button
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", true);
                        handleSubmit();
                      }}
                    >
                      Save and Exit
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => setOpenAddCePopup(false)}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        );
      }}
    </Formik>
  );
};

export default OrderingAndReplenishment;
