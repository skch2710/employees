import React, { useState, useEffect, useContext } from "react";
import { Formik, Form, Field } from "formik";
import { useDispatch } from "react-redux";
import {
  Button,
  Grid,
  FormLabel,
  FormControlLabel,
  Typography,
} from "@material-ui/core";
import _isArray from "lodash/isArray";
import {
  eligibilityDefaultValues,
  eligibilityDefaultValuesFromResponse,
} from "./constants";
import { COContext } from "../../../../COContext";
import { useEligibilityStyles } from "./styles";
import { getPayload } from "./helper";
import _isEmpty from "lodash/isEmpty";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import {
  fetchProgramType,
  fetchClaimType,
  savePhEligibilityDetails,
  getResponseOfUUID,
} from "../../../../../../context/actions/PharmacyEligibility";
import { updatePharmacySectionStatus } from "../../../../../../context/actions/ConfigOverview";
import { MENUS } from "../../../PopupSidebar/constants";
import { updateCeConfigStatusPercentage } from "../../../../../../utils/common";
import {
  fetchPharmaciesTableData,
  fetchPhEligibilityDetails,
} from "../../../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { POLLING_COUNT, REGEX } from "../../../../../../utils/constants";
import Toggle from "../../../../../../components/common/Toggle";
import AutoComplete from "../../../../../../components/common/AutoComplete";

const PharmacyEligibility = () => {
  const classes = useEligibilityStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    messageUuid,
    currentPharmacy,
    phConfigSectionStatus,
    setPhConfigSectionStatus,
    setPopupActiveMenu,
    setOpenAddCePopup,
    phConfigStatusPercent,
    setPhConfigStatusPercent,
    isNewPharmacy,
    phGridPayload,
  } = useContext(COContext);
  const { clientId } = currentPharmacy || {};
  const { phEligibility } = phConfigSectionStatus;
  const { ceid: ceId } = messageUuid || {};

  const [programTypeList, setProgramTypeList] = useState([]);
  const [claimTypeList, setClaimTypeList] = useState([]);
  const [defaultValues, setDefaultValues] = useState(
    eligibilityDefaultValues()
  );

  const handleFormSubmit = async (values) => {
    const payload = getPayload({
      ...values,
      clientConfigId: !_isEmpty(currentPharmacy)
        ? currentPharmacy.clientConfigId
        : "",
    });
    const res = await dispatch(savePhEligibilityDetails(payload));
    if (!_isEmpty(res)) {
      if (res.data) {
        handlePolling({
          messageUUid: res.data,
          stopNavigation: values.stopNavigation,
          currentCount: POLLING_COUNT,
        });
      }
    }
  };

  const handlePolling = async ({
    messageUUid,
    stopNavigation,
    currentCount,
  }) => {
    const count = currentCount;
    const resp = await dispatch(getResponseOfUUID(messageUUid, count));
    if (resp && resp.statusCode === 200) {
      !isNewPharmacy && dispatch(fetchPhEligibilityDetails(clientId));
      if (isNewPharmacy || phEligibility) {
        dispatch(
          updatePharmacySectionStatus({
            ceId,
            clientId,
            sectionId: 14,
            callback,
          })
        );
      }
      if (stopNavigation) setOpenAddCePopup(false);
      else setPopupActiveMenu(MENUS.PH_ORDERING_AND_REPLENISHMENT);
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({ messageUUid, stopNavigation, currentCount: count - 1 });
    }
  };

  const callback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || phConfigStatusPercent;
      if (ceConfigPercent) {
        setPhConfigStatusPercent(ceConfigPercent);
      }
      setPhConfigSectionStatus((prev) => ({ ...prev, phEligibility: false }));
      dispatch(fetchPharmaciesTableData(phGridPayload));
    }
  };

  const handleValidate = (values) => {
    const error = {};
    if (values.programType === "")
      error.programType = "Please Select Program Type";
    if (values.claimType === "") error.claimType = "Please Select Claim Type";
    return error;
  };

  const getProgramType = async () => {
    const res = await dispatch(fetchProgramType());
    _isArray(res) && setProgramTypeList(res);
  };

  const getClaimType = async () => {
    const res = await dispatch(fetchClaimType());
    _isArray(res) && setClaimTypeList(res);
  };

  const getPhEligibilityDetails = async () => {
    const res = await dispatch(fetchPhEligibilityDetails(clientId));
    if (res) setDefaultValues(eligibilityDefaultValuesFromResponse(res));
  };

  useEffect(() => {
    getProgramType();
    getClaimType();
    getPhEligibilityDetails();
  }, []);

  return (
    <Formik
      enableReinitialize={true}
      initialValues={defaultValues}
      onSubmit={handleFormSubmit}
      validate={handleValidate}
    >
      {({ values, setFieldValue, errors, touched, handleSubmit }) => {
        return (
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                <BasicTypography
                  variant="h4"
                  title={`${
                    currentPharmacy.pharmacyName ||
                    currentPharmacy.phName +
                      " " +
                      "#" +
                      currentPharmacy.storeNumber ||
                    "Pharmacy Name"
                  } > Eligibility`}
                />
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography
                      variant="h5"
                      title="Secondary Eligibility"
                    />
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Program Type</FormLabel>
                        <Field
                          as="select"
                          name="programType"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(programTypeList) ? programTypeList : []
                              }
                              inputPlaceholder={"Select Program Type"}
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "programType",
                                  value ? value.programTypeId : ""
                                );
                              }}
                              getOptionLabel={(option) =>
                                option.programType || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.programType}
                                  </BasicTypography>
                                );
                              }}
                              value={
                                (_isArray(programTypeList) &&
                                  programTypeList.find(
                                    (e) => e.programTypeId == values.programType
                                  )) ||
                                ""
                              }
                              multiple={false}
                            />
                          )}
                        </Field>
                        {errors.programType && touched.programType && (
                          <Typography color="error" variant="caption">
                            {errors.programType}
                          </Typography>
                        )}
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Claim Type to Process</FormLabel>
                        <Field
                          as="select"
                          name="claimType"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(claimTypeList)
                                  ? claimTypeList
                                  : []
                              }
                              inputPlaceholder={"Select Claim Type"}
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "claimType",
                                  value ? value.claimProcessTypeId : ""
                                );
                              }}
                              getOptionLabel={(option) =>
                                option.claimProcessType || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.claimProcessType}
                                  </BasicTypography>
                                );
                              }}
                              value={
                                (_isArray(claimTypeList) &&
                                claimTypeList.find(
                                    (e) =>
                                      e.claimProcessTypeId ==
                                      values.claimType
                                  )) || ""
                              }
                              multiple={false}
                            />
                          )}
                        </Field>
                        {errors.claimType && touched.claimType && (
                          <Typography color="error" variant="caption">
                            {errors.claimType}
                          </Typography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}></Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.falloutClaims}
                                name="falloutClaims"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "falloutClaims",
                                    e.target.checked
                                  )
                                }
                                disabled
                              />
                            }
                            label="Fallout claims for Applied Acquisition Cost = $0 if WAC, NADAC or SWP are not available"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.pharmacySupports}
                                name="pharmacySupports"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "pharmacySupports",
                                    e.target.checked
                                  )
                                }
                                disabled
                              />
                            }
                            label="Pharmacy supports Cash U&C claims"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            disabled
                            checked={values.cashClaimsC2DrugsBtn}
                            name="cashClaimsC2DrugsBtn"
                            onChange={(e) =>
                              setFieldValue(
                                "cashClaimsC2DrugsBtn",
                                e.target.checked
                              )
                            }
                          />
                          <label className={classes.toggleLabel}>
                            Exclude C2 Drugs Outside Of{" "}
                            <Field
                              disabled
                              name="cashClaimsC2DrugsInput"
                              type="number"
                              className={classes.formControlInput}
                            />{" "}
                            days for Cash Claims
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            disabled
                            checked={values.thirdPartyClaimsC4DrugsBtn}
                            name="thirdPartyClaimsC4DrugsBtn"
                            onChange={(e) =>
                              setFieldValue(
                                "thirdPartyClaimsC4DrugsBtn",
                                e.target.checked
                              )
                            }
                          />
                          <label className={classes.toggleLabel}>
                            Exclude C4 Drugs Outside Of{" "}
                            <Field
                              disabled
                              name="thirdPartyClaimsC4DrugsInput"
                              type="number"
                              className={classes.formControlInput}
                            />{" "}
                            days for Third Party Claims
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            disabled
                            checked={values.thirdPartyClaimsC2DrugsBtn}
                            name="thirdPartyClaimsC2DrugsBtn"
                            onChange={(e) =>
                              setFieldValue(
                                "thirdPartyClaimsC2DrugsBtn",
                                e.target.checked
                              )
                            }
                          />
                          <label className={classes.toggleLabel}>
                            Exclude C2 Drugs Outside Of{" "}
                            <Field
                              disabled
                              name="thirdPartyClaimsC2DrugsInput"
                              type="number"
                              className={classes.formControlInput}
                            />{" "}
                            days for Third Party Claims
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            disabled
                            checked={values.thirdPartyClaimsC5DrugsBtn}
                            name="thirdPartyClaimsC5DrugsBtn"
                            onChange={(e) =>
                              setFieldValue(
                                "thirdPartyClaimsC5DrugsBtn",
                                e.target.checked
                              )
                            }
                          />
                          <label className={classes.toggleLabel}>
                            Exclude C5 Drugs Outside Of{" "}
                            <Field
                              disabled
                              name="thirdPartyClaimsC5DrugsInput"
                              type="number"
                              className={classes.formControlInput}
                            />{" "}
                            days for Third Party Claims
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            disabled
                            checked={values.thirdPartyClaimsC3DrugsBtn}
                            name="thirdPartyClaimsC3DrugsBtn"
                            onChange={(e) =>
                              setFieldValue(
                                "thirdPartyClaimsC3DrugsBtn",
                                e.target.checked
                              )
                            }
                          />
                          <label className={classes.toggleLabel}>
                            Exclude C3 Drugs Outside Of{" "}
                            <Field
                              disabled
                              name="thirdPartyClaimsC3DrugsInput"
                              type="number"
                              className={classes.formControlInput}
                            />{" "}
                            days for Third Party Claims
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            disabled
                            checked={values.nonPreferredGenericsBtn}
                            name="nonPreferredGenericsBtn"
                            onChange={(e) =>
                              setFieldValue(
                                "nonPreferredGenericsBtn",
                                e.target.checked
                              )
                            }
                          />
                          <label className={classes.toggleLabel}>
                            Exclude Non-Preferred Generics Outside Of{" "}
                            <Field
                              disabled
                              name="nonPreferredGenericsInput"
                              type="number"
                              className={classes.formControlInput}
                            />{" "}
                            days
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.isEncrypted}
                                name="isEncrypted"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue("isEncrypted", e.target.checked)
                                }
                                disabled
                              />
                            }
                            label="Is Encrypted"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.excludeOrphanDrugs}
                                name="excludeOrphanDrugs"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "excludeOrphanDrugs",
                                    e.target.checked
                                  )
                                }
                                disabled
                              />
                            }
                            label="Exclude Orphan Drugs"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.claimReprocess}
                                name="claimReprocess"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "claimReprocess",
                                    e.target.checked
                                  )
                                }
                              />
                            }
                            label="Claim Reprocess"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <Toggle
                            checked={values.reversalConstraintBtn}
                            name="reversalConstraintBtn"
                            onChange={(e) => {
                              setFieldValue(
                                "reversalConstraintBtn",
                                e.target.checked
                              );
                              setFieldValue("reversalConstraintInput", "");
                            }}
                          />
                          <label className={classes.toggleLabel}>
                            Reversal Constraint{" "}
                            <Field
                              name="reversalConstraintInput"
                              type="text"
                              className={classes.formControlInput}
                              disabled={!values.reversalConstraintBtn}
                              value={values.reversalConstraintInput || ""}
                              onChange={(e) => {
                                const { value } = e.target;
                                if (value && !REGEX.onlyNumbers.test(value))
                                  return;
                                setFieldValue("reversalConstraintInput", value);
                              }}
                            />{" "}
                            days
                          </label>
                        </div>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography
                      variant="h5"
                      title="Claim Exclusions Based on Fees"
                    />
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid
                        item
                        xs={12}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.cashClaimLesserLogic}
                                name="cashClaimLesserLogic"
                                component={Toggle}
                                onChange={(e) =>
                                  setFieldValue(
                                    "cashClaimLesserLogic",
                                    e.target.checked
                                  )
                                }
                                disabled
                              />
                            }
                            label="Cash Claim Lesser of Logic"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        className={classes.switchGridContainer}
                      >
                        <div>
                          <FormControlLabel
                            control={
                              <Field
                                checked={values.turnOnMinSpread}
                                name="turnOnMinSpread"
                                component={Toggle}
                                onChange={(e) => {
                                  setFieldValue(
                                    "turnOnMinSpread",
                                    e.target.checked
                                  );
                                  setFieldValue("brandMinSpread", "0");
                                  setFieldValue("brandMinAdminFee", "0");
                                  setFieldValue("genericMinSpread", "0");
                                  setFieldValue("genericMinAdminFee", "0");
                                }}
                              />
                            }
                            label="Turn on Minimum Spread/Admin Fee Rule"
                            classes={{
                              root: classes.switchRoot,
                              label: classes.switchLabel,
                            }}
                          />
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={3}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <label className={classes.toggleLabel}>
                            Brand Min Spread{" "}
                            <Field
                              name="brandMinSpread"
                              type="text"
                              className={classes.formControlInput}
                              disabled={!values.turnOnMinSpread}
                              onChange={(e) => {
                                const { value } = e.target;
                                const regEx = /^[0-9]*\.{0,1}[0-9]{0,2}$/g;
                                if (value && !regEx.test(value)) return;
                                setFieldValue(
                                  "brandMinSpread",
                                  value.toString()
                                );
                              }}
                            />
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={3}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <label className={classes.toggleLabel}>
                            Brand Min Admin Fee{" "}
                            <Field
                              name="brandMinAdminFee"
                              type="text"
                              className={classes.formControlInput}
                              disabled={!values.turnOnMinSpread}
                              onChange={(e) => {
                                const { value } = e.target;
                                const regEx = /^[0-9]*\.{0,1}[0-9]{0,2}$/g;
                                if (value && !regEx.test(value)) return;
                                setFieldValue(
                                  "brandMinAdminFee",
                                  value.toString()
                                );
                              }}
                            />
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={3}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <label className={classes.toggleLabel}>
                            Generic Min Spread{" "}
                            <Field
                              name="genericMinSpread"
                              type="text"
                              className={classes.formControlInput}
                              disabled={!values.turnOnMinSpread}
                              onChange={(e) => {
                                const { value } = e.target;
                                const regEx = /^[0-9]*\.{0,1}[0-9]{0,2}$/g;
                                if (value && !regEx.test(value)) return;
                                setFieldValue(
                                  "genericMinSpread",
                                  value.toString()
                                );
                              }}
                            />
                          </label>
                        </div>
                      </Grid>

                      <Grid
                        item
                        xs={12}
                        sm={3}
                        className={classes.switchGridContainer}
                      >
                        <div className={classes.toggleBtnContainer}>
                          <label className={classes.toggleLabel}>
                            Generic Min Admin Fee{" "}
                            <Field
                              name="genericMinAdminFee"
                              type="text"
                              className={classes.formControlInput}
                              disabled={!values.turnOnMinSpread}
                              onChange={(e) => {
                                const { value } = e.target;
                                const regEx = /^[0-9]*\.{0,1}[0-9]{0,2}$/g;
                                if (value && !regEx.test(value)) return;
                                setFieldValue(
                                  "genericMinAdminFee",
                                  value.toString()
                                );
                              }}
                            />
                          </label>
                        </div>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2} justifyContent={"flex-end"}>
                  <Grid item>
                    <Button
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", false);
                        handleSubmit();
                      }}
                    >
                      Next
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() =>
                        setPopupActiveMenu(MENUS.PH_ORDERING_AND_REPLENISHMENT)
                      }
                    >
                      Skip
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", true);
                        handleSubmit();
                      }}
                    >
                      Save and Exit
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => setOpenAddCePopup(false)}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        );
      }}
    </Formik>
  );
};

export default PharmacyEligibility;
