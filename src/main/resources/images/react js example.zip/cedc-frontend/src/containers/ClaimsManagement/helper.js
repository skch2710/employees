import moment from "moment";

export const getOnlyDates = (data) => {
  return data.map((el) => {
    return moment(el.date).format("MM/DD/YYYY");
  });
};

export const getCurrentObject = (data, incomingDate) => {
  return (
    data.find((el) => {
      const date = moment(el.date).format("MM/DD/YYYY");
      return date === incomingDate;
    }) || {}
  );
};
