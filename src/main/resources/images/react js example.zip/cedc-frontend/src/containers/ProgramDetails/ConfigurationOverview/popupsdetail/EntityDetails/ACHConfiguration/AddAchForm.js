import React from "react";
import { Box, FormLabel, Grid } from "@material-ui/core";
import { Field, useFormikContext } from "formik";
import DatePicker from "../../../../../../components/common/DatePicker";
import moment from "moment";
import { useAchTableStyles } from "./style";
import _debounce from "lodash/debounce";
import { useDispatch } from "react-redux";
import {
  validateAcNo,
  validateRoutingNo,
} from "../../../../../../context/actions/ConfigOverview";
import { useCallback } from "react";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";

const AddAchForm = ({ setIsUniqueAcNo, setIsUniqueRoutingNo }) => {
  const { values, setFieldValue, resetForm, errors, touched } =
    useFormikContext();
  const globalClasses = useGlobalStyles();
  const classes = useAchTableStyles();
  const dispatch = useDispatch();

  const handleChangeAcNumber = useCallback(
    _debounce(async (value) => {
      const isUnique = await dispatch(validateAcNo(value));
      setIsUniqueAcNo(isUnique);
    }, 500),
    []
  );

  const handleChangeRoutingNumber = useCallback(
    _debounce(async (e) => {
      const isUnique = await dispatch(validateRoutingNo(e.target.value));
      setIsUniqueRoutingNo(isUnique);
    }, 500),
    []
  );

  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={3}>
        <FormLabel required>Account Number</FormLabel>
        <Field
          name="accountNumber"
          type="text"
          className={globalClasses.formControl}
          placeholder="Enter Account Number"
          maxLength={50}
          onChange={(e) => {
            const { value } = e.target;
            const regEx = /^\S*$/;
            if (value && !regEx.test(value)) return;
            setFieldValue("accountNumber", value.toString());
            if (value) handleChangeAcNumber(value);
          }}
        />
        {errors.accountNumber && touched.accountNumber && (
          <BasicTypography color="error" variant="caption">
            {errors.accountNumber}
          </BasicTypography>
        )}
      </Grid>

      <Grid item xs={12} sm={3}>
        <FormLabel required>Routing Number</FormLabel>
        <Field
          name="routingNumber"
          type="text"
          className={globalClasses.formControl}
          placeholder="Enter Routing Number"
          maxLength={9}
          onChange={(e) => {
            const value = e.target.value;
            const regEx = /^[0-9]{1,11}$/g;
            if (value && !regEx.test(e.target.value)) return;
            setFieldValue("routingNumber", e.target.value);
            if (value) handleChangeRoutingNumber(e);
          }}
        />
        {errors.routingNumber && touched.routingNumber && (
          <BasicTypography color="error" variant="caption">
            {errors.routingNumber}
          </BasicTypography>
        )}
      </Grid>

      <Grid item xs={12} sm={3}>
        <FormLabel required>Bank Name</FormLabel>
        <Field
          name="bankName"
          type="text"
          className={globalClasses.formControl}
          placeholder="Enter Bank Name"
          maxLength={50}
          onChange={(e) => {
            const { value } = e.target;
            setFieldValue("bankName", value.toString());
          }}
        />
        {errors.bankName && touched.bankName && (
          <BasicTypography color="error" variant="caption">
            {errors.bankName}
          </BasicTypography>
        )}
      </Grid>

      <Grid item xs={12} sm={3}>
        <FormLabel required>% of Remittance</FormLabel>
        <Field
          name="percentageOfRemittance"
          placeholder="Enter % of Remittance"
          className={globalClasses.formControl}
          onChange={(e) => {
            let re = /^(100)$|(^[0-9]{0,2})$/g;
            if (e.target.value && !re.test(e.target.value)) return;
            setFieldValue("percentageOfRemittance", e.target.value);
          }}
        />
        {errors.percentageOfRemittance && touched.percentageOfRemittance && (
          <BasicTypography color="error" variant="caption">
            {errors.percentageOfRemittance}
          </BasicTypography>
        )}
      </Grid>

      <Grid item xs={12} sm={3} className={classes.pennyTestGrid}>
        <div className={classes.pennyTestCheckboxDiv}>
          <Field
            name="pennyTestCompleted"
            type="checkbox"
            id="pennyTestCompleted"
            className={classes.pennyTestCheckbox}
            onChange={(e) => {
              setFieldValue(e.target.name, e.target.checked);
              setFieldValue("pennyTestCompletionDate", "");
            }}
          />
          <FormLabel
            htmlFor="pennyTestCompleted"
            classes={{ root: classes.pennyTestCheckboxLabel }}
          >
            Penny Test Completed
          </FormLabel>
        </div>
      </Grid>

      {values.pennyTestCompleted && (
        <Grid item xs={12} sm={3}>
          <FormLabel>Penny Test Completion Date</FormLabel>
          <Field as="select" name="pennyTestCompletionDate">
            {({ field }) => (
              <DatePicker
                {...field}
                disabledDate={(d) => !d || d.isAfter(new Date())}
                onChange={(_date, dateString) => {
                  setFieldValue("pennyTestCompletionDate", dateString);
                }}
                value={
                  values.pennyTestCompletionDate != ""
                    ? moment(values.pennyTestCompletionDate)
                    : ""
                }
              />
            )}
          </Field>
          {errors.pennyTestCompletionDate &&
            touched.pennyTestCompletionDate && (
              <BasicTypography color="error" variant="caption">
                {errors.pennyTestCompletionDate}
              </BasicTypography>
            )}
        </Grid>
      )}
    </Grid>
  );
};

export default AddAchForm;
