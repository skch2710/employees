import React from "react";
import { useDispatch } from "react-redux";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import { providersExport } from "../../../context/actions/providers";
import jsPDF from "jspdf";
import { notNull } from "../../../utils/constants";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
const fileName = "Providers List";

const Export = ({
  ciId,
  count,
  ceProvider,
  ceSelected,
  CEidarray,
  searchData,
}) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const {providerNPI, firstName, lastName, startDate, endDate, providerType}= searchData
  const [values, setValues] = React.useState("");
  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const dataa = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    FileSaver.saveAs(dataa, fileName + ".xlsx");
  };
  let heads = [];
  let rows = [];

  const ExportTOPDF = (data) => {
    const listheads = data.map((items) => {
      let keys_heads = {
        "First Name": Object.keys(items)[0],
        "Last Name": Object.keys(items)[1],
        "Provider NPI": Object.keys(items)[2],
        "Provider DEA": Object.keys(items)[3],
        "Provider SPI": Object.keys(items)[4],
        "Provider Type": Object.keys(items)[5],
        "Start Date": Object.keys(items)[6],
        "End Date": Object.keys(items)[7],
        "Last Modified Date": Object.keys(items)[8],
      };
      heads.push(keys_heads);
    });
    data.map((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };
  const handleChange = (e) => {
    setValues(e.target.value);
    let payload = {
      ceid: ceProvider ? [ciId] : ceSelected ? [ceSelected.ceID] : CEidarray,
      providerNPI: providerNPI || "",
      sortBy: "lastName",
      sortOrder: "asc",
      export: true,
      firstName: firstName || "",
      lastName: lastName || "",
      endDate: endDate || "",
      startDate: startDate || "",
      providerType: providerType || "",
    };
    dispatch(
      providersExport(payload, (res) => {
        var data = res.content.map(
          ({
            firstName,
            lastName,
            providerNpi,
            providerDea,
            prescriberSpi,
            exclusive,
            startDate,
            endDate,
            lastModifiedDate,
          }) => ({
            "First Name": notNull(firstName),
            "Last Name": notNull(lastName),
            "Provider NPI": notNull(providerNpi),
            "Provider DEA": notNull(providerDea),
            "Provider SPI": notNull(prescriberSpi),
            "Provider Type": notNull(exclusive),
            "Start Date": notNull(startDate),
            "End Date": notNull(endDate),
            "Last Modified Date": notNull(lastModifiedDate),
          })
        );
        if (e.target.value == "excel") {
          setTimeout(ExportToExcel(data), 5000);
          setValues("");
        }
        if (e.target.value == "pdf") {
          setTimeout(ExportTOPDF(data), 5000);
          const doc = new jsPDF();
          doc.autoTable({
            styles: { fontSize: 8 },
            head: [heads[0]],
            theme: "grid",
            tableWidth: "auto",
            fontStyle: "normal",
            body: [...rows],
          });
          doc.save("Providers Sheet.pdf");
          setValues("");
        }
      })
    );
  };

  return (
    <form>
      <fieldset
        disabled={count > 0 ? false : true}
        className={classes.exportAlign}
      >
        <select onChange={handleChange} value={values}>
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          {/* <option value="pdf">PDF</option> */}
        </select>
      </fieldset>
    </form>
  );
};

export default Export;
