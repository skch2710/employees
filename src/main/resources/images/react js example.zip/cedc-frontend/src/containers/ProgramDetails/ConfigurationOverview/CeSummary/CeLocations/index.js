import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import {
  Collapse,
  Divider,
  Grid,
  IconButton,
  Paper,
  Tooltip,
  useTheme,
} from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import { TiFilter } from "react-icons/ti";
import { MdVerified } from "react-icons/md";
import MaterialTable, { MTableToolbar } from "material-table";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  getUserSession,
  isEmptyGrid,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { useCeLocationStyle } from "./styles";
import {
  getCeLocationsFiltersObject,
  getCeLocationPayloadJson,
} from "./helper";
import { getCeLocations } from "../../../../../context/actions/ConfigOverview";
import { pagination } from "../../../../../utils/constants";
import DataNotFound from "../../../../../components/common/DataNotFound";
import DatePicker from "../../../../../components/common/DatePicker";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import useLocationExport from "./useLocationsExport";
import moment from "moment";
import { useCeSummaryStyle } from "../styles";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import {
  useGlobalStyles,
  getTableHeaderStyles,
  getTableCellStyles,
  getTableActionCellStyles,
} from "../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../../components/common/Pagination";

const CeLocations = memo((props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const theme = useTheme();
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();
  const commonSummaryClasses = useCeSummaryStyle();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const iconsAndButtons = useTableIconsAndButtons();
  const { exportToExcel } = useLocationExport();
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};
  const locationPermission = getUserPermissionOnModuleName(
    "Covered Entity Locations"
  );

  const { loading: locationsLoading, records: locationsList } = useSelector(
    (state) => state.coLocationsList
  );

  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "locationName",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [isCollapsed, setIsCollapsed] = useState(true);
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);
  const classes = useCeLocationStyle({
    totalElements: !_isEmpty(locationsList) && locationsList.totalElements,
    pageSize: controllers.pageSize,
    pageNumber: controllers.pageNumber,
  });

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      fetchCeLocations({
        sortBy: controllers.sortBy,
        sortOrder: controllers.sortOrder,
      });
    }
  }, [selectedCeForOverview]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  const fetchCeLocations = async (payload = {}, callback) => {
    const tableData = await dispatch(
      getCeLocations(
        getCeLocationPayloadJson({
          ...payload,
          ceId: selectedCeForOverview.ceid,
        })
      )
    );
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      let rowsPerPage = Number(pageSize);
      const totalPages = Math.ceil(locationsList.totalElements / rowsPerPage);
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      fetchCeLocations(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controllers.sortOrder,
          sortBy: controllers.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, locationsList, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = CE_LOCATIONS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchCeLocations(
        {
          pageNumber: controllers.pageNumber,
          pageSize: controllers.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controllers, columnFilters, locationsList]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getCeLocationsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchCeLocations(
      {
        ...controllers,
        filter: filterPayload,
        pageNumber: pagination.page,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const CE_LOCATIONS = [
    {
      title: "Verified",
      field: "verified",
      filtering: false,
      sorting: false,
      customFilterAndSearch: () => false,
      render: (rowData) => {
        return rowData.source == "OPA File" ? (
          <MdVerified className={classes.verifiedIcon} />
        ) : null;
      },
    },
    {
      title: "Source",
      field: "source",
      defaultFilter: enableFilters && columnFiltersRef.current.source,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.source || ""}>
            <span>{rowData.source || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.source}
          placeholder="Source"
        />
      ),
    },
    {
      title: "Participating 340B Site",
      field: "site340b",
      defaultFilter: enableFilters && columnFiltersRef.current.site340b,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.site340b === "true" ? "Yes" : "No"}>
            <span>{rowData.site340b === "true" ? "Yes" : "No"}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={columnFiltersRef.current.site340b || ""}
          >
            <option value={""}>Select option</option>
            <option value="true">Yes</option>
            <option value="false">No</option>
          </select>
        );
      },
    },
    {
      title: "Covered Entity",
      field: "coveredEntity",
      defaultFilter: enableFilters && columnFiltersRef.current.coveredEntity,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity || ""}>
            <span>{rowData.coveredEntity || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.coveredEntity}
          placeholder="Covered Entity"
        />
      ),
    },
    {
      title: "Location Name",
      field: "locationName",
      defaultFilter: enableFilters && columnFiltersRef.current.locationName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationName || ""}>
            <span>{rowData.locationName || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationName}
          placeholder="Location Name"
        />
      ),
    },
    {
      title: "Location HRSA ID",
      field: "locationHrsaId",
      defaultFilter: enableFilters && columnFiltersRef.current.locationHrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationHrsaId || ""}>
            <span>{rowData.locationHrsaId || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationHrsaId}
          placeholder="Location HRSA ID"
        />
      ),
    },
    {
      title: "Address Line 1",
      field: "addressLine1",
      defaultFilter: enableFilters && columnFiltersRef.current.addressLine1,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine1 || ""}>
            <span>{rowData.addressLine1 || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addressLine1}
          placeholder="Address Line 1"
        />
      ),
    },
    {
      title: "Address Line 2",
      field: "addressLine2",
      defaultFilter: enableFilters && columnFiltersRef.current.addressLine2,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine2 || ""}>
            <span>{rowData.addressLine2 || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addressLine2}
          placeholder="Address Line 2"
        />
      ),
    },
    {
      title: "City",
      field: "city",
      defaultFilter: enableFilters && columnFiltersRef.current.city,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.city || ""}>
            <span>{rowData.city || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.city}
          placeholder="City"
        />
      ),
    },
    {
      title: "State",
      field: "state",
      defaultFilter: enableFilters && columnFiltersRef.current.state,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.state || ""}>
            <span>{rowData.state || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.state}
          placeholder="State"
        />
      ),
    },
    {
      title: "Zip",
      field: "zip",
      defaultFilter: enableFilters && columnFiltersRef.current.zip,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.zip || ""}>
            <span>{rowData.zip || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.zip}
          placeholder="Zip"
        />
      ),
    },
    {
      title: "OPA Location Start Date",
      field: "startDate",
      defaultFilter: enableFilters && columnFiltersRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate || ""}>
            <span>{rowData.startDate || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.startDate
                ? moment(columnFiltersRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "OPA Location End Date",
      field: "endDate",
      defaultFilter: enableFilters && columnFiltersRef.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.endDate
                ? moment(columnFiltersRef.current.endDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Status",
      field: "locationStatus",
      defaultFilter: enableFilters && columnFiltersRef.current.locationStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationStatus}>
            <span>{rowData.locationStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationStatus}
          placeholder="Status"
        />
      ),
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(locationsList),
      onClick: () => setEnableFilters((prev) => !prev),
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(locationsList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(locationsList),
      onClick: () =>
        exportToExcel({
          controllers,
          columnFilters,
          ceId: selectedCeForOverview.ceid,
        }),
    },
  ];

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Locations" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={
                  !userSession.isInternalUser ||
                  !coPermissions.readWriteFlag ||
                  !locationPermission.readWriteFlag
                }
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(
                      MENUS.CE_LOCATIONS,
                      selectedCeForOverview.ceid
                    );
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  <div className={globalClasses.tableCardPrimary}>
                    <MaterialTable
                      title={
                        <BasicTypography
                          variant="h5"
                          title={`Covered Entity Locations (${getTableHeaderCount(
                            locationsList.totalElements
                          )})`}
                        />
                      }
                      columns={CE_LOCATIONS}
                      data={locationsList.content || []}
                      page={controllers.pageNumber - 1}
                      totalCount={locationsList.totalElements}
                      onChangePage={onPageChange}
                      onOrderChange={handleSort}
                      onFilterChange={handleColumnFilter}
                      tableRef={tableRef}
                      icons={{
                        SortArrow: () => TableCustomSortArrow(controllers),
                        Filter: () => <TiFilter fontSize="small" />,
                      }}
                      actions={ACTIONS}
                      components={{
                        Container: (props) => (
                          <Paper {...props} elevation={0} />
                        ),
                        Pagination: (props) => <Pagination {...props} />,
                        Toolbar: (props) => (
                          <MTableToolbar
                            classes={{ root: globalClasses.gridMuiToolbar }}
                            {...props}
                          />
                        ),
                        OverlayLoading: () => <TableProgressBar />,
                      }}
                      localization={{
                        header: {
                          actions: "Actions",
                        },
                        body: {
                          emptyDataSourceMessage: locationsLoading ? (
                            ""
                          ) : (
                            <DataNotFound />
                          ),
                        },
                      }}
                      isLoading={locationsLoading}
                      options={{
                        debounceInterval: 500,
                        search: false,
                        actionsColumnIndex: 0,
                        filtering: enableFilters,
                        paging: true,
                        showFirstLastPageButtons: false,
                        paginationPosition: "bottom",
                        exportButton: false,
                        paginationType: "stepped",
                        exportAllData: false,
                        headerStyle: getTableHeaderStyles(theme),
                        cellStyle: getTableCellStyles(theme),
                        actionsCellStyle: getTableActionCellStyles(theme),
                        tableLayout: "auto",
                        draggable: false,
                        columnResizable: true,
                        emptyRowsWhenPaging: false,
                        pageSize: controllers.pageSize,
                        maxBodyHeight: 400,
                        pageSizeOptions: isEmptyGrid(locationsList)
                          ? []
                          : pagination.pageSizeOptions,
                        showEmptyDataSourceMessage: true,
                      }}
                    />
                  </div>
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
});

export default CeLocations;
