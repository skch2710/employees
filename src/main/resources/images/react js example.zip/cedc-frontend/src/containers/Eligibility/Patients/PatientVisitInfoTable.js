import React, { useState, useEffect, useCallback, useRef } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { useDispatch, useSelector } from "react-redux";
import { Paper, Tooltip, Button, Grid } from "@material-ui/core";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { TiFilter } from "react-icons/ti";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";
import { pagination } from "../../../utils/constants";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import { useTheme } from "@material-ui/core/styles";
import { getPatientVisitInfo } from "../../../context/actions/Patients";
import { filterFunctionality } from "../../../utils/common";
import _isEmpty from "lodash/isEmpty";
import ExportPatientVisitInfo from "./ExportPatientVisitInfo";
import { getTableHeaderCount, isEmptyGrid } from "../../../utils/helper";
import TableProgressBar from "../../../components/common/TableProgressBar";
import DataNotFound from "../../../components/common/DataNotFound";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../components/common/Pagination";

const PatientVisitInfoTable = ({
  patientRowData,
  setOpenPopup,
  setValue,
  viewPatient,
  editPatient,
}) => {
  const { patientId, personId } = patientRowData || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const { exportToExcel } = ExportPatientVisitInfo();
  const theme = useTheme();
  const iconsAndButtons = useTableIconsAndButtons();

  const { records: patientVisitInfoList, loading } = useSelector(
    (state) => state.getPatientInnerGrid
  );

  const columnFiltersRef = useRef({});
  const [filter, setFilter] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [patientPayload, setPatientPayload] = useState({});
  const [controller, setController] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "lastName",
  });

  const fetchInnerGridData = (payload = {}) => {
    const payloadJson = {
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortBy: "",
      sortOrder: "",
      filter: [],
      export: false,
      patientId: patientId || personId,
      filter: columnFilters,
      ...payload,
    };
    setPatientPayload(payloadJson);
    dispatch(
      getPatientVisitInfo(payloadJson, (res) => {
        setController((prev) => ({
          ...prev,
          pageNumber: res && res.pageNo,
          pageSize: res && res.pageSize,
        }));
      })
    );
  };

  useEffect(() => {
    if (patientId || personId) fetchInnerGridData();
  }, []);

  const onChangePagination = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const { totalElements = 0 } = patientVisitInfoList;
      const totalPages = Math.ceil(totalElements / rowsPerPage) || 1;
      if (controller.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.pageNumber;
      fetchInnerGridData({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller]
  );

  const onChangeSorting = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PATIENTS_INNER_TABLE_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchInnerGridData({ sortOrder, sortBy });
    },
    [controller, columnFilters]
  );

  const onChangeFilter = async (value) => {
    const payload = {
      pageNumber: controller.pageNumber,
      pageSize: controller.pageSize,
    };
    if (value.length) {
      const responseValue = await filterFunctionality(
        value,
        "PatientVisitInfo"
      );
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setColumnFilters(responseValue);
    } else {
      payload.filter = null;
      setColumnFilters([]);
    }
    const updatedObj = {};
    value.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    columnFiltersRef.current = { ...updatedObj };
    fetchInnerGridData(payload);
  };

  const actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      disabled: isEmptyGrid(patientVisitInfoList),
      isFreeAction: true,
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(patientVisitInfoList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(patientVisitInfoList),
      onClick: () => exportToExcel({ patientPayload }),
    },
  ];

  const PATIENTS_INNER_TABLE_COLUMNS = [
    {
      title: "Visit Date",
      field: "admitVisitDate",
      defaultFilter: filter && columnFiltersRef.current.admitVisitDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.admitVisitDate}>
            <span>{rowData.admitVisitDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.admitVisitDate
                ? moment(columnFiltersRef.current.admitVisitDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Hospital Service",
      field: "hospitalService",
      defaultFilter: filter && columnFiltersRef.current.hospitalService,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.hospitalService}>
            <span>{rowData.hospitalService}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.hospitalService}
          placeholder="Hospital Service"
        />
      ),
    },
    {
      title: "Admit Type",
      field: "admitType",
      defaultFilter: filter && columnFiltersRef.current.admitType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.admitType}>
            <span>{rowData.admitType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.admitType}
          placeholder="Admit Type"
        />
      ),
    },
    {
      title: "Servicing Facility",
      field: "servicingFacility",
      defaultFilter: filter && columnFiltersRef.current.servicingFacility,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.servicingFacility}>
            <span>{rowData.servicingFacility}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.servicingFacility}
          placeholder="Servicing Facility"
        />
      ),
    },
    {
      title: "Assigned Patient Location",
      field: "assignedPatientLocation",
      defaultFilter: filter && columnFiltersRef.current.assignedPatientLocation,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.assignedPatientLocation}>
            <span>{rowData.assignedPatientLocation}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.assignedPatientLocation}
          placeholder="Assigned Patient Location"
        />
      ),
    },
    {
      title: "Provider NPI",
      field: "providerNpi",
      defaultFilter: filter && columnFiltersRef.current.providerNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerNpi}>
            <span>{rowData.providerNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.providerNpi}
          placeholder="Provider NPI"
        />
      ),
    },
    {
      title: "Provider FN",
      field: "providerFn",
      defaultFilter: filter && columnFiltersRef.current.providerFn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerFn}>
            <span>{rowData.providerFn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.providerFn}
          placeholder="Provider FN"
        />
      ),
    },
    {
      title: "Provider LN",
      field: "providerLn",
      defaultFilter: filter && columnFiltersRef.current.providerLn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerLn}>
            <span>{rowData.providerLn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.providerLn}
          placeholder="Provider LN"
        />
      ),
    },
  ];

  return (
    <>
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Patient Visit Info Data (${getTableHeaderCount(
                patientVisitInfoList.totalElements
              )})`}
            />
          }
          columns={PATIENTS_INNER_TABLE_COLUMNS}
          data={patientVisitInfoList.content}
          page={controller.pageNumber - 1}
          totalCount={patientVisitInfoList.totalElements || pagination.limit}
          actions={actions}
          onOrderChange={onChangeSorting}
          onChangePage={onChangePagination}
          onFilterChange={onChangeFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(controller),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                {...props}
                classes={{ root: globalClasses.gridMuiToolbar }}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: filter,
            paginationType: "stepped",
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controller && controller.pageSize,
            draggable: false,
            pageSizeOptions: isEmptyGrid(patientVisitInfoList)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>
      {(viewPatient || editPatient) && (
        <Grid container justifyContent="flex-end" spacing={2}>
          <Grid item>
            <Button
              type="submit"
              color="primary"
              size="small"
              variant="contained"
              className={globalClasses.primaryBtn}
              onClick={() => setValue(2)}
            >
              Next
            </Button>
          </Grid>
          <Grid item>
            <Button
              type="button"
              size="small"
              variant="outlined"
              color="default"
              className={globalClasses.secondaryBtn}
              onClick={() => {
                setOpenPopup(false);
              }}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      )}
    </>
  );
};

export default PatientVisitInfoTable;
