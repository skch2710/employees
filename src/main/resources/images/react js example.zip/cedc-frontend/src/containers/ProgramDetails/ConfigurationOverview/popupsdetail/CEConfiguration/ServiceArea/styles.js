import { makeStyles } from "@material-ui/core/styles";

export const serviceAreaPopUpStyles = makeStyles((_theme) => {
  return {
    configOptionWrapper: {
      display: "flex",
      gap: "5px",
      alignItems: "center",
    },
    globalErrorMsg: {
      padding: "90px",
      display: "flex",
      justifyContent: "center",
    },
    switchContainerGrid: {
      display: "flex",
      alignItems: "flex-start",
      gap: "5px",
    },
  };
});
