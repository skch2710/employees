import { makeStyles } from "@material-ui/core/styles";

export const useNdcSelectionStyles = makeStyles((theme) => ({
  greyCard: {
    backgroundColor: theme.colors.grey.boxOneBackground,
    borderRadius: "10px",
    padding: "15px",
    border: `solid 1px ${theme.colors.grey.boxOneBorder}`,
  },
  dlpSectionTitle: {
    fontSize: "12px",
    color: theme.colors.blue.dark,
    fontFamily: theme.fontFamily,
    fontWeight: 100,
  },
  autoApplyExclusionsCheckBox: {
    margin: "10px 0px 0px -5px",
  },
  reportContainer: {
    display: "flex",
    columnGap: "5px",
    alignItems: "center",
  },
  errorFileLink: {
    cursor: "pointer",
  },
}));
