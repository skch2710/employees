import React, {
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button, Grid } from "@material-ui/core";
import { SiMicrosoftexcel } from "react-icons/si";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import _get from "lodash/get";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import { NdcContext } from "../../NdcContext";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import SearchForm from "./SearchForm";
import Excel from "../../../../../assets/excel.png";
import DraftCreationTables from "./DraftCreationTables";
import {
  getNdcSearchPayload,
  getDraftPayloadToSave,
  getNdcSelectionDraftTablePayload,
  getNdcDynamicListParamsSearchPayload,
} from "./helper";
import {
  downloadNdcErrorFile,
  fetchNdcSectionStatus,
  getDynamicListParametersTableData,
  getNdcDraftListTableData,
  getNdcSearchResultTableData,
  saveNdcSelection,
} from "../../../../../context/actions/NdcExclusions";
import { getUserSession, isEmptyGrid } from "../../../../../utils/helper";
import { NDC_TABS } from "../../constants";
import DynamicListConfiguration from "./DynamicListConfiguration";
import { SET_NDC_SELECTION_SEARCH_LIST } from "../../../../../context/reducers/NdcExclusions/constants";
import BasicPopup from "../../../../../components/Popup/BasicPopup";
import BulkUpload from "./BulkUpload";
import Success from "../../../../../assets/pass.png";
import Failed from "../../../../../assets/fail.png";
import { useNdcSelectionStyles } from "./styles";
import classNames from "classnames";

const NdcListSelection = () => {
  const globalClasses = useGlobalStyles();
  const classes = useNdcSelectionStyles();
  const userSession = getUserSession();
  const {
    handleConfigPopup,
    ndcData,
    setNdcSelectionDraftTableData,
    ndcSelectionDraftTableData,
    setActiveInactiveTabs,
    setActiveNdcConfigTab,
    activeInactiveTabs,
    setNdcSelectionBulkUploadReport,
    setProgress,
    setNdcData,
    ndcSelectionBulkUploadReport,
  } = useContext(NdcContext) || {};
  const dispatch = useDispatch();
  const actionRef = useRef(null);
  const { records: dlpGridTableData } = useSelector(
    (state) => state.ndcDynamicListParams
  );
  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [bulkUploadPopup, setBulkUploadPopup] = useState(false);
  const { bulkUploaded = false, confirmBulkUploaded = false } =
    ndcSelectionBulkUploadReport;

  const getNdcSearchTableData = async (payload = {}, callback) => {
    const searchPayload = getNdcSearchPayload(payload);
    const tableData = await dispatch(
      getNdcSearchResultTableData(searchPayload)
    );
    if (!_isEmpty(tableData)) callback && callback(tableData);
  };

  const validateForm = ({ values, setFieldError }) => {
    if (
      (!values.drugManufacturerId || values.drugManufacturerId.length === 0) &&
      !values.gcn &&
      !values.ndc &&
      !values.drugName
    ) {
      setFieldError(
        "ndcSearchCriteriaError",
        "Please enter details to search NDC's"
      );
      return true;
    } else {
      return false;
    }
  };

  const handleSubmit = (values, { setFieldError }) => {
    if (bulkUploaded && !confirmBulkUploaded) {
      setNdcSelectionBulkUploadReport({
        ...ndcSelectionBulkUploadReport,
        confirmBulkUploaded: true,
      });
      return;
    }
    const haveErrors = validateForm({ values, setFieldError });
    if (haveErrors) return;

    getNdcSearchTableData(values, (resp) => {
      actionRef.current && actionRef.current.submitForm(resp);
    });
    setFormSubmittedValues(values);
  };

  const handleClear = useCallback((values) => {
    setFormSubmittedValues(values);
    actionRef.current && actionRef.current.clearForm(values);
  }, []);

  const getNdcDraftTableData = async ({ listId = 0, listHistoryId = 0 }) => {
    const tableData = await dispatch(
      getNdcDraftListTableData(
        getNdcSelectionDraftTablePayload({ listId, listHistoryId })
      )
    );
    if (!_isEmpty(tableData)) {
      setNdcSelectionDraftTableData({
        content: tableData.content,
        totalElements: tableData.totalElements,
      });
    }
  };

  useEffect(() => {
    if (!_isEmpty(ndcData)) {
      getNdcDraftTableData(ndcData);
      const searchPayload = getNdcDynamicListParamsSearchPayload(ndcData);
      dispatch(getDynamicListParametersTableData(searchPayload));
    }
    return () => {
      dispatch({
        type: SET_NDC_SELECTION_SEARCH_LIST,
        data: {},
      });
      setNdcSelectionBulkUploadReport({});
    };
  }, []);

  const handleNdcSelectionSubmit = async () => {
    if (bulkUploaded && !confirmBulkUploaded) {
      setNdcSelectionBulkUploadReport({
        ...ndcSelectionBulkUploadReport,
        confirmBulkUploaded: true,
      });
      return;
    }
    const payload = {
      listId: ndcData.listId || 0,
      listHistoryId: ndcData.listHistoryId || 0,
      draftExclusionList:
        getDraftPayloadToSave(ndcSelectionDraftTableData.content) || [],
      createdById: userSession.userId,
      modifiedById: userSession.userId,
    };
    const resp = await dispatch(saveNdcSelection(payload));
    if (!_isEmpty(resp)) {
      getNdcSectionStatus(ndcData.listId);
      setNdcData((prev) => ({
        ...prev,
        listHistoryId: _get(resp, "0.listHistoryId", prev.listHistoryId),
      }));
      navigateToNextTab();
    }
  };

  const navigateToNextTab = () => {
    setActiveNdcConfigTab(NDC_TABS.NDC_LIST_APPLICATION);
    if (!activeInactiveTabs[NDC_TABS.NDC_LIST_APPLICATION]) {
      setActiveInactiveTabs((prev) => {
        return {
          ...prev,
          [NDC_TABS.NDC_LIST_APPLICATION]: true,
        };
      });
    }
  };

  const getNdcSectionStatus = async (listId) => {
    const res = await dispatch(fetchNdcSectionStatus(listId));
    !_isEmpty(res) && setProgress(res);
  };

  const handleBulkUploadPopup = (state) => {
    if (state) setNdcSelectionBulkUploadReport({});
    setBulkUploadPopup(state);
  };

  const handleErrorFileDownload = (path) => {
    dispatch(downloadNdcErrorFile(path));
  };

  const handleNdcUploadSuccess = (res = {}) => {
    const { ndcList = [] } = res;
    if (ndcList && ndcList.length > 0) {
      const newPayload = getNdcSearchPayload({ ndc: ndcList });
      setFormSubmittedValues(newPayload);
      dispatch(getNdcSearchResultTableData(newPayload));
    }
  };

  const getBulkUploadReport = (report = {}) => {
    const { successMessage, failureMessage, failFilePath } = report;
    return (
      <Grid container spacing={1}>
        {successMessage && (
          <Grid item classes={{ root: classes.reportContainer }}>
            <img src={Success} alt="passed" height={18} width={18} />
            <BasicTypography variant="subtitle2">
              {successMessage}
            </BasicTypography>
          </Grid>
        )}
        {failureMessage && (
          <Grid item>
            <span
              className={classNames(
                classes.reportContainer,
                classes.errorFileLink
              )}
              onClick={() => handleErrorFileDownload(failFilePath)}
            >
              <img src={Failed} alt="failed" height={18} width={18} />
              <BasicTypography variant="caption" color="error">
                {failureMessage}
              </BasicTypography>
            </span>
          </Grid>
        )}
      </Grid>
    );
  };

  return (
    <>
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <BasicTypography variant="h4">NDC Selection</BasicTypography>
        </Grid>
        <Grid item xs={12}>
          <DynamicListConfiguration />
        </Grid>
        <Grid item>
          <SearchForm handleSubmit={handleSubmit} handleClear={handleClear} />
        </Grid>
        <Grid item>
          <Grid
            container
            justifyContent="flex-end"
            spacing={2}
            alignItems="center"
          >
            <Grid item>
              <a
                className={globalClasses.iconPlusClickableLink}
                href="/templates/NDC_template.xlsx"
              >
                <img src={Excel} alt="Template" />
                <span>Download Template</span>
              </a>
            </Grid>
            <Grid item>
              <Button
                startIcon={<SiMicrosoftexcel size={14} />}
                variant="outlined"
                size="small"
                className={globalClasses.grayButton}
                onClick={() => handleBulkUploadPopup(true)}
              >
                Bulk Upload
              </Button>
            </Grid>
          </Grid>
        </Grid>
        {!_isEmpty(ndcSelectionBulkUploadReport) && (
          <Grid item container justifyContent="flex-end">
            <Grid item>
              {getBulkUploadReport(ndcSelectionBulkUploadReport)}
            </Grid>
          </Grid>
        )}
        <Grid item>
          <DraftCreationTables
            ref={actionRef}
            searchTableProps={{ formSubmittedValues, getNdcSearchTableData }}
          />
        </Grid>
        <Grid item>
          <Grid container spacing={2} justifyContent="flex-end">
            <Grid item>
              {isEmptyGrid(ndcSelectionDraftTableData.content) &&
              !isEmptyGrid(dlpGridTableData) ? (
                <Button
                  type="button"
                  size="small"
                  variant="contained"
                  className={globalClasses.primaryBtn}
                  onClick={() => navigateToNextTab()}
                >
                  Next
                </Button>
              ) : (
                <Button
                  type="submit"
                  size="small"
                  variant="contained"
                  className={globalClasses.primaryBtn}
                  disabled={isEmptyGrid(ndcSelectionDraftTableData.content)}
                  onClick={handleNdcSelectionSubmit}
                >
                  Save And Continue
                </Button>
              )}
            </Grid>
            <Grid item>
              <Button
                type="reset"
                size="small"
                variant="contained"
                className={globalClasses.grayButton}
                onClick={() => handleConfigPopup({ state: false })}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <BasicPopup
        title="Bulk Upload NDC's"
        show={bulkUploadPopup}
        handleClose={() => handleBulkUploadPopup(false)}
        disableFooter={true}
        dialogProps={{
          maxWidth: "sm",
        }}
      >
        <BulkUpload
          handleBulkUploadPopup={handleBulkUploadPopup}
          handleNdcUploadSuccess={handleNdcUploadSuccess}
        />
      </BasicPopup>

      <BasicPopup
        show={confirmBulkUploaded}
        title="Confirmation"
        handleClose={() => {
          setNdcSelectionBulkUploadReport({
            ...ndcSelectionBulkUploadReport,
            confirmBulkUploaded: false,
          });
        }}
        submitProps={{
          buttonTitle: "Ok",
          handleSubmit: () => {
            if (bulkUploaded) {
              setNdcSelectionBulkUploadReport({});
            }
          },
        }}
        cancelProps={{
          buttonTitle: "Cancel",
          handleCancel: () => {
            setNdcSelectionBulkUploadReport({
              ...ndcSelectionBulkUploadReport,
              confirmBulkUploaded: false,
            });
          },
        }}
        dialogProps={{
          maxWidth: "sm",
        }}
      >
        <BasicTypography variant="h5">
          All your search results are going to be cleared.
        </BasicTypography>
      </BasicPopup>
    </>
  );
};

export default NdcListSelection;
