import React, { useRef, useState } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEmpty from "lodash/isEmpty";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../components/common/DataNotFound";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import { useOPALocationsTablesStyles } from "./styles";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import { useSelector } from "react-redux";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";

const CESameLocationTable = (props) => {
  const { ceList = [] } = props || {};
  const theme = useTheme();
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();

  const { loading } = useSelector((state) => state.ndcSelectionSearchList);

  const [enableFilters, setEnableFilters] = useState(false);
  const tableRef = useRef(null);

  const classes = useOPALocationsTablesStyles();

  const LOCATIONS_COLUMNS = [
    {
      title: "Covered Entity Name",
      field: "coveredEntity",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity}>
            <span>{rowData.coveredEntity || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Covered Entity Name" />
      ),
    },
    {
      title: "Location Name",
      field: "locationName",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationName}>
            <span>{rowData.locationName || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Location Name" />
      ),
    },
    {
      title: "Location HRSA ID ",
      field: "locationHrsaId",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationHrsaId}>
            <span>{rowData.locationHrsaId || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="HRSA ID" />
      ),
    },
    {
      title: "Address Line 1",
      field: "addressLine1",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine1}>
            <span>{rowData.addressLine1 || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Address Line 1" />
      ),
    },
    {
      title: "Address Line 2",
      field: "addressLine2",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine2}>
            <span>{rowData.addressLine2}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Address Line 2" />
      ),
    },
    {
      title: "City",
      field: "city",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.city}>
            <span>{rowData.city}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="City" />
      ),
    },
    {
      title: "State",
      field: "state",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.state}>
            <span>{rowData.state}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="State" />
      ),
    },
    {
      title: "Zip",
      field: "zip",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.zip}>
            <span>{rowData.zip}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Zip" />
      ),
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      // disabled: isEmptyGrid(searchResults),
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  return (
    <>
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Covered Entities Associated with Same Address`}
            />
          }
          tableRef={tableRef}
          columns={LOCATIONS_COLUMNS}
          data={ceList}
          //page={controllers.pageNumber - 1}
          // totalCount={searchResults.totalElements}
          icons={{
            SortArrow: () => TableCustomSortArrow(),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            //Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: false,
            selection: false,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            // pageSize: controllers.pageSize,
            maxBodyHeight: 200,
            minBodyHeight: 150,
            // pageSizeOptions: isEmptyGrid(searchResults)
            //   ? []
            //   : pagination.pageBillingSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>
    </>
  );
};

export default CESameLocationTable;
