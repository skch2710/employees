import { makeStyles } from "@material-ui/core";

export const useCreatePasswordStyles = makeStyles((_theme) => ({
  questionsInputFields: {
    padding: "0 7px",
  },
  paper: {
    padding: "70px 147px 20px 173px",
    backgroundColor: "#FBFBFB",
  },
  subtitle: {
    display: "flex",
    marginTop: "10px",
  },
  subtitle2: {
    color: "#071B72F8",
  },
  spacing: {
    marginTop: "20px",
  },
  iconStyle: {
    width: "83px",
    height: "79px",
  },
  formControl: {
    color: "#434653 ",
    width: "98% !important",
    padding: "0 0 0 7px !important",
    border: "1px solid #2699FB  !important",
    borderRadius: "4px !important",
    boxShadow: "1px 1px 3px rgb(41 84 106 / 7%) !important",
    height: "30px !important",
    fontSize: "small !important",
  },
  messageGrid: {
    border: "1px solid #f9e6ef",
    backgroundColor: "#f9e6ef",
    padding: "10px",
    fontSize: "12px",
    width: "98%",
  },
}));

export const useLoginStyles = makeStyles((theme) => ({
  messageGrid: {
    border: "1px solid #f9e6ef",
    backgroundColor: "#f9e6ef",
    padding: "10px",
    fontSize: "12px",
    width: "98%",
  },
  signUpTitle: {
    color: theme.colors.blue[100],
  },
}));

export const useLoginVerificationStyles = makeStyles((theme) => ({
  verificationTitle: {
    color: theme.colors.blue[100],
  },
}));

