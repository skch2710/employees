import { makeStyles } from "@material-ui/core";

export const useReportRenderingStyles = makeStyles((_theme) => ({
  "powerBiReportContainer": {
    height: "80vh",
    margin: "1% auto",
    width: "100%",
  },
  reportNameStyle: {
    overflowWrap: "break-word",
  },
}));
