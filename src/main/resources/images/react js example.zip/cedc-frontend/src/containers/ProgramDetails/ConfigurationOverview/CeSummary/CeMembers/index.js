import React, { useContext, useEffect } from "react";
import { Grid, IconButton, Paper } from "@material-ui/core";
// import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { getMembersPayloadJson } from "./helper";
import { fetchMembersTableData } from "../../../../../context/actions/ConfigOverview";
import { useCeSummaryStyle } from "../styles";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";

const CeMembers = (props = {}) => {
  const { selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const _globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};
  const membersPermissions = getUserPermissionOnModuleName("Patients") || {};

  const { loading: _membersLoading, records: membersList = {} } =
    useSelector((state) => state.coMembersList) || {};

  // const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      getCeMembers();
    }
  }, [selectedCeForOverview]);

  // useEffect(() => {
  //   setIsCollapsed(isAllCollapsed);
  // }, [isAllCollapsed]);

  // const toggleCollapse = useCallback(() => {
  //   setIsCollapsed((prev) => !prev);
  // }, []);

  const getCeMembers = async (payload = {}, callback) => {
    const tableData = await dispatch(
      fetchMembersTableData(
        getMembersPayloadJson({
          ...payload,
          ceId: selectedCeForOverview.ceid,
        })
      )
    );
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography
              variant="h3"
              title={`Patient - ${
                getTableHeaderCount(membersList.totalElements) || 0
              } Active`}
            />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={
                  !userSession.isInternalUser ||
                  !coPermissions.readWriteFlag ||
                  !membersPermissions.readWriteFlag
                }
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(MENUS.CE_MEMBERS, selectedCeForOverview.ceid);
                  }}
                />
              </IconButton>
              {/* <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton> */}
            </div>
          </div>
        </Grid>
        {/* <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  Hi
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid> */}
      </Grid>
    </Paper>
  );
};

export default CeMembers;
