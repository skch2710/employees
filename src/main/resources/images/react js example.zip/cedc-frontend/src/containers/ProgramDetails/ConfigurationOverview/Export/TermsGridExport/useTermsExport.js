import { useDispatch, useSelector } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import _isEmpty from "lodash/isEmpty";
import { ALL_CE_OPTION, LABELS, notNull } from "../../../../../utils/constants";
import { fetchTermsGridTableData } from "../../../../../context/actions/ConfigOverview";
import { defaultCoSearchPayload } from "../../helper";

const useTermsExport = () => {
  const dispatch = useDispatch();
  const { ceList } = useSelector((state) => state.coveredEntities);

  const exportToExcel = async (props = {}) => {
    const { controllers, columnFilters, formSubmittedValues } = props;
    const tableData = await dispatch(
      fetchTermsGridTableData(
        defaultCoSearchPayload({
          sortBy: controllers.sortBy,
          sortOrder: controllers.sortOrder,
          filter: columnFilters,
          export: true,
          ceId: ALL_CE_OPTION,
          ceList,
          ...formSubmittedValues,
        })
      )
    );
    if (!_isEmpty(tableData)) {
      var data = tableData.content.map(
        ({
          ceName,
          effectiveDate,
          contractStartDate,
          contractEndDate,
          fullname,
          emailAddress,
          contactNumber,
          activeProviders,
          activeMembers,
          activePharmacies,
          flatFeePerClient,
          flatFeePerTransaction,
          configStatus,
          flatFeePlusPercentage,
          percentageOnly,
          pharmacyChainGrossSavings,
        }) => ({
          [LABELS.CoveredEntity]: notNull(ceName),
          "Configuration Status": notNull(configStatus),
          "Effective Date": notNull(effectiveDate),
          "340BDirect+ Fee Start Date": notNull(contractStartDate),
          "340BDirect+ Fee End Date": notNull(contractEndDate),
          "Primary Contact": notNull(fullname),
          "Email Address": notNull(emailAddress),
          "Primary Phone": notNull(contactNumber),
          "Active Providers": notNull(activeProviders),
          "Active Patients": notNull(activeMembers),
          "Active Pharmacies": notNull(activePharmacies),
          "Percentage": notNull(percentageOnly),
          "Flat Fee + Percentage": notNull(flatFeePlusPercentage),
          "Flat Fee": notNull(flatFeePerClient),
          "Flat Fee Per Claim": notNull(flatFeePerTransaction),
          "Pharmacy Chain Gross Savings": notNull(pharmacyChainGrossSavings)
        })
      );

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "Covered Entities List" + ".xlsx");
    }
  };

  return { exportToExcel };
};

export default useTermsExport;
