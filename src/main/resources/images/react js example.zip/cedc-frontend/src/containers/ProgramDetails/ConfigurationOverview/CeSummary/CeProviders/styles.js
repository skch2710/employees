import { makeStyles } from "@material-ui/core";

export const useCeProvidersStyle = makeStyles((_theme) => {
  return {};
});
