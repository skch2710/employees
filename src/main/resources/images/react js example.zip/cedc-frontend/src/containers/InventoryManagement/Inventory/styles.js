import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const useInvStyles = makeStyles((theme) => {
  return {
    selectedCheckBox: {
      color: theme.colors.blue[500],
    },
    closeFilterIcon: {
      padding: "5px",
    },
    formActionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
    },
    exportContainer: {
      textAlign: "right",
      padding: "8px 10px 0 0",
    },
    exportSelect: {
      height: "30px",
      padding: "0 6px",
      borderRadius: "4px",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
    radioGridContainer: {
      display: "flex",
      alignItems: "flex-end",
      flexBasis: "auto"
    },
    gridContentContainer: {
      height: "30px",
      display: "flex",
      alignItems: "center",
      gap: "4px",
      color: theme.colors.monochrome.input,
    },
    radioInput: {
      margin: "0 !important",
    },
    radioAndLabelContainer: {
      display: "flex",
      gap: "5px",
      alignItems: "center",
      width:"max-content",
      "& label": {
        color: `${theme.colors.monochrome.input} !important`,
        fontFamily: theme.fontFamily,
      },
    },
  };
});
