import React, { useCallback, useContext, useEffect, useState } from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { useCeSummaryStyle } from "../styles";
import { getCeVisitWindowConfig } from "../../../../../context/actions/ConfigOverview";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import _get from "lodash/get";

const CeVisitWindowConfig = (props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};

  const { visitWindowConfig = {} } =
    useSelector((state) => state.coVisitWindowConfig) || {};

  const { defaultVisitWindow = {}, customVisitWindows = [] } =
    visitWindowConfig || {};

  const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      dispatch(getCeVisitWindowConfig(selectedCeForOverview.ceid));
    }
  }, [selectedCeForOverview]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Visit Window" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={
                  !userSession.isInternalUser || !coPermissions.readWriteFlag
                }
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(
                      MENUS.CE_VISIT_WINDOW,
                      selectedCeForOverview.ceid
                    );
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5">
                        Default Visit Window
                      </BasicTypography>
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={3}>
                        <Grid item md={1}>
                          <BasicTypography variant="subtitle2">
                            {_get(
                              defaultVisitWindow,
                              "daysBeforeVisitDate",
                              ""
                            )}
                          </BasicTypography>
                        </Grid>
                        <Grid item md={2}>
                          <BasicTypography variant="subtitle2">
                            Days before visit
                          </BasicTypography>
                        </Grid>
                        <Grid item md={1}>
                          <BasicTypography variant="subtitle2">
                            {_get(defaultVisitWindow, "daysAfterVisitDate", "")}
                          </BasicTypography>
                        </Grid>
                        <Grid item md={2}>
                          <BasicTypography variant="subtitle2">
                            Days after visit
                          </BasicTypography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                {customVisitWindows.length ? (
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        <BasicTypography variant="h5">
                          Custom Configuration Variables
                        </BasicTypography>
                      </Grid>
                      {customVisitWindows.map(
                        (customVisitWindow = {}, cvwIndex) => (
                          <Grid item md={12} key={`cvw-${cvwIndex}`}>
                            <Grid container spacing={3}>
                              <Grid item md={2}>
                                <BasicTypography variant="subtitle2">
                                  {customVisitWindow.customValueType}
                                </BasicTypography>
                              </Grid>
                              <Grid item md={2}>
                                <Grid container direction="column" spacing={1}>
                                  {!_isEmpty(
                                    customVisitWindow.customValueIds
                                  ) &&
                                    customVisitWindow.customValueIds.map(
                                      (customValues = {}, index) => (
                                        <Grid item key={index}>
                                          <BasicTypography variant="subtitle2">
                                            {customValues.customValue || ""}
                                          </BasicTypography>
                                        </Grid>
                                      )
                                    )}
                                </Grid>
                              </Grid>
                              <Grid item md={1}>
                                <BasicTypography variant="subtitle2">
                                  {customVisitWindow.daysBeforeVisitDate}
                                </BasicTypography>
                              </Grid>
                              <Grid item md={2}>
                                <BasicTypography variant="subtitle2">
                                  Days before visit
                                </BasicTypography>
                              </Grid>
                              <Grid item md={1}>
                                <BasicTypography variant="subtitle2">
                                  {customVisitWindow.daysAfterVisitDate}
                                </BasicTypography>
                              </Grid>
                              <Grid item md={2}>
                                <BasicTypography variant="subtitle2">
                                  Days after visit
                                </BasicTypography>
                              </Grid>
                            </Grid>
                          </Grid>
                        )
                      )}
                    </Grid>
                  </Grid>
                ) : null}
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CeVisitWindowConfig;
