import React, { useState } from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import {
  TabPanel,
  a11yProps,
} from "../../../../components/common/VerticalTab/Tabpanel";
import Box from "@mui/material/Box";
import { InvoicesTabsStyles } from "../styles";
import InvoiceDetails from "./ActionsViewTabs/InvoiceDetails";
import RemittanceDetails from "./ActionsViewTabs/RemittanceDetails";
import ClaimDetails from "./ActionsViewTabs/ClaimDetails";
import TrueUpDetails from "./ActionsViewTabs/TrueUpDetails";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";

const ActionsView = ({
  submitactiontype,
  setOpenPopup,
  rowData,
  filtersValues,
}) => {
  const globalClasses = useGlobalStyles();
  const classes = InvoicesTabsStyles();
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%" }}>
      <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
          indicatorColor="primary"
          classes={{
            indicator: classes.tabsIndicator,
            flexContainer: classes.tabsContainer,
          }}
        >
          <Tab
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            label="Invoice Fee Details"
            {...a11yProps(0)}
          />
          <Tab
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            label="340B Remittance Details"
            {...a11yProps(1)}
          />
          <Tab
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            label="Claim Details"
            {...a11yProps(2)}
          />
          <Tab
            classes={{
              root: classes.tabsLabel,
              selected: classes.selectedTab,
            }}
            label="True Up Details"
            {...a11yProps(3)}
          />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <InvoiceDetails
          actionsRowDataDetails={{ ...rowData }}
          setValue={setValue}
          setOpenPopup={setOpenPopup}
          filtersValues={filtersValues}
        />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <RemittanceDetails
          actionsRowDataDetails={{ ...rowData }}
          setValue={setValue}
          setOpenPopup={setOpenPopup}
          filtersValues={filtersValues}
        />
      </TabPanel>
      <TabPanel value={value} index={2}>
        <ClaimDetails
          actionsRowDataDetails={{ ...rowData }}
          setValue={setValue}
          setOpenPopup={setOpenPopup}
          filtersValues={filtersValues}
        />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <TrueUpDetails
          actionsRowDataDetails={{ ...rowData }}
          setValue={setValue}
          setOpenPopup={setOpenPopup}
          filtersValues={filtersValues}
        />
      </TabPanel>
    </Box>
  );
};

export default ActionsView;
