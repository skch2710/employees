import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { getInvoiceGridDataExport } from "../../../../context/actions/Invoice";
import { notNull } from "../../../../utils/constants";
import {
  formatValue,
  formatValueInAccordion,
} from "../../../../utils/common";
import {
  getDefaultInvoiceListExport
} from "../constants";


const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { controller, columnFilters, formRef } = props;
    const { isSubmitting, values } = (formRef && formRef.current) || {};
    dispatch(
      getInvoiceGridDataExport(
        {
          ...getDefaultInvoiceListExport(values),
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              ceName,
              invoiceNumber,
              invoicePeriodStartDate,
              invoicePeriodEndDate,
              totalInvoiced,
              dispensingFee,
              trueUp,
              ceTotalReceivedAmount,
              direct340BTrxnFee
            }) => ({
              "Covered Entity": notNull(ceName),
              "Invoice Number": invoiceNumber,
              "Billing Period": `${invoicePeriodStartDate} - ${invoicePeriodEndDate}`,
              "Pharmacy EAC": formatValueInAccordion(notNull(totalInvoiced)),
              "Dispensing Fees": formatValueInAccordion(notNull(dispensingFee)),
              "True Up Fees": formatValueInAccordion(notNull(trueUp)),
              "Net Remittance": formatValueInAccordion(notNull(ceTotalReceivedAmount)),
              "340BDirect+ Fees": formatValueInAccordion(notNull(direct340BTrxnFee)),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Invoice List" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
