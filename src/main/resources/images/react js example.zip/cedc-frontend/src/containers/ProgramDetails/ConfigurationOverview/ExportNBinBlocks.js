import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { phNetworkBINBlocksExport } from "../../../context/actions/ConfigOverview";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import { LABELS, notNull } from "../../../utils/constants";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import "jspdf-autotable";
const fileName = "Pharmacy Network Bin Blocks List";

const ExportNBinBlocks = ({
  ciId, 
  sortBy,
  sortOrder,
  count,
}) => {
  const dispatch = useDispatch();
  const classes = useStyles()
  const [values, setValues] = useState("");
  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const dataa = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8" });
    FileSaver.saveAs(dataa, fileName + ".xlsx");
  };

  let heads = [];
  let rows = [];

  const ExportTOPDF = (data) => {
    const listheads = data.map((i) => {
      let keys_heads = {
        "BIN": Object.keys(i)[0],
        "PCN": Object.keys(i)[1],
        "Group Number": Object.keys(i)[2],
        "Bin Reason": Object.keys(i)[3],
        "Start Date": Object.keys(i)[4],
        "End Date": Object.keys(i)[5],
        [LABELS.PharmacyChain]: Object.keys(i)[6],
        "Admin Co": Object.keys(i)[7],

      };
      heads.push(keys_heads);
    });

    const listrows = data.map((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
      phNetworkBINBlocksExport(
        {
          ceID: [ciId],
          sortBy: sortBy,
          sortOrder: sortOrder,
          startDate:"",
          endDate:"",
          entityLocationID:  [0],
          export: true,
        },
        function (result) {
          var data = result.content.map(
            ({
              bin,
              pcn,
              groupNumber,
              binReason,
              startDate,
              endDate,
              phGroupName,
              adminCo
            }) => ({
                [LABELS.PharmacyChain]: notNull(phGroupName),
                "Admin Co": notNull(adminCo),
              "BIN": notNull(bin),
              "PCN": notNull(pcn),
              "Group Number": notNull(groupNumber),
              "Bin Reason": notNull(binReason),
              "Start Date": notNull(startDate),
              "End Date": notNull(endDate),
            })
          );

          if (e.target.value == "excel") {
            setTimeout(ExportToExcel(data), 5000);
            setValues("");
          }
          if (e.target.value == "pdf") {
            setTimeout(ExportTOPDF(data), 5000);
            const doc = new jsPDF();
            doc.autoTable({
              head: [heads[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...rows],
            });
            doc.save("pharmacy_network_bin_blocks_sheet.pdf");
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset disabled={count > 0 ? false : true} className={classes.exportAlign}>
        <select onChange={handleChange} value={values}>
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default ExportNBinBlocks;
