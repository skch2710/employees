import React, {
  forwardRef,
  memo,
  useCallback,
  useContext,
  useState,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { TiFilter } from "react-icons/ti";
import moment from "moment";
import { useSelector } from "react-redux";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { pagination } from "../../../../../../utils/constants";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import {
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../../../components/common/DatePicker";
import { NdcContext } from "../../../NdcContext";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import NdcDetailsTable from "./NdcDetailsTable";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import Pagination from "../../../../../../components/common/Pagination";
import _get from "lodash/get";

const NdcDraftTable = memo(
  forwardRef((_props = {}, ref) => {
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const iconsAndButtons = useTableIconsAndButtons();
    const { ndcSelectionDraftTableData = {} } = useContext(NdcContext) || {};
    const { loading } = useSelector(
      (state) => state.ndcSelectionDraftListLoading
    );

    const [enableFilters, setEnableFilters] = useState(false);
    const [showNdcDetailsPopup, setShowNdcDetailsPopup] = useState(false);
    const [ndcDetailsRowData, setNdcDetailsRowData] = useState({});

    const handleDraftExport = (data = []) => {
      const filteredData = data.map((row = {}) => ({
        GCN: row.gcn || "",
        NDC: row.ndc || "",
        "Drug Name": row.drugName || "",
        Manufacturer: row.drugManufacturer || "",
        "NDC Effective Start Date": row.ndcEffectiveStartDate || "",
        "NDC Effective End Date": row.ndcEffectiveEndDate || "",
      }));
      const ws = XLSX.utils.json_to_sheet(filteredData);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "NDC Draft List.xlsx");
    };

    const NDC_DRAFT_RESULT_COLUMNS = [
      {
        title: "GCN",
        field: "gcn",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.gcn}>
              <span>{rowData.gcn}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="GCN" />
        ),
      },
      {
        title: "NDC",
        field: "ndc",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndc}>
              <a
                className={globalClasses.gridClickableLink}
                onClick={handleNdcDetailsPopup({ state: true, rowData })}
              >
                {rowData.ndc}
              </a>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="NDC" />
        ),
      },
      {
        title: "Drug Name",
        field: "drugName",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugName}>
              <span>{rowData.drugName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Drug Name" />
        ),
      },
      {
        title: "Manufacturer",
        field: "drugManufacturer",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugManufacturer}>
              <span>{rowData.drugManufacturer}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Manufacturer" />
        ),
      },
      {
        title: "NDC Effective Start Date",
        field: "ndcEffectiveStartDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndcEffectiveStartDate || ""}>
              <span>{rowData.ndcEffectiveStartDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
      {
        title: "NDC Effective End Date",
        field: "ndcEffectiveEndDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndcEffectiveEndDate || ""}>
              <span>{rowData.ndcEffectiveEndDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
    ];

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(ndcSelectionDraftTableData),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(ndcSelectionDraftTableData),
        isFreeAction: true,
        onClick: () => handleDraftExport(ref.current.dataManager.filteredData),
      },
    ];

    const handleNdcDetailsPopup = useCallback(
      (prop = {}) =>
        () => {
          const { state, rowData } = prop;
          if (state) {
            setNdcDetailsRowData(rowData);
          }
          setShowNdcDetailsPopup(state);
        },
      []
    );

    return (
      <>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`NDC - Draft Exclusion List (${getTableHeaderCount(
                _get(ndcSelectionDraftTableData, "totalElements", 0)
              )})`}
            />
          }
          tableRef={ref}
          columns={NDC_DRAFT_RESULT_COLUMNS}
          data={_get(ndcSelectionDraftTableData, "content", [])}
          totalCount={_get(ndcSelectionDraftTableData, "totalElements", 0)}
          icons={{
            SortArrow: () => TableCustomSortArrow(),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            Pagination: (props) => <Pagination {...props} />,
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            selection: true,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            paginationType: "stepped",
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: pagination.limit,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(ndcSelectionDraftTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
        <BasicPopup
          title="NDC History"
          show={showNdcDetailsPopup}
          disableFooter={true}
          dialogProps={{
            maxWidth: "md",
          }}
          handleClose={handleNdcDetailsPopup({ state: false })}
        >
          <NdcDetailsTable ndcDetailsRowData={ndcDetailsRowData} />
        </BasicPopup>
      </>
    );
  })
);

export default NdcDraftTable;
