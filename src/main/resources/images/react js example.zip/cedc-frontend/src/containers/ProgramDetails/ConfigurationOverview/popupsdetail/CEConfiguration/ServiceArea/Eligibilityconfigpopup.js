import React, { useContext, useState } from "react";
import { Grid, Button, FormLabel } from "@material-ui/core";
import { Switch } from "antd";
import { getUserSession } from "../../../../../../utils/helper";
import { COContext } from "../../../../COContext";
import { serviceAreaPopUpStyles } from "./styles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import Toggle from "../../../../../../components/common/Toggle";

const Eligibilityconfigpopup = ({
  serviceAreaData,
  handleSave,
  setOpenPopup,
  formRef,
  submitData,
  isVisitInfo,
}) => {
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();
  const { messageUuid } = useContext(COContext);
  const classes = serviceAreaPopUpStyles();
  const [admitType, setAdmitType] = useState(
    (serviceAreaData &&
      serviceAreaData.length > 0 &&
      serviceAreaData[0]["Admit Type"]) ||
      []
  );
  const [hospitalService, setHospitalService] = useState(
    (serviceAreaData &&
      serviceAreaData.length > 0 &&
      serviceAreaData[0]["Hospital Service"]) ||
      []
  );
  const [patientLocation, setPatientLocation] = useState(
    (serviceAreaData &&
      serviceAreaData.length > 0 &&
      serviceAreaData[0]["Patient Location"]) ||
      []
  );
  const [patientType, setPatientType] = useState(
    (serviceAreaData &&
      serviceAreaData.length > 0 &&
      serviceAreaData[0]["Patient Type"]) ||
      []
  );
  const [serviceFacility, setServiceFacility] = useState(
    (serviceAreaData &&
      serviceAreaData.length > 0 &&
      serviceAreaData[0]["Servicing Facility"]) ||
      []
  );

  const handleChange = (e, type, key) => {
    let index;
    if (type === "hospitalService") {
      index = hospitalService.findIndex(
        (keyValue) => keyValue.configItemId == key.configItemId
      );
      hospitalService[index].inactiveFlag = e.target.checked ? "N" : "Y";
      setHospitalService([...hospitalService]);
    }
    if (type === "admitType") {
      index = admitType.findIndex(
        (keyValue) => keyValue.configItemId == key.configItemId
      );
      admitType[index].inactiveFlag = e.target.checked ? "N" : "Y";

      setAdmitType([...admitType]);
    }
    if (type === "serviceFacility") {
      index = serviceFacility.findIndex(
        (keyValue) => keyValue.configItemId == key.configItemId
      );
      serviceFacility[index].inactiveFlag = e.target.checked ? "N" : "Y";

      setServiceFacility([...serviceFacility]);
    }
    if (type === "patientLocation") {
      index = patientLocation.findIndex(
        (keyValue) => keyValue.configItemId == key.configItemId
      );
      patientLocation[index].inactiveFlag = e.target.checked ? "N" : "Y";

      setPatientLocation([...patientLocation]);
    }
    if (type === "patientType") {
      index = patientType.findIndex(
        (keyValue) => keyValue.configItemId == key.configItemId
      );
      patientType[index].inactiveFlag = e.target.checked ? "N" : "Y";
      setPatientType([...patientType]);
    }
  };

  const saveTemp = () => {
    let array = [];
    let json = [
      ...admitType,
      ...hospitalService,
      ...serviceFacility,
      ...patientLocation,
      ...patientType,
    ];
    json.map((key) => {
      let obj = {
        ceid:
          (messageUuid && messageUuid.ceid) ||
          (formRef &&
            formRef.current &&
            formRef.current.values &&
            formRef.current.values.ceid),
        configItemId: key.configItemId,
        deselected: key.inactiveFlag === "N" ? true : false,
        createdById: userSession.createdBy,
        modifiedById: userSession.userId,
      };
      //  As per latest API changes (as on 06 Feb 2023), if we get 'ceVisitItemId' as null
      //  in GET call then consider that config as 'New', in this case we need not pass 'ceEligibleItemId' key
      if (key.ceVisitItemId) {
        obj["ceEligibleItemId"] = key.ceVisitItemId;
      }
      array.push({ ...obj });
    });
    if (array.length > 0) {
      if (isVisitInfo) submitData(false, array);
      else handleSave(array);
    }
  };

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="body2">
          Select those items below that are eligible for 340B program. The
          covered entities Eligibility records will be loaded.
        </BasicTypography>
        <Grid />
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item md xs={12}>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <BasicTypography variant="h5">Hospital Service</BasicTypography>
              </Grid>
              <Grid item>
                <Grid container direction="column" spacing={1}>
                  {hospitalService &&
                    hospitalService.length > 0 &&
                    hospitalService.map((keyItem, index) => (
                      <Grid
                        item
                        key={"hospitalService" + index}
                        className={classes.switchContainerGrid}
                      >
                        <Toggle
                          checked={keyItem.inactiveFlag === "N" ? true : false}
                          onChange={(e) => {
                            handleChange(e, "hospitalService", keyItem);
                          }}
                        />
                        <FormLabel className={globalClasses.noPaddingForLabels}>
                          {keyItem.configurationType}
                        </FormLabel>
                      </Grid>
                    ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid item md xs={12}>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <BasicTypography variant="h5">Admit Type</BasicTypography>
              </Grid>
              <Grid item>
                <Grid container direction="column" spacing={1}>
                  {admitType &&
                    admitType.length > 0 &&
                    admitType.map((keyItem, index) => (
                      <Grid
                        item
                        key={"admitType" + index}
                        className={classes.switchContainerGrid}
                      >
                        <Toggle
                          checked={keyItem.inactiveFlag === "N" ? true : false}
                          onChange={(e) =>
                            handleChange(e, "admitType", keyItem)
                          }
                        />
                        <FormLabel className={globalClasses.noPaddingForLabels}>
                          {keyItem.configurationType}
                        </FormLabel>
                      </Grid>
                    ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid item md xs={12}>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <BasicTypography variant="h5">
                  Servicing Facility
                </BasicTypography>
              </Grid>
              <Grid item>
                <Grid container direction="column" spacing={1}>
                  {serviceFacility &&
                    serviceFacility.length > 0 &&
                    serviceFacility.map((keyItem, index) => (
                      <Grid
                        item
                        key={"serviceFacility" + index}
                        className={classes.switchContainerGrid}
                      >
                        <Toggle
                          checked={keyItem.inactiveFlag === "N" ? true : false}
                          onChange={(e) =>
                            handleChange(e, "serviceFacility", keyItem)
                          }
                        />
                        <FormLabel className={globalClasses.noPaddingForLabels}>
                          {keyItem.configurationType}
                        </FormLabel>
                      </Grid>
                    ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid item md xs={12}>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <BasicTypography variant="h5">{`${
                  isVisitInfo ? "Assigned" : ""
                } Patient Location`}</BasicTypography>
              </Grid>
              <Grid item>
                <Grid container direction="column" spacing={1}>
                  {patientLocation &&
                    patientLocation.length > 0 &&
                    patientLocation.map((keyItem, index) => (
                      <Grid
                        key={"patientLocation" + index}
                        item
                        className={classes.switchContainerGrid}
                      >
                        <Toggle
                          checked={keyItem.inactiveFlag === "N" ? true : false}
                          onChange={(e) =>
                            handleChange(e, "patientLocation", keyItem)
                          }
                        />
                        <FormLabel className={globalClasses.noPaddingForLabels}>
                          {keyItem.configurationType}
                        </FormLabel>
                      </Grid>
                    ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid item md xs={12}>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <BasicTypography variant="h5">Patient Type</BasicTypography>
              </Grid>
              <Grid item>
                <Grid container direction="column" spacing={1}>
                  {patientType &&
                    patientType.length > 0 &&
                    patientType.map((keyItem, index) => (
                      <Grid
                        item
                        key={"patientType" + index}
                        className={classes.switchContainerGrid}
                      >
                        <Toggle
                          checked={keyItem.inactiveFlag === "N" ? true : false}
                          onChange={(e) =>
                            handleChange(e, "patientType", keyItem)
                          }
                        />
                        <FormLabel className={globalClasses.noPaddingForLabels}>
                          {keyItem.configurationType}
                        </FormLabel>
                      </Grid>
                    ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2} justifyContent="flex-end">
          <Grid item>
            <Button
              type="button"
              color="primary"
              size="small"
              variant="contained"
              className={globalClasses.primaryBtn}
              onClick={() => {
                saveTemp();
                setOpenPopup(false);
              }}
            >
              {`${isVisitInfo ? "Save" : "OK"}`}
            </Button>
          </Grid>
          <Grid item>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              className={globalClasses.secondaryBtn}
              onClick={() => {
                setOpenPopup(false);
              }}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Eligibilityconfigpopup;
