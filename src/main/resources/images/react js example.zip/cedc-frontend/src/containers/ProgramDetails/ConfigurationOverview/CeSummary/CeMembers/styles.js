import { makeStyles } from "@material-ui/core";

export const useCeMembersStyle = makeStyles((_theme) => {
  return {};
});
