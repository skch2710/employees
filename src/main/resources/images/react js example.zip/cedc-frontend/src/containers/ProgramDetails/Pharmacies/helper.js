import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import { SET_PH_BASIC_DETAILS } from "../../../context/reducers/Pharmacies/constants";
import { pagination } from "../../../utils/constants";
import { getCeIdsArray, isAllCeSelected } from "../../../utils/helper";

export const getPharmaciesDefaultValues = () => {
  return {
    ceId: [],
    phGroupId: "",
    pharmacy: "",
    startDate: "",
    endDate: "",
    phConfigStatus: "",
    status: "Active",
  };
};

export const getPhConfigStatusOptions = () => [
  { ceConfigStatusId: 1, ceConfigStatus: "Partial" },
  { ceConfigStatusId: 2, ceConfigStatus: "Complete" },
];

export const defaultPhSearchPayload = (values = {}) => {
  return {
    ceid: isAllCeSelected(values.ceId)
      ? getCeIdsArray(values.ceList)
      : getCeIdsArray(values.ceId),
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "",
    sortBy: values.sortBy || "",
    phGroupId: values.phGroupId ? Number(values.phGroupId) : "",
    phid: values.pharmacy ? Number(values.pharmacy) : "",
    startDate: values.startDate || "",
    endDate: values.endDate || "",
    statusId: values.phConfigStatus ? Number(values.phConfigStatus) : "",
    status: values.status || "Active",
    filter: values.filter || [],
    export: values.export || false,
  };
};

export const getPharmaciesFiltersObject = (filters = []) => {
  const dateFields = ["goLiveDate", "startDate", "endDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getYesNoValueOfToggle = (value = "") => {
  return value === "Y" || value === true ? "Yes" : "No";
};

export const getReverseYesNoValueOfToggle = (value = "") => {
  return value === "Y" ? "No" : "Yes";
};

export const getPhGroupIdArray = (groups = []) => {
  return _isArray(groups) ? groups.map((group) => group.phGroupId) : [];
};

export const getCoveredEntity = ({ ceId = "", ceList = [] } = {}) => {
  return ceList.filter((ce) => ce.ceID === Number(ceId));
};

export const resetReduxSummaryStates = (dispatch) => {
  dispatch({
    type: SET_PH_BASIC_DETAILS,
    data: {},
  });
};
