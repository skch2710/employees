import { useDispatch } from "react-redux";
import { getProvidersLocationGridData } from "../../../context/actions/providers";
import { notNull } from "../../../utils/constants";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
const fileName = "Providers Locations List";

const ExportProviderLocations = () => {
  const dispatch = useDispatch();

  const exportToExcel = ({ ceid, prescriberId, controller, columnFilters }) => {
    const payload = {
      prescriberId: prescriberId,
      ceID: ceid,
      export: true,
      filter: columnFilters,
      ...controller,
    };
    dispatch(
      getProvidersLocationGridData(payload, (res) => {
        var data = res.content.map(
          ({ ceName, tfbId, locationName, locationHrsaId }) => ({
            "Covered Entity": notNull(ceName),
            "340B ID": notNull(tfbId),
            "Location Name": notNull(locationName),
            "Location HRSA ID": notNull(locationHrsaId),
          })
        );
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, {
          bookType: "xlsx",
          type: "array",
        });
        const fileData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(fileData, fileName + ".xlsx");
      })
    );
  };
  return { exportToExcel };
};

export default ExportProviderLocations;
