import React, { memo, useEffect, useState } from "react";
import { Grid, Button } from "@material-ui/core";
import moment from "moment";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useDispatch } from "react-redux";
import IcoPdf from "../../../../../../assets/ico-pdf.png";
import _isEmpty from "lodash/isEmpty";
import {
  getRemittanceDetailsList,
  getRemittanceDetailsSummary,
} from "../../../../../../context/actions/Invoice";
import classNames from "classnames";
import { formatValue } from "../../../../../../utils/common";
import { getRemittanceExportPdf } from "../../../../../../context/actions/Invoice";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useRemittanceDetailsStyle } from "./styles";
import RemittanceDetailsAccordion from "./RemittanceDetailsAccordion";

const RemittanceDetails = ({ actionsRowDataDetails, filtersValues }) => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = useRemittanceDetailsStyle();

  const { ceId, invoicePeriodEndDate, invoicePeriodStartDate } =
    actionsRowDataDetails || {};
  const [remittanceDetailsSummary, setRemittanceDetailsSummary] = useState({});
  const [remittanceDetails, setRemittanceDetails] = useState([]);
  const startDate = moment(actionsRowDataDetails.invoicePeriodStartDate);
  const endDate = moment(actionsRowDataDetails.invoicePeriodEndDate);
  const formattedStartDate = startDate.format("MMMM D , Y");
  const formattedEndDate = endDate.format("MMMM D , Y");

  const fetchRemittanceDetailsSummary = async () => {
    const payload = {
      ceId: ceId,
      phGroupId: filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
      phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
      invoicePeriodStartDate: invoicePeriodStartDate,
      invoicePeriodEndDate: invoicePeriodEndDate,
      isMainResult: 1,
    };
    const res = await dispatch(getRemittanceDetailsSummary(payload));
    setRemittanceDetailsSummary(!_isEmpty(res) ? res : {});
  };

  const fetchRemittanceDetails = (payload = {}) => {
    dispatch(
      getRemittanceDetailsList(
        {
          ceId: ceId,
          invoicePeriodStartDate: invoicePeriodStartDate,
          invoicePeriodEndDate: invoicePeriodEndDate,
          phGroupId: filtersValues == "" ? 0 : filtersValues.phGroupId,
          phId: filtersValues == "" ? 0 : filtersValues.phId,
          isMainResult: 0,
        },
        (data) => {
          setRemittanceDetails(data);
        }
      )
    );
  };

  const dynamicGrids = () => {
    const grids = remittanceDetails.map(function (ele, index) {
      return <RemittanceDetailsAccordion key={index} res={ele} />;
    });
    return grids;
  };

  const downloadPdf = () => {
    const Payload = {
      ceid: ceId,
      phGroupId: filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
      phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
      startDate: invoicePeriodStartDate,
      endDate: invoicePeriodEndDate,
    };
    dispatch(getRemittanceExportPdf(Payload));
  };

  useEffect(() => {
    fetchRemittanceDetails();
    fetchRemittanceDetailsSummary();
  }, []);

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={5}>
            <BasicTypography
              variant="h5"
              title={`Invoice Number : ${actionsRowDataDetails.invoiceNumber}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={` Billing Cycle : ${formattedStartDate} -
                    ${formattedEndDate}`}
            />
          </Grid>
          <Grid item className={classes.pdfAlignment} xs={12} sm={3}>
            <Button
              startIcon={<img src={IcoPdf} width={20} height={20} />}
              type="submit"
              color="default"
              size="small"
              onClick={downloadPdf}
              component="button"
              classes={{
                root: classNames(classes.btn, globalClasses.exportButton),
              }}
            >
              Export
            </Button>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12} md={8}>
        {dynamicGrids()}
      </Grid>
      <Grid item xs={12} md={4}>
        <div className={globalClasses.cardPrimary}>
          <Grid
            container
            wrap="nowrap"
            spacing={2}
            className={classes.detailsSummary}
          >
            <Grid item>
              <BasicTypography variant="h4" title="340B Remittance Summary" />
            </Grid>
          </Grid>
          <Grid className={classes.remittanceTotals}>
            <table className={classes.summaryTable}>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>
                  Insured Claims - Pharmacy Remittance
                </td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(
                    remittanceDetailsSummary &&
                      remittanceDetailsSummary.insuredClaimsPharmacyRemittance
                  )}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>
                  Uninsured Claims - Pharmacy Remittance
                </td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(
                    remittanceDetailsSummary &&
                      remittanceDetailsSummary.unInsuredClaimsPharmacyRemittance
                  )}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>True Up</td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(
                    remittanceDetailsSummary && remittanceDetailsSummary.trueup
                  )}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>Total 340BDirect+ Fees</td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(
                    remittanceDetailsSummary &&
                      remittanceDetailsSummary.totalDirectPlusFee
                  )}
                </td>
              </tr>
              <tr className={classes.netDueCe}>
                <td className={classes.ceNetDueLabel}>
                  Net Remittance to Covered Entity
                </td>
                <td className={classes.ceNetDueLabel}>$</td>
                <td className={classes.ceNetDueValue}>
                  {formatValue(
                    remittanceDetailsSummary &&
                      remittanceDetailsSummary.netRemittence
                  )}
                </td>
              </tr>
            </table>
          </Grid>
        </div>
      </Grid>
    </Grid>
  );
};
export default memo(RemittanceDetails);
