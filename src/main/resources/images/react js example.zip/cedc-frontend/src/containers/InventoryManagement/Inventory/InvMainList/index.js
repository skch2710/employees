import React, {
  memo,
  useState,
  useRef,
  forwardRef,
  useCallback,
  useImperativeHandle,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Grid, Paper, Tooltip, useTheme } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { LABELS, pagination } from "../../../../utils/constants";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getInvFiltersObject } from "../helper";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import InvDetailsInfo from "../InvDetailsInfo";
import DataNotFound from "../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import useFileExport from "./useFileExport";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const InvMainList = forwardRef(
  (
    {
      InvmainListdata,
      formRef,
      fetchInventoryDetails,
      loading,
      count,
      formSubmittedValues,
      enableFilters,
      setEnableFilters,
      InvControllers,
      setInvControllers,
    },
    ref
  ) => {
    const globalClasses = useGlobalStyles();
    const theme = useTheme();
    const { exportToExcel } = useFileExport();
    const iconsAndButtons = useTableIconsAndButtons();

    const [columnFilters, setColumnFilters] = useState([]);
    const [rowData, setRowData] = useState({});
    const [showInnerGridItemInfo, setShowInnerGridItemInfo] = useState(false);
    const columnFiltersRef = useRef({});
    const tableRef = useRef(null);

    const setControllers = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setInvControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          page: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    useImperativeHandle(ref, () => ({
      clearForm(initialValues) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        const clearBtnPayload = {
          pageNumber: 1,
          pageSize: 25,
        };
        const Payload = { ...clearBtnPayload, ...initialValues };
      },
      submitForm(resp) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        setControllers(resp);
      },
    }));

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        // If search button was pressed then and only then the values of form will get passed as payload to api on pagination change.
        const { isSubmitting } = (formRef && formRef.current) || {};
        const {
          page: controllerPage,
          pageSize: controllerPageSize,
          sortOrder,
          sortBy,
        } = InvControllers;
        const rowsPerPage = Number(pageSize);
        const totalPages =
          Math.ceil(InvmainListdata.totalElements / rowsPerPage) || 1;
        if (controllerPage > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllerPageSize)
          currentPage = controllerPage;

        fetchInventoryDetails(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: sortOrder,
            sortBy: sortBy,
            filter: columnFilters,
            ...(isSubmitting ? formSubmittedValues : {}), // Here we are checking form is submitted or not and adding payload accordingly.
          },
          (resp) => setControllers(resp)
        );
      },
      [
        columnFilters,
        formRef,
        InvControllers,
        formSubmittedValues,
        InvmainListdata,
      ]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const { isSubmitting } = (formRef && formRef.current) || {};
        const sortOrder = InvControllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = INV_LIST[orderedColumnId].field;
        setInvControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        if (formSubmittedValues && formSubmittedValues.phGroupId) {
          fetchInventoryDetails(
            {
              pageNumber: InvControllers.page,
              pageSize: InvControllers.pageSize,
              sortOrder,
              sortBy,
              filter: columnFilters,
              ...(isSubmitting ? formSubmittedValues : {}),
            },

            (resp) => setControllers(resp, { sortOrder, sortBy })
          );
        }
      },
      [InvControllers, formRef, formSubmittedValues, columnFilters]
    );

    const handleColumnFilter = (filters) => {
      const { isSubmitting } = (formRef && formRef.current) || {};
      const filterPayload = getInvFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      fetchInventoryDetails(
        {
          ...InvControllers,
          filter: filterPayload,
          pageNumber: pagination.page,
          ...(isSubmitting ? formSubmittedValues : {}),
        },
        (resp) => setControllers(resp)
      );
    };

    const INV_LIST = [
      {
        title: "NDC",
        field: "ndc",
        defaultFilter: enableFilters && columnFiltersRef.current.ndc,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ndc}>
              <span>{rowData.ndc}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.ndc}
            placeholder="NDC"
          />
        ),
      },
      {
        title: "Drug Name",
        field: "drugName",
        defaultFilter: enableFilters && columnFiltersRef.current.drugName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugName}>
              <span>{rowData.drugName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.drugName}
            placeholder="Drug Name"
          />
        ),
      },
      {
        title: "Wholesaler",
        field: "wholesalerName",
        defaultFilter: enableFilters && columnFiltersRef.current.wholesalerName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.wholesalerName}>
              <span>{rowData.wholesalerName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.wholesalerName}
            placeholder="Wholesaler"
          />
        ),
      },
      {
        title: "Pkg Size",
        field: "packageSize",
        defaultFilter: enableFilters && columnFiltersRef.current.packageSize,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.packageSize}>
              <span>{rowData.packageSize}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.packageSize}
            placeholder="Pkg Size"
          />
        ),
      },
      {
        title: "Opening Units",
        field: "openingUnits",
        defaultFilter: enableFilters && columnFiltersRef.current.openingUnits,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.openingUnits}>
              <span>{rowData.openingUnits}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.openingUnits}
            placeholder="Opening Units"
          />
        ),
      },
      {
        title: "Units Dispensed",
        field: "unitsDispensed",
        defaultFilter: enableFilters && columnFiltersRef.current.unitsDispensed,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.unitsDispensed}>
              <span>{rowData.unitsDispensed}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.unitsDispensed}
            placeholder="Units Dispensed"
          />
        ),
      },
      {
        title: "Units Replenished",
        field: "unitsReplenished",
        defaultFilter:
          enableFilters && columnFiltersRef.current.unitsReplenished,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.unitsReplenished}>
              <span>{rowData.unitsReplenished}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.unitsReplenished}
            placeholder="Units Replenished"
          />
        ),
      },
      {
        title: "Returned Units",
        field: "returnedUnits",
        defaultFilter: enableFilters && columnFiltersRef.current.returnedUnits,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.returnedUnits}>
              <span>{rowData.returnedUnits}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.returnedUnits}
            placeholder="Returned Units"
          />
        ),
      },
      {
        title: "Px Owned Units",
        field: "pxOwedInventory",
        defaultFilter:
          enableFilters && columnFiltersRef.current.pxOwedInventory,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pxOwedInventory}>
              <span>{rowData.pxOwedInventory}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pxOwedInventory}
            placeholder="Px Owned Units"
          />
        ),
      },
      {
        title: LABELS.CoveredEntity + " Owned Units",
        field: "ceOwnedInventory",
        defaultFilter:
          enableFilters && columnFiltersRef.current.ceOwnedInventory,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ceOwnedInventory}>
              <span>{rowData.ceOwnedInventory}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.ceOwnedInventory}
            placeholder="Covered Entity Owned Units"
          />
        ),
      },
      {
        title: "340B Inventory Cost",
        field: "three40BInventoryCost",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.three40BInventoryCost,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.three40BInventoryCost}>
                  <span>{rowData.three40BInventoryCost}</span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.three40BInventoryCost}
            placeholder="340B Inventory Cost"
          />
        ),
      },
      {
        title: "Schedule Type",
        field: "scheduleType",
        defaultFilter: enableFilters && columnFiltersRef.current.scheduleType,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.scheduleType}>
              <span>{rowData.scheduleType}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.scheduleType}
            placeholder="Schedule Type"
          />
        ),
      },
      {
        title: "Manufacturer",
        field: "drugManufacturerName",
        defaultFilter:
          enableFilters && columnFiltersRef.current.drugManufacturerName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.drugManufacturerName}>
              <span>{rowData.drugManufacturerName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.drugManufacturerName}
            placeholder="Manufacturer"
          />
        ),
      },
    ];

    const actions = [
      {
        icon: iconsAndButtons.Plus(),
        tooltip: "Inventory Details",
        isFreeAction: false,
        onClick: (_event, rowData) => {
          setRowData(rowData);
          setShowInnerGridItemInfo(true);
        },
      },
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        isFreeAction: true,
        disabled: count < 1,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportButton({
          disabled: isEmptyGrid(InvmainListdata),
        }),
        isFreeAction: true,
        disabled: isEmptyGrid(InvmainListdata),
        onClick: () =>
          exportToExcel({
            formRef,
            InvControllers,
            columnFilters,
          }),
      },
    ];

    return (
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Inventory List (${getTableHeaderCount(
                InvmainListdata.totalElements
              )})`}
            />
          }
          tableRef={tableRef}
          columns={INV_LIST}
          data={InvmainListdata.content || []}
          page={InvControllers.page - 1}
          totalCount={InvmainListdata.totalElements || 0}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(InvControllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={actions}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: InvControllers.pageSize,
            maxBodyHeight: 400,
            minBodyHeight: 100,
            pageSizeOptions: isEmptyGrid(InvmainListdata)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
        <BasicPopup
          title={"Inventory Details/NDC"}
          show={showInnerGridItemInfo}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
          handleClose={() => setShowInnerGridItemInfo(false)}
        >
          <InvDetailsInfo MainGridData={rowData} />
        </BasicPopup>
      </div>
    );
  }
);

export default memo(InvMainList);
