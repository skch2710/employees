import { useDispatch } from "react-redux";
import { patientExport } from "../../../context/actions/Patients";
import { notNull } from "../../../utils/constants";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
const fileName = "Patients List";
const coPatientFileName = "CO_Patients List";

const ExportPatient = () => {
  const dispatch = useDispatch();

  const exportToExcel = ({ patientSearchData, defaultFilters, Co }) => {
    const {
      ceid,
      dob,
      firstName,
      lastName,
      startDate,
      endDate,
      mrn,
      patientType,
      sortBy,
      sortOrder,
    } = patientSearchData;
    let payload = {
      ceid: ceid,
      dob: dob,
      endDate: endDate,
      firstName: firstName,
      lastName: lastName,
      export: true,
      mrn: mrn,
      sortBy: sortBy,
      sortOrder: sortOrder,
      startDate: startDate,
      patientType: patientType,
      filter: defaultFilters,
    };
    dispatch(
      patientExport(payload, Co, (res) => {
        var data = res.content.map(
          ({
            mrn,
            firstName,
            middleName,
            lastName,
            suffix,
            dob,
            gender,
            patientType,
            startDate,
            recentVisitDate,
            endDate,
            lastModifiedDate,
            slidingScaleIndicator,
            slidingScaleEffectiveDate,
          }) => ({
            MRN: notNull(mrn),
            "First Name": firstName,
            "Middle Name": notNull(middleName),
            "Last Name": notNull(lastName),
            Suffix: notNull(suffix),
            DOB: notNull(dob),
            Gender: notNull(gender),
            Exclude: notNull(patientType),
            "Sliding Scale Category": notNull(slidingScaleIndicator),
            "Sliding Scale Effective Date": notNull(slidingScaleEffectiveDate),
            "First Visit Date": notNull(startDate),
            "Recent Visit Date": notNull(recentVisitDate),
            "Eligibility End Date": notNull(endDate),
            "Last Modified Date": notNull(lastModifiedDate),
          })
        );
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, {
          bookType: "xlsx",
          type: "array",
        });
        const fileData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(fileData, fileName + ".xlsx");
      })
    );
  };

  const exportMemberToExcel = ({ patientSearchData, defaultFilters, Co }) => {
    const { ceid, pageNumber, pageSize, sortBy, sortOrder } = patientSearchData;
    let payload = {
      ceid: ceid,
      export: true,
      sortBy: sortBy,
      sortOrder: sortOrder,
      filter: defaultFilters,
      pageNumber: pageNumber,
      pageSize: pageSize,
    };
    dispatch(
      patientExport(payload, Co, (res) => {
        var data = res.content.map(
          ({
            coveredEntity,
            id340b,
            mrn,
            firstName,
            middleName,
            lastName,
            suffix,
            dob,
            gender,
            visitDate,
            hospitalService,
            admitType,
            servicingFacility,
            assignedPatientLocation,
            slidingScaleIndicator,
            slidingScaleEffectiveDate,
            providerFn,
            providerLn,
            prescriberDea,
            providerNpi,
            providerSpi,
          }) => ({
            "Covered Entity": notNull(coveredEntity),
            "HRSA ID": notNull(id340b),
            MRN: notNull(mrn),
            "Patient First Name": firstName,
            "Patient Middle Name": notNull(middleName),
            "Patient Last Name": notNull(lastName),
            Suffix: notNull(suffix),
            "Patient DOB": notNull(dob),
            Gender: notNull(gender),
            "Admit/Visit Date": notNull(visitDate),
            "Hospital Service": notNull(hospitalService),
            "Admit Type": notNull(admitType),
            "Servicing Facility": notNull(servicingFacility),
            "Assigned Patient Location": notNull(assignedPatientLocation),
            "Sliding Scale Category": notNull(slidingScaleIndicator),
            "Sliding Scale Effective Date": notNull(slidingScaleEffectiveDate),
            "Provider FN": notNull(providerFn),
            "Provider LN": notNull(providerLn),
            "Provider DEA": notNull(prescriberDea),
            "Provider NPI": notNull(providerNpi),
            "Provider SPI": notNull(providerSpi),
          })
        );
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, {
          bookType: "xlsx",
          type: "array",
        });
        const fileData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(fileData, coPatientFileName + ".xlsx");
      })
    );
  };
  return { exportToExcel, exportMemberToExcel };
};

export default ExportPatient;
