import React, { useState, useEffect } from "react";
import { Formik, Form, Field } from "formik";
import {
  Grid,
  Button,
  IconButton,
  FormLabel,
  Typography,
} from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import _get from "lodash/get";
import _debounce from "lodash/debounce";
import { IoIosCloseCircleOutline } from "react-icons/io";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import AutoComplete from "../../../components/common/AutoComplete";
import {
  getPharmacyGroups,
  getPharmacyStore,
  GetScheduleTypevalues,
  GetFilterTypes,
  getDrugManufacturer,
  getWholeSaler,
} from "../../../context/actions/Inventory";
import { getFilteredInvDefaultValue } from "./constants";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { useInvStyles } from "./styles";
import {
  ERROR,
  LABELS,
  REGEX,
  setAutoCompleteInputVal,
} from "../../../utils/constants";
import { INVENTORY_SEARCH } from "../../../context/constants";

// const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;

const InvSearchForm = (props) => {
  const {
    handleSubmit,
    formRef,
    handleClear,
    ceList = [],
    setEnableFilters,
  } = props;
  const dispatch = useDispatch();
  const classes = useInvStyles();
  const globalClasses = useGlobalStyles();
  const defaultValues = getFilteredInvDefaultValue(ceList);
  const getScheduleTypevalues =
    useSelector((state) => state.getScheduleTypevalues.records) || [];
  const pharmacyList = useSelector((state) => state.getPharamacy.records) || [];
  const [filtersOpen, setFiltersOpen] = useState(true);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);
  const [wholesalerList, setWholeSalerList] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [isManufLoading, setIsManufLoading] = useState(false);

  const resetStates = () => {
    setPharmacyGroups([]);
    setWholeSalerList([]);
  };

  const fetchPharmacyGroups = (value, disableLoader = false) => {
    const data = {
      ceid: [value],
    };
    dispatch(
      getPharmacyGroups(data, disableLoader, (groups = []) => {
        _isArray(groups) && setPharmacyGroups([...groups]);
      })
    );
  };

  useEffect(() => {
    dispatch(GetFilterTypes());
    dispatch(GetScheduleTypevalues());
  }, []);

  useEffect(() => {
    if (ceList.length === 1) {
      fetchPharmacyGroups(ceList[0].ceID, true);
    }
  }, [ceList]);

  const onClear = (values) => {
    resetStates();
    dispatch({ type: INVENTORY_SEARCH, data: {} });
    fetchPharmacyGroups(ceList.length === 1 ? ceList[0].ceID : 0);
    setEnableFilters(false);
  };

  const getDrugManufacturerOptions = _debounce(
    async ({ values, inputValue } = {}) => {
      setManufacturers([]);
      setIsManufLoading(true);
      const payload = {
        ceID: _get(values, "ceID.ceID", 0) || 0,
        phID: _get(values, "phID.phid", 0) || 0,
        wholesalerID: _get(values, "wholesalerID.wholesalerID", 0),
        drugManufacturerName: inputValue,
      };
      const resp = await getDrugManufacturer(payload, { setIsManufLoading });
      if (_isArray(resp)) {
        setManufacturers(resp);
      }
    },
    500
  );

  // Form validation
  const formValidate = (values) => {
    let error = {};
    if (!values.ceID) {
      error.ceID = "Please select the Covered Entity";
    }
    if (!values.phGroupId) {
      error.phGroupId = ERROR.emptyPharmacyChainErrorMessage;
    }
    return error;
  };

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      validate={formValidate}
      innerRef={formRef}
      enableReinitialize={true}
    >
      {({ values, errors, touched, setFieldValue, initialValues }) => {
        return (
          <Form>
            {filtersOpen ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <Grid container spacing={2} justifyContent="space-between">
                      <Grid item>
                        <BasicTypography variant="h4" title="Filters" />
                      </Grid>
                      <Grid item>
                        <IconButton
                          classes={{
                            root: classes.closeFilterIcon,
                          }}
                        >
                          <IoIosCloseCircleOutline
                            onClick={() => {
                              setFiltersOpen(false);
                            }}
                          />
                        </IconButton>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      {ceList && ceList.length === 1 ? (
                        <Grid item xs={12} sm={4}>
                          <FormLabel required>Covered Entity</FormLabel>
                          {
                            <Field
                              as="select"
                              name="ceID"
                              className={globalClasses.formControl}
                              disabled={
                                ceList && ceList.length > 1 ? false : true
                              }
                              onChange={(e) => {
                                fetchPharmacyGroups(Number(e.target.value));
                                setFieldValue("ceID", Number(e.target.value));
                                setFieldValue("phGroupId", 0);
                                setFieldValue("phID", "");
                                setFieldValue("wholesalerID", 0);
                                setFieldValue("drugManufacturerID", 0);
                              }}
                            >
                              <option value={0}>Select Covered Entity</option>
                              {!_isEmpty(ceList) &&
                                ceList.map((keysItem, indexVal) => {
                                  return (
                                    <option
                                      key={indexVal}
                                      value={keysItem.ceID}
                                      disabled={
                                        ceList.length > 1 ? false : true
                                      }
                                    >
                                      {keysItem.ceName}
                                    </option>
                                  );
                                })}
                            </Field>
                          }
                          {errors.ceID && touched.ceID && (
                            <Typography color="error" variant="caption">
                              {errors.ceID}
                            </Typography>
                          )}
                        </Grid>
                      ) : (
                        <Grid item xs={12} sm={4}>
                          <FormLabel required>Covered Entity</FormLabel>
                          {
                            <Field
                              as="select"
                              className={globalClasses.formControl}
                              name="ceID"
                            >
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  disableCloseOnSelect={false}
                                  options={_isArray(ceList) ? ceList : []}
                                  inputPlaceholder={"Select Covered Entity"}
                                  onChange={(e, value) => {
                                    setFieldValue(
                                      "coveredEntityInput",
                                      value ? value.ceName : ""
                                    );
                                    fetchPharmacyGroups(
                                      value !== null ? value.ceID : 0
                                    );
                                    setFieldValue("ceID", value);
                                    setFieldValue("phGroupId", 0);
                                    setFieldValue("phID", "");
                                    setFieldValue("wholesalerID", 0);
                                    setFieldValue("drugManufacturerID", 0);
                                  }}
                                  getOptionLabel={(option) =>
                                    option.ceName || ""
                                  }
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.ceName}
                                      </BasicTypography>
                                    );
                                  }}
                                  inputValue={values.coveredEntityInput || ""}
                                  onInputChange={(_e, value) =>
                                    setAutoCompleteInputVal({
                                      value,
                                      callback: (newValue) => {
                                        setFieldValue(
                                          "coveredEntityInput",
                                          newValue
                                        );
                                      },
                                    })
                                  }
                                  multiple={false}
                                />
                              )}
                            </Field>
                          }
                          {errors.ceID && touched.ceID && (
                            <Typography color="error" variant="caption">
                              {errors.ceID}
                            </Typography>
                          )}
                        </Grid>
                      )}
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>{LABELS.PharmacyChain}</FormLabel>
                        {
                          <Field as="select" name="phGroupId">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(pharmacyGroups) ? pharmacyGroups : []
                                }
                                inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                                onChange={(_e, value) => {
                                  setFieldValue("phGroupId", value);
                                  dispatch(
                                    getPharmacyStore({
                                      ceid: [_get(values, "ceID.ceID", values.ceID)],
                                      phGroupId: [_get(value, "phGroupId", 0)],
                                    })
                                  );
                                  setFieldValue("phID", "");
                                  setFieldValue("wholesalerID", 0);
                                  setFieldValue("drugManufacturerID", 0);
                                }}
                                getOptionLabel={(option) =>
                                  option.phGroupName || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.phGroupName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                        {errors.phGroupId && touched.phGroupId && (
                          <Typography color="error" variant="caption">
                            {errors.phGroupId}
                          </Typography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                        {
                          <Field as="select" name="phID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(pharmacyList) ? pharmacyList : []
                                }
                                disabled={!values.phGroupId}
                                inputPlaceholder={` Select ${LABELS.PharmacyStore}`}
                                onChange={(e, value) => {
                                  setFieldValue("phID", value);
                                  setFieldValue("wholesalerID", 0);
                                  setFieldValue("drugManufacturerID", 0);
                                  const data = {
                                    ceid:
                                      values.ceID.ceID !== undefined
                                        ? [values.ceID.ceID]
                                        : values.ceID,
                                    pharmacyId:
                                      value && value !== null ? value.phid : 0,
                                  };
                                  dispatch(
                                    getWholeSaler(data, (response) => {
                                      setWholeSalerList(response);
                                    })
                                  );
                                }}
                                getOptionLabel={(option) => option.phName || ""}
                                renderOption={(option) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.phName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Wholesaler</FormLabel>
                        {
                          <Field as="select" name="wholesalerID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(wholesalerList) ? wholesalerList : []
                                }
                                inputPlaceholder={"Select Wholesaler"}
                                disabled={!values.phID}
                                disableCloseOnSelect={false}
                                onChange={(e, value) => {
                                  setFieldValue("wholesalerID", value);
                                }}
                                getOptionLabel={(option) =>
                                  option.wholesalerName || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.wholesalerName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>NDC</FormLabel>
                        <Field
                          name="ndc"
                          id="ndc"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter NDC"
                          maxLength={11}
                          onChange={(e) => {
                            const value = e.target.value;
                            const regEx = /^[0-9]{1,11}$/g;
                            if (value && !regEx.test(e.target.value)) return;
                            setFieldValue("ndc", e.target.value);
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Drug Name</FormLabel>
                        <Field
                          name="drugName"
                          id="drugname"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Drug Name "
                          maxlength={50}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (
                              value &&
                              !REGEX.excludeLeadingAndTrailingSpaces.test(
                                e.target.value
                              )
                            )
                              return;
                            setFieldValue("drugName", value);
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Manufacturer</FormLabel>
                        <Field as="select" name="drugManufacturerID">
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              loading={isManufLoading}
                              options={manufacturers}
                              getOptionLabel={(option) =>
                                option.drugManufacturerName || option
                              }
                              multiple={false}
                              disableCloseOnSelect={false}
                              inputPlaceholder="Enter Drug Manufacturer"
                              renderOption={(option) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.drugManufacturerName}
                                  </BasicTypography>
                                );
                              }}
                              onInputChange={(_e, inputValue) => {
                                if (inputValue) {
                                  getDrugManufacturerOptions({
                                    values,
                                    inputValue,
                                  });
                                } else setManufacturers([]);
                              }}
                              onChange={(_e, value) => {
                                setFieldValue("drugManufacturerID", value);
                              }}
                              textFieldProps={{
                                inputProps: {
                                  name: "drugManufacturerID",
                                },
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Schedule Type </FormLabel>
                        {
                          <Field as="select" name="drugDEAClassID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(getScheduleTypevalues)
                                    ? getScheduleTypevalues
                                    : []
                                }
                                inputPlaceholder={"Select Schedule Type"}
                                disableCloseOnSelect={false}
                                onChange={(e, value) => {
                                  setFieldValue("drugDEAClassID", value);
                                }}
                                getOptionLabel={(option) =>
                                  option.drugDEAClassCode
                                    ? "C" +
                                      option.drugDEAClassCode +
                                      "-" +
                                      option.drugDEAClassDesc
                                    : "" || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      C{option.drugDEAClassCode}-
                                      {option.drugDEAClassDesc}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}></Grid>
                      <Grid item xs={12} sm={12}>
                        <FormLabel>Inventory Filtering</FormLabel>
                      </Grid>
                      <Grid
                        item
                        xs={3}
                        sm={1}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              name="inventoryFilter"
                              type="radio"
                              value="A"
                              className={classes.radioInput}
                            />
                            <FormLabel>All</FormLabel>
                          </div>
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={3}
                        sm={1}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              name="inventoryFilter"
                              type="radio"
                              value="F"
                              className={classes.radioInput}
                            />
                            <FormLabel>Full</FormLabel>
                          </div>
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={3}
                        sm={1}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              name="inventoryFilter"
                              type="radio"
                              value="P"
                              className={classes.radioInput}
                            />
                            <FormLabel>Partial</FormLabel>
                          </div>
                        </div>
                      </Grid>
                      <Grid
                        item
                        xs={3}
                        sm={3}
                        className={classes.radioGridContainer}
                      >
                        <div className={classes.gridContentContainer}>
                          <div className={classes.radioAndLabelContainer}>
                            <Field
                              id="manualOrders"
                              name="inventoryFilter"
                              type="radio"
                              value="C"
                              className={classes.radioInput}
                            />
                            <FormLabel>Covered Entity Owned Drugs</FormLabel>
                          </div>
                        </div>
                      </Grid>
                    </Grid>
                    <Grid container spacing={2} justifyContent="flex-end">
                      <Grid item>
                        <Button
                          type="submit"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                        >
                          Search
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          onClick={() => onClear(initialValues)}
                        >
                          Clear
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            ) : (
              <Button
                type="submit"
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setFiltersOpen(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default InvSearchForm;
