import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Grid, Paper, Tooltip } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import _isEmpty from "lodash/isEmpty";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { pagination } from "../../../../utils/constants";
import { getPOInfo } from "../../../../context/actions/PurchaseOrders";
import { getPoInfoFiltersObject } from "../helper";
import { PO_INFO } from "../../../../context/constants";
import DataNotFound from "../../../../components/common/DataNotFound";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import POItemHistory from "../POItemHistory";
import POClaims from "../POClaims";
import useFileExport from "./useFileExport";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const POItemInfoTable = ({ po }) => {
  const { poID, hrsaID, ceName, pharmacy, poDate, poItemID } = po || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const iconsAndButtons = useTableIconsAndButtons();

  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [rowData, setRowData] = useState({});
  const [showItemHistory, setShowItemHistory] = useState(false);
  const [showClaims, setShowClaims] = useState(false);
  const columnFiltersRef = useRef({});

  const { records: poInfoList = {}, loading } =
    useSelector((state) => state.getPoInfo) || {};

  const fetchPoItemInfo = (payload = {}) => {
    dispatch(
      getPOInfo(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          poID: poID,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (poID) {
      fetchPoItemInfo();
    }
    return () => {
      dispatch({ type: PO_INFO, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages = Math.ceil(poInfoList.totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;

      fetchPoItemInfo({
        ...controller,
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, poInfoList, controller]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PO_INFO_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchPoItemInfo({
        pageNumber: controller.page,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getPoInfoFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchPoItemInfo({
      ...controller,
      filter: filterPayload,
    });
  };

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(poInfoList),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(poInfoList),
      }),
      tooltip: "Export",
      disabled: isEmptyGrid(poInfoList),
      isFreeAction: true,
      onClick: () =>
        exportToExcel({
          poID,
          poItemID,
          controller,
          columnFilters,
        }),
    },
    {
      icon: iconsAndButtons.History(),
      tooltip: "Item History",
      isFreeAction: false,
      onClick: (_event, rowData) => {
        setRowData(rowData);
        setShowItemHistory(true);
      },
    },
    {
      icon: iconsAndButtons.Claim(),
      tooltip: "Claims",
      isFreeAction: false,
      onClick: (_event, rowData) => {
        setRowData(rowData);
        setShowClaims(true);
      },
    },
  ];

  const PO_INFO_COLUMNS = [
    {
      title: "NDC 11",
      field: "ndc",
      defaultFilter: enableFilters && columnFiltersRef.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ndc}
          placeholder="NDC 11"
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: enableFilters && columnFiltersRef.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugName}
          placeholder="Drug Name"
        />
      ),
    },
    {
      title: "Item Status",
      field: "itemStatus",
      defaultFilter: enableFilters && columnFiltersRef.current.itemStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemStatus}>
            <span>{rowData.itemStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.itemStatus}
          placeholder="Item Status"
        />
      ),
    },
    {
      title: "Ordered Qty",
      field: "orderedQty",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.orderedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.orderedQty}>
            <span>{rowData.orderedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.orderedQty}
          placeholder="Ordered Qty"
        />
      ),
    },
    {
      title: "Acknowledged Qty",
      field: "acknowledgedQty",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.acknowledgedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.acknowledgedQty}>
            <span>{rowData.acknowledgedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.acknowledgedQty}
          placeholder="Acknowledged Qty"
        />
      ),
    },
    {
      title: "Invoiced Qty",
      field: "invoicedQty",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.invoicedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.invoicedQty}>
            <span>{rowData.invoicedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.invoicedQty}
          placeholder="Invoiced Qty"
        />
      ),
    },
    {
      title: "Ordered Package Cost",
      field: "orderedPackageCost",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.orderedPackageCost,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.orderedPackageCost}>
                <span>{rowData.orderedPackageCost}</span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.orderedPackageCost}
          placeholder="Ordered Package Cost"
        />
      ),
    },
    {
      title: "Acknowledged Package Cost",
      field: "acknowledgedPackageCost",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.acknowledgedPackageCost,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.acknowledgedPackageCost}>
                <span>{rowData.acknowledgedPackageCost}</span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.acknowledgedPackageCost}
          placeholder="Acknowledged Package Cost"
        />
      ),
    },
    {
      title: "Invoiced Package Cost",
      field: "invoicedPackageCost",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.invoicedPackageCost,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.invoicedPackageCost}>
                <span>{rowData.invoicedPackageCost}</span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.invoicedPackageCost}
          placeholder="Invoiced Package Cost"
        />
      ),
    },
  ];

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={12}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <BasicTypography variant="subtitle2">{`PO #: ${poID}`}</BasicTypography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item md={12}>
          <div className={globalClasses.tableCardPrimary}>
            <MaterialTable
              title={
                <BasicTypography
                  variant="h5"
                  title={`Purchase Order Item Data (${getTableHeaderCount(
                    poInfoList.totalElements
                  )})`}
                />
              }
              columns={PO_INFO_COLUMNS}
              data={poInfoList.content}
              page={controller.page - 1}
              totalCount={poInfoList.totalElements}
              onChangePage={onPageChange}
              onOrderChange={handleSort}
              onFilterChange={handleColumnFilter}
              icons={{
                SortArrow: () => TableCustomSortArrow(controller),
                Filter: () => <TiFilter fontSize="small" />,
              }}
              actions={ACTIONS}
              components={{
                Container: (props) => <Paper {...props} elevation={0} />,
                Pagination: (props) => <Pagination {...props} />,
                Toolbar: (props) => (
                  <MTableToolbar
                    classes={{ root: globalClasses.gridMuiToolbar }}
                    {...props}
                  />
                ),
                OverlayLoading: () => <TableProgressBar />,
              }}
              localization={{
                header: {
                  actions: "Actions",
                },
                body: {
                  emptyDataSourceMessage: loading ? "" : <DataNotFound />,
                },
              }}
              isLoading={loading}
              options={{
                debounceInterval: 500,
                showTitle: true,
                search: false,
                actionsColumnIndex: 0,
                filtering: enableFilters,
                paging: true,
                showFirstLastPageButtons: false,
                paginationPosition: "bottom",
                exportButton: false,
                paginationType: "stepped",
                headerStyle: getTableHeaderStyles(theme),
                cellStyle: getTableCellStyles(theme),
                actionsCellStyle: getTableActionCellStyles(theme),
                tableLayout: "auto",
                draggable: false,
                columnResizable: true,
                emptyRowsWhenPaging: false,
                pageSize: controller.pageSize,
                maxBodyHeight: 400,
                minBodyHeight: 100,
                pageSizeOptions: isEmptyGrid(poInfoList)
                  ? []
                  : pagination.pageSizeOptions,
              }}
            />
          </div>
        </Grid>
      </Grid>
      <BasicPopup
        title={"Item History"}
        show={showItemHistory}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
        }}
        handleClose={() => setShowItemHistory(false)}
      >
        <POItemHistory po={rowData} />
      </BasicPopup>
      <BasicPopup
        title={"Item Info > Purchase Order Claims"}
        show={showClaims}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
        }}
        handleClose={() => setShowClaims(false)}
      >
        <POClaims po={{ ...rowData, hrsaID, ceName, pharmacy, poDate }} />
      </BasicPopup>
    </>
  );
};

export default memo(POItemInfoTable);
