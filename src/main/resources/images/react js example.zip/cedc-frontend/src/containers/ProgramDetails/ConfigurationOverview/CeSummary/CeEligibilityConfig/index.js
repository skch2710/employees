import React, { useCallback, useContext, useEffect, useState } from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { useCeSummaryStyle } from "../styles";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import EligibilityRuleSets from "../../popupsdetail/EntityDetails/CeEligibilityRules/EligibilityRuleSets";
import {
  getEligibilityRuleSets,
  getEligibilityRulesLookup,
} from "../../../../../context/actions/EligibilityRules";
import _isArray from "lodash/isArray";

const CeEligibilityConfig = (props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};

  const { eligibilityConfig = [] } = useSelector(
    (state) => state.coEligibilityConfig
  );

  const sortedEligibilityConfig =
    _isArray(eligibilityConfig) &&
    eligibilityConfig.sort((p1, p2) =>
      p1.ruleSetId > p2.ruleSetId ? 1 : p1.ruleSetId < p2.ruleSetId ? -1 : 0
    );

  const [ruleNames, setRuleNames] = useState([]);
  const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      dispatch(getEligibilityRuleSets(selectedCeForOverview.ceid));
    }
  }, [selectedCeForOverview]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  useEffect(() => {
    fetchEligibilityRulesLookup();
  }, []);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  const fetchEligibilityRulesLookup = async () => {
    const ruleNamesArray = await dispatch(getEligibilityRulesLookup());
    setRuleNames(_isArray(ruleNamesArray) ? ruleNamesArray : []);
  };

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Eligibility Rules" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={
                  !userSession.isInternalUser || !coPermissions.readWriteFlag
                }
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(
                      MENUS.CE_ELIGIBILITY,
                      selectedCeForOverview.ceid
                    );
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              {_isArray(sortedEligibilityConfig) &&
                sortedEligibilityConfig.map((item, index) => (
                  <EligibilityRuleSets
                    ruleSet={item}
                    index={index}
                    isFromWizard={false}
                    ruleNames={ruleNames}
                  />
                ))}
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CeEligibilityConfig;
