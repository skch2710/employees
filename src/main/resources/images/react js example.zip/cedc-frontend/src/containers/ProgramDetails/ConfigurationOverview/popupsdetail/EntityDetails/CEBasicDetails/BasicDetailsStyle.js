import { makeStyles } from "@material-ui/core/styles";

export const useCeBasicDetailsStyles = makeStyles((_theme) => {
  return {
    addBtnContainer: {
      display: "flex",
      alignItems: "flex-end",
    },
    addUserBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
    },
  };
});
