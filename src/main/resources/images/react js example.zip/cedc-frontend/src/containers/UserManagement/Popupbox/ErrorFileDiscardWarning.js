import React, { useEffect, useState, useCallback } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import ErrorFileDiscardPopupBody from "./ErrorFileDiscardPopupBody";

const ErrorFileDiscardWarning = (props) => {
  const { when, onOK, onCancel } = props;
  const dispatch = useDispatch();
  const history = useHistory();

  const [showPrompt, setShowPrompt] = useState(false);
  const [currentPath, setCurrentPath] = useState("");

  useEffect(() => {
    if (when) {
      history.block((prompt = {}) => {
        const { pathname, state } = prompt;
        if (state && state.routeBack === "/usermanagement") return true;
        if (pathname !== history.location.pathname) {
          setShowPrompt(true);
        }
        setCurrentPath(pathname);
        return false;
      });
    } else {
      history.block((prompt) => {
        if (prompt.pathname !== history.location.pathname) {
          dispatch({ type: "Bulk_Upload", data: null });
        }
        return true;
      });
    }

    return () => {
      history.block(() => {});
    };
  }, [history, when]);

  const handleClose = () => {
    setShowPrompt(false);
  };

  const handleOK = useCallback(async () => {
    if (onOK) {
      const canRoute = await Promise.resolve(onOK());
      if (canRoute) {
        history.block(() => {});
        history.push(currentPath);
        dispatch({ type: "Bulk_Upload", data: null });
      }
    }
  }, [currentPath, history, onOK]);

  const handleCancel = useCallback(async () => {
    if (onCancel) {
      const canRoute = await Promise.resolve(onCancel());
      if (canRoute) {
        history.block(() => {});
        history.push(currentPath);
      }
    }
    setShowPrompt(false);
  }, [currentPath, history, onCancel]);

  return (
    <ErrorFileDiscardPopupBody
      showPrompt={showPrompt}
      handleClose={handleClose}
      handleCancel={handleCancel}
      handleOK={handleOK}
    />
  );
};

export default ErrorFileDiscardWarning;
