import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import DatePicker from "../../../../../../components/common/DatePicker";
import moment from "moment";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { formatValue, getUserPreveleges } from "../../../../../../utils/common";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import { LABELS, pagination } from "../../../../../../utils/constants";
import { getTrueupList } from "../../../../../../context/actions/Invoice";
import { getTrueupFiltersObject } from "../../../helper";
import { isEmptyGrid } from "../../../../../../utils/helper";
import { GET_CLAIM_LIST } from "../../../../../../context/constants";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import tableIcons from "../../../../../../components/common/TableIcons/MaterialTableIcons";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../../../components/common/Pagination";

const TrueUpDetails = ({ actionsRowDataDetails, filtersValues } = {}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const phiAccess = getUserPreveleges("PHI Access");

  const { ceId, invoicePeriodEndDate, invoicePeriodStartDate } =
    actionsRowDataDetails || {};
  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const startDate = new Date(actionsRowDataDetails.invoicePeriodStartDate);
  const endDate = new Date(actionsRowDataDetails.invoicePeriodEndDate);
  const formattedStartDate = moment(startDate).format("MMMM D , Y");
  const formattedEndDate = moment(endDate).format("MMMM D , Y");
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);

  const { records: trueUpDetails, loading } = useSelector(
    (state) => state.getTrueupData
  );

  const fetchTrueupDetails = (payload = {}) => {
    dispatch(
      getTrueupList(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          ceid: ceId,
          startPeriod: invoicePeriodStartDate,
          endPeriod: invoicePeriodEndDate,
          phGroupId:
            filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
          phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    fetchTrueupDetails();
    return () => {
      dispatch({ type: GET_CLAIM_LIST, data: {} });
    };
  }, []);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setController((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(trueUpDetails.totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchTrueupDetails(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controller.sortOrder,
          sortBy: controller.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, trueUpDetails, controller]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = TRUE_UP_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchTrueupDetails(
        {
          pageNumber: controller.page,
          pageSize: controller.pageSize,
          sortOrder,
          sortBy,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controller]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getTrueupFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchTrueupDetails({
      ...controller,
      filter: filterPayload,
    });
  };

  const actions = [
    {
      icon: tableIcons.Filter,
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: trueUpDetails && trueUpDetails.totalElements < 1,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  const TRUE_UP_COLUMNS = [
    {
      title: "Billing Cycle",
      field: "invoicePeriodStartDate",
      render: (InvoiceMainListData) =>
        `${InvoiceMainListData.invoicePeriodStartDate} - ${InvoiceMainListData.invoicePeriodEndDate}`,
      defaultFilter: enableFilters && columnFiltersRef.current.billingPeriod,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip
            title={`${rowData.invoicePeriodStartDate} - ${rowData.invoicePeriodEndDate}`}
          >
            <span>
              {rowData.invoicePeriodStartDate}-{rowData.invoicePeriodEndDate}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.invoicePeriodStartDate
                ? moment(columnFiltersRef.current.invoicePeriodStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "340B ID",
      field: "tfbID",
      defaultFilter: enableFilters && columnFiltersRef.current.tfbID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.tfbID}>
            <span>{rowData.tfbID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.tfbID}
          placeholder="340B ID"
        />
      ),
    },
    {
      title: "Claim ID",
      field: "claimId",
      defaultFilter: enableFilters && columnFiltersRef.current.claimId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimId}>
            <span>{rowData.claimId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimId}
          placeholder="Claim ID"
        />
      ),
    },
    {
      title: "Processed Date",
      field: "processedDate",
      defaultFilter: enableFilters && columnFiltersRef.current.processedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.processedDate}>
            <span>{rowData.processedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.processedDate
                ? moment(columnFiltersRef.current.processedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Rx Number",
      field: "rxNumber",
      cellStyle: {
        ...getTableCellStyles(theme),
        color: phiAccess.readOnlyFlag ? theme.colors.yellow.default : "",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.rxNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.rxNumber}>
            <span>{rowData.rxNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.rxNumber}
          placeholder="Rx Number"
        />
      ),
    },
    {
      title: "Rx Written Date",
      field: "rxWrittenDate",
      defaultFilter: enableFilters && columnFiltersRef.current.rxWrittenDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.rxWrittenDate}>
            <span>{rowData.rxWrittenDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.rxWrittenDate
                ? moment(columnFiltersRef.current.rxWrittenDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Refill #",
      field: "refillNumber",
      defaultFilter: enableFilters && columnFiltersRef.current.refillNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.refillNumber}>
            <span>{rowData.refillNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.refillNumber}
          placeholder="Refill #"
        />
      ),
    },
    {
      title: "Date of Service",
      field: "dateOfService",
      defaultFilter: enableFilters && columnFiltersRef.current.dateOfService,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dateOfService}>
            <span>{rowData.dateOfService}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.dateOfService
                ? moment(columnFiltersRef.current.dateOfService)
                : ""
            }
          />
        );
      },
    },
    {
      title: "BIN",
      field: "bin",
      defaultFilter: enableFilters && columnFiltersRef.current.bin,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bin}>
            <span>{rowData.bin}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.bin}
          placeholder="BIN"
        />
      ),
    },
    {
      title: "PCN",
      field: "pcn",
      defaultFilter: enableFilters && columnFiltersRef.current.pcn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pcn}>
            <span>{rowData.pcn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pcn}
          placeholder="PCN"
        />
      ),
    },
    {
      title: LABELS.PharmacyChain,
      field: "phGroupName",
      defaultFilter: enableFilters && columnFiltersRef.current.phGroupName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.phGroupName}>
            <span>{rowData.phGroupName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.phGroupName}
          placeholder={LABELS.PharmacyChain}
        />
      ),
    },
    {
      title: LABELS.PharmacyStore,
      field: "store",
      defaultFilter: enableFilters && columnFiltersRef.current.store,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.store}>
            <span>{rowData.store}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.store}
          placeholder={LABELS.PharmacyStore}
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "dispensingStoreNpi",
      defaultFilter:
        enableFilters && columnFiltersRef.current.dispensingStoreNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingStoreNpi}>
            <span>{rowData.dispensingStoreNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingStoreNpi}
          placeholder="Pharmacy NPI"
        />
      ),
    },
    {
      title: "NDC11",
      field: "ndc",
      defaultFilter: enableFilters && columnFiltersRef.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ndc}
          placeholder="NDC11"
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: enableFilters && columnFiltersRef.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugName}
          placeholder="Drug Name"
        />
      ),
    },
    {
      title: "Brand or Generic",
      field: "brandGenericFlag",
      defaultFilter: enableFilters && columnFiltersRef.current.brandGenericFlag,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.brandGenericFlag}>
            <span>{rowData.brandGenericFlag}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.brandGenericFlag}
          placeholder="Brand or Generic"
        />
      ),
    },
    {
      title: "Replenished Percentage",
      field: "replenishedPercentage",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.replenishedPercentage,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishedPercentage}>
            <span className={globalClasses.tableNumericPadding}>
              {rowData.replenishedPercentage}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishedPercentage}
          placeholder="Replenished Percentage"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "True-Up Units",
      field: "trueUpUnits",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUpUnits,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpUnits}>
            <span className={globalClasses.tableNumericPadding}>
              {formatValue(rowData.trueUpUnits)}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUpUnits}
          placeholder="True-Up Units"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "True-Up  Amount",
      field: "trueUpAmount",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUpAmount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.trueUpAmount}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.trueUpAmount)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUpAmount}
          placeholder="True-Up  Amount"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "True-Up Reason",
      field: "trueUpReason",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUpReason,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpReason}>
            <span>{rowData.trueUpReason}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUpReason}
          placeholder="True-Up Reason"
        />
      ),
    },
    {
      title: "True-Up Type",
      field: "trueUpType",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUpType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpType}>
            <span>{rowData.trueUpType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUpType}
          placeholder="True-Up Type"
        />
      ),
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={3}>
            <BasicTypography
              variant="h5"
              title={`Invoice Number : ${actionsRowDataDetails.invoiceNumber}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={`Billing Cycle : ${formattedStartDate} -
                    ${formattedEndDate}`}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Grid className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h4"
                title={`True Up Details (${trueUpDetails.totalElements || 0})`}
              />
            }
            ref={tableRef}
            columns={TRUE_UP_COLUMNS}
            data={trueUpDetails.content}
            page={controller.page - 1}
            totalCount={trueUpDetails.totalElements || 0}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={actions}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              exportAllData: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(trueUpDetails)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default memo(TrueUpDetails);
