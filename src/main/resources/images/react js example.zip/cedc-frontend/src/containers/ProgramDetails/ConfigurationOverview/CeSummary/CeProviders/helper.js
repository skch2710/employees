import { pagination } from "../../../../../utils/constants";

export const getProvidersPayloadJson = (values = {}) => {
  const { ceId, ...rest } = values;
  return {
    ceid: [values.ceId],
    providerNPI: "",
    firstName: "",
    lastName: "",
    endDate: "",
    startDate: "",
    providerType: "",
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "",
    sortOrder: "",
    filter: [],
    export: false,
    ...rest,
  };
};
