import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { getPOItemHistoryExport } from "../../../../context/actions/PurchaseOrders";
import { notNull } from "../../../../utils/constants";
import { PO_ITEM_HISTORY_EXPORT_FILE_NAME } from "../constants";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { poID, poItemID, controller, columnFilters } = props;
    dispatch(
      getPOItemHistoryExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          poItemID: poItemID,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              poItemID,
              poIdSeqID,
              filePoItemNumber,
              itemInvoiceNumber,
              poItemStatusID,
              packageOrdered,
              packageAcknowledged,
              packageInvoiced,
              packageReconciled,
              fileItemStatus,
              itemOrderedDate,
              itemAcknowledgedDate,
              itemInvoicedDate,
              itemReconciledDate,
              acknowledgedNDC,
              inVoicedNDC,
              substitutedParentpoItemId,
              pgmPackageSize,
              createdByID,
              createdDate,
            }) => ({
              "PO Item ID": notNull(poItemID),
              "PO Item SEQID": notNull(poIdSeqID),
              "File PO Item Number": notNull(filePoItemNumber),
              "Item Invoice Number": notNull(itemInvoiceNumber),
              "PO Item Status": notNull(poItemStatusID),
              "Package Ordered": notNull(packageOrdered),
              "Package Acknowledged": notNull(packageAcknowledged),
              "Package Invoiced": notNull(packageInvoiced),
              "Package Reconciled": notNull(packageReconciled),
              "File Item Status Code": notNull(fileItemStatus),
              "Item Ordered Date": notNull(itemOrderedDate),
              "Item Acknowledged Date": notNull(itemAcknowledgedDate),
              "Item Invoiced Date": notNull(itemInvoicedDate),
              "Item Reconciled Date": notNull(itemReconciledDate),
              "Acknowledged NDC": notNull(acknowledgedNDC),
              "Invoiced NDC": notNull(inVoicedNDC),
              "Substituted Parent PO Item ID": notNull(
                substitutedParentpoItemId
              ),
              "Pgm Package Size": notNull(pgmPackageSize),
              "Created By": notNull(createdByID),
              "Created Date": notNull(createdDate),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(
            fileData,
            PO_ITEM_HISTORY_EXPORT_FILE_NAME + ".xlsx"
          );
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
