import { useDispatch } from "react-redux";
import { providersExport } from "../../../context/actions/providers";
import { notNull } from "../../../utils/constants";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
const fileName = "Providers List";

const ExportProvider = () => {
  const dispatch = useDispatch();

  const exportToExcel = ({
    ciId,
    ceProvider,
    ceSelected,
    CEidarray,
    searchData,
    defaultFilters,
    controller
  }) => {
    const {
      providerNPI,
      firstName,
      lastName,
      startDate,
      endDate,
      providerType,
      status
    } = searchData;
    let payload = {
      ceid: ceProvider ? [ciId] : ceSelected ? [ceSelected.ceID] : CEidarray,
      providerNPI: providerNPI || "",
      sortBy: controller.sortBy,
      sortOrder: controller.sortOrder,
      export: true,
      filter: defaultFilters,
      firstName: firstName || "",
      lastName: lastName || "",
      endDate: endDate || "",
      startDate: startDate || "",
      providerType: providerType || "",
      status: status || ""
    };
    dispatch(
      providersExport(payload, (res) => {
        var data = res.content.map(
          ({
            firstName,
            lastName,
            providerNpi,
            providerDea,
            prescriberSpi,
            exclusive,
            startDate,
            endDate,
            lastModifiedDate,
          }) => ({
            "Provider First Name": notNull(firstName),
            "Provider Last Name": notNull(lastName),
            "Provider NPI": notNull(providerNpi),
            "Provider DEA": notNull(providerDea),
            "Provider SPI": notNull(prescriberSpi),
            "Program Type": notNull(exclusive),
            "Provider Start Date": notNull(startDate),
            "Provider End Date": notNull(endDate),
            "Last Modified Date": notNull(lastModifiedDate),
          })
        );
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, {
          bookType: "xlsx",
          type: "array",
        });
        const fileData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(fileData, fileName + ".xlsx");
      })
    );
  };
  return { exportToExcel };
};

export default ExportProvider;
