import React, { useState, useEffect, useRef, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form, Field } from "formik";
import { useHistory } from "react-router-dom";
import {
  Grid,
  Button,
  IconButton,
  FormLabel,
  Typography,
} from "@material-ui/core";
import DatePicker from "../../../components/common/DatePicker";
import Excel from "../../../assets/excel.png";
import moment from "moment";
import useQuery from "../../../utils/useQuery";
import { IoIosCloseCircleOutline } from "react-icons/io";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import { getFilteredPatientDefaultValue } from "./constant";
import {
  pagination,
  REGEX,
  setAutoCompleteInputVal,
  statusArray
} from "../../../utils/constants";
import {
  endDateValidation,
  getUserPreveleges,
  startDateValidation,
} from "../../../utils/common";
import Tooltip from "@mui/material/Tooltip";
import {
  getPatientSearchData,
  fetchPatientType,
} from "../../../context/actions/Patients";
import { getAllCoveredEntities } from "../../../context/actions/Common";
import PatientslistTable from "./PatientslistTable";
import {
  PATIENTS,
  CE_MEMBERS,
} from "../../../components/common/Table/TableHeadCells";
import { filterFunctionality } from "./helper";
import _isEmpty from "lodash/isEmpty";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { getUserSession } from "../../../utils/helper";
import { usePatientStyles } from "./style";
import AutoComplete from "../../../components/common/AutoComplete";
import _isArray from "lodash/isArray";
import _get from "lodash/get";

const Patients = ({ Co = false, permissionObj, messageUuid }) => {
  const dispatch = useDispatch();
  const formikRef = useRef(null);
  const globalClasses = useGlobalStyles();
  const classes = usePatientStyles();
  const userSession = getUserSession();
  const history = useHistory();

  const { ceList } = useSelector((state) => state.coveredEntities);
  const { records: patients } = useSelector((state) => state.patients);
  const { records: membersList } = useSelector((state) => state.coMembers);

  const [patientPermission, setPatientPermission] = useState(null);
  const [open, setOpen] = useState(true);
  const { ceId: searchParamCeId } = useQuery();
  const defaultValues = getFilteredPatientDefaultValue(
    userSession.coveredEntityDTOs,
    searchParamCeId
  );
  const [clearButton, setClearButton] = useState(false);
  const [enableactionbutton, setenableactionbutton] = useState(false);
  const [filterValues, setFilterValues] = useState([]);
  const [patientSearchData, setPatientSearchData] = useState({});
  const [openPopup, setOpenPopup] = useState(false);
  const [actionTitle, setActionTitle] = useState("");
  const [submitActionType, setSubmitActionType] = useState("");
  const [patientTypes, setPatientTypes] = useState([]);
  const [controller, setController] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: Co ? "desc" : "asc",
    sortBy: Co ? "modifiedDate" : "lastName, firstName",
  });

  const handleChange = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    const { name, value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue(name, value);
  };

  const onChangePagination = useCallback(
    (newPage, pageSize, sortObj) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const { totalElements = 0 } = Co ? membersList : patients;
      const totalPages = Math.ceil(totalElements / rowsPerPage) || 1;
      if (controller.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.pageNumber;
      fetchPatients({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: filterValues,
        sortBy: sortObj.sortBy,
        sortOrder: sortObj.sortOrder,
      });
    },
    [filterValues, controller]
  );

  const onChangeSorting = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = Co
        ? CE_MEMBERS[orderedColumnId].field
        : PATIENTS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchPatients({ sortBy, sortOrder });
    },
    [controller, filterValues]
  );

  const onChangeFilter = async (value) => {
    const payload = {
      pageNumber: pagination.page,
      pageSize: controller.pageSize,
    };
    if (value.length) {
      const responseValue = await filterFunctionality(
        value,
        Co ? "CeMember" : "Patients"
      );
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setFilterValues(responseValue);
    } else {
      payload.filter = null;
      setFilterValues([]);
    }
    fetchPatients(payload);
  };

  const fetchPatients = (payload = {}) => {
    const { values } = formikRef.current;
    const formValue = !_isEmpty(patientSearchData)
      ? patientSearchData
      : defaultValues;
    const patientPayload = !Co
      ? {
          dob: formValue.dob,
          endDate: formValue.endDate,
          firstName: formValue.firstName,
          lastName: formValue.secondName,
          mrn: formValue.mrn,
          startDate: formValue.startDate,
          patientType: formValue.patientType,
        }
      : {};
    const payloadJson = {
      ceid: !Co
        ? _isArray(formValue.ceid)
          ? formValue.ceid
          : [formValue.ceid]
        : messageUuid && messageUuid.ceid !== null && [messageUuid.ceid],
      export: false,
      filter: filterValues,
      ...patientPayload,
      ...controller,
      ...payload,
      status: payload.status || formValue.status,
    };

    setPatientSearchData(payloadJson);
    dispatch(
      getPatientSearchData(payloadJson, Co, (data) => {
        setController((prev) => ({
          ...prev,
          pageNumber: data.pageNo,
          pageSize: data.pageSize,
        }));
        formikRef.current.isSubmitting = false;
      })
    );
  };

  const handleSubmit = (values) => {
    setClearButton(false);
    const payload = {
      ...values,
      ceid: [values.ceid],
      patientType: _get(values, "patientType.personType", ""),
      ...controller,
      pageNumber: pagination.page,
    };
    payload.filter = [];
    setPatientSearchData(payload);
    setFilterValues([]);
    fetchPatients(payload);
  };

  const getPatientTypes = async () => {
    const paTypes = (await fetchPatientType()) || [];
    setPatientTypes([...paTypes]);
  };

  useEffect(() => {
    const { values } = formikRef.current;
    const ceId = !_isEmpty(patientSearchData)
      ? patientSearchData.ceid
      : [values.ceid];
    fetchPatients(!Co && { ceid: ceId });
    setPatientPermission(getUserPreveleges("Patients"));
    if (!Co) getPatientTypes();
    return () => {
      dispatch({ type: Co ? "GET_MEMBER_LIST" : "GET_PATIENT_LIST", data: {} });
    };
  }, []);

  useEffect(() => {
    if (clearButton) fetchPatients();
  }, [clearButton]);

  const formValidate = (values) => {
    const errors = {};
    if (!values.ceid) {
      errors.ceid = "Please select the covered entity.";
    }
    return errors;
  };

  const clearFunction = (resetForm) => {
    searchParamCeId && history.push(history.location.pathname);
    resetForm();
    setClearButton(true);
    setFilterValues([]);
    setPatientSearchData({});
    setController((prev) => ({
      ...prev,
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "asc",
      sortBy: "",
    }));
  };

  const openAddPatientPopup = () => {
    setOpenPopup(true);
    setActionTitle("Add Patient");
    setSubmitActionType("Add Patient");
  };

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Formik
          initialValues={defaultValues}
          onSubmit={handleSubmit}
          validate={formValidate}
          innerRef={formikRef}
        >
          {({ values, errors, touched, setFieldValue, resetForm }) => (
            <>
              {!Co && (
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography
                      variant="h1"
                      title="Eligibility - Patients"
                    />
                  </Grid>
                  <Grid item md={12}>
                    <Form>
                      {open ? (
                        <div className={globalClasses.cardPrimary}>
                          <Grid container spacing={2}>
                            <Grid item md={12}>
                              <Grid
                                container
                                spacing={2}
                                justifyContent="space-between"
                              >
                                <Grid item>
                                  <BasicTypography
                                    variant="h4"
                                    title="Filters"
                                  />
                                </Grid>
                                <Grid item>
                                  <IconButton
                                    onClick={() => {
                                      setOpen(false);
                                    }}
                                  >
                                    <IoIosCloseCircleOutline />
                                  </IconButton>
                                </Grid>
                              </Grid>
                            </Grid>
                            <Grid item md={12}>
                              <Grid container spacing={2}>
                                <Grid item xs={12} sm={4}>
                                  <FormLabel required>Covered Entity</FormLabel>
                                  <Field
                                    as="select"
                                    name="ceid"
                                    className={globalClasses.formControl}
                                  >
                                    {({ field }) => (
                                      <AutoComplete
                                        {...field}
                                        disabled={
                                          ceList && ceList.length > 1
                                            ? false
                                            : true
                                        }
                                        options={_isArray(ceList) ? ceList : []}
                                        inputPlaceholder={
                                          "Select Covered Entity"
                                        }
                                        disableCloseOnSelect={false}
                                        onChange={(e, value) => {
                                          resetForm();
                                          setFieldValue(
                                            "ceid",
                                            value ? Number(value.ceID) : ""
                                          );
                                        }}
                                        getOptionLabel={(option) =>
                                          option.ceName || ""
                                        }
                                        value={
                                          (_isArray(ceList) &&
                                            ceList.find(
                                              (e) => e.ceID == values.ceid
                                            )) || ""
                                        }
                                        renderOption={(option, _other) => {
                                          return (
                                            <BasicTypography variant="subtitle2">
                                              {option.ceName}
                                            </BasicTypography>
                                          );
                                        }}
                                        multiple={false}
                                        textFieldProps={{
                                          inputProps: {
                                            name: "ceid",
                                          },
                                        }}
                                      />
                                    )}
                                  </Field>
                                  {errors.ceid && touched.ceid && (
                                    <Typography color="error" variant="caption">
                                      {errors.ceid}
                                    </Typography>
                                  )}
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>MRN</FormLabel>
                                  <Field
                                    name="mrn"
                                    type="text"
                                    className={globalClasses.formControl}
                                    placeholder="Enter Patient MRN"
                                    maxLength={20}
                                    onChange={(e) =>
                                      handleChange(e, setFieldValue)
                                    }
                                  />
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>Patient First Name</FormLabel>
                                  <Field
                                    name="firstName"
                                    type="text"
                                    className={globalClasses.formControl}
                                    placeholder="Enter Patient First Name"
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      if (
                                        value &&
                                        !REGEX.alphabetsAndHypen.test(value)
                                      )
                                        return;
                                      setFieldValue("firstName", value);
                                      handleChange(e, setFieldValue);
                                    }}
                                    maxLength={25}
                                  />
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>Patient Last Name</FormLabel>
                                  <Field
                                    name="lastName"
                                    type="text"
                                    className={globalClasses.formControl}
                                    placeholder="Enter Patient Last Name"
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      if (
                                        value &&
                                        !REGEX.alphabetsAndHypen.test(value)
                                      )
                                        return;
                                      setFieldValue("lastName", value);
                                      handleChange(e, setFieldValue);
                                    }}
                                    maxLength={25}
                                  />
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>Patient DOB</FormLabel>
                                  <DatePicker
                                    name="dob"
                                    onChange={(e, date) =>
                                      setFieldValue("dob", date)
                                    }
                                    value={
                                      values.dob !== ""
                                        ? moment(values.dob)
                                        : ""
                                    }
                                  />
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>Patient Type</FormLabel>
                                  <Field
                                    as="select"
                                    className={globalClasses.formControl}
                                    name="patientType"
                                  >
                                    {({ field }) => (
                                      <AutoComplete
                                        {...field}
                                        disableCloseOnSelect={false}
                                        options={
                                          _isArray(patientTypes)
                                            ? patientTypes
                                            : []
                                        }
                                        inputPlaceholder={"Select Patient Type"}
                                        onChange={(e, value) => {
                                          setFieldValue("patientType", value);
                                        }}
                                        getOptionLabel={(option) =>
                                          option.personType || ""
                                        }
                                        renderOption={(option, _other) => {
                                          return (
                                            <BasicTypography variant="subtitle2">
                                              {option.personType}
                                            </BasicTypography>
                                          );
                                        }}
                                        multiple={false}
                                      />
                                    )}
                                  </Field>
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>Admit/Visit Date</FormLabel>
                                  <DatePicker
                                    disabledDate={(date) =>
                                      startDateValidation(date, values.endDate)
                                    }
                                    onChange={(e, date) => {
                                      if (!date) setFieldValue("endDate", "");
                                      setFieldValue("startDate", date);
                                    }}
                                    value={
                                      values.startDate !== ""
                                        ? moment(values.startDate)
                                        : ""
                                    }
                                  />
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel> Eligibility Termination Date</FormLabel>
                                  <DatePicker
                                    onChange={(e, date) => {
                                      setFieldValue("endDate", date);
                                    }}
                                    disabledDate={(d) =>
                                      endDateValidation(d, values.startDate)
                                    }
                                    value={
                                      values.endDate !== ""
                                        ? moment(values.endDate)
                                        : ""
                                    }
                                  />
                                </Grid>

                                <Grid item xs={12} sm={4}>
                                  <FormLabel>Status</FormLabel>
                                  <Field as="select" name="status">
                                    {({ field }) => (
                                      <AutoComplete
                                        {...field}
                                        options={
                                          _isArray(statusArray)
                                            ? statusArray
                                            : []
                                        }
                                        inputPlaceholder={"Select Status"}
                                        disableCloseOnSelect={false}
                                        disableClearable={true}
                                        onChange={(e, value) => {
                                          setFieldValue(
                                            "status",
                                            value && value.status
                                          );
                                        }}
                                        getOptionLabel={(option) =>
                                          option.status || ""
                                        }
                                        value={
                                          statusArray.find(
                                            (e) => e.status == values.status
                                          ) || statusArray[0]
                                        }
                                        renderOption={(option, _other) => {
                                          return (
                                            <BasicTypography variant="subtitle2">
                                              {option.status}
                                            </BasicTypography>
                                          );
                                        }}
                                        multiple={false}
                                        textFieldProps={{
                                          inputProps: {
                                            name: "status",
                                          },
                                        }}
                                        
                                      />
                                    )}
                                  </Field>
                                </Grid>
                              </Grid>
                            </Grid>
                            <Grid item md={12}>
                              <Grid
                                container
                                justifyContent="flex-end"
                                spacing={2}
                              >
                                <Grid item>
                                  <Tooltip
                                    placement="top"
                                    title={
                                      patientPermission !== undefined &&
                                      patientPermission !== null &&
                                      !patientPermission.readWriteFlag
                                        ? "You don't have Permission."
                                        : ""
                                    }
                                  >
                                    <span>
                                      <Button
                                        startIcon={<AddCircleOutlineIcon />}
                                        variant="outlined"
                                        size="small"
                                        component="button"
                                        className={globalClasses.grayButton}
                                        onClick={openAddPatientPopup}
                                        disabled={
                                          !values.ceid ||
                                          (patientPermission !== undefined &&
                                          patientPermission !== null &&
                                          patientPermission.readWriteFlag
                                            ? false
                                            : true)
                                        }
                                      >
                                        Add Patient
                                      </Button>
                                    </span>
                                  </Tooltip>
                                </Grid>
                                <Grid item>
                                  <Button
                                    type="submit"
                                    size="small"
                                    variant="contained"
                                    className={globalClasses.primaryBtn}
                                  >
                                    Search
                                  </Button>
                                </Grid>
                                <Grid item>
                                  <Button
                                    type="reset"
                                    size="small"
                                    variant="outlined"
                                    className={globalClasses.secondaryBtn}
                                    onClick={() => clearFunction(resetForm)}
                                  >
                                    Clear
                                  </Button>
                                </Grid>
                              </Grid>
                            </Grid>
                          </Grid>
                        </div>
                      ) : (
                        <Button
                          variant="contained"
                          className={globalClasses.primaryBtn}
                          onClick={() => {
                            setOpen(true);
                          }}
                        >
                          Filters
                        </Button>
                      )}
                    </Form>
                  </Grid>
                </Grid>
              )}
            </>
          )}
        </Formik>
      </Grid>
      {!Co && (
        <Grid item md={12}>
          <div className={classes.templateLink}>
            <Tooltip
              title={
                patientPermission !== null && !patientPermission.readWriteFlag
                  ? "You don't have Permission."
                  : ""
              }
            >
              <span>
                <img
                  src={Excel}
                  alt="Active"
                  className={globalClasses.templateDownloadIcon}
                />
                <a
                  href={`/templates/Patient_Template.xlsx`}
                  download="Patient_Template"
                  className={
                    patientPermission !== null &&
                    patientPermission.readWriteFlag
                      ? globalClasses.clickableLink
                      : globalClasses.disabledDownloadTemp
                  }
                  disabled={
                    patientPermission !== null &&
                    patientPermission.readWriteFlag
                      ? false
                      : true
                  }
                >
                  Download Template
                </a>
              </span>
            </Tooltip>
          </div>
        </Grid>
      )}
      <Grid item md={12}>
        <PatientslistTable
          searchFormRef={formikRef.current && formikRef.current.values}
          patients={Co ? membersList : patients}
          patientSearchData={patientSearchData}
          ceList={ceList}
          controller={controller}
          defaultFilters={filterValues}
          onChangePagination={onChangePagination}
          onChangeSorting={onChangeSorting}
          onChangeFilter={onChangeFilter}
          Co={Co}
          setenableactionbutton={enableactionbutton}
          permissionObj={permissionObj}
          patientPermission={patientPermission}
          openPopup={openPopup}
          submitActionType={submitActionType}
          actionTitle={actionTitle}
          setOpenPopup={setOpenPopup}
          setActionTitle={setActionTitle}
          setSubmitActionType={setSubmitActionType}
        />
      </Grid>
    </Grid>
  );
};

export default Patients;
