import { Button, Grid } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import React, { memo, useContext, useEffect, useRef, useState } from "react";
import { BsChevronLeft, BsChevronRight } from "react-icons/bs";
import { useDispatch, useSelector } from "react-redux";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import { SET_NDC_CLIENT_EXCLUSIONS } from "../../../../../../context/reducers/NdcExclusions/constants";
import {
  getExcludedData,
  getSelectedRows,
} from "../../../../../../utils/helper";
import { NdcContext } from "../../../NdcContext";
import EditNdcDates from "../../EditNdcDates";
import EditNdcDatesPopupFooter from "../../EditNdcDatesPopupFooter";
import { getMinDate } from "../helper";
import NdcClientExceptionsTable from "./NdcClientExceptionsTable";
import NdcClientExclusionsTable from "./NdcClientExclusionsTable";
import { useNdcTablesStyles } from "./styles";

const ClientExclusionTables = memo((props = {}) => {
  const { searchTableProps } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = useNdcTablesStyles();
  const { ndcClientExceptionData, setNdcClientExceptionData, ndcData } =
    useContext(NdcContext) || {};
  const searchTableRef = useRef(null);
  const draftTableRef = useRef(null);
  const { startDate, endDate } = ndcData || {};
  const [defaultFormValues, setDefaultFormValues] = useState({
    startDate: startDate,
    endDate: endDate,
  });

  const { records: clientExclusionData } = useSelector(
    (state) => state.ndcClientExclusionsList
  );

  const [showEditNdcDatesPopup, setShowEditNdcDatesPopup] = useState({
    show: false,
    action: "",
  });

  const handleAddToDraft = (values = {}) => {
    const selectedRows = getSelectedRows(searchTableRef);
    if (selectedRows.length) {
      const afterAddingDates = selectedRows.map((row) => ({
        ...row,
        exceptionAppliedStartDate: values.startDate || "",
        exceptionAppliedEndDate: values.endDate || row.exclusionAppliedEndDate,
      }));
      const totalRows = [
        ...ndcClientExceptionData.content,
        ...afterAddingDates,
      ];
      setNdcClientExceptionData({
        content: totalRows,
        totalElements: totalRows.length,
      });
      const leftGridData = getExcludedData({
        originalList: clientExclusionData.content,
        draftList: selectedRows,
        identifierKey: "id",
      });
      dispatch({
        type: SET_NDC_CLIENT_EXCLUSIONS,
        data: { content: leftGridData, totalElements: leftGridData.length },
      });
      setShowEditNdcDatesPopup({ show: false });
    }
  };

  const handleEditNdcDatesPopup = (state, action = "") => {
    if (state) {
      const leftSelectedRows = getSelectedRows(searchTableRef);
      const rightSelectedRows = getSelectedRows(draftTableRef);
      setDefaultFormValues({
        startDate: "",
        endDate: "",
      });
      if (action === "add" && leftSelectedRows.length) {
        setShowEditNdcDatesPopup({ show: true, action });
      }
      if (action === "remove" && rightSelectedRows.length) {
        setShowEditNdcDatesPopup({ show: true, action });
      }
    } else {
      setShowEditNdcDatesPopup({ show: false });
    }
  };

  const handleRemoveFromException = (values = {}) => {
    const selectedRows = getSelectedRows(draftTableRef);
    if (selectedRows.length) {
      const updatedRowData = getExcludedData({
        originalList: ndcClientExceptionData.content,
        draftList: selectedRows,
        identifierKey: "id",
      });
      setNdcClientExceptionData({
        content: updatedRowData,
        totalElements: updatedRowData.length,
      });
      const prevData = clientExclusionData.content || [];
      const exclusionsAfterAddingDates = selectedRows.map((row) => ({
        ...row,
        startDate: values.startDate || row.startDate,
        endDate: values.endDate || row.endDate,
      }));
      const originalAppliedExclusionsList = [
        ...prevData,
        ...exclusionsAfterAddingDates,
      ];
      dispatch({
        type: SET_NDC_CLIENT_EXCLUSIONS,
        data: {
          content: originalAppliedExclusionsList,
          totalElements: originalAppliedExclusionsList.length,
        },
      });
      setShowEditNdcDatesPopup({ show: false });
    }
  };

  useEffect(() => {
    return () => setNdcClientExceptionData({ content: [], totalElements: 0 });
  }, []);

  const handleValidate = (values = {}) => {
    const error = {};
    if (!values.startDate) {
      error.startDate = `Please select the ${
        showEditNdcDatesPopup.action === "remove" ? "Exclusion" : "Exception"
      } Applied Start Date`;
    }
    return error;
  };

  return (
    <>
      <Grid container spacing={2} justifyContent="space-between">
        <Grid item className={classes.gridTableContainer}>
          <div className={globalClasses.tableCardPrimary}>
            <NdcClientExclusionsTable
              ref={searchTableRef}
              {...searchTableProps}
            />
          </div>
        </Grid>
        <Grid item className={classes.gridActionBtnContainer}>
          <Grid
            container
            spacing={2}
            direction="column"
            alignItems="center"
            className={classes.actionButtonContainer}
          >
            <Grid item>
              <Button
                endIcon={<BsChevronRight size={14} />}
                variant="contained"
                size="small"
                className={globalClasses.primaryBtn}
                onClick={() => handleEditNdcDatesPopup(true, "add")}
              >
                Add
              </Button>
            </Grid>
            <Grid item>
              <Button
                startIcon={<BsChevronLeft size={14} />}
                variant="contained"
                size="small"
                className={globalClasses.redBtn}
                onClick={() => handleEditNdcDatesPopup(true, "remove")}
              >
                Remove
              </Button>
            </Grid>
          </Grid>
        </Grid>
        <Grid item className={classes.gridTableContainer}>
          <div className={globalClasses.tableCardPrimary}>
            <NdcClientExceptionsTable ref={draftTableRef} />
          </div>
        </Grid>
      </Grid>
      <BasicPopup
        title={
          showEditNdcDatesPopup.action === "remove"
            ? "NDC Client Effective Date"
            : "NDC Client Exception Date"
        }
        show={showEditNdcDatesPopup.show}
        disableFooter={true}
        isCustomFooter={true}
        footerActionElement={
          <EditNdcDatesPopupFooter
            handleEditNdcDatesPopup={handleEditNdcDatesPopup}
          />
        }
        dialogProps={{
          maxWidth: "md",
        }}
        withFormik={true}
        formikProps={{
          initialValues: defaultFormValues,
          onSubmit: (values) => {
            showEditNdcDatesPopup.action === "add"
              ? handleAddToDraft(values)
              : handleRemoveFromException(values);
          },
          validate: handleValidate,
        }}
        handleClose={() => handleEditNdcDatesPopup(false)}
      >
        <EditNdcDates
          startDateProps={{
            minDate: getMinDate(getSelectedRows(searchTableRef)) || moment(),
            label:
              showEditNdcDatesPopup.action === "add"
                ? "Exception Applied Start Date"
                : "Exclusion Applied Start Date",
          }}
          endDateProps={{
            minDate: ndcData.startDate,
            label:
              showEditNdcDatesPopup.action === "add"
                ? "Exception Applied End Date"
                : "Exclusion Applied End Date",
          }}
          selectedRows={getSelectedRows(
            showEditNdcDatesPopup.action === "add"
              ? searchTableRef
              : draftTableRef
          )}
        />
      </BasicPopup>
    </>
  );
});

export default ClientExclusionTables;
