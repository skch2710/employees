import React, { useState, useEffect, memo, useCallback, useRef } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { useDispatch, useSelector } from "react-redux";
import { Paper, Tooltip } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import _isEmpty from "lodash/isEmpty";
import { useTheme } from "@material-ui/core/styles";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { pagination } from "../../../utils/constants";
import { getProvidersLocationGridData } from "../../../context/actions/providers";
import ExportProviderLocations from "./ExportProviderLocations";
import { filterFunctionality } from "../../../utils/common";
import { getTableHeaderCount, isEmptyGrid } from "../../../utils/helper";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
  getTableActionCellStyles,
} from "../../../Styles/useGlobalStyles";
import TableProgressBar from "../../../components/common/TableProgressBar";
import DataNotFound from "../../../components/common/DataNotFound";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import { useProviderStyle } from "./styles";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../components/common/Pagination";

const ProvidersLocations = ({ provideRowData } = {}) => {
  const { ceid, prescriberId } = provideRowData || {};
  const dispatch = useDispatch();
  const theme = useTheme();
  const iconsAndButtons = useTableIconsAndButtons();
  const globalClasses = useGlobalStyles();
  const { exportToExcel } = ExportProviderLocations();
  const columnFiltersRef = useRef({});

  const { records: providerInnerGridList, loading } = useSelector(
    (state) => state.providersLocationsGridData
  );

  const [filter, setFilter] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [controller, setController] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "locationName",
  });

  const classes = useProviderStyle({
    totalElements:
      !_isEmpty(providerInnerGridList) && providerInnerGridList.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.pageNumber,
  });

  const fetchInnerGridData = (payload = {}) => {
    dispatch(
      getProvidersLocationGridData(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          ceid: ceid,
          prescriberId: [prescriberId],
          filter: columnFilters,
          ...payload,
        },
        (res) => {
          setController((prev) => ({
            ...prev,
            pageNumber: res.pageNo,
            pageSize: res.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (ceid) fetchInnerGridData();
  }, []);

  const onChangePagination = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const { totalElements = 0 } = providerInnerGridList;
      const totalPages = Math.ceil(totalElements / rowsPerPage) || 1;
      if (controller.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.pageNumber;
      fetchInnerGridData({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller]
  );

  const onChangeSorting = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PROVIDERS_LOCATION_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchInnerGridData({ sortOrder, sortBy });
    },
    [controller, columnFilters]
  );

  const onChangeFilter = async (value) => {
    const payload = {
      pageNumber: controller.pageNumber,
      pageSize: controller.pageSize,
    };
    if (value.length) {
      const responseValue = await filterFunctionality(
        value,
        "ProviderLocationInnerGrid"
      );
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setColumnFilters(responseValue);
    } else {
      payload.filter = null;
      setColumnFilters([]);
    }
    const updatedObj = {};
    value.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    columnFiltersRef.current = { ...updatedObj };
    fetchInnerGridData(payload);
  };

  const actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      disabled: isEmptyGrid(providerInnerGridList) && _isEmpty(columnFilters),
      isFreeAction: true,
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(providerInnerGridList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(providerInnerGridList),
      onClick: () =>
        exportToExcel({
          ceid: ceid,
          prescriberId: [prescriberId],
          columnFilters,
          controller,
        }),
    },
  ];

  const PROVIDERS_LOCATION_COLUMNS = [
    {
      title: "Covered Entity",
      field: "ceName",
      defaultFilter: filter && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceName}>
            <span>{rowData.ceName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceName}
          placeholder="Covered Entity"
        />
      ),
    },
    {
      title: "340B ID",
      field: "tfbId",
      defaultFilter: filter && columnFiltersRef.current.tfbId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.tfbId}>
            <span>{rowData.tfbId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.tfbId}
          placeholder="340B ID"
        />
      ),
    },
    {
      title: "Location Name",
      field: "locationName",
      defaultFilter: filter && columnFiltersRef.current.locationName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationName}>
            <span>{rowData.locationName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationName}
          placeholder="Location Name"
        />
      ),
    },
    {
      title: "Location HRSA ID",
      field: "locationHrsaId",
      defaultFilter: filter && columnFiltersRef.current.locationHrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationHrsaId}>
            <span>{rowData.locationHrsaId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationHrsaId}
          placeholder="Location HRSA ID"
        />
      ),
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Provider Location Data (${getTableHeaderCount(
              providerInnerGridList.totalElements
            )})`}
          />
        }
        columns={PROVIDERS_LOCATION_COLUMNS}
        data={providerInnerGridList.content}
        page={controller.pageNumber - 1}
        totalCount={providerInnerGridList.totalElements || 0}
        actions={actions}
        onOrderChange={onChangeSorting}
        onChangePage={onChangePagination}
        onFilterChange={onChangeFilter}
        isLoading={loading}
        icons={{
          SortArrow: () => TableCustomSortArrow(controller),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              {...props}
              classes={{ root: globalClasses.gridMuiToolbar }}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        options={{
          debounceInterval: 500,
          search: false,
          searchFieldVariant: "standard",
          actionsColumnIndex: 0,
          filtering: filter,
          paginationType: "stepped",
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controller.pageSize,
          draggable: false,
          pageSizeOptions: isEmptyGrid(providerInnerGridList)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default memo(ProvidersLocations);
