import { makeStyles } from "@material-ui/core/styles";

export const useNdcListAppTabStyles = makeStyles((theme) => ({
  selectedCheckBox: {
    color: theme.colors.primary.default,
  },
  greyCard: {
    backgroundColor: theme.colors.monochrome.bg,
    borderRadius: "10px",
    padding: "15px",
    border: `solid 1px ${theme.colors.secondary.default}`,
  },
}));
