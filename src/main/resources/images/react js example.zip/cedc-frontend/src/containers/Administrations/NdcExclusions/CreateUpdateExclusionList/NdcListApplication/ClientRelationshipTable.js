import React, {
  memo,
  useRef,
  useState,
  useCallback,
  useEffect,
  useMemo,
  useContext,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import _isEmpty from "lodash/isEmpty";
import { useDispatch, useSelector } from "react-redux";
import { Button, Grid, Paper, Tooltip, useTheme } from "@material-ui/core";
import moment from "moment";
import { TiFilter } from "react-icons/ti";
import { pagination } from "../../../../../utils/constants";
import DataNotFound from "../../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import { getClientRelationshipFiltersObject, getMinDate } from "./helper";
import Pagination from "../../../../../components/common/Pagination";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getExcludedData,
  getSelectedRows,
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../utils/helper";
import {
  useGlobalStyles,
  getTableCellStyles,
  getTableHeaderStyles,
} from "../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import EditNdcDates from "../EditNdcDates";
import EditNdcDatesPopupFooter from "../EditNdcDatesPopupFooter";
import BasicPopup from "../../../../../components/Popup/BasicPopup";
import { SET_NDC_CLIENT_EXCLUSIONS } from "../../../../../context/reducers/NdcExclusions/constants";
import { NdcContext } from "../../NdcContext";
import _get from "lodash/get";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";

const ClientRelationshipTable = memo((props = {}) => {
  const { getClientRelationTableData, formSubmittedValues } = props;
  const theme = useTheme();
  const dispatch = useDispatch();
  const iconsAndButtons = useTableIconsAndButtons();
  const tableRef = useRef(null);
  const columnFiltersRef = useRef({});
  const globalClasses = useGlobalStyles();
  const { ndcClientExceptionData, setNdcClientExceptionData } =
    useContext(NdcContext) || {};

  const [tableData, setTableData] = useState({ content: [], totalElements: 0 });

  const { loading, records: clientRelationshipTableData = {} } =
    useSelector((state) => state.clientRelationshipTableData) || {};
  const { records: clientExclusionData } = useSelector(
    (state) => state.ndcClientExclusionsList
  ) || { content: [], totalElements: 0 };

  useEffect(() => {
    setTableData(clientRelationshipTableData);
  }, [clientRelationshipTableData]);

  const [enableFilters, setEnableFilters] = useState(false);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
  });
  const [columnFilters, setColumnFilters] = useState([]);
  const [showEditNdcClientDatesPopup, setShowEditNdcClientDatesPopup] =
    useState(false);

  const [defaultFormValues, setDefaultFormValues] = useState({
    startDate: "",
    endDate: "",
  });

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(
          _get(clientRelationshipTableData, "totalElements", 0) / rowsPerPage
        ) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      getClientRelationTableData(
        {
          ...formSubmittedValues,
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controllers.sortOrder,
          sortBy: controllers.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [
      columnFilters,
      clientRelationshipTableData,
      controllers,
      formSubmittedValues,
    ]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = CLIENT_RELATIONSHIP_COLUMNS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      getClientRelationTableData(
        {
          ...formSubmittedValues,
          pageNumber: controllers.pageNumber,
          pageSize: controllers.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [
      controllers,
      columnFilters,
      clientRelationshipTableData,
      formSubmittedValues,
    ]
  );

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getClientRelationshipFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    getClientRelationTableData(
      {
        ...controllers,
        filter: filterPayload,
        pageNumber: pagination.page,
        ...formSubmittedValues,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const CLIENT_RELATIONSHIP_COLUMNS = [
    {
      title: "Covered Entity",
      field: "ceName",
      defaultFilter: enableFilters && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceName}>
            <span>{rowData.ceName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="Covered Entity"
          value={columnFiltersRef.current.ceName}
        />
      ),
    },
    {
      title: "HRSA ID",
      field: "hrsaId",
      defaultFilter: enableFilters && columnFiltersRef.current.hrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.hrsaId}>
            <span>{rowData.hrsaId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="HRSA ID"
          value={columnFiltersRef.current.hrsaId}
        />
      ),
    },
    {
      title: "Pharmacy Chain",
      field: "pharmacyChain",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyChain,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyChain}>
            <span>{rowData.pharmacyChain}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="Pharmacy Chain"
          value={columnFiltersRef.current.pharmacyChain}
        />
      ),
    },
    {
      title: "Pharmacy Store",
      field: "pharmacyStore",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyStore,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyStore}>
            <span>{rowData.pharmacyStore}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="Pharmacy Store"
          value={columnFiltersRef.current.pharmacyStore}
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "pharmacyNpi",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNpi}>
            <span>{rowData.pharmacyNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyNpi}
          placeholder="Pharmacy NPI"
        />
      ),
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  const handleAddClientExclusion = () => {
    const selectedRows = getSelectedRows(tableRef);
    if (!selectedRows.length) return;
    const totalList = [
      ..._get(clientExclusionData, "content", []),
      ...selectedRows,
    ];
    dispatch({
      type: SET_NDC_CLIENT_EXCLUSIONS,
      data: { content: totalList, totalElements: totalList.length },
    });
    const tableUpdatedRows = getExcludedData({
      originalList: _get(tableData, "content", []),
      draftList: totalList,
      identifierKey: "id",
    });
    setTableData({
      content: tableUpdatedRows,
      totalElements: tableUpdatedRows.length,
    });
  };

  const handleAddClientException = () => {
    const selectedRows = getSelectedRows(tableRef);
    if (!selectedRows.length) return;
    setShowEditNdcClientDatesPopup(true);
  };

  const handleSubmit = (values) => {
    const selectedRows = getSelectedRows(tableRef);
    const afterAddingDates = selectedRows.map((row) => ({
      ...row,
      exceptionAppliedStartDate: values.startDate || "",
      exceptionAppliedEndDate: values.endDate || row.exclusionAppliedEndDate,
    }));
    const totalRows = [
      ..._get(ndcClientExceptionData, "content", []),
      ...afterAddingDates,
    ];
    setNdcClientExceptionData({
      content: totalRows,
      totalElements: totalRows.length,
    });
    const tableUpdatedRows = getExcludedData({
      originalList: _get(tableData, "content", []),
      draftList: totalRows,
      identifierKey: "id",
    });
    setTableData({
      content: tableUpdatedRows,
      totalElements: tableUpdatedRows.length,
    });
    setShowEditNdcClientDatesPopup(false);
  };

  const handleValidate = (values = {}) => {
    const error = {};
    if (!values.startDate) {
      error.startDate = "Please select the Exception Applied Start Date";
    }
    return error;
  };

  const clientRows = useMemo(
    () =>
      getExcludedData({
        originalList: _get(tableData, "content", []),
        draftList: _get(clientExclusionData, "content", []),
        identifierKey: "id",
      }),
    [tableData, clientExclusionData, clientRelationshipTableData]
  );

  return (
    <>
      <Grid container spacing={1} direction="column">
        <Grid item container spacing={1} justifyContent="flex-end">
          <Grid item>
            <Button
              startIcon={<AddCircleOutlineIcon />}
              variant="outlined"
              size="small"
              component="button"
              className={globalClasses.outlinedBtn}
              onClick={() => handleAddClientExclusion()}
            >
              Add to Applied Client Exclusions
            </Button>
          </Grid>
          <Grid item>
            <Button
              startIcon={<AddCircleOutlineIcon />}
              variant="outlined"
              size="small"
              component="button"
              className={globalClasses.outlinedBtn}
              onClick={() => handleAddClientException()}
            >
              Add to Client Exceptions
            </Button>
          </Grid>
        </Grid>
        <Grid item>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`New Client Relationships (${getTableHeaderCount(
                  _get(clientRelationshipTableData, "totalElements", 0)
                )})`}
              />
            }
            columns={CLIENT_RELATIONSHIP_COLUMNS}
            data={clientRows || []}
            page={controllers.pageNumber - 1}
            totalCount={_get(clientRelationshipTableData, "totalElements", 0)}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            tableRef={tableRef}
            icons={{
              SortArrow: () => TableCustomSortArrow(controllers),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={ACTIONS}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              selection: true,
              showTextRowsSelected: false,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              exportAllData: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controllers.pageSize,
              maxBodyHeight: 400,
              pageSizeOptions: isEmptyGrid(tableData)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
              debounceInterval: 500,
            }}
          />
        </Grid>
      </Grid>
      <BasicPopup
        title="NDC Dates"
        show={showEditNdcClientDatesPopup}
        disableFooter={true}
        isCustomFooter={true}
        footerActionElement={
          <EditNdcDatesPopupFooter
            handleEditNdcDatesPopup={(value) =>
              setShowEditNdcClientDatesPopup(value)
            }
          />
        }
        dialogProps={{
          maxWidth: "md",
        }}
        withFormik={true}
        formikProps={{
          initialValues: defaultFormValues,
          onSubmit: handleSubmit,
          validate: handleValidate,
        }}
        handleClose={() => setShowEditNdcClientDatesPopup(false)}
      >
        <EditNdcDates
          startDateProps={{
            minDate: getMinDate(getSelectedRows(tableRef)) || moment(),
            label: "Exception Applied Start Date",
          }}
          endDateProps={{
            label: "Exception Applied End Date",
          }}
          selectedRows={getSelectedRows(tableRef)}
        />
      </BasicPopup>
    </>
  );
});

export default ClientRelationshipTable;
