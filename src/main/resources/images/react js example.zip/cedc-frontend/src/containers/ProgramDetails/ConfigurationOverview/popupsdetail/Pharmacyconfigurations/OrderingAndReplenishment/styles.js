import { makeStyles } from "@material-ui/core/styles";

export const useOrderingReplenishmentStyles = makeStyles((theme) => {
  return {
    switchGridContainer: {
      display: "flex",
      alignItems: "flex-end",
    },
    switchContainer: {
      display: "flex",
      justifyContent: "space-between",
      width: "100%",
      height: "30px",
    },
    switchLabel: {
      color: theme.colors.monochrome.input,
      fontSize: "13px",
    },
    actionBtnGridItem: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
  };
});
