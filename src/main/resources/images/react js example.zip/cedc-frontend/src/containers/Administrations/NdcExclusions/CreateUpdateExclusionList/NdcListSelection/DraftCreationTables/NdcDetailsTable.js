import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import MaterialTable from "material-table";
import moment from "moment";
import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import DatePicker from "../../../../../../components/common/DatePicker";
import Pagination from "../../../../../../components/common/Pagination";
import { ColumnFilterIcon } from "../../../../../../components/common/Table/usetableStyle";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import { fetchNdcDetailsTableData } from "../../../../../../context/actions/NdcExclusions";
import { pagination } from "../../../../../../utils/constants";
import { isEmptyGrid } from "../../../../../../utils/helper";
import { NdcContext } from "../../../NdcContext";
import { getNdcDetailsFiltersObject } from "../helper";

const NdcDetailsTable = memo((props = {}) => {
  const { ndcDetailsRowData } = props;
  const dispatch = useDispatch();
  const theme = useTheme();
  const iconsAndButtons = useTableIconsAndButtons();
  const tableRef = useRef(null);
  const columnFiltersRef = useRef({});
  const { ndcData } = useContext(NdcContext);

  const { loading, records: ndcDetailsData } =
    useSelector((state) => state.ndcDetailsList) || {};

  const [enableFilters, setEnableFilters] = useState(false);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
  });
  const [columnFilters, setColumnFilters] = useState([]);

  const getNdcDetailsTableData = async (payload = {}, callback) => {
    const payloadJson = {
      listId: ndcData.listId,
      drugId: payload.drugId || ndcDetailsRowData.drugId,
      pageNumber: payload.pageNumber || pagination.page,
      pageSize: payload.pageSize || pagination.limit,
      sortOrder: payload.sortOrder || "",
      sortBy: payload.sortBy || "",
      filter: payload.filter || [],
      export: payload.export || false,
    };
    const tableData = await dispatch(fetchNdcDetailsTableData(payloadJson));
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  useEffect(() => {
    if (!_isEmpty(ndcDetailsRowData))
      getNdcDetailsTableData({ drugId: ndcDetailsRowData.drugId });
  }, [ndcDetailsRowData]);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(ndcDetailsData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && pageSize !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      getNdcDetailsTableData(
        {
          pageNumber: currentPage,
          pageSize: pageSize,
          sortOrder: controllers.sortOrder,
          sortBy: controllers.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = NDC_DETAILS_COLUMNS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      getNdcDetailsTableData(
        {
          pageNumber: controllers.pageNumber,
          pageSize: controllers.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controllers, columnFilters]
  );

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getNdcDetailsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    getNdcDetailsTableData(
      {
        ...controllers,
        filter: filterPayload,
        pageNumber: pagination.page,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const NDC_DETAILS_COLUMNS = [
    {
      title: "GCN",
      field: "gcn",
      defaultFilter: enableFilters && columnFiltersRef.current.gcn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.gcn}>
            <span>{rowData.gcn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="GCN"
          value={columnFiltersRef.current.gcn}
        />
      ),
    },
    {
      title: "NDC",
      field: "ndc",
      defaultFilter: enableFilters && columnFiltersRef.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="NDC"
          value={columnFiltersRef.current.ndc}
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: enableFilters && columnFiltersRef.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="Drug Name"
          value={columnFiltersRef.current.drugName}
        />
      ),
    },
    {
      title: "Manufacturer",
      field: "drugManufacturer",
      defaultFilter: enableFilters && columnFiltersRef.current.drugManufacturer,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugManufacturer}>
            <span>{rowData.drugManufacturer}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="Manufacturer"
          value={columnFiltersRef.current.drugManufacturer}
        />
      ),
    },
    {
      title: "Therapeutic Class",
      field: "therapeuticClass",
      defaultFilter: enableFilters && columnFiltersRef.current.therapeuticClass,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.therapeuticClass}>
            <span>{rowData.therapeuticClass}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.therapeuticClass}
          placeholder="Therapeutic Class"
        />
      ),
    },
    {
      title: "NDC Effective Start Date",
      field: "ndcEffectiveStartDate",
      defaultFilter:
        enableFilters && columnFiltersRef.current.ndcEffectiveStartDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcEffectiveStartDate || ""}>
            <span>{rowData.ndcEffectiveStartDate || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.ndcEffectiveStartDate
                ? moment(columnFiltersRef.current.ndcEffectiveStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "NDC Effective End Date",
      field: "ndcEffectiveEndDate",
      defaultFilter:
        enableFilters && columnFiltersRef.current.ndcEffectiveEndDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcEffectiveEndDate || ""}>
            <span>{rowData.ndcEffectiveEndDate || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.ndcEffectiveEndDate
                ? moment(columnFiltersRef.current.ndcEffectiveEndDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(ndcDetailsData),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  return (
    <MaterialTable
      title=""
      tableRef={tableRef}
      columns={NDC_DETAILS_COLUMNS}
      data={ndcDetailsData.content}
      page={controllers.pageNumber - 1}
      totalCount={ndcDetailsData.totalElements}
      onChangePage={onPageChange}
      onOrderChange={handleSort}
      onFilterChange={handleColumnFilter}
      icons={{
        SortArrow: () => TableCustomSortArrow(controllers),
        Filter: ColumnFilterIcon,
      }}
      actions={ACTIONS}
      components={{
        Container: (props) => <Paper {...props} elevation={0} />,
        OverlayLoading: () => <TableProgressBar />,
        Pagination: (props) => <Pagination {...props} />,
      }}
      localization={{
        header: {
          actions: "Actions",
        },
        body: {
          emptyDataSourceMessage: loading ? "" : <DataNotFound />,
        },
      }}
      isLoading={loading}
      options={{
        debounceInterval: 500,
        search: false,
        actionsColumnIndex: 0,
        filtering: enableFilters,
        paging: true,
        showFirstLastPageButtons: false,
        showTextRowsSelected: false,
        paginationPosition: "bottom",
        exportButton: false,
        paginationType: "stepped",
        exportAllData: false,
        headerStyle: getTableHeaderStyles(theme),
        cellStyle: getTableCellStyles(theme),
        actionsCellStyle: getTableActionCellStyles(theme),
        tableLayout: "auto",
        draggable: false,
        columnResizable: true,
        emptyRowsWhenPaging: false,
        pageSize: controllers.pageSize,
        maxBodyHeight: 400,
        minBodyHeight: 100,
        pageSizeOptions: isEmptyGrid(ndcDetailsData)
          ? []
          : pagination.pageSizeOptions,
        showEmptyDataSourceMessage: true,
      }}
    />
  );
});

export default NdcDetailsTable;
