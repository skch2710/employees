import React, { useState, useEffect, memo, useCallback, useRef } from "react";
import MaterialTable from "material-table";
import { useDispatch, useSelector } from "react-redux";
import { Paper, Tooltip, Grid, Typography } from "@material-ui/core";

//react-icons
import { TiFilter } from "react-icons/ti";
import { pagination, POLLING_COUNT } from "../../../utils/constants";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import { useTheme } from "@material-ui/core/styles";
import _isEmpty from "lodash/isEmpty";
import _debounce from "lodash/debounce";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../Styles/useGlobalStyles";
import { useProviderStyle } from "./styles";

import {
  getProvidersDeaGridData,
  getProviderDEAExist,
  saveProviderDea,
  saveProviderDeaMessageUuid,
} from "../../../context/actions/providers";
import { SET_PROVIDERS_DEA_TABLE_DATA_LOADING } from "../../../context/actions/providers/constants";

import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import { getProviderDeaFiltersObject } from "../../../utils/common";
import { isEmptyGrid, getUserSession } from "../../../utils/helper";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import DataNotFound from "../../../components/common/DataNotFound";
import TableProgressBar from "../../../components/common/TableProgressBar";
import { specialCharNotRequired } from "../../../utils/validation";
import Pagination from "../../../components/common/Pagination";

const ProviderDeaView = ({ provideRowData }) => {
  const { ceid, prescriberId } = provideRowData || {};
  const dispatch = useDispatch();
  const theme = useTheme();
  const classes = useStyles();
  const globalClasses = useGlobalStyles();
  const providerStyles = useProviderStyle();
  const [filter, setFilter] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});
  const iconsAndButtons = useTableIconsAndButtons();
  const userSessionData = getUserSession();
  const tableRef = useRef(null);
  const validateDea = specialCharNotRequired();
  const { records: providersDeaGridData, loading } = useSelector((state) => {
    return state.providersDeaGridData;
  });
  const [tableData, setTableData] = useState(
    providersDeaGridData.content || []
  );

  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "dea",
  });
  const deaError = useRef("");

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
    setTableData(resp.content);
  };

  const fetchInnerGridData = (payload = {}) => {
    dispatch(
      getProvidersDeaGridData(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "asc",
          filter: [],
          export: false,
          ceid: ceid,
          prescriberId: prescriberId,
          filter: columnFilters,
          ...payload,
        },
        (resp) => setControllersOnResp(resp)
      )
    );
  };

  useEffect(() => {
    if (ceid) fetchInnerGridData();
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(providersDeaGridData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      fetchInnerGridData({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = TABLE_COLUMN[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchInnerGridData({
        pageNumber: controllers.pageNumber,
        pageSize: controllers.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controllers, columnFilters]
  );

  const handleColumnFilter = async (filters = []) => {
    const payload = {
      pageNumber: controllers.pageNumber,
      pageSize: controllers.pageSize,
    };
    if (filters.length) {
      const responseValue = getProviderDeaFiltersObject(filters);
      payload.filter = responseValue;
      setColumnFilters(responseValue);
    } else {
      payload.filter = null;
      setColumnFilters([]);
    }
    const updatedObj = {};
    filters.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    columnFiltersRef.current = updatedObj;
    fetchInnerGridData(payload);
  };

  const handlePolling = async ({ messageUUid, currentCount }) => {
    const count = currentCount;
    const resp = await dispatch(saveProviderDeaMessageUuid(messageUUid, count));
    if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    } else if (resp && resp.statusCode === 200) {
      dispatch({ type: SET_PROVIDERS_DEA_TABLE_DATA_LOADING, data: true });
      setTimeout(() => fetchInnerGridData(), 4000);
    }
  };

  const addOrEditDea = async (data) => {
    const payload = {
      providerDeas: [
        {
          prescriberId: prescriberId || 0,
          dea: data.dea,
          inactiveFlag: "N",
        },
      ],
      createdById: userSessionData.userId,
      modifiedById: userSessionData.userId,
    };
    if (data.prescriberDeaId)
      payload.providerDeas[0].prescriberDeaId = data.prescriberDeaId;
    if (data.dea.length == 0) payload.providerDeas[0].inactiveFlag = "Y";

    const resp = await dispatch(saveProviderDea(payload, false));
    if (!_isEmpty(resp) && resp.data) {
      handlePolling({ messageUUid: resp.data, currentCount: POLLING_COUNT });
    }
  };

  const addOrEditRow = (newData, oldData = {}) => {
    return new Promise(async (resolve, reject) => {
      if (newData.dea === oldData.dea) {
        await addOrEditDea(newData);
        return resolve();
      }
      const existResp = await dispatch(getProviderDEAExist(newData.dea, false));
      if (existResp.statusCode == 200) {
        deaError.current = existResp.successMessage;
        reject();
      } else {
        await addOrEditDea(newData);
        deaError.current = "";
        resolve();
      }
    });
  };

  const TABLE_COLUMN = [
    {
      title: "DEA",
      field: "dea",
      defaultFilter: filter && columnFiltersRef.current.dea,
      validate: (row) =>
        (row.dea || "").length === 0
          ? {
              isValid: false,
              helperText: "Please enter DEA",
            }
          : {
              isValid: true,
              helperText: "",
            },
      customFilterAndSearch: () => true,
      editComponent: (props) => (
        <>
          <input
            type="text"
            value={props.value}
            className={providerStyles.deaTableInput}
            onChange={(e) => {
              const { value } = e.target;
              if (validateDea.test(value) && value.length <= 15) {
                props.onChange(value);
              }
              if (value.length === 0) deaError.current = "";
            }}
          />
          <Grid>
            <Typography color="error" variant="caption">
              {props.helperText}
            </Typography>
            <Typography color="error" variant="caption">
              {deaError.current}
            </Typography>
          </Grid>
        </>
      ),
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dea}>
            <span>{rowData.dea}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dea}
          placeholder="DEA"
        />
      ),
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      disabled: isEmptyGrid(providersDeaGridData) && _isEmpty(columnFilters),
      isFreeAction: true,
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
  ];

  return (
    <div className={classes.root}>
      <div className={providerStyles.providerDeaTableContainer}>
        <MaterialTable
          title=""
          columns={TABLE_COLUMN}
          data={tableData}
          page={controllers.pageNumber - 1}
          actions={ACTIONS}
          tableRef={tableRef}
          totalCount={providersDeaGridData.totalElements || 0}
          icons={{
            Add: iconsAndButtons.AddCustomButton({
              title: "Add DEA",
              className: globalClasses.exportButton,
              onClick: () => (deaError.current = ""),
            }),
            Edit: iconsAndButtons.Edit({
              color: theme.colors.grey[600],
              onClick: () => (deaError.current = ""),
            }),
            Check: iconsAndButtons.Check(),
            Clear: iconsAndButtons.Clear(),
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          editable={{
            onRowAdd: addOrEditRow,
            onRowUpdate: addOrEditRow,
          }}
          onOrderChange={handleSort}
          onChangePage={onPageChange}
          onFilterChange={handleColumnFilter}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            OverlayLoading: () => <TableProgressBar />,
          }}
          isLoading={loading}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          options={{
            debounceInterval: 500,
            search: false,
            searchFieldVariant: "standard",
            actionsColumnIndex: 0,
            filtering: filter,
            paginationType: "stepped",
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            columnResizable: true,
            emptyRowsWhenPaging: false,
            draggable: false,
            maxBodyHeight: 400,
            pageSize: controllers.pageSize,
            pageSizeOptions: isEmptyGrid(providersDeaGridData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
            addRowPosition: "first",
            actionsColumnIndex: -1,
          }}
        />
      </div>
    </div>
  );
};

export default memo(ProviderDeaView);
