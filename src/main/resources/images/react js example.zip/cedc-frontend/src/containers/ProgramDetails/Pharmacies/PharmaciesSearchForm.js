import React, { useEffect, useRef, useState } from "react";
import { Field, Form, Formik } from "formik";
import { Button, FormLabel, Grid, IconButton } from "@material-ui/core";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import { useDispatch } from "react-redux";
import { IoIosCloseCircleOutline } from "react-icons/io";
import useQuery from "../../../utils/useQuery";
import {
  getCoveredEntity,
  getPharmaciesDefaultValues,
  getPhConfigStatusOptions,
  getPhGroupIdArray,
} from "./helper";
import { LABELS, setAutoCompleteInputVal, statusArray } from "../../../utils/constants";
import { getCeIdsArray, getUserSession } from "../../../utils/helper";
import {
  getPharmacyGroups,
  getPharmacyStore,
} from "../../../context/actions/Common";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { usePharmacyFiltersStyles } from "./styles";
import {
  getCeListAndPhChainListOnPhId,
  getCeListOnPhGroupId,
} from "../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import MultiSelectDropdown from "../../../components/common/MultiSelectDropdown";
import { endDateValidation, startDateValidation } from "../../../utils/common";
import AutoComplete from "../../../components/common/AutoComplete";

const PharmaciesSearchForm = (props = {}) => {
  const { handleSubmit, handleClear, ceList = [] } = props;
  const dispatch = useDispatch();
  const userSession = getUserSession();
  const { ceId: searchParamCeId } = useQuery();
  const globalClasses = useGlobalStyles();
  const classes = usePharmacyFiltersStyles();

  const [defaultValues, setDefaultValues] = useState(
    getPharmaciesDefaultValues()
  );
  const [coveredEntityAllOptions, setCoveredEntityAllOptions] = useState([]);
  const [showFilters, setShowFilters] = useState(true);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);
  const [pharmaciesList, setPharmaciesList] = useState([]);
  const phFormikRef = useRef(null);

  const fetchPharmacyGroups = async (ceIds, otherProps = {}) => {
    const ceIdArray = getCeIdsArray(ceIds);
    const resp = await dispatch(getPharmacyGroups(ceIdArray));
    if (_isArray(resp)) {
      setPharmacyGroups(resp);
      const { phGroupId, setFieldValue } = otherProps;
      if (phGroupId) {
        const isPresent = resp.some(
          (group = {}) => group.phGroupId === phGroupId
        );
        !isPresent && setFieldValue && setFieldValue("phGroupId", "");
      }
      fetchPharmacies(ceIds, getPhGroupIdArray(resp));
    }
  };

  const fetchPharmacies = async (ceIds, phGroupIds) => {
    const ceIdArray = getCeIdsArray(ceIds);
    const resp = await dispatch(
      getPharmacyStore({
        phGroupId: phGroupIds,
        ceid: ceIdArray,
      })
    );
    _isArray(resp) && setPharmaciesList(resp);
  };

  const setCeListAndPhChainList = async ({ phId, setFieldValue }) => {
    const resp = await dispatch(getCeListAndPhChainListOnPhId(phId));
    if (!_isEmpty(resp)) {
      const { CoveredEntities, pharmacyGroups } = resp || {};
      setPharmacyGroups(pharmacyGroups);
      if (userSession.isInternalUser) {
        setFieldValue("ceId", CoveredEntities);
      }
      fetchPharmacies(CoveredEntities, getPhGroupIdArray(pharmacyGroups));
    }
  };

  useEffect(() => {
    if (ceList.length) {
      const options = searchParamCeId
        ? getCoveredEntity({ ceId: Number(searchParamCeId), ceList })
        : ceList;
      setCoveredEntityAllOptions(ceList);
      fetchPharmacyGroups(options);
      setDefaultValues((prev) => ({
        ...prev,
        ceId: searchParamCeId
          ? getCoveredEntity({ ceId: Number(searchParamCeId), ceList })
          : userSession.isInternalUser
          ? [...ceList]
          : ceList,
      }));
    }
  }, [ceList]);

  const fetchCoveredEntityDropdownOptions = async (
    phGroupId,
    setFieldValue
  ) => {
    const resp = await dispatch(
      getCeListOnPhGroupId({
        phGroupId: [phGroupId],
      })
    );
    if (_isArray(resp)) {
      setFieldValue("ceId", resp);
      //setCoveredEntityAllOptions([...resp]);
    }
    //_isArray(resp) && setCoveredEntityAllOptions([...resp]);
  };

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      enableReinitialize={true}
      innerRef={phFormikRef}
    >
      {({ values, setFieldValue, initialValues, touched }) => {
        return (
          <Form>
            {showFilters ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2}>
                  <Grid item md={12} className={classes.filterHeader}>
                    <BasicTypography variant="h4" title="Filters" />
                    <IconButton
                      onClick={() => {
                        setShowFilters(false);
                      }}
                    >
                      <IoIosCloseCircleOutline />
                    </IconButton>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2} alignItems="center">
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Covered Entity</FormLabel>
                        <Field as="select" multiple name="ceId">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disabled={ceList.length <= 1}
                              disableClearable={true}
                              inputPlaceholder={
                                userSession.isInternalUser
                                  ? "Select Covered Entity"
                                  : ""
                              }
                              options={coveredEntityAllOptions}
                              getOptionSelected={(option, value) =>
                                option.ceID === value.ceID
                              }
                              getOptionLabel={(option) => option.ceName}
                              textFieldProps={{
                                inputProps: {
                                  name: "ceId",
                                },
                              }}
                              onChange={(_e, value) => {
                                setFieldValue("ceId", value);
                                if (value.length) {
                                  fetchPharmacyGroups(value, {
                                    setFieldValue,
                                    phGroupId: values.phGroupId,
                                  });
                                }
                                setFieldValue("phGroupId", "");
                                setFieldValue("pharmacy", "");
                              }}
                              inputValue={values.coveredEntityInput || ""}
                              onInputChange={(_e, value) =>
                                setAutoCompleteInputVal({
                                  value,
                                  callback: (newValue) => {
                                    setFieldValue(
                                      "coveredEntityInput",
                                      newValue
                                    );
                                  },
                                })
                              }
                              tooltipProps={{
                                title:
                                  !userSession.isInternalUser &&
                                  values.ceId.length
                                    ? values.ceId[0].ceName
                                    : "",
                              }}
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="phGroupId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(pharmacyGroups) ? pharmacyGroups : []
                              }
                              inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                              value={
                                (_isArray(pharmacyGroups) &&
                                  pharmacyGroups.find(
                                    (e) => e.phGroupId == values.phGroupId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? newValue.phGroupId
                                  : "";
                                setFieldValue("pharmacy", "");
                                setFieldValue("phGroupId", Number(value));
                                if (value) {
                                  if (
                                    userSession.isInternalUser &&
                                    values.ceId &&
                                    (values.ceId.length === ceList.length ||
                                      !touched.ceId)
                                  ) {
                                    fetchCoveredEntityDropdownOptions(
                                      Number(value),
                                      setFieldValue
                                    );
                                  }
                                  fetchPharmacies(values.ceId, [Number(value)]);
                                } else {
                                  fetchPharmacyGroups(values.ceId);
                                  setCoveredEntityAllOptions(
                                    userSession.isInternalUser
                                      ? [...ceList]
                                      : ceList
                                  );
                                }
                              }}
                              getOptionLabel={(option) =>
                                option.phGroupName || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.phGroupName}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyStore}</FormLabel>

                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="pharmacy"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(pharmaciesList) ? pharmaciesList : []
                              }
                              inputPlaceholder={`Select ${LABELS.PharmacyStore}`}
                              value={
                                (_isArray(pharmaciesList) &&
                                  pharmaciesList.find(
                                    (e) => e.phid == values.pharmacy
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? Number(newValue.phid)
                                  : "";
                                setFieldValue("pharmacy", value);
                                if (value) {
                                  if (!values.phGroupId) {
                                    const pharmacy = pharmaciesList.find(
                                      (ph) => ph.phid === value
                                    );
                                    setFieldValue(
                                      "phGroupId",
                                      pharmacy.phGroupId
                                    );
                                    setCeListAndPhChainList({
                                      phId: value,
                                      setFieldValue,
                                    });
                                  }
                                }
                              }}
                              getOptionLabel={(option) => option.phName || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.phName}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>Start Date</FormLabel>
                        <Field as="select" name="startDate">
                          {({ field }) => (
                            <DatePicker
                              {...field}
                              onChange={(_e, date) => {
                                if (!date) setFieldValue("endDate", "");
                                setFieldValue("startDate", date);
                              }}
                              placeholder="Select Start Date"
                              value={
                                values.startDate !== ""
                                  ? moment(values.startDate, "MM/DD/YYYY")
                                  : ""
                              }
                              disabledDate={(date) =>
                                startDateValidation(date, values.endDate)
                              }
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>End Date</FormLabel>
                        <Field as="select" name="endDate">
                          {({ field }) => (
                            <DatePicker
                              {...field}
                              onChange={(_e, date) => {
                                setFieldValue("endDate", date);
                              }}
                              placeholder="Select End Date"
                              value={
                                values.endDate !== ""
                                  ? moment(values.endDate, "MM/DD/YYYY")
                                  : ""
                              }
                              disabledDate={(d) =>
                                endDateValidation(d, values.startDate)
                              }
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>Pharmacy Configuration Status</FormLabel>
                        <Field
                          as="select"
                          name="phConfigStatus"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={getPhConfigStatusOptions()}
                              inputPlaceholder={`Select Status`}
                              value={
                                getPhConfigStatusOptions().find(
                                  (e) =>
                                    e.ceConfigStatusId == values.phConfigStatus
                                ) || ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? Number(newValue.ceConfigStatusId)
                                  : "";
                                setFieldValue("phConfigStatus", value);
                              }}
                              getOptionLabel={(option) =>
                                option.ceConfigStatus || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.ceConfigStatus}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <FormLabel>Status</FormLabel>
                        <Field as="select" name="status">
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={_isArray(statusArray) ? statusArray : []}
                              inputPlaceholder={"Select Status"}
                              disableCloseOnSelect={false}
                              disableClearable={true}
                              onChange={(e, value) => {
                                setFieldValue("status", value && value.status);
                              }}
                              getOptionLabel={(option) => option.status || ""}
                              value={
                                statusArray.find(
                                  (e) => e.status == values.status
                                ) || statusArray[0]
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.status}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                              textFieldProps={{
                                inputProps: {
                                  name: "status",
                                },
                              }}
                              
                            />
                          )}
                        </Field>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={12} className={classes.actionBtnContainer}>
                    <Button
                      type="submit"
                      color="primary"
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                    >
                      Search
                    </Button>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      color="default"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setDefaultValues((prev) => ({
                          ...prev,
                          ceId: userSession.isInternalUser
                            ? [...ceList]
                            : ceList,
                        }));
                        fetchPharmacyGroups(ceList);
                        setCoveredEntityAllOptions(
                          userSession.isInternalUser ? [...ceList] : ceList
                        );
                        handleClear({
                          ...initialValues,
                          ceId: ceList,
                        });
                      }}
                    >
                      Clear
                    </Button>
                  </Grid>
                </Grid>
              </div>
            ) : (
              <Button
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setShowFilters(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default PharmaciesSearchForm;
