import React from 'react'
import { Link } from 'react-router-dom'

const Emaillink = () => {
  return (
    <div style={{marginTop:"220px"}}> 
        <center>
        <Link to= {{pathname:"/createpassword",search: "?uuid=2533c6e4#1649758807286"}}><h4>340BDirect.com/redirect/setpasswordpage</h4></Link>
        </center>
    </div>
  )
}

export default Emaillink;