import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Checkbox,
  Grid,
  Paper,
  Tooltip,
  useTheme,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import _get from "lodash/get";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, { memo } from "react";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../../../components/common/DatePicker";
import Pagination from "../../../../../../components/common/Pagination";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { pagination } from "../../../../../../utils/constants";
import { useCeBillingAndFeesStyles } from "./styles";

const ClientFeeTables = (props) => {
  const { pharmacy, handleRowSelection, handleUncheckAll, handleCheckAll } =
    props;
  const theme = useTheme();
  const classes = useCeBillingAndFeesStyles();
  const globalClasses = useGlobalStyles();

  const PHARMACIES_COLUMNS = [
    {
      title: "Customized",
      field: "customized",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.customized}>
            <span>{rowData.customized}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Customized" />
      ),
    },
    {
      title: "Covered Entity",
      field: "entityName",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.entityName}>
            <span>{rowData.entityName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Covered Entity" />
      ),
    },
    {
      title: "Fee Type",
      field: "feeType",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeType}>
            <span>{rowData.feeType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Fee Type" />
      ),
    },
    {
      title: "Fee Value",
      field: "flatFee",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.flatFee}>
            <span>{rowData.flatFee}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Fee Value" />
      ),
    },
    {
      title: "Percentage",
      field: "percentage",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.percentage}>
            <span>{rowData.percentage}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Percentage" />
      ),
    },
    {
      title: "Basis Of",
      field: "basisOf",
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.basisOf}>
            <span>{rowData.basisOf}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Basis Of" />
      ),
    },
    {
      title: "Claim Type",
      field: "claimType",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimType}>
            <span>{rowData.claimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Claim Type" />
      ),
    },
    {
      title: "Additional Claim Type Detail",
      field: "addlClaimType",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addlClaimType}>
            <span>{rowData.addlClaimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          placeholder="Additional Claim Type Detail"
        />
      ),
    },
    {
      title: "Switch",
      field: "switchType",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.switchType}>
            <span>{rowData.switchType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput {...props} placeholder="Switch" />
      ),
    },
    {
      title: "Start Date",
      field: "feeStartDate",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeStartDate}>
            <span>{rowData.feeStartDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
          />
        );
      },
    },
    {
      title: "End Date",
      field: "feeEndDate",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeEndDate}>
            <span>{rowData.feeEndDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
          />
        );
      },
    },
    {
      title: "Applied",
      field: "applied",
      filtering: false,
      sorting: false,
      render: () => {
        return (
          <Checkbox
            name="appliedFeesStatus"
            color="default"
            checked
            classes={{
              root: classes.checkbox,
            }}
          />
        );
      },
    },
  ];

  return (
    <Grid item md={12}>
      <Paper className={classes.cardWrapper}>
        <Accordion defaultExpanded={true}>
          <AccordionSummary
            className={classes.collapseTitle}
            expandIcon={<ExpandMoreIcon className={classes.collapseIcon} />}
            aria-label="Expand"
          >
            <BasicTypography variant="h3" title={pharmacy.phName} />
          </AccordionSummary>
          <AccordionDetails>
            <div className={classes.tableContainer}>
              <MaterialTable
                id={pharmacy.id}
                columns={PHARMACIES_COLUMNS}
                data={_get(pharmacy, "clientAdminFees", [])}
                totalCount={pharmacy.clientAdminFees.length}
                onSelectionChange={(allRows, rowData) => {
                  if (!rowData && !allRows.length) {
                    // !reset all
                    handleUncheckAll({ pharmacy });
                  } else if (!rowData && allRows.length) {
                    // !checked all
                    handleCheckAll({ pharmacy, rows: allRows });
                  } else if (rowData) {
                    handleRowSelection({
                      rowData,
                      checked: rowData.tableData.checked,
                    });
                  }
                }}
                icons={{
                  SortArrow: () => TableCustomSortArrow(),
                  Filter: () => <TiFilter fontSize="small" />,
                }}
                components={{
                  Container: (props) => <Paper {...props} elevation={0} />,
                  Toolbar: (props) => (
                    <MTableToolbar
                      classes={{ root: globalClasses.gridMuiToolbar }}
                      {...props}
                    />
                  ),
                  Pagination: (props) => <Pagination {...props} />,
                  OverlayLoading: () => <TableProgressBar />,
                }}
                localization={{
                  header: {
                    actions: "Actions",
                  },
                }}
                isLoading={false}
                options={{
                  showTitle: false,
                  toolbar: false,
                  debounceInterval: 500,
                  search: false,
                  filtering: false,
                  paging: false,
                  selection: true,
                  showFirstLastPageButtons: false,
                  showTextRowsSelected: false,
                  paginationPosition: "bottom",
                  paginationType: "stepped",
                  headerStyle: getTableHeaderStyles(theme),
                  cellStyle: getTableCellStyles(theme),
                  tableLayout: "auto",
                  draggable: false,
                  columnResizable: true,
                  emptyRowsWhenPaging: false,
                  pageSize: pagination.limit,
                  maxBodyHeight: 400,
                  minBodyHeight: 100,
                  pageSizeOptions: pharmacy.clientAdminFees.length
                    ? pagination.pageBillingSizeOptions
                    : [],
                  showEmptyDataSourceMessage: true,
                }}
              />
            </div>
          </AccordionDetails>
        </Accordion>
      </Paper>
    </Grid>
  );
};

export default memo(ClientFeeTables);
