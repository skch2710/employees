import { makeStyles } from "@material-ui/core";

export const useProgramDetailsStyles = makeStyles((_theme) => ({
  dialogPaper: {
    height: "85vh",
  },
}));
