import React, { useEffect } from "react";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import MaterialTable, { MTableToolbar } from "material-table";
import { tableCellGlobalJson } from "../../../../../../components/common/Table/usetableStyle";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Paper, useTheme, Tooltip } from "@material-ui/core";
import { useSelector } from "react-redux";
import {
  useGlobalStyles,
  getTableCellStyles,
  getTableHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { getTableHeaderCount } from "../../../../../../utils/helper";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import { useCeOrderingConfigStyles } from "./styles";
import { ORDERING_CONFIG_MODULE } from "../../../../../../utils/constants";

const WholesalersGrid = ({ module, wholesalers = [] }) => {
  const theme = useTheme();
  const globalClasses = useGlobalStyles();
  const classes = useCeOrderingConfigStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const { loading } = useSelector((state) => state.globalLoader);
  const WHOLESALER_COLUMNS = [
    {
      title: "Wholesaler Name",
      field: "wholesalerName",
      render: (rowData) => {
        return (
          <Tooltip title={rowData.wholesalerName || ""}>
            <span>{rowData.wholesalerName || ""}</span>
          </Tooltip>
        );
      },
    },
    ...(module === ORDERING_CONFIG_MODULE.CO
      ? []
      : [
          {
            title: "Wholesaler Account Number",
            field: "wholesalerAccountNumber",
            render: (rowData) => {
              return (
                <Tooltip title={rowData.wholesalerAccountNumber || ""}>
                  <span>{rowData.wholesalerAccountNumber || ""}</span>
                </Tooltip>
              );
            },
          },
        ]),
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.AddCustomButton({
        title: "Select Wholesalers",
        disabled: true,
      }),
      isFreeAction: true,
      disabled: true,
    },
  ];

  return (
    <div
      className={
        module === ORDERING_CONFIG_MODULE.CO
          ? classes.tableCardPadding
          : globalClasses.tableCardPrimary
      }
    >
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Wholesalers Details (${getTableHeaderCount(
              wholesalers.length
            )})`}
          />
        }
        columns={WHOLESALER_COLUMNS}
        data={wholesalers}
        actions={ACTIONS}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Toolbar: (props) => (
            <MTableToolbar
              {...props}
              classes={{ root: globalClasses.gridMuiToolbar }}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
          },
        }}
        options={{
          search: false,
          sorting: false,
          actionsColumnIndex: 0,
          paging: false,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          maxBodyHeight: 400,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};
export default WholesalersGrid;
