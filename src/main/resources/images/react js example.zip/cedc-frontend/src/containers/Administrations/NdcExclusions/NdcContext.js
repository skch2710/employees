import _noop from "lodash/noop";
import React, { createContext, useState } from "react";
import { NDC_TABS } from "./constants";
import { getNdcListPayload } from "./helpers";

const NdcContext = createContext({
  setShowAddEditNdcListPopup: _noop(),
  setActiveInactiveTabs: _noop(),
  setProgress: _noop(),
  setNdcData: _noop(),
  setActiveNdcConfigTab: _noop(),
  setNdcConfigPopupTitle: _noop(),
  setNdcSelectionDraftTableData: _noop(),
  setNdcClientExceptionData: _noop(),
  setDynamicParamsTb: _noop(),
});

const initialActiveInactiveTabs = {
  [NDC_TABS.NDC_BASIC_DETAILS]: true,
  [NDC_TABS.NDC_SELECTION]: false,
  [NDC_TABS.NDC_LIST_APPLICATION]: false,
  [NDC_TABS.NDC_LIST_REVIEW]: false,
};

const NdcContextProvider = ({ children }) => {
  const [showAddEditNdcListPopup, setShowAddEditNdcListPopup] = useState(false);
  const [progress, setProgress] = useState({});
  const [activeNdcConfigTab, setActiveNdcConfigTab] = useState(
    NDC_TABS.NDC_BASIC_DETAILS
  );
  const [ndcData, setNdcData] = useState({});
  const [isNewList, setIsNewList] = useState(true);
  const [ndcConfigPopupTitle, setNdcConfigPopupTitle] = useState(
    "Create NDC Exclusion List"
  );
  const [activeInactiveTabs, setActiveInactiveTabs] = useState(
    initialActiveInactiveTabs
  );
  const [ndcSelectionDraftTableData, setNdcSelectionDraftTableData] = useState({
    content: [],
    totalElements: 0,
  });
  const [ndcClientExceptionData, setNdcClientExceptionData] = useState({
    content: [],
    totalElements: 0,
  });
  const [ndcSelectionBulkUploadReport, setNdcSelectionBulkUploadReport] =
    useState({});
  const [dynamicParamsTb, setDynamicParamsTb] = useState(false);
  const [ndcSearchPayload, setNdcSearchPayload] = useState(getNdcListPayload());

  const handleConfigPopup = ({ state } = {}) => {
    if (!state) {
      setNdcData({});
      setActiveNdcConfigTab(NDC_TABS.NDC_BASIC_DETAILS);
      setActiveInactiveTabs(initialActiveInactiveTabs);
      setNdcSelectionBulkUploadReport({});
    }
    setShowAddEditNdcListPopup(state);
    setProgress({});
  };

  const value = {
    showAddEditNdcListPopup,
    handleConfigPopup,
    progress,
    setProgress,
    isNewList,
    setIsNewList,
    ndcData,
    setNdcData,
    activeNdcConfigTab,
    setActiveNdcConfigTab,
    ndcConfigPopupTitle,
    setNdcConfigPopupTitle,
    ndcSelectionDraftTableData,
    setNdcSelectionDraftTableData,
    activeInactiveTabs,
    setActiveInactiveTabs,
    setNdcClientExceptionData,
    ndcClientExceptionData,
    ndcSelectionBulkUploadReport,
    setNdcSelectionBulkUploadReport,
    dynamicParamsTb,
    setDynamicParamsTb,
    ndcSearchPayload,
    setNdcSearchPayload,
  };

  return <NdcContext.Provider value={value}>{children}</NdcContext.Provider>;
};

export { NdcContext, NdcContextProvider };
