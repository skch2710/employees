import React from "react";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import {
  Grid,
  FormLabel,
  IconButton,
  Collapse,
  Divider,
  Tooltip,
} from "@material-ui/core";
import { Field } from "formik";
import _isArray from "lodash/isArray";
import { IoIosArrowDown } from "react-icons/io";
import { IoIosArrowUp } from "react-icons/io";
import DividerWithText from "./DividerWithText";
import Toggle from "../../../../../../components/common/Toggle";
import { useCeEligibilityStyles } from "./styles";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { getDeepCopy } from "./helper";
import { useDataNotFoundStyle } from "../../../../../../components/common/DataNotFound/style";

const EligibilityRuleSets = ({
  isFromWizard = false,
  ruleSet,
  index,
  setCreateRuleSet,
  createRuleSet,
  ruleNames,
}) => {
  const classes = useCeEligibilityStyles();
  const globalClasses = useGlobalStyles();
  const noResultsFoundStyles = useDataNotFoundStyle();

  const handleClickCollapse = (index) => {
    const updatedState = getDeepCopy(createRuleSet).map((item, i) => ({
      ...item,
      isExpanded: i === index ? !item.isExpanded : item.isExpanded,
    }));
    setCreateRuleSet(updatedState);
  };

  const handleChangeToggle = (index) => {
    let dupState = JSON.parse(JSON.stringify(createRuleSet));
    dupState.map((item, i) => {
      if (i === index) item.isToggleOn = !item.isToggleOn;
    });
    setCreateRuleSet(dupState);
  };

  const getTitle = (item) => {
    const attributeItem =
      (_isArray(ruleNames) &&
        ruleNames.find(
          (lookupItem) => lookupItem.attributeId === item.attributeId
        )) ||
      {};

    return attributeItem.attribute;
  };

  return (
    <>
      {index > 0 && <DividerWithText>OR</DividerWithText>}
      <Grid container spacing={1} className={classes.ruleSetGridContainer}>
        <Grid item md={12}>
          <BasicTypography
            variant="h4"
            title={`Rule Set - ${index < 9 ? 0 : ""}${index + 1}`}
          />
        </Grid>
        <Grid item md={12} className={classes.ruleSetCollapseContainer}>
          <div className={classes.ruleSetContainer}>
            {ruleSet.attributes.map((item, index) => (
              <div className={classes.ruleSetDivContainer} key={index}>
                {index > 0 && (
                  <span className={classes.conditionalOperator}>&</span>
                )}
                <BasicTypography
                  variant="h5"
                  title={getTitle(item)}
                  className={classes.ruleNameBox}
                />
              </div>
            ))}
          </div>

          {!isFromWizard && (
            <div>
              <Toggle
                name={`toggleSwitch${index}`}
                disabled
                checked={ruleSet.inActiveFlag === "Y" ? true : false}
              />
            </div>
          )}

          {isFromWizard && (
            <div>
              <Field
                name={`toggleSwitch${index}`}
                component={Toggle}
                checked={ruleSet.isToggleOn}
                onChange={() => handleChangeToggle(index)}
              />
              <Tooltip title="View Historical Data">
                <IconButton
                  onClick={() => handleClickCollapse(index)}
                  className={classes.collpaseBtn}
                >
                  {ruleSet.isExpanded ? (
                    <IoIosArrowUp size="16px" />
                  ) : (
                    <IoIosArrowDown size="16px" />
                  )}
                </IconButton>
              </Tooltip>
            </div>
          )}
        </Grid>
        <Grid item md={12}>
          <Collapse in={ruleSet.isExpanded} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            {ruleSet.historyInfo.length === 0 && (
              <>
                <Grid className={classes.ruleSetInfoContainer}>
                  <div className={noResultsFoundStyles.bodyContainer}>
                    <p>No History Found</p>
                  </div>
                </Grid>
                <Divider classes={{ root: globalClasses.divider }} />
              </>
            )}
            <div>
              {ruleSet.historyInfo.map((item, index) => (
                <div key={index}>
                  <Grid className={classes.ruleSetInfoContainer}>
                    <div className={classes.startEndStatusContainer}>
                      <div>
                        <FormLabel>Start Date</FormLabel>
                        <BasicTypography variant="subtitle2">
                          {item.ruleSetStartDate}
                        </BasicTypography>
                      </div>
                      <div>
                        <FormLabel>End Date</FormLabel>
                        <BasicTypography variant="subtitle2">
                          {item.ruleSetEndDate}
                        </BasicTypography>
                      </div>
                      <div>
                        <FormLabel>Rule Set Status</FormLabel>
                        <BasicTypography variant="subtitle2">
                          {item.inActiveFlag === "N" ? "Inactive" : "Active"}
                        </BasicTypography>
                      </div>
                    </div>
                  </Grid>
                  <Divider classes={{ root: globalClasses.divider }} />
                </div>
              ))}
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </>
  );
};
export default EligibilityRuleSets;
