import React from "react";
import { useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Grid, Button } from "@material-ui/core";
import LoginImages from "./LoginImages";
import { getLoginVerificationDefaultValue } from "../../utils/constants";
import { Formik, Field, Form } from "formik";
import "./account.scss";
import { validateOTP } from "../../context/actions/Auth";
import LoaderUI from "../../components/common/Loader/Loader";
import Footer from "./footer";
import { getLatestCE } from "../../context/actions/ConfigOverview";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import classNames from "classnames";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import { useLoginVerificationStyles } from "./styles";

const Loginverification = ({ location }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const globalClasses = useGlobalStyles();
  const classes = useLoginVerificationStyles();
  const defaultValues = getLoginVerificationDefaultValue();
  const user = useSelector((state) => state.user);
  const loader = useSelector((state) => state.user.loading);

  const checkArraySub = (dataArray) => {
    if (dataArray && dataArray.length > 0) {
      let firstIndex = dataArray[0];
      if (firstIndex && firstIndex.subNav && firstIndex.subNav.length > 0) {
        history.replace(firstIndex.subNav[0].path, { from: "login" });
      } else {
        history.replace(firstIndex.path, { from: "login" });
      }
    } else {
      history.replace("/home", { from: "login" });
    }
  };

  if (user.loggedIn === false) {
    history.push("/");
  }
  const handleSubmit = (values, { setErrors }) => {
    dispatch(
      validateOTP(
        { userName: user.userName, password: user.password, otp: values.otp },
        (result) => {
          if (result.statusCode === 200) {
            dispatch(getLatestCE());
            if (location.state && location.state.routeBack) {
              history.replace(location.state.routeBack);
            } else {
              if (localStorage.sessionslogindata === undefined) {
                history.push("/");
              }
              var data = JSON.parse(localStorage.sessionslogindata);
              const Sidenavdata = data.navigations;
              checkArraySub(Sidenavdata);
            }
          } else if (result.statusCode === 404) {
            setErrors({ otp: result.errorMessage });
          }
        }
      )
    );
  };

  const formValidate = (values) => {
    let error = {};
    if (values.otp.trim() === "") {
      error.otp = "Please enter the OTP";
    }
    if (values.otp.length !== 6) {
      error.otp = "OTP must have 6 digits";
    }
    return error;
  };

  const goback = () => {
    history.push("/login");
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={defaultValues}
        onSubmit={handleSubmit}
        validate={formValidate}
      >
        {({ errors }) => (
          <>
            <Grid className="login-bg">
              <Grid className="container-fluid">
                {loader && <LoaderUI />}
                <div className="row login-height">
                  <LoginImages />
                  <Grid className="col-12 col-lg-5 col-md-5 col-sm-12">
                    <Grid className="login-right-wrapper">
                      <BasicTypography
                        variant="h2"
                        className={classNames(
                          classes.verificationTitle,
                          "mb-3"
                        )}
                      >
                        Verify your identity
                      </BasicTypography>

                      <Form>
                        <Grid className="mb-3">
                          <Grid className="form-text m-b-30">
                            Please enter the One Time Password(OTP) sent to your
                            registered email account. OTP will expire in 5 mins.
                          </Grid>
                          <span>
                            User Name : <strong>{user.userName}</strong>
                          </span>
                        </Grid>
                        <Grid className="mb-3">
                          <Field
                            name="otp"
                            type="text"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.otpBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            id="exampleInputEmail1"
                            aria-describedby="otpHelp"
                            placeholder="Enter OTP"
                          />
                          {errors.otp && (
                            <div style={{ color: "red" }}>{errors.otp}</div>
                          )}
                        </Grid>

                        <Button
                          color="primary"
                          type="submit"
                          disabled={loader}
                          className="btn btn-primary"
                          component="button"
                          variant="contained"
                          size="large"
                        >
                          Verify
                        </Button>
                        <Button
                          onClick={goback}
                          className="btn btn-secondary m-l-20 "
                          component="button"
                          variant="outlined"
                          size="large"
                        >
                          Back
                        </Button>
                      </Form>
                    </Grid>
                  </Grid>
                </div>
              </Grid>
            </Grid>
          </>
        )}
      </Formik>
      <Footer />
    </>
  );
};
export default Loginverification;
