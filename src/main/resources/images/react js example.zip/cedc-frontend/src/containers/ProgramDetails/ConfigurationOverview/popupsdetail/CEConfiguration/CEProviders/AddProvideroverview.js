import React from "react";
import { useDispatch } from "react-redux";
import { Grid, Button, FormLabel, Typography } from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import {
  checkProviderType,
  getProviderDEAExist,
  getProviderNpiExist,
  getProviderSPIExist,
} from "../../../../../../context/actions/providers";
import { getAddProviderDefaultValues } from "./constant";
import _debounce from "lodash/debounce";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { REGEX } from "../../../../../../utils/constants";

const AddProvideroverview = ({
  setOpenPopup,
  setIndexValue,
  setFormData,
  formData,
  messageUuid,
  ceSelected,
  rowData,
  editProvider,
  view,
  title,
  formRef,
  spiExist,
  setSpiExist,
  deaExist,
  setDeaExist,
  npiExist,
  setNpiExist,
}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const { providerDea = "", spi = ""} = formData

  const handleSubmit = (e) => {
    setFormData(e);
    setIndexValue(e, 1);
  };

  const formValidate = (values) => {
    if (!view) {
      const errors = {};
      if (!values.npi) {
        setNpiExist("")
        errors.npi = "Please enter the Provider NPI";
      } else if (values.npi && values.npi.length < 10) {
        setNpiExist("")
        errors.npi = "Provider NPI must be 10 digit";
      }
      if (!values.firstName || values.firstName.trim() === "") {
        errors.firstName = "Please enter the Provider First Name";
      }
      if (!values.lastName || values.lastName.trim() === "") {
        errors.lastName = "Please enter the Provider Last Name";
      }
      if (!values.providerDea) setDeaExist("");
      if (deaExist) {
        errors.providerDea = deaExist;
      }
      if (!values.spi) setSpiExist("");
      if (spiExist) {
        errors.spi = spiExist;
      }
      if (npiExist) {
        errors.npi = npiExist;
      }
      return errors;
    }
  };

  const handleChangeSpi = _debounce(async (value) => {
    const resp = await dispatch(getProviderSPIExist(value));
    if (resp.statusCode == 200) setSpiExist(resp.successMessage);
    else setSpiExist("");
  }, 500);

  const handleChangeDea = _debounce(async (value) => {
    const resp = await dispatch(getProviderDEAExist(value));
    if (resp.statusCode == 200) setDeaExist(resp.successMessage);
    else setDeaExist("");
  }, 500);

  const handleChange = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    const { name, value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue(name, value);
  };

  return (
    <Formik
      enableReinitialize={true}
      initialValues={formData}
      onSubmit={handleSubmit}
      validate={formValidate}
      innerRef={formRef}
    >
      {({ values, errors, touched, setFieldValue }) => (
        <Form>
          <Grid container spacing={2}>
            <Grid item md={12}>
              <BasicTypography variant="h4">Provider Overview</BasicTypography>
            </Grid>
            <Grid item md={12}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <FormLabel required={!view}>Provider NPI</FormLabel>
                  {view ? (
                    <div>{values.npi}</div>
                  ) : (
                    <Field
                      name="npi"
                      id="npi"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider NPI"
                      maxLength={10}
                      disabled={title === "Edit Provider"}
                      onChange={async (e) => {
                        const { value } = e.target;
                        const regEx = /^[0-9]*$/g;
                        if (value && !regEx.test(value)) return;
                        setFieldValue("npi", value.toString());
                        if (value.length === 10) {
                          const payload= {
                            npi:value,
                            ceid: editProvider && rowData
                            ? rowData.ceid
                            : messageUuid && messageUuid.ceid ||
                              (ceSelected && ceSelected.ceID),
                          }
                          const resp = await dispatch(
                            getProviderNpiExist(payload)
                          );
                          if(resp.statusCode===401){
                            setNpiExist(resp.successMessage)
                          }
                          if (resp.statusCode === 200 && resp.data.length > 0){
                            const response = await dispatch(checkProviderType(value));
                            if (response.statusCode == 404) {
                              setNpiExist(response.errorMessage);
                            } else if (response.statusCode !== 404) {
                              setNpiExist("")
                              const { 
                                isTerminated = "", 
                                lastModifiedDate = "",
                                providerNpi = "",
                                prescriberSpi = ""
                              } = resp.data[0];
                              setFormData({
                                ...resp.data[0],
                                ...(isTerminated === "Y" && {
                                  prescriberPanelTypeId: 0,
                                  lastModifiedDate: editProvider && rowData ? lastModifiedDate : "",
                                  startDate: "",
                                  endDate: "",
                                }),
                                ...{
                                  npi: providerNpi,
                                  spi: prescriberSpi,
                                },
                              });
                            }
                          }
                          else
                            setFormData({
                              ...getAddProviderDefaultValues(),
                              npi: value,
                            });
                        }
                      }}
                    />
                  )}
                  {touched.npi && errors.npi && (
                    <Typography color="error" variant="caption">
                      {errors.npi}
                    </Typography>
                  )}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormLabel required={!view}>Provider First Name</FormLabel>
                  {view ? (
                    <div>{values.firstName}</div>
                  ) : (
                    <Field
                      name="firstName"
                      id="firstName"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider First Name"
                      maxLength={50}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                        setFieldValue("firstName", value);
                        handleChange(e, setFieldValue);
                      }}
                    />
                  )}
                  {touched.firstName && errors.firstName && (
                    <Typography color="error" variant="caption">
                      {errors.firstName}
                    </Typography>
                  )}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormLabel required={!view}>Provider Last Name</FormLabel>
                  {view ? (
                    <div>{values.lastName}</div>
                  ) : (
                    <Field
                      name="lastName"
                      id="lastName"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider Last Name"
                      maxLength={50}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                        setFieldValue("lastName", value);
                        handleChange(e, setFieldValue);
                      }}
                    />
                  )}
                  {touched.lastName && errors.lastName && (
                    <Typography color="error" variant="caption">
                      {errors.lastName}
                    </Typography>
                  )}
                </Grid>
              </Grid>
            </Grid>
            <Grid item md={12}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <FormLabel>Provider DEA</FormLabel>
                  {view ? (
                    <div>{values.providerDea ? values.providerDea : "_"}</div>
                  ) : (
                    <Field
                      name="providerDea"
                      id="providerDea"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider DEA"
                      maxLength={15}
                      onChange={(e) => {
                        const regEx = /^\s+|\s{2,}$/g;
                        const { value } = e.target;
                        if (value && regEx.test(value)) return;
                        setFieldValue("providerDea", value);
                        if(providerDea !== value) handleChangeDea(value);
                      }}
                    />
                  )}
                  {touched.providerDea && errors.providerDea && (
                    <Typography color="error" variant="caption">
                      {errors.providerDea}
                    </Typography>
                  )}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormLabel>Provider SPI</FormLabel>
                  {view ? (
                    <div>{values.spi ? values.spi : "_"}</div>
                  ) : (
                    <Field
                      name="spi"
                      id="spi"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider SPI"
                      maxLength={15}
                      onChange={(e) => {
                        const regEx = /^\s+|\s{2,}$/g;
                        const { value } = e.target;
                        if (value && regEx.test(value)) return;
                        setFieldValue("spi", value);
                        if(spi !== value) handleChangeSpi(value);
                      }}
                    />
                  )}
                  {touched.spi && errors.spi && (
                    <Typography color="error" variant="caption">
                      {errors.spi}
                    </Typography>
                  )}
                </Grid>
              </Grid>
            </Grid>
            <Grid item md={12}>
              <Grid container justifyContent="flex-end" spacing={2}>
                <Grid item>
                  <Button
                    type="submit"
                    color="primary"
                    size="small"
                    variant="contained"
                    className={globalClasses.primaryBtn}
                  >
                    Next
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    type="reset"
                    size="small"
                    variant="outlined"
                    color="default"
                    className={globalClasses.secondaryBtn}
                    onClick={() => {
                      setOpenPopup(false);
                    }}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );
};

export default AddProvideroverview;
