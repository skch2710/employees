import { makeStyles } from "@material-ui/core";

export const usePopupSidebarStyles = makeStyles((theme) => ({
  menuTitle: {
    display: "flex",
    alignItems: "center",
    gap: "5px",
    fontFamily: theme.fontFamily,
    color: theme.colors.blue[800],
  },
  mainMenuTitle: {
    fontSize: theme.widgetLeftNavigation.mainMenu.fontSize,
  },
  subMenuTitle: {
    fontSize: theme.widgetLeftNavigation.subMenu.fontSize,
  },
  expandCollapseIcons: {
    width: "16px",
    height: "16px",
  },
  subMenuListItem: {
    padding: "2px 2px 2px 40px",
  },
  mainMenuListItem: {
    padding: "4px 8px",
  },
  subList: {
    padding: 0,
  },
  partiallyCompleteIcon: {
    width: "10px",
    color: theme.colors.red.default,
  },
  sideBarIcon: {
    fill: theme.colors.blue[800],
    stroke: theme.colors.blue[800],
    width: "20px",
    height: "20px",
  },
}));
