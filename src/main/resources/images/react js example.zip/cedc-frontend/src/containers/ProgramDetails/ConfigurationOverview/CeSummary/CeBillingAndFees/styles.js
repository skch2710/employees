import { makeStyles } from "@material-ui/core";

export const useCeBillingAndFeesStyle = makeStyles((_theme) => {
  return {};
});
