import { makeStyles } from "@material-ui/core";

export const useCeEligibilityConfigStyle = makeStyles((_theme) => {
  return {};
});
