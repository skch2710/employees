import React, { useRef, useEffect, useState } from "react";
import { Paper, Tooltip } from "@material-ui/core";
import _isEqual from "lodash/isEqual";
import _isEmpty from "lodash/isEmpty";
import { DatePicker } from "antd";
import moment from "moment";

//Common
import MaterialTable, { MTableToolbar } from "material-table";
import { useStyles } from "../../../../mui-styles/commonTableMuiStyle";
import { pagination } from "../../../../utils/constants";
import {
  checkValue,
  getZeroValueInTotalElements,
  undefinedArrayContent,
} from "../../../../utils/common";
import {
  headerStyle,
  icons,
  mtStyle,
  tableCellGlobalJson,
} from "../../../../components/common/Table/usetableStyle";
import tableIcons from "../../../../components/common/TableIcons/MaterialTableIcons";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";

const Globalbin = ({
  setSortGBinBy,
  sortGBinorder,
  setSortGBinOrder,
  pageGBin,
  setPageGBin,
  rowsPerPageGBin,
  setRowsPerPageGBin,
  phGBinData,
  onChangeFilter,
  defaultFilters,
}) => {
  const classes = useStyles();
  const phData = _isEmpty(phGBinData) ? phGBinData : [];
  const filterValues = useRef({});
  const [filter, setFilter] = useState(false);
  useEffect(() => {
    if (!_isEqual(defaultFilters, filterValues.current)) {
      const updatedObj = {};
      defaultFilters.forEach((eachVal) => {
        updatedObj[eachVal.column.field] = eachVal.value;
      });
      filterValues.current = { ...updatedObj };
    }
  }, [defaultFilters]);

  const onChangeRowsPerPage = (pagesize) => {
    const { totalElements = 0 } = phData;
    const totalPages = Math.ceil(totalElements / pagesize);
    if (pageGBin > totalPages) setPageGBin(pagination.page);
    setRowsPerPageGBin(pagesize);
  };

  const onChangePagination = (data, pagesize) => {
    let currentpage = data + 1;
    if (pagesize === rowsPerPageGBin) setPageGBin(currentpage);
  };

  const onChangeSorting = (orderedColumnId) => {
    setSortGBinOrder(sortGBinorder === "asc" ? "desc" : "asc");
    setSortGBinBy(COLUMNS[orderedColumnId].field);
  };

  const setFilterValues = (filterVal) => {
    const updatedObj = {};
    filterVal.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    filterValues.current = { ...updatedObj };
    onChangeFilter(filterVal, "globalBin");
  };

  const COLUMNS = [
    {
      title: "BIN",
      field: "bin",
      cellStyle: tableCellGlobalJson,
      defaultFilter: filter && filterValues.current.bin,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.bin)}>
            <span>{checkValue(rowData.bin)}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "PCN",
      field: "pcn",
      cellStyle: tableCellGlobalJson,
      defaultFilter: filter && filterValues.current.pcn,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.pcn)}>
            <span>{checkValue(rowData.pcn)}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Group Number",
      field: "groupNumber",
      defaultFilter: filter && filterValues.current.groupNumber,
      cellStyle: tableCellGlobalJson,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.groupNumber)}>
            <span>{checkValue(rowData.groupNumber)}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "BIN Reason",
      field: "binReason",
      cellStyle: tableCellGlobalJson,
      defaultFilter: filter && filterValues.current.binReason,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.binReason)}>
            <span>{checkValue(rowData.binReason)}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Start Date",
      field: "startDate",
      defaultFilter: filter && filterValues.current.startDate,
      cellStyle: tableCellGlobalJson,
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={classes.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              filterValues.current.startDate
                ? moment(filterValues.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "End Date",
      field: "endDate",
      defaultFilter: filter && filterValues.current.endDate,
      cellStyle: tableCellGlobalJson,
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={classes.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              filterValues.current.endDate
                ? moment(filterValues.current.endDate)
                : ""
            }
          />
        );
      },
    },
  ];
  const Actions = [
    {
      icon: tableIcons.Filter,
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      disabled: _isEmpty(phData) || phData.totalElements < 1,
      isFreeAction: true,
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
  ];

  return (
    <div className={classes.root}>
      <div className="card card-first-level">
        <MaterialTable
          title={<BasicTypography variant="h6" title="Data Preview" />}
          columns={COLUMNS}
          data={phData !== null ? undefinedArrayContent(phData) : []}
          page={pageGBin - 1}
          totalCount={phData !== null ? phData.totalElements : 0}
          onChangePage={onChangePagination}
          onOrderChange={onChangeSorting}
          onChangeRowsPerPage={onChangeRowsPerPage}
          onFilterChange={(val) => {
            setFilterValues(val);
          }}
          icons={icons}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Toolbar: (props) => (
              <div style={mtStyle}>
                <MTableToolbar {...props} />
              </div>
            ),
          }}
          actions={Actions}
          options={{
            debounceInterval: 500,
            search: false,
            searchFieldAlignment: "right",
            searchAutoFocus: true,
            searchFieldVariant: "standard",
            actionsColumnIndex: 0,
            filtering: filter,
            paginationType: "stepped",
            paging: "true",
            showFirstLastPageButtons: false,
            paginationPosition: "top",
            exportButton: false,
            exportAllData: false,
            exportFileName: "Locations List",
            headerStyle: headerStyle,
            tableLayout: "auto",
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: rowsPerPageGBin,
            draggable: false,
            pageSizeOptions: pagination.pageSizeOptions,
          }}
        />
      </div>
    </div>
  );
};

export default Globalbin;
