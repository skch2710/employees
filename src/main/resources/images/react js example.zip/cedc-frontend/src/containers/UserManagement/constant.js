export const XLS_COLUMN_NAMES = [
  "First Name",
  "Last Name",
  "Email ID",
  "Primary Phone Number",
  "Title",
  "Role Type",
  "Send Invoice Notifications",
  "Primary Contact",
];

export const ALLOWED_FILE_TYPES =
  "application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

export const GLOBAL_FILTERS_MAP = {
  fn: "firstName",
  ln: "lastName",
  un: "userName",
  em: "emailID",
  ut: "userType",
  st: "status",
};

export const SUPER_USER_ROLE_IDS = [1, 5];

export const ALLOWED_CREATING_USERS_MAP = {
  1: [1, 2, 3, 4, 5, 6, 7],
  2: [1, 2, 3, 4, 5, 6, 7],
  3: [3, 4, 5, 6, 7],
  4: [4, 5, 6, 7],
  5: [5, 6, 7],
  6: [5, 6, 7],
  7: [7],
};

export const BACKGROUND_COLOR_FOR_ROLE_NAMES = {
  1: "#00e096",
  2: "#FF2D55",
  3: "#0095FF",
  4: "#eaf1f8",
  5: "#00e096",
  6: "#0095FF",
  7: "#eaf1f8",
};
