import React, { useContext, useEffect } from "react";
import { Grid, IconButton, Paper } from "@material-ui/core";
// import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import { BsPencilSquare } from "react-icons/bs";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { getProvidersPayloadJson } from "./helper";
import { fetchProvidersTableData } from "../../../../../context/actions/ConfigOverview";
import { useCeSummaryStyle } from "../styles";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";

const CeProviders = (props = {}) => {
  const { selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const _globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const coPermissions =
    getUserPermissionOnModuleName("Configuration Overview") || {};
  const providersPermissions = getUserPermissionOnModuleName("Providers") || {};

  const { loading: _providersLoading, records: providersList = {} } =
    useSelector((state) => state.coProvidersList) || {};

  // const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      getCeProviders();
    }
  }, [selectedCeForOverview]);

  // useEffect(() => {
  //   setIsCollapsed(isAllCollapsed);
  // }, [isAllCollapsed]);

  // const toggleCollapse = useCallback(() => {
  //   setIsCollapsed((prev) => !prev);
  // }, []);

  const getCeProviders = async (payload = {}, callback) => {
    const tableData = await dispatch(
      fetchProvidersTableData(
        getProvidersPayloadJson({
          ...payload,
          ceId: selectedCeForOverview.ceid,
        })
      )
    );
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography
              variant="h3"
              title={`Providers - ${providersList.totalElements || 0} Active`}
            />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={
                  !userSession.isInternalUser ||
                  !coPermissions.readWriteFlag ||
                  !providersPermissions.readWriteFlag
                }
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(
                      MENUS.CE_PROVIDERS,
                      selectedCeForOverview.ceid
                    );
                  }}
                />
              </IconButton>
              {/* <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton> */}
            </div>
          </div>
        </Grid>
        {/* <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  Hi
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid> */}
      </Grid>
    </Paper>
  );
};

export default CeProviders;
