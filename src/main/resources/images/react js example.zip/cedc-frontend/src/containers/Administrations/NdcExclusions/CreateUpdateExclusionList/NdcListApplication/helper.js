import moment from "moment";
import _isArray from "lodash/isArray";
import { pagination } from "../../../../../utils/constants";
import {
  getCeIdsArray,
  getManufIdArray,
  getPhGroupIdArray,
  getPhIdArray,
  getWhIdArray,
} from "../../../../../utils/helper";

export const getClientSearchFormDefaultValues = () => {
  return {
    applyExclusionsAutomatically: false,
    ndcExcTypeId: "",
    ndcExcTypeDtlId: "",
    claimTypeId: [],
    listId: "",
  };
};

export const getClientRelationshipTable = (values = {}) => {
  return {
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "",
    sortBy: values.sortBy || "",
    filter: values.filter || [],
    export: values.export || false,
    ceid: getCeIdsArray(values.ceID) || [],
    phGroupId: getPhGroupIdArray(values.phGroupId) || [],
    phid: getPhIdArray(values.phID) || [],
    wholesalerId: getWhIdArray(values.wholesalerID) || [],
    manufacturerId: getManufIdArray(values.drugManufacturerID) || [],
    listId: values.listId || [],
    listHistoryId: values.listHistoryId || 0,
    listEffectiveStartDate: "",
    listEffectiveEndDate: "",
  };
};

export const getClientExclusionSearchPayload = (values = {}) => {
  return {
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "",
    sortBy: values.sortBy || "",
    filter: values.filter || [],
    export: values.export || true,
    ceid: getCeIdsArray(values.ceID) || [],
    phGroupId: getPhGroupIdArray(values.phGroupId) || [],
    phid: getPhIdArray(values.phID) || [],
    wholesalerId: getWhIdArray(values.wholesalerID) || [],
    manufacturerId: getManufIdArray(values.drugManufacturerID) || [],
    listId: values.listId || [],
    listEffectiveStartDate: "",
    listEffectiveEndDate: "",
    listHistoryId: values.listHistoryId || 0,
    isEdit: values.hasOwnProperty("isEdit") ? values.isEdit : true,
  };
};

export const getNdcClientExclusionSearchFiltersObject = (filters = []) => {
  const dateFields = [];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getClientRelationshipFiltersObject = (filters = []) => {
  const dateFields = [];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getListApplicationSaveLists = ({
  list = [],
  autoExclApplyId = 0,
} = {}) => {
  return (
    list.map((listItem = {}) => {
      return {
        ...listItem,
        id: 0,
        autoExclApplyId,
      };
    }) || []
  );
};

export const getClientsPayloadToSave = (
  draftList = [],
  ndcData = {},
  userSession = {}
) => {
  if (_isArray(draftList)) {
    return draftList.map(
      ({
        id,
        autoExclApplyId,
        clientId,
        ndcEffectiveStartDate,
        ndcEffectiveEndDate,
      } = {}) => ({
        id: id,
        listHistoryId: ndcData.listHistoryId,
        autoExclApplyId: autoExclApplyId,
        clientId: clientId,
        exclAppliedStartDate: ndcEffectiveStartDate,
        exclAppliedEndDate: ndcEffectiveEndDate,
        createdById: userSession.userId,
        modifiedById: userSession.userId,
      })
    );
  }
  return [];
};

export const getCoveredEntityInitialValues = ({ ceList, value }) => {
  const ceObj =
    ceList.find((item = {}) => Number(item.ceID) === Number(value)) || {};
  return {
    ceID: [ceObj],
  };
};

export const getPhGroupInitialValues = ({ value, pharmacyGroups }) => {
  const phGrObj =
    pharmacyGroups.find(
      (phGr = {}) => Number(phGr.phGroupId) === Number(value)
    ) || {};
  return {
    phGroupId: [phGrObj],
  };
};

export const getManufacturerInitialValues = ({ manufacturers, value }) => {
  return {
    drugManufacturerID:
      manufacturers.filter(
        (man = {}) => man.drugManufacturerId === Number(value)
      ) || [],
  };
};

export const getWholesalerInitialValues = ({ wholesalerList, value }) => {
  return {
    wholesalerID:
      wholesalerList.filter((wh = {}) => wh.wholesalerId === Number(value)) ||
      [],
  };
};

export const getExclusionTypeValueDropdownOption = ({
  type = "",
  array = [],
} = {}) => {
  switch (type) {
    case "wholesaler":
      return array.map((item = {}) => ({
        label: item.wholesalerName,
        value: item.wholesalerId,
      }));
    case "manufacturer":
      return array.map((item = {}) => ({
        label: item.drugManufacturerName,
        value: item.drugManufacturerId,
      }));
    case "phGroup":
      return array.map((item = {}) => ({
        label: item.phGroupName,
        value: item.phGroupId,
      }));
    case "ce":
      return array.map((item = {}) => ({
        label: item.ceName,
        value: item.ceID,
      }));
    default:
      return [];
  }
};

export const getMinDate = (selectedRows = []) => {
  const startDatesArray =
    selectedRows.map((row = {}) => {
      if (row.startDate) {
        return moment(row.startDate);
      }
      return moment();
    }) || [];
  return moment.max(startDatesArray).format("MM/DD/YYYY");
};
