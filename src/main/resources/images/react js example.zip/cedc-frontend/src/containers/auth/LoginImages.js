import React from "react";
import  Logobig  from "../../assets/logo-big.png";
import LoginTheam from "../../assets/login-theam.png";

const LoginImages = () =>{
    return <div className="col-12 col-lg-7 col-md-7 col-sm-12 col-xs-12">
    <div className="login-left-wrapper">
        <img src={Logobig} alt="340B Direct"/>
        <img className="img-hid" src={LoginTheam} alt="340B Direct"/>
    </div>
</div>
}

export default LoginImages;