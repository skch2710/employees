import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import { checkValue } from "../../utils/common";
import { LABELS } from "../../utils/constants";
import ColumnLevelFilterInput from "../../components/common/ColumnLevelFilterInput";
import { ViewFullReportUnrep } from "../../context/actions/Home";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../components/common/TableCustomSortArrow";
import DataNotFound from "../../components/common/DataNotFound";
import { getTableHeaderStyles } from "../../mui-styles/commonTableMuiStyle";
import { pagination } from "../../utils/constants";
import useFileExportUnrepInv from "./useFileExportUnrepInv";
import { getUnrepInvFiltersObj } from "./helper";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import { isEmptyGrid } from "../../utils/helper";
import {
  getTableCellStyles,
  getTableNumericHeaderStyles,
  useGlobalStyles,
} from "../../Styles/useGlobalStyles";
import TableProgressBar from "../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../components/common/TableIcons";
import Pagination from "../../components/common/Pagination";

const ViewFullreportdonut2 = ({
  ceid,
  phid,
  phGroupId,
  processedStartDate,
  processedEndDate,
} = {}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExportUnrepInv();
  const iconsAndButtons = useTableIconsAndButtons();

  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "phid",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});

  const { records: UnrepInvList = {}, loading } =
    useSelector((state) => state.getViewFullReportUnrep) || {};

  const fetchViewFullReport = (payload = {}) => {
    dispatch(
      ViewFullReportUnrep(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "phid",
          sortOrder: "asc",
          export: false,
          filter: [],
          ceid: ceid,
          phid: phid,
          phGroupId: phGroupId,
          processedStartDate: processedStartDate,
          processedEndDate: processedEndDate,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    fetchViewFullReport();
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages = Math.ceil(UnrepInvList.totalElements / rowsPerPage);
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchViewFullReport({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
        sortOrder: controller.sortOrder,
        sortBy: controller.sortBy,
      });
    },
    [columnFilters, controller, UnrepInvList]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = HOME_FUllREPORT_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchViewFullReport({
        pageNumber: controller.page,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getUnrepInvFiltersObj(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchViewFullReport({
      ...controller,
      filter: filterPayload,
    });
  };

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(UnrepInvList),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(UnrepInvList),
        onClick: () =>
          exportToExcel({
            ceid,
            phid,
            phGroupId,
            processedStartDate,
            processedEndDate,
            controller,
            columnFilters,
          }),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(UnrepInvList) && _isEmpty(columnFilters),
    },
  ];

  const HOME_FUllREPORT_COLUMNS = [
    {
      title: LABELS.CoveredEntity,
      field: "ceName",
      defaultFilter: enableFilters && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.ceName)}>
            <span>{checkValue(rowData.ceName)}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceName}
          placeholder="Covered Entity"
        />
      ),
    },
    {
      title: LABELS.PharmacyStore,
      field: "phName",
      defaultFilter: enableFilters && columnFiltersRef.current.phName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.phName)}>
            <span>{checkValue(rowData.phName)}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.phName}
          placeholder="Pharmacy Store"
        />
      ),
    },
    {
      title: "Unreplenished Inventory Cost",
      field: "unreplenishedInventoryCost",
      type: "numeric",
      maxWidth: 170,
      defaultFilter:
        enableFilters && columnFiltersRef.current.unreplenishedInventoryCost,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={checkValue(rowData.unreplenishedInventoryCost)}>
            <span className={globalClasses.tableNumericPadding}>
              {checkValue(rowData.unreplenishedInventoryCost)}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.unreplenishedInventoryCost}
          placeholder="Unreplenished Inventory Cost"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <div className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Unreplenished Inventory Cost by Pharmacy  (${
                  UnrepInvList.totalElements || 0
                })`}
              />
            }
            columns={HOME_FUllREPORT_COLUMNS}
            data={UnrepInvList.content}
            page={controller.page - 1}
            totalCount={UnrepInvList.totalElements}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={ACTIONS}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              showTitle: true,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(UnrepInvList)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </div>
      </Grid>
    </Grid>
  );
};

export default memo(ViewFullreportdonut2);
