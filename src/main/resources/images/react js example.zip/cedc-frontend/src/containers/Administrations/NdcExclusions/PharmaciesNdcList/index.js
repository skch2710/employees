import { Paper, Tooltip, useTheme } from "@material-ui/core";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, {
  forwardRef,
  useCallback,
  useContext,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../../components/common/DataNotFound";
import DatePicker from "../../../../components/common/DatePicker";
import Pagination from "../../../../components/common/Pagination";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { NdcListDelete } from "../../../../context/actions/NdcExclusions";
import { getUserPreveleges } from "../../../../utils/common";
import { pagination } from "../../../../utils/constants";
import {
  getTableHeaderCount,
  getUserSession,
  isEmptyGrid,
} from "../../../../utils/helper";
import { NdcContext } from "../NdcContext";
import ViewListHistory from "../ViewListHistory";
import { NDC_TABS } from "../constants";
import { getNdcListPayload, getPhNdcFiltersObject } from "../helpers";
import { useConfirmationPopupStyles } from "../styles";
import useFileExport from "./useFileExport";

const PharmaciesNdcList = forwardRef(
  ({ formRef, formSubmittedValues, fetchNdcDetails }, ref) => {
    const globalClasses = useGlobalStyles();
    const dispatch = useDispatch();
    const theme = useTheme();
    const { exportToExcel } = useFileExport();
    const iconsAndButtons = useTableIconsAndButtons();
    const userSession = getUserSession();
    const {
      handleConfigPopup,
      ndcData,
      setNdcData,
      setIsNewList,
      setNdcConfigPopupTitle,
      setActiveNdcConfigTab,
    } = useContext(NdcContext);
    const createExclusionListAccess = getUserPreveleges("NDC Exclusions");
    const tableRef = useRef(null);
    const columnFiltersRef = useRef({});
    const classes = useConfirmationPopupStyles({});
    const { loading, records: ndcGridTableData = {} } =
      useSelector((state) => state.getNdcExclusionList) || {};

    const [ndcExclusionRowData, setNdcExclusionRowData] = useState(false);
    const [listHistoryInfo, setListHistoryInfo] = useState(false);
    const [columnFilters, setColumnFilters] = useState([]);
    const [showConfirmationPopup, setShowConfirmationPopup] = useState(false);
    const [enableFilters, setEnableFilters] = useState(false);
    const [controllers, setControllers] = useState({
      page: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "asc",
      sortBy: "listName",
    });

    const setControllersOnResp = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          page: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    // On click of clear filter button this clearForm function will get executed to reset pagination, page size and fetch default list.
    useImperativeHandle(ref, () => ({
      clearForm(initialValues) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        setEnableFilters(false);
        fetchNdcDetails(initialValues, {}, (resp) =>
          setControllersOnResp(resp)
        );
      },
      submitForm(resp) {
        columnFiltersRef.current = {};
        setControllersOnResp(resp);
      },
    }));

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        const {
          page: controllerPage,
          pageSize: controllerPageSize,
          sortOrder,
          sortBy,
        } = controllers;
        const rowsPerPage = Number(pageSize);
        const totalPages =
          Math.ceil(ndcGridTableData.totalElements / rowsPerPage) || 1;
        if (controllerPage > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllerPageSize)
          currentPage = controllerPage;
        fetchNdcDetails(
          {
            ...formSubmittedValues,
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: sortOrder,
            sortBy: sortBy,
            filter: columnFilters,
          },
          {},
          (resp) => setControllersOnResp(resp)
        );
      },
      [
        columnFilters,
        formRef,
        controllers,
        formSubmittedValues,
        ndcGridTableData,
      ]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = NDC_PHARMACY_LIST_COLUMN[orderedColumnId].field;
        setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        fetchNdcDetails(
          {
            ...formSubmittedValues,
            pageNumber: controllers.page,
            pageSize: controllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
          },
          {},
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        );
      },
      [controllers, formRef, formSubmittedValues, columnFilters]
    );

    const handleColumnFilter = (filters) => {
      const { isSubmitting } = (formRef && formRef.current) || {};
      const filterPayload = getPhNdcFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      fetchNdcDetails(
        {
          ...controllers,
          filter: filterPayload,
          ...formSubmittedValues,
        },
        (resp) => setControllersOnResp(resp)
      );
    };

    const terminateNdc = () => {
      const data = {
        listId: ndcData.listId,
        inactiveFlag: ndcData.status === "Inactive" ? "N" : "Y",
      };
      dispatch(
        NdcListDelete(data, (res) => {
          if (res.statusCode === 200) {
            setShowConfirmationPopup(false);
            fetchNdcDetails(
              {},
              {
                ...getNdcListPayload(formSubmittedValues),
                filter: columnFilters,
              }
            );
          }
        })
      );
    };

    const ColumnFilterIcon = () => {
      return <TiFilter fontSize="small" />;
    };

    const NDC_PHARMACY_LIST_COLUMN = [
      {
        title: "Status",
        field: "status",
        defaultFilter: enableFilters && columnFiltersRef.current.status,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.status}>
              <span>{rowData.status}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={columnFiltersRef.current.status || ""}
          >
            <option value={""}>Select option</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        ),
      },
      {
        title: "List Name",
        field: "listName",
        defaultFilter: enableFilters && columnFiltersRef.current.listName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.listName}>
              <span>{rowData.listName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.listName}
            placeholder="List Name"
          />
        ),
      },
      {
        title: "Covered Entity",
        field: "coveredEntity",
        defaultFilter: enableFilters && columnFiltersRef.current.coveredEntity,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.coveredEntity}>
              <span>{rowData.coveredEntity}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.coveredEntity}
            placeholder="Covered Entity"
          />
        ),
      },
      {
        title: "Covered Entity HRSA ID",
        field: "hrsaId",
        defaultFilter: enableFilters && columnFiltersRef.current.hrsaId,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.hrsaId}>
              <span>{rowData.hrsaId}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.hrsaId}
            placeholder="Covered Entity HRSA ID"
          />
        ),
      },
      {
        title: "Pharmacy Chain",
        field: "pharmacyGroup",
        defaultFilter: enableFilters && columnFiltersRef.current.pharmacyGroup,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyGroup}>
              <span>{rowData.pharmacyGroup}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pharmacyGroup}
            placeholder="Pharmacy Chain"
          />
        ),
      },
      {
        title: "Pharmacy Store",
        field: "pharmacyStore",
        defaultFilter: enableFilters && columnFiltersRef.current.pharmacyStore,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyStore}>
              <span>{rowData.pharmacyStore}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pharmacyStore}
            placeholder="Pharmacy Store"
          />
        ),
      },
      {
        title: "List Applied Date",
        field: "listAppliedDate",
        defaultFilter:
          enableFilters && columnFiltersRef.current.listAppliedDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.listAppliedDate}>
              <span>{rowData.listAppliedDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.listAppliedDate
                  ? moment(columnFiltersRef.current.listAppliedDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "List Termination Date",
        field: "listTerminationDate",
        defaultFilter:
          enableFilters && columnFiltersRef.current.listTerminationDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.listTerminationDate}>
              <span>{rowData.listTerminationDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.listTerminationDate
                  ? moment(columnFiltersRef.current.listTerminationDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "Created By",
        field: "createdBy",
        defaultFilter: enableFilters && columnFiltersRef.current.createdBy,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.createdBy}>
              <span>{rowData.createdBy}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.createdBy}
            placeholder="Created By"
          />
        ),
      },
      {
        title: "Last Updated By",
        field: "lastUpdatedBy",
        defaultFilter: enableFilters && columnFiltersRef.current.lastUpdatedBy,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.lastUpdatedBy}>
              <span>{rowData.lastUpdatedBy}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.lastUpdatedBy}
            placeholder="Last Updated By"
          />
        ),
      },
      {
        title: "Last Updated Date",
        field: "lastUpdatedDate",
        defaultFilter:
          enableFilters && columnFiltersRef.current.lastUpdatedDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.lastUpdatedDate}>
              <span>{rowData.lastUpdatedDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.lastUpdatedDate
                  ? moment(columnFiltersRef.current.lastUpdatedDate)
                  : ""
              }
            />
          );
        },
      },
    ];

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        isFreeAction: true,
        disabled: isEmptyGrid(ndcGridTableData),
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportButton({
          disabled: isEmptyGrid(ndcGridTableData),
        }),
        isFreeAction: true,
        disabled: isEmptyGrid(ndcGridTableData),
        onClick: () =>
          exportToExcel({
            formSubmittedValues,
            formRef,
            controllers,
            columnFilters,
          }),
      },
      {
        icon: iconsAndButtons.History(),
        tooltip: userSession.isInternalUser
          ? "View History"
          : "You don’t have permission.",
        disabled: !userSession.isInternalUser,
        isFreeAction: false,
        onClick: (_event, rowData) => {
          setNdcExclusionRowData(rowData);
          setListHistoryInfo(true);
        },
      },
      {
        icon: iconsAndButtons.Edit(),
        disabled: !createExclusionListAccess.readWriteFlag,
        tooltip: `${
          !createExclusionListAccess.readWriteFlag
            ? "You don’t have permission."
            : "Edit"
        }`,
        isFreeAction: false,
        onClick: (_e, rowData) => {
          setNdcConfigPopupTitle(rowData.listName);
          setIsNewList(false);
          setNdcData(rowData);
          setActiveNdcConfigTab(NDC_TABS.NDC_BASIC_DETAILS);
          handleConfigPopup({ state: true });
        },
      },
      (rowData) => {
        const isTerminated = rowData.status === "Inactive" ? true : false;
        return {
          icon: iconsAndButtons.Block({
            isBlocked: isTerminated,
          }),
          tooltip: `${
            createExclusionListAccess &&
            createExclusionListAccess != null &&
            !createExclusionListAccess.terminateFlag
              ? "You don’t have permission."
              : isTerminated
              ? "Terminated"
              : "Terminate"
          }`,
          disabled:
            !isTerminated &&
            createExclusionListAccess &&
            createExclusionListAccess != null &&
            createExclusionListAccess.terminateFlag
              ? false
              : true,
          isFreeAction: false,
          onClick: (_e, rowData) => {
            setShowConfirmationPopup(true);
            setNdcData(rowData);
          },
        };
      },
      {
        icon: iconsAndButtons.Copy(),
        disabled: !createExclusionListAccess.readWriteFlag,
        tooltip: `${
          !createExclusionListAccess.readWriteFlag
            ? "You don’t have permission."
            : "Copy"
        }`,
        isFreeAction: false,
        onClick: (_e, rowData) => {
          setNdcConfigPopupTitle(rowData.listName);
          setIsNewList(false);
          setNdcData({ ...rowData, isCopy: true });
          handleConfigPopup({ state: true });
        },
      },
      {
        icon: iconsAndButtons.AddCustomButton({
          title: "Create Exclusion List",
        }),
        tooltip: `${
          !createExclusionListAccess.readWriteFlag
            ? "You don’t have permission."
            : ""
        }`,
        isFreeAction: true,
        onClick: () => {
          setNdcConfigPopupTitle("Create NDC Exclusion List");
          setIsNewList(true);
          setNdcData({});
          handleConfigPopup({ state: true });
        },
        disabled: !createExclusionListAccess.readWriteFlag,
      },
    ];

    return (
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`NDC Exclusion Lists (${getTableHeaderCount(
                ndcGridTableData.totalElements
              )})`}
            />
          }
          columns={NDC_PHARMACY_LIST_COLUMN}
          data={(ndcGridTableData && ndcGridTableData.content) || []}
          page={controllers.page - 1}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          totalCount={ndcGridTableData.totalElements}
          onFilterChange={handleColumnFilter}
          tableRef={tableRef}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: ColumnFilterIcon,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            pageSize: controllers.pageSize,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            maxBodyHeight: 400,
            minBodyHeight: 100,
            pageSizeOptions: isEmptyGrid(ndcGridTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
        <BasicPopup
          title="NDC Exclusion List / List History"
          show={listHistoryInfo}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
          handleClose={() => setListHistoryInfo(false)}
        >
          <ViewListHistory rowData={ndcExclusionRowData} />
        </BasicPopup>
        {showConfirmationPopup && (
          <BasicPopup
            show={showConfirmationPopup}
            handleClose={() => setShowConfirmationPopup(false)}
            submitProps={{
              buttonTitle: "Yes",
              handleSubmit: () => terminateNdc(),
            }}
            cancelProps={{
              buttonTitle: "No",
              handleCancel: () => {
                setShowConfirmationPopup(false);
              },
            }}
            dialogProps={{
              maxWidth: "sm",
              classes: {
                paper: classes.confirmationPopup,
              },
            }}
          >
            <BasicTypography variant="h5">
              Are you sure you want to deactivate the selected NDC Exclusion
              List?
            </BasicTypography>
          </BasicPopup>
        )}
      </div>
    );
  }
);

export default PharmaciesNdcList;
