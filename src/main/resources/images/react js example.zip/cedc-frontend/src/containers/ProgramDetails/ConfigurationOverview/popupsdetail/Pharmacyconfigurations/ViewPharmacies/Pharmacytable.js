import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEqual from "lodash/isEqual";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, { useContext, useEffect, useRef, useState } from "react";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import {
  useGlobalStyles,
  getTableHeaderStyles,
  getTableCellStyles,
} from "../../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import DatePicker from "../../../../../../components/common/DatePicker";
import Pagination from "../../../../../../components/common/Pagination";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import {
  getZeroValueInTotalElements,
  undefinedArrayContent,
} from "../../../../../../utils/common";
import { LABELS, pagination } from "../../../../../../utils/constants";
import {
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import ViewPharmaciesExport from "./ViewPharmaciesExport";

const Pharmacytable = ({
  controllers,
  onChangePagination,
  onChangeRowsperpage,
  onChangeSorting,
  onChangeFilter,
  viewPhTableData,
  defaultFilters,
  ceId,
  phNetworkId,
  phStoreId,
  viewPhLoading,
  tableRef,
}) => {
  const theme = useTheme();
  const { exportViewPharmacies } = ViewPharmaciesExport();
  const iconsAndButtons = useTableIconsAndButtons();
  const globalClasses = useGlobalStyles();
  const {
    setCurrentPharmacy,
    setPopupActiveMenu,
    setIsNewPharmacy,
    fetchPhSectionStatuses,
  } = useContext(COContext) || {};

  const addPhPermissionObj = getUserPermissionOnModuleName("Pharmacies") || {};

  const [showFilter, setShowFilter] = useState(false);
  const filterValues = useRef({});

  let count = getZeroValueInTotalElements(viewPhTableData);

  useEffect(() => {
    if (!_isEqual(defaultFilters, filterValues.current)) {
      const updatedObj = {};
      defaultFilters.forEach((eachVal) => {
        updatedObj[eachVal.column.field] = eachVal.value;
      });
      filterValues.current = { ...updatedObj };
    }
  }, [defaultFilters]);

  const setFilterValues = (filterVal) => {
    const updatedObj = {};
    filterVal.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    filterValues.current = { ...updatedObj };
    onChangeFilter(filterVal);
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const PH_COLUMNS = [
    {
      title: "Configuration Status",
      field: "configStatus",
      defaultFilter: showFilter && filterValues.current.configStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.configStatus}>
            <span>{rowData.configStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.configStatus}
          placeholder="Configuration Status"
        />
      ),
    },
    {
      title: [LABELS.PharmacyStore],
      field: "pharmacyName",
      defaultFilter: showFilter && filterValues.current.pharmacyName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyName}>
            <a
              onClick={() => {
                setCurrentPharmacy(rowData);
                setPopupActiveMenu(MENUS.PH_BASIC_DETAILS);
                setIsNewPharmacy(false);
                fetchPhSectionStatuses({
                  ceId: rowData.ceid,
                  clientId: rowData.clientId,
                });
              }}
              className={globalClasses.clickableLink}
            >
              {rowData.pharmacyName}
            </a>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.pharmacyName}
          placeholder={[LABELS.PharmacyStore]}
        />
      ),
    },
    {
      title: [LABELS.PharmacyChain],
      field: "pharmacyNetwork",
      defaultFilter: showFilter && filterValues.current.pharmacyNetwork,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNetwork}>
            <span>{rowData.pharmacyNetwork}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.pharmacyNetwork}
          placeholder={[LABELS.PharmacyChain]}
        />
      ),
    },
    {
      title: "Pharmacy Go-Live Date",
      field: "goLiveDate",
      defaultFilter: showFilter && filterValues.current.goLiveDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.goLiveDate}>
            <span>{rowData.goLiveDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.goLiveDate
                ? moment(filterValues.current.goLiveDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "PSA Start Date",
      field: "startDate",
      defaultFilter: showFilter && filterValues.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.startDate
                ? moment(filterValues.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "PSA Termination Date",
      field: "endDate",
      defaultFilter: showFilter && filterValues.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.endDate
                ? moment(filterValues.current.endDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Third Party Brand $+%",
      field: "brandDispensingFeeThirdParty",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter && filterValues.current.brandDispensingFeeThirdParty,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.brandDispensingFeeThirdParty || ""}>
            <span>{rowData.brandDispensingFeeThirdParty || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.brandDispensingFeeThirdParty}
          placeholder="Third Party Brand $+%"
        />
      ),
    },
    {
      title: "Third Party Generic $+%",
      field: "genericDispensingFeeThirdParty",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter && filterValues.current.genericDispensingFeeThirdParty,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.genericDispensingFeeThirdParty || ""}>
            <span>{rowData.genericDispensingFeeThirdParty || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.genericDispensingFeeThirdParty}
          placeholder="Third Party Generic $+%"
        />
      ),
    },
    {
      title: "Third Party Specialty Brand $+%",
      field: "specialtyBrandDispensingFeeThirdParty",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter &&
        filterValues.current.specialtyBrandDispensingFeeThirdParty,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.specialtyBrandDispensingFeeThirdParty || ""}>
            <span>{rowData.specialtyBrandDispensingFeeThirdParty || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.specialtyBrandDispensingFeeThirdParty}
          placeholder="Third Party Specialty Brand $+%"
        />
      ),
    },
    {
      title: "Third Party Specialty Generic $+%",
      field: "specialtyGenericDispensingFeeThirdParty",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter &&
        filterValues.current.specialtyGenericDispensingFeeThirdParty,
      render: (rowData) => {
        return (
          <Tooltip
            title={rowData.specialtyGenericDispensingFeeThirdParty || ""}
          >
            <span>{rowData.specialtyGenericDispensingFeeThirdParty || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.specialtyGenericDispensingFeeThirdParty}
          placeholder="Third Party Specialty Generic $+%"
        />
      ),
    },
    {
      title: "Cash Flat Fee $+%",
      field: "cashFlatFeeBoth",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter: showFilter && filterValues.current.cashFlatFeeBoth,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.cashFlatFeeBoth || ""}>
            <span>{rowData.cashFlatFeeBoth || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.cashFlatFeeBoth}
          placeholder="Cash Flat Fee $+%"
        />
      ),
    },
    {
      title: "Cash Specialty Brand $+%",
      field: "specialtyBrandDispensingFeeCash",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter && filterValues.current.specialtyBrandDispensingFeeCash,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.specialtyBrandDispensingFeeCash || ""}>
            <span>{rowData.specialtyBrandDispensingFeeCash || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.specialtyBrandDispensingFeeCash}
          placeholder="Cash Specialty Brand $+%"
        />
      ),
    },
    {
      title: "Cash Specialty Generic $+%",
      field: "specialtyGenericDispensingFeeCash",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter && filterValues.current.specialtyGenericDispensingFeeCash,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.specialtyGenericDispensingFeeCash || ""}>
            <span>{rowData.specialtyGenericDispensingFeeCash || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.specialtyGenericDispensingFeeCash}
          placeholder="Cash Specialty Generic $+%"
        />
      ),
    },
    {
      title: "Cash Brand $+%",
      field: "brandDispensingFeeCash",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter: showFilter && filterValues.current.brandDispensingFeeCash,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.brandDispensingFeeCash || ""}>
            <span>{rowData.brandDispensingFeeCash || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.brandDispensingFeeCash}
          placeholder="Cash Brand $+%"
        />
      ),
    },
    {
      title: "Cash Generic $+%",
      field: "genericDispensingFeeCash",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        showFilter && filterValues.current.genericDispensingFeeCash,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.genericDispensingFeeCash || ""}>
            <span>{rowData.genericDispensingFeeCash || ""}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.genericDispensingFeeCash}
          placeholder="Cash Generic $+%"
        />
      ),
    },
    {
      title: "Program Type",
      field: "programType",
      defaultFilter: showFilter && filterValues.current.programType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.programType}>
            <span>{rowData.programType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.programType}
          placeholder="Program Type"
        />
      ),
    },
    {
      title: "Billing Model",
      field: "billingModel",
      defaultFilter: showFilter && filterValues.current.billingModel,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.billingModel}>
            <span>{rowData.billingModel}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.billingModel}
          placeholder="Billing Model"
        />
      ),
    },
    {
      title: "Wholesaler",
      field: "wholesaler",
      defaultFilter: showFilter && filterValues.current.wholesaler,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.wholesaler}>
            <span>{rowData.wholesaler}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.wholesaler}
          placeholder="Wholesaler"
        />
      ),
    },
    {
      title: "Participating in Cash Program",
      field: "participatingInCashProgram",
      defaultFilter:
        showFilter && filterValues.current.participatingInCashProgram,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.participatingInCashProgram}>
            <span>{rowData.participatingInCashProgram}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.participatingInCashProgram}
          placeholder="Participating in Cash Program"
        />
      ),
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${showFilter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      onClick: () => {
        setShowFilter((prev) => !prev);
      },
      disabled: count < 1,
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: count < 1,
      }),
      isFreeAction: true,
      disabled: count < 1,
      onClick: () => {
        exportViewPharmacies({
          ceId: ceId,
          sortBy: controllers.sortBy,
          sortOrder: controllers.sortOrder,
          phNetworkId: phNetworkId,
          phStoreId: phStoreId,
          defaultFilters: defaultFilters,
        });
      },
    },
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add Pharmacy" }),
      tooltip: !addPhPermissionObj.readWriteFlag
        ? "You don't have Permission."
        : "",
      isFreeAction: true,
      disabled: !addPhPermissionObj.readWriteFlag ? true : false,
      onClick: () => {
        setCurrentPharmacy({});
        setPopupActiveMenu(MENUS.PH_BASIC_DETAILS);
      },
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h4"
            title={`Pharmacies Data (${getTableHeaderCount(count)})`}
          />
        }
        tableRef={tableRef}
        columns={PH_COLUMNS}
        data={undefinedArrayContent(viewPhTableData)}
        page={controllers.page - 1}
        totalCount={viewPhTableData.totalElements}
        onChangePage={onChangePagination}
        onOrderChange={onChangeSorting}
        onChangeRowsPerPage={onChangeRowsperpage}
        onFilterChange={(val) => {
          setFilterValues(val);
        }}
        actions={Actions}
        icons={{
          SortArrow: () => TableCustomSortArrow(controllers),
          Filter: ColumnFilterIcon,
        }}
        localization={{
          body: {
            emptyDataSourceMessage: !viewPhLoading ? <DataNotFound /> : "",
          },
        }}
        isLoading={viewPhLoading}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          OverlayLoading: () => <TableProgressBar />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
        }}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: showFilter,
          paginationType: "stepped",
          paging: "true",
          maxBodyHeight: 400,
          minBodyHeight: 80,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controllers.pageSize,
          draggable: false,
          pageSizeOptions: isEmptyGrid(viewPhTableData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default Pharmacytable;
