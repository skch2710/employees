export const eligibilityRulesDefaultValues = () => ({
  Location: false,
  Encounter: false,
  Provider: false,
  Patient: false,
});

export const getDeepCopy = (data = []) => {
  return JSON.parse(JSON.stringify(data));
};
