import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Collapse,
  Divider,
  FormLabel,
  Grid,
  IconButton,
  Paper,
} from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { BsPencilSquare } from "react-icons/bs";
import { COContext } from "../../COContext";
import { MENUS } from "../../ConfigurationOverview/PopupSidebar/constants";
import { usePhEligibilityAndOrderingStyle } from "./styles";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getReverseYesNoValueOfToggle, getYesNoValueOfToggle } from "../helper";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../utils/helper";
import {
  fetchPhEligibilityDetails,
  phGroupOrderingAndReplenishDetails,
} from "../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import { ORDERING_CONFIG_MODULE } from "../../../../utils/constants";
import _get from "lodash/get";
import WholesalersGrid from "../../ConfigurationOverview/popupsdetail/EntityDetails/CeOrderingConfiguration/WholesalersGrid";

const EligibilityAndOrdering = memo((props = {}) => {
  const { selectedPharmacy, isAllCollapsed } = props;
  const { clientId, ceid } = selectedPharmacy || {};
  const { clickOnPencil, setCurrentPharmacy, setCoveredEntityName } =
    useContext(COContext) || {};
  const userSession = getUserSession();
  const isInternalUser = userSession.isInternalUser;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = usePhEligibilityAndOrderingStyle();
  const readWritePermission =
    getUserPermissionOnModuleName("Pharmacies").readWriteFlag;

  const [isCollapsed, setIsCollapsed] = useState(true);

  const { loading: _phEligibilityDetailsLoading, phEligibilityDetails } =
    useSelector((state) => state.phEligibilityDetails) || {};
  const { loading: _phOrderingDetailsLoading, phOrderingDetails } =
    useSelector((state) => state.phOrderingDetails) || {};

  useEffect(() => {
    if (clientId) {
      dispatch(fetchPhEligibilityDetails(clientId));
      dispatch(phGroupOrderingAndReplenishDetails(clientId));
    }
  }, [clientId]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  });

  return (
    <Paper className={classes.eligibilityAndOrderingWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={classes.titleWrapper}>
            <BasicTypography
              variant="h3"
              title="Eligibility and Ordering Details"
            />
            <div className={classes.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={!isInternalUser || !readWritePermission}
              >
                <BsPencilSquare
                  onClick={() => {
                    setCurrentPharmacy(selectedPharmacy);
                    setCoveredEntityName(selectedPharmacy.coveredEntity);
                    clickOnPencil(MENUS.PH_ELIGIBILITY, ceid);
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <Grid container spacing={3}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Pharmacy Eligibility Details"
                      />
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Program Type</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phEligibilityDetails.programType || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Claim Type to Process</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phEligibilityDetails.claimTypeToProcess || "--"}
                          </BasicTypography>
                        </Grid>
                        {isInternalUser && (
                          <>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                Fallout claims for Applied Acquisition Cost = $0
                                if WAC, NADAC or SWP are not available
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.falloutClaimsForAppliedAcquisitionCost40IfWacNadacOr
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                Pharmacy supports Cash U&C claims
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.pharmacySupportCashUcClaims
                                )}
                              </BasicTypography>
                            </Grid>

                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                {`Exclude C2 Drugs Outside Of ${
                                  phEligibilityDetails.excludeC2drugsOutsideOfDaysForCashClaims ||
                                  0
                                } days for Cash Claims`}
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.excludeC2drugsOutsideOfDaysForCashClaimsRadioButton
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                {`Exclude C4 Drugs Outside Of ${
                                  phEligibilityDetails.excludeC4drugsOutsideOfDaysForThirdPartyClaims ||
                                  0
                                } days for Third Party Claims`}
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.excludeC4drugsOutsideOfDaysForThirdPartyClaimsRadio
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                {`Exclude C2 Drugs Outside Of ${
                                  phEligibilityDetails.excludeC2drugsOutsideOfDaysForThirdPartyClaims ||
                                  0
                                } days for Third Party Claims`}
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.excludeC2drugsOutsideOfDaysForThirdPartyClaimsRadio
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                {`Exclude C5 Drugs Outside Of ${
                                  phEligibilityDetails.excludeC5drugsOutsideOfDaysForThirdPartyClaims ||
                                  0
                                } days for Third Party Claims`}
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.excludeC5drugsOutsideOfDaysForThirdPartyClaimsRadio
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                {`Exclude C3 Drugs Outside Of ${
                                  phEligibilityDetails.excludeC3drugsOutsideOfDaysForThirdPartyClaims ||
                                  0
                                } days for Third Party Claims`}
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.excludeC3drugsOutsideOfDaysForThirdPartyClaimsRadio
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>
                                {`Exclude Non-Preferred Generics Outside Of ${
                                  phEligibilityDetails.excludeNonPreferredGenericsOutsideOfDays ||
                                  0
                                } days`}
                              </FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.excludeNonPreferredGenericsOutsideOfDaysRadio
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} md={4}>
                              <FormLabel>Is Encrypted</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {getYesNoValueOfToggle(
                                  phEligibilityDetails.isEncrypted
                                )}
                              </BasicTypography>
                            </Grid>
                          </>
                        )}
                        <Grid item xs={12} md={4}>
                          <FormLabel>Exclude Orphan Drugs</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getYesNoValueOfToggle(
                              phEligibilityDetails.excludeOrphanDrugs
                            )}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Claim Reprocess</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getYesNoValueOfToggle(
                              phEligibilityDetails.claimReprocess
                            )}
                          </BasicTypography>
                        </Grid>
                        {isInternalUser && (
                          <Grid item xs={12} md={4}>
                            <FormLabel>
                              {`Reversal Constraint ${
                                phEligibilityDetails.reversalConstraint || 0
                              } days`}
                            </FormLabel>
                            <BasicTypography variant="subtitle2">
                              {phEligibilityDetails.reversalConstraint === 0
                                ? "No"
                                : "Yes"}
                            </BasicTypography>
                          </Grid>
                        )}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                {isInternalUser && (
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        <BasicTypography
                          variant="h5"
                          title="Claim Exclusions Based on Fees"
                        />
                      </Grid>
                      <Grid item md={12}>
                        <Grid container spacing={2}>
                          <Grid item xs={12} md={4}>
                            <FormLabel>Cash Claim Lesser of Logic</FormLabel>
                            <BasicTypography variant="subtitle2">
                              {getYesNoValueOfToggle(
                                phEligibilityDetails.cashClaimLesserOfLogic
                              )}
                            </BasicTypography>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <FormLabel>
                              Turn on Minimum Spread/Admin Fee Rule
                            </FormLabel>
                            <BasicTypography variant="subtitle2">
                              {getYesNoValueOfToggle(
                                phEligibilityDetails.turnOnMinSpreadAdminFeeRule
                              )}
                            </BasicTypography>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <FormLabel>Brand Min Spread</FormLabel>
                            <BasicTypography variant="subtitle2">
                              ${phEligibilityDetails.brandMinSpread}
                            </BasicTypography>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <FormLabel>Brand Min Admin Fee</FormLabel>
                            <BasicTypography variant="subtitle2">
                              ${phEligibilityDetails.brandMinAdminFee || 0}
                            </BasicTypography>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <FormLabel>Generic Min Spread</FormLabel>
                            <BasicTypography variant="subtitle2">
                              ${phEligibilityDetails.genericMinSpread || 0}
                            </BasicTypography>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <FormLabel>Generic Min Admin Fee</FormLabel>
                            <BasicTypography variant="subtitle2">
                              ${phEligibilityDetails.genericMinAdminFee || 0}
                            </BasicTypography>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                )}
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Pharmacy Chain Order and Replenish"
                      />
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Billing Model</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phOrderingDetails.billingMode || "--"}
                          </BasicTypography>
                        </Grid>
                        {isInternalUser && (
                          <Grid item xs={12} md={4}>
                            <FormLabel>Inventory Swell</FormLabel>
                            <BasicTypography variant="subtitle2">
                              {phOrderingDetails.inventorySwellProgram || "--"}
                            </BasicTypography>
                          </Grid>
                        )}
                        {isInternalUser && (
                          <Grid item xs={12} md={4}>
                            <FormLabel>
                              Support Multiple Wholesaler For Covered Entity
                              Network
                            </FormLabel>
                            <BasicTypography variant="subtitle2">
                              {getYesNoValueOfToggle(
                                phOrderingDetails.supportMultipleWholesalerForCeNetwork
                              )}
                            </BasicTypography>
                          </Grid>
                        )}
                        <Grid item xs={12} md={4}>
                          <FormLabel>Send Order Notifications</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getYesNoValueOfToggle(
                              phOrderingDetails.sendOrderNotifications
                            )}
                          </BasicTypography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Client Order and Replenish"
                      />
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Ordering Pharmacy</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getYesNoValueOfToggle(
                              phOrderingDetails.orderingPharmacy
                            )}
                          </BasicTypography>
                        </Grid>
                        {isInternalUser && (
                          <Grid item xs={12} md={4}>
                            <FormLabel>
                              Generate C2 Orders Out of Swell
                            </FormLabel>
                            <BasicTypography variant="subtitle2">
                              {getYesNoValueOfToggle(
                                phOrderingDetails.generateC2OrdersOutOfSwell
                              )}
                            </BasicTypography>
                          </Grid>
                        )}
                        <Grid item xs={12} md={4}>
                          <FormLabel>
                            Participate in Central Replenishment
                          </FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getYesNoValueOfToggle(
                              phOrderingDetails.participateInCentralReplenishment
                            )}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Replenish Threshold Percent</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phOrderingDetails.replenishThresholdPercent}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Turn Off True-Up</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getReverseYesNoValueOfToggle(
                              phOrderingDetails.turnOffTrueUp
                            )}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <FormLabel>
                            Turn Off Covered Entity Owned Inventory
                          </FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getReverseYesNoValueOfToggle(
                              phOrderingDetails.turnOffCeOwnedInventory
                            )}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <FormLabel>Process Unsolicited 855 and 810</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {getYesNoValueOfToggle(
                              phOrderingDetails.processUnsolicited855and810
                            )}
                          </BasicTypography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <WholesalersGrid
                    module={ORDERING_CONFIG_MODULE.PH}
                    wholesalers={_get(phOrderingDetails, "wholesalers", [])}
                  />
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
});

export default EligibilityAndOrdering;
