import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../utils/helper";

export const useClaimsStyles = makeStyles((theme) => {
  return {
    additionalFiltersLink: {
      color: theme.colors.primary.default,
      cursor: "pointer",
    },
    claimsTableFooterActionsContainer: {
      padding: "8px 6px",
    },
    rxInfo: {
      fontWeight: 700,
    },
    title: {
      color: "#43425D",
    },
    subtitle: {
      color: "#071B72F8",
    },
    btnStyle: {
      marginTop: "10px",
      marginLeft: "-8px",
    },
    emailErrorMsg: {
      color: "red",
      fontSize: "12px",
    },
    selectedCheckBox: {
      color: "#1BADBB",
    },
    achAccounts: {
      maxHeight: "250px",
      overflowY: "scroll",
      padding: "15px",
      margin: "15px",
      border: "1px solid #e7e7e7",
      backgroundColor: "#fcfcfc",
    },
    customTextField: () => ({
      "& input::placeholder": {
        fontSize: "small",
        color: theme.colors.monochrome.placeholder,
        opacity: 1,
      },
    }),
    cardCustomStyles: {
      padding: "20px",
    },
    auditHistoryTitle: {
      color: theme.colors.blue[200],
    },
    auditedByName: {
      fontSize: "13px",
      color: theme.colors.blue.default,
    },
    timeline: {
      transform: "rotate(90deg)",
    },
    timelineContentContainer: {
      textAlign: "left",
    },
    timelineContent: {
      display: "inline-block",
      transform: "rotate(-90deg)",
      textAlign: "center",
      minWidth: 50,
    },
    timelineIcon: {
      transform: "rotate(-90deg)",
    },
    multiSelectArrow: {
      "& .MuiIconButton-root": {
        display: "none",
      },
    },
    dateOfServiceTo: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "30px",
    },
    rxPopupPaper: {
      minHeight: "85vh",
    },
    statusTag: {
      backgroundColor: theme.colors.green.bg,
      padding: "2px 4px",
      fontSize: "12px",
      border: `1px solid ${theme.colors.green.default}`,
      borderRadius: "4px",
    },
  };
});

export const useTimelineStyles = makeStyles((theme) => {
  return {
    timelineContainer: {
      width: "100%",
      height: "104px",
      "& .events": {
        height: "3px !important",
        top: "36px !important",
        "& li > span": {
          background: theme.colors.blue[600],
          height: "20px !important",
          width: "20px !important",
          bottom: "-8px !important",
          border: `4px solid ${theme.colors.monochrome.offWhite} !important`,
        },
      },
      "& .buttons > li": {
        top: "36px !important",
      },
    },
    labelContainer: {
      position: "relative",
      "& p": {
        fontWeight: 700,
        margin: 0,
      },
    },
    bottomLabelContainer: {
      width: "100%",
      position: "absolute",
      top: "50px",
      left: "50%",
      transform: "translateX(-50%)",
      border: `1px solid ${theme.colors.secondary.default}`,
      padding: "4px",
      borderRadius: "4px",
      fontSize: theme.typography.placeholder.fontSize,
      color: theme.colors.monochrome.placeholder,
    },
  };
});
