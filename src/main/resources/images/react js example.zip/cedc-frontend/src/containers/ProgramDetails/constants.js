export const ALL_OPTION = { ceName: "All", ceID: -1 };
