import { Paper, Tooltip } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import _isEmpty from "lodash/isEmpty";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, { useCallback, useEffect, useRef, useState } from "react";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableCellStyles,
  useGlobalStyles,
} from "../../../../Styles/useGlobalStyles";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../../components/common/DataNotFound";
import DatePicker from "../../../../components/common/DatePicker";
import Pagination from "../../../../components/common/Pagination";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import {
  deleteLocation,
  getLocationVariationData,
} from "../../../../context/actions/Locations";
import { getTableHeaderStyles } from "../../../../mui-styles/commonTableMuiStyle";
import { pagination } from "../../../../utils/constants";
import {
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  getUserSession,
  isEmptyGrid,
} from "../../../../utils/helper";
import ExportLocations from "../ExportLocations";
import ParticipatePopup from "../ParticipatePopup";
import AddVariationPopup from "./AddVariationPopup";
import { SET_LOCATIONS_VARIATIONS_LIST } from "../../../../context/reducers/Locations/constants";

const AddressVariations = ({ locationData }) => {
  const dispatch = useDispatch();
  const theme = useTheme();
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();

  const [editData, setEditData] = useState({});
  const [columnFilters, setColumnFilters] = useState([]);
  const [enableFilters, setEnableFilters] = useState(false);
  const [openPopup, setOpenPopup] = useState(false);
  const [actionTitle, setActionTitle] = useState("Add New Variation");
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "locationName",
  });
  const [isTerminatePopup, setIsTerminatePopup] = useState(false);
  const columnFiltersRef = useRef({});
  const tableRef = useRef({});
  const { exportToExcel } = ExportLocations();
  const iconsAndButtons = useTableIconsAndButtons();

  const { records: locationsTableData, loading } =
    useSelector((state) => state.getLocationVariationListData) || {};

  const permissionObj =
    getUserPermissionOnModuleName("Covered Entity Locations") || {};

  useEffect(() => {
    getSearchTableData(controllers);
    return () => dispatch({ type: SET_LOCATIONS_VARIATIONS_LIST, data: {} });
  }, []);

  const getSearchTableData = async (payload = {}, callback) => {
    const payloadJson = {
      ceid: locationData && [locationData.ceid],
      parentId: locationData.entityLocationId || 0,
      entityLocationId: [],
      endDate: "",
      startDate: "",
      site340B: "",
      locationStatus: "Participating",
      locationHrsaId: "",
      city: "",
      stateId: "",
      ...controllers,
      ...payload,
      filter: payload.filter || columnFilters || [],
    };

    const tableData = await dispatch(getLocationVariationData(payloadJson));
    if (!_isEmpty(tableData)) callback && callback(tableData);
  };

  useEffect(() => {
    if (!_isEmpty(editData) && !openPopup) setEditData({});
  }, [openPopup]);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(locationsTableData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      getSearchTableData(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controllers.sortOrder,
          sortBy: controllers.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, locationsTableData, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = COVERED_ENTITY_LOCATIONS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      getSearchTableData(
        {
          pageNumber: controllers.pageNumber,
          pageSize: controllers.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controllers, columnFilters, locationsTableData]
  );
  const getFiltersObject = (filters = []) => {
    return filters.map((filter) => {
      return {
        column: {
          field: filter.column.field,
        },
        operator: "startWith",
        value: filter.value,
      };
    });
  };
  const handleColumnFilter = (filters = []) => {
    const filterPayload = getFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    getSearchTableData(
      {
        ...controllers,
        filter: filterPayload,
        pageNumber: pagination.page,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const COVERED_ENTITY_LOCATIONS = [
    {
      title: "Source",
      field: "source",
      defaultFilter: enableFilters && columnFiltersRef.current.source,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.source}>
            <span>{rowData.source}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.source}
          placeholder="Source"
        />
      ),
    },

    {
      title: " Participating 340B Site",
      field: "site340b",
      defaultFilter: enableFilters && columnFiltersRef.current.site340b,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip
            title={
              rowData.site340b
                ? rowData.site340b === "true"
                  ? "Yes"
                  : "No"
                : ""
            }
          >
            <span>
              {rowData.site340b
                ? rowData.site340b === "true"
                  ? "Yes"
                  : "No"
                : ""}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={columnFiltersRef.current.site340b || ""}
          >
            <option value={""}>Select option</option>
            <option value="true">Yes</option>
            <option value="false">No</option>
          </select>
        );
      },
    },
    {
      title: "Covered Entity",
      field: "coveredEntity",
      defaultFilter: enableFilters && columnFiltersRef.current.coveredEntity,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity}>
            <span>{rowData.coveredEntity}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.coveredEntity}
          placeholder="Covered Entity"
        />
      ),
    },

    {
      title: "Location Name",
      field: "locationName",
      defaultFilter: enableFilters && columnFiltersRef.current.locationName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationName}>
            <span>{rowData.locationName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationName}
          placeholder="Location Name"
        />
      ),
    },
    {
      title: "Location HRSA ID",
      field: "locationHrsaId",
      defaultFilter: enableFilters && columnFiltersRef.current.locationHrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationHrsaId}>
            <span>{rowData.locationHrsaId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationHrsaId}
          placeholder="Location HRSA ID"
        />
      ),
    },
    {
      title: "Address Line 1",
      field: "addressLine1",
      defaultFilter: enableFilters && columnFiltersRef.current.addressLine1,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine1}>
            <span>{rowData.addressLine1}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addressLine1}
          placeholder="Address Line 1"
        />
      ),
    },
    {
      title: "Address Line 2",
      field: "addressLine2",
      defaultFilter: enableFilters && columnFiltersRef.current.addressLine2,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine2}>
            <span>{rowData.addressLine2}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addressLine2}
          placeholder="Address Line 2"
        />
      ),
    },
    {
      title: "City",
      field: "city",
      defaultFilter: enableFilters && columnFiltersRef.current.city,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.city}>
            <span>{rowData.city}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.city}
          placeholder="City"
        />
      ),
    },
    {
      title: "State",
      field: "state",
      defaultFilter: enableFilters && columnFiltersRef.current.state,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.state}>
            <span>{rowData.state}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.state}
          placeholder="State"
        />
      ),
    },
    {
      title: "Zip",
      field: "zip",
      defaultFilter: enableFilters && columnFiltersRef.current.zip,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.zip}>
            <span>{rowData.zip}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.zip}
          placeholder="Zip"
        />
      ),
    },
    {
      title: "OPA Location Start Date",
      field: "startDate",
      defaultFilter: enableFilters && columnFiltersRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.startDate
                ? moment(columnFiltersRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "OPA Location End Date",
      field: "endDate",
      defaultFilter: enableFilters && columnFiltersRef.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.endDate
                ? moment(columnFiltersRef.current.endDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Status",
      field: "locationStatus",
      defaultFilter: enableFilters && columnFiltersRef.current.locationStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationStatus}>
            <span>{rowData.locationStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationStatus}
          placeholder="Status"
        />
      ),
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(locationsTableData),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(locationsTableData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(locationsTableData),
      onClick: () =>
        exportToExcel({
          searchData: {
            ceid: locationData.ceid,
            parentId: locationData.entityLocationId,
            entityLocationId: 0,
            locationStatus: "Participating",
          },
          columnFilters,
          sortBy: controllers.sortBy,
          sortOrder: controllers.sortOrder,
        }),
    },
    {
      icon: iconsAndButtons.AddCustomButton({
        title: "Add Variation",
      }),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : !locationData.ceid
          ? "Please select a Covered Entity to enable this button"
          : "",
      isFreeAction: true,
      disabled: permissionObj !== null && !permissionObj.readWriteFlag,
      onClick: () => {
        setOpenPopup(true);
      },
    },
    
    (rowData) => {
      const isTerminated =
        rowData.locationStatus === "Terminated" ? true : false;

      return {
        icon: iconsAndButtons.Block({ isBlocked: isTerminated }),
        tooltip:
          permissionObj !== null && !permissionObj.terminateFlag
            ? "You don't have Permission."
            : isTerminated
            ? "Terminated"
            : "Terminate",
        isFreeAction: false,
        disabled:
          !isTerminated && permissionObj !== null && permissionObj.terminateFlag
            ? false
            : true,
        onClick: (_event, rowData) => {
          setEditData(rowData);
          setIsTerminatePopup(true);
        },
      };
    },
    
  ];

  const handleTerminatePopup = ({ state, endDate }) => {
    if (state) {
      const payload = {
        ceId: editData.ceid,
        entityLocationId: editData.entityLocationId,
        modifiedById: userSession.userId,
        endDate: endDate.opaLocEndDate,
      };
      dispatch(
        deleteLocation(payload, (res) => {
          if (res.statusCode === 200) {
            setIsTerminatePopup(false);
            getSearchTableData(controllers);
          }
        })
      );
    } else {
      setIsTerminatePopup(false);
    }
  };

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Address Variation (${getTableHeaderCount(
              locationsTableData.totalElements
            )})`}
          />
        }
        tableRef={tableRef}
        columns={COVERED_ENTITY_LOCATIONS}
        data={locationsTableData.content || []}
        page={controllers.pageNumber - 1}
        totalCount={locationsTableData.totalElements}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        actions={Actions}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        icons={{
          SortArrow: () => TableCustomSortArrow(controllers),
          Filter: ColumnFilterIcon,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paginationType: "stepped",
          paging: true,
          pageSize: controllers.pageSize,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          draggable: false,
          maxBodyHeight: 240,
          doubleHorizontalScroll: false,
          pageSizeOptions: isEmptyGrid(locationsTableData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
      {openPopup && (
        <BasicPopup
          title={actionTitle}
          show={openPopup}
          handleClose={() => {
            setOpenPopup(false);
          }}
          disableFooter={true}
          dialogProps={{
            maxWidth: "md",
          }}
        >
          <AddVariationPopup
            setOpenPopup={setOpenPopup}
            selectedLocation={locationData}
            title={actionTitle}
            searchData={{}}
            defaultFilters={columnFilters}
            pageNumber={controllers.pageNumber}
            pageSize={controllers.pageSize}
            sortBy={controllers.sortBy}
            sortOrder={controllers.sortBy}
            getSearchTableData={getSearchTableData}
          />
        </BasicPopup>
      )}
      {isTerminatePopup && (
        <BasicPopup
          show={isTerminatePopup}
          disableFooter={true}
          disableHeader={true}
          dialogProps={{
            maxWidth: "sm",
          }}
        >
          <ParticipatePopup
            handleParticipatePopup={handleTerminatePopup}
            isTerminatePopup={isTerminatePopup}
            popupMessage={"Do you want to terminate the selected record?"}
          />
        </BasicPopup>
      )}
    </div>
  );
};
export default AddressVariations;
