import { Checkbox, Grid, Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, { memo, useCallback, useContext, useRef, useState } from "react";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
  getTableActionCellStyles,
} from "../../../../../../Styles/useGlobalStyles";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import DatePicker from "../../../../../../components/common/DatePicker";
import Pagination from "../../../../../../components/common/Pagination";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import {
  editCeAdminFee,
  saveCeAdminFees,
} from "../../../../../../context/actions/ConfigOverview/EntityConfiguration/CeBillingAndFees";
import { LABELS, pagination } from "../../../../../../utils/constants";
import { getUserSession, isEmptyGrid } from "../../../../../../utils/helper";
import { COContext } from "../../../../COContext";
import AddAdminFees from "./AddAdminFees";
import AdminFeePopupFooter from "./AdminFeePopupFooter";
import {
  getAdminFeeDefaultFormValues,
  getAdminFeeSavePayload,
  getAdminFeesFiltersObject,
} from "./helpers";
import { useAdminFeesTableStyles } from "./styles";

const AdminFeesTable = memo((props = {}) => {
  const { getAdminFeeTableData, isConfigurable = false } = props;
  const { coveredEntityName, ceId } = useContext(COContext);
  const theme = useTheme();
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const userSession = getUserSession();
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [showAddFee, setShowAddFee] = useState(false);
  const [defaultFormValues, setDefaultFormValues] = useState(
    getAdminFeeDefaultFormValues()
  );

  const columnFiltersRef = useRef({});
  const getFeeTypesRef = useRef(null);
  const { loading, records: adminFeesTableData } =
    useSelector((state) => state.ceAdminBillingFeesList) || {};

  const classes = useAdminFeesTableStyles({
    totalElements:
      !_isEmpty(adminFeesTableData) && adminFeesTableData.totalElements,
    pageSize: controllers.pageSize,
    pageNumber: controllers.pageNumber,
  });

  const handleSubmit = async (values, { resetForm, setFieldError }) => {
    const payload = getAdminFeeSavePayload({
      ...values,
      ceId,
      createdById: userSession.userId,
      modifiedById: userSession.userId,
    });
    if (values.isEdit) {
      if (
        Number(values.applicableFor) === 2 &&
        _isEmpty(values.selectedClients)
      ) {
        setFieldError("selectedClients", "Please select at least one client.");
        return;
      }
      const resp = await dispatch(editCeAdminFee(payload));
      if (resp) getAdminFeeTableData({ filter: columnFilters });
      resp && setShowAddFee(false);
    } else {
      const resp = await dispatch(saveCeAdminFees(payload));
      if (resp) getAdminFeeTableData({ filter: columnFilters });
      if (resp && values.isExit) setShowAddFee(false);
      else if (resp) {
        resetForm();
        getFeeTypesRef.current && getFeeTypesRef.current.fetchFeeTypes();
      }
    }
  };

  const ADMIN_FEES = [
    {
      title: LABELS.CoveredEntity,
      field: "ceName",
      defaultFilter: enableFilters && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceName}>
            <span>{rowData.ceName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceName}
          placeholder={LABELS.CoveredEntity}
        />
      ),
    },
    {
      title: "Fee Type",
      field: "feeType",
      defaultFilter: enableFilters && columnFiltersRef.current.feeType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeType}>
            <span>{rowData.feeType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.feeType}
          placeholder="Fee Type"
        />
      ),
    },
    {
      title: "Fee Value",
      field: "flatFee",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.flatFee,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.flatFee || ""}>
                <span>{rowData.flatFee || ""}</span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.flatFee}
          placeholder="Fee Value"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Percentage",
      field: "percentage",
      defaultFilter: enableFilters && columnFiltersRef.current.percentage,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        const displayValue = rowData.percentage ? `${rowData.percentage}%` : "";
        return (
          <Tooltip title={displayValue}>
            <span>{displayValue}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.percentage}
          placeholder="Percentage"
        />
      ),
    },
    {
      title: "Basis Of",
      field: "basisOf",
      defaultFilter: enableFilters && columnFiltersRef.current.basisOf,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.basisOf}>
            <span>{rowData.basisOf}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.basisOf}
          placeholder="Basis Of"
        />
      ),
    },
    {
      title: "Claim Type",
      field: "claimType",
      defaultFilter: enableFilters && columnFiltersRef.current.claimType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimType}>
            <span>{rowData.claimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimType}
          placeholder="Claim Type"
        />
      ),
    },
    {
      title: "Covered Entity Admin Fee Model",
      field: "addlClaimType",
      defaultFilter: enableFilters && columnFiltersRef.current.addlClaimType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addlClaimType}>
            <span>{rowData.addlClaimType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addlClaimType}
          placeholder="Covered Entity Admin Fee Model"
        />
      ),
    },
    {
      title: "Switch",
      field: "switchType",
      defaultFilter: enableFilters && columnFiltersRef.current.switchType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.switchType}>
            <span>{rowData.switchType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.switchType}
          placeholder="Switch"
        />
      ),
    },
    {
      title: "340BDirect+ Start Date",
      field: "feeStartDate",
      defaultFilter: enableFilters && columnFiltersRef.current.feeStartDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeStartDate}>
            <span>{rowData.feeStartDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.feeStartDate
                ? moment(columnFiltersRef.current.feeStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "340BDirect+ End Date",
      field: "feeEndDate",
      defaultFilter: enableFilters && columnFiltersRef.current.feeEndDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.feeEndDate}>
            <span>{rowData.feeEndDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.feeEndDate
                ? moment(columnFiltersRef.current.feeEndDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Fee Applied",
      field: "applied",
      filtering: false,
      sorting: false,
      render: (_rowData) => {
        return (
          <Checkbox
            name="appliedFeesStatus"
            color="default"
            checked
            classes={{
              root: classes.checkbox,
            }}
          />
        );
      },
    },
  ];

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      let rowsPerPage = Number(pageSize);
      const totalPages = Math.ceil(
        adminFeesTableData.totalElements / rowsPerPage
      );
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      getAdminFeeTableData(
        {
          ...controllers,
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          filter: columnFilters,
        },
        (resp) => {
          setControllers((prev) => ({
            ...prev,
            pageNumber: resp.pageNo || pagination.page,
            pageSize: resp.pageSize || pagination.limit,
          }));
        }
      );
    },
    [columnFilters, adminFeesTableData, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = ADMIN_FEES[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      getAdminFeeTableData({
        ...controllers,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controllers, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getAdminFeesFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    getAdminFeeTableData({
      ...controllers,
      filter: filterPayload,
    });
  };

  const handlePopupClose = () => {
    setShowAddFee(false);
    setDefaultFormValues(getAdminFeeDefaultFormValues());
  };

  const FILTER_BUTTON = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(adminFeesTableData),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  const ADDITIONAL_OPTIONS = [
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add Admin Fees" }),
      isFreeAction: true,
      onClick: () => {
        setShowAddFee(true);
      },
    },
    (row) => {
      return {
        icon: iconsAndButtons.Edit(),
        tooltip: "Edit",
        isFreeAction: false,
        disabled: moment(
          moment(row.feeStartDate).format("MM/DD/YYYY")
        ).isBefore(moment(), "day"),
        onClick: (_e, rowData) => {
          setDefaultFormValues(
            getAdminFeeDefaultFormValues({
              ...rowData,
              isEdit: true,
              ceAdminFeeNewId: rowData.id,
            })
          );
          setShowAddFee(true);
        },
      };
    },
  ];

  const handleValidate = async (values) => {
    const error = {};
    if (Number(values.feesType) === 0) {
      error.feesType = "Please select the Fee Type";
    }
    if (!values.startDate) {
      error.startDate = "Please select the 340BDirect+ Fee Start Date";
    }
    if (
      (Number(values.feesType) === 3 ||
        Number(values.feesType) === 5 ||
        Number(values.feesType) === 6) &&
      !values.adminFee
    ) {
      error.adminFee = "Please enter the Flat Fee";
    }
    if (
      (Number(values.feesType) === 3 || Number(values.feesType) === 5) &&
      (!values.claimType || Number(values.claimType) === 0)
    ) {
      error.claimType = "Please select the Claim Type";
    }
    if (
      (Number(values.feesType) === 3 || Number(values.feesType) === 5) &&
      (!values.addClaimType || Number(values.addClaimType) === 0)
    ) {
      error.addClaimType = "Please select the Covered Entity Admin Fee Model";
    }
    if (
      (Number(values.feesType) === 4 ||
        Number(values.feesType) === 5 ||
        Number(values.feesType) === 9) &&
      !values.adminFeePercentage
    ) {
      error.adminFeePercentage = "Please enter Percentage Only";
    }
    if (values.isEdit && !values.applicableFor) {
      error.applicableFor = "Please select the at least one option";
    }
    return error;
  };

  return (
    <>
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Admin Fees (${adminFeesTableData.totalElements || 0})`}
            />
          }
          columns={ADMIN_FEES}
          data={adminFeesTableData.content}
          page={controllers.pageNumber - 1}
          totalCount={adminFeesTableData.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={
            isConfigurable
              ? [...FILTER_BUTTON, ...ADDITIONAL_OPTIONS]
              : FILTER_BUTTON
          }
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            detailPanelType: "single",
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(adminFeesTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>
      <BasicPopup
        show={showAddFee}
        title={`${coveredEntityName || "Covered Entity"} Billing Details / ${
          defaultFormValues.isEdit ? "Edit" : "Add"
        } Admin Fees`}
        disableFooter={true}
        isCustomFooter={true}
        footerActionElement={
          <AdminFeePopupFooter handlePopupClose={handlePopupClose} />
        }
        handleClose={() => handlePopupClose()}
        dialogProps={{
          maxWidth: "md",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
        withFormik={true}
        formikProps={{
          initialValues: defaultFormValues,
          onSubmit: handleSubmit,
          validate: handleValidate,
        }}
      >
        <AddAdminFees ref={getFeeTypesRef} />
      </BasicPopup>
    </>
  );
});

export default AdminFeesTable;
