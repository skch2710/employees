import React, { useState, useEffect, useRef, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form, Field } from "formik";
import { useHistory } from "react-router-dom";
import {
  Grid,
  FormControlLabel,
  IconButton,
  Button,
  FormLabel,
} from "@material-ui/core";
import classNames from "classnames";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import DatePicker from "../../../components/common/DatePicker";
import {
  getPreferredProvidersDefaultValue,
  REGEX,
  setAutoCompleteInputVal,
  statusArray,
} from "../../../utils/constants";
import useQuery from "../../../utils/useQuery";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { PROVIDER_COLUMNS } from "../../../components/common/Table/TableHeadCells";
import { pagination } from "../../../utils/constants";
import LoaderUI from "../../../components/common/Loader/Loader";
import AutoComplete from "../../../components/common/AutoComplete";
import excel from "../../../assets/excel.png";
import {
  ProvidersSearch,
  GetProviderstype,
  getProviderNpi,
} from "../../../context/actions/providers";
import {
  endDateValidation,
  filterFunctionality,
  startDateValidation,
} from "../../../utils/common";
import moment from "moment";
import _debounce from "lodash/debounce";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import Tooltip from "@mui/material/Tooltip";
import _get from "lodash/get";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import {
  getCoveredEntity,
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../utils/helper";
import ProvidersMaterialTable from "./ProvidersMaterialTable";

const Providers = () => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const { ceId: searchParamCeId } = useQuery();
  const userRole = getUserSession();
  const history = useHistory();
  const defaultValues = getPreferredProvidersDefaultValue(
    userRole.coveredEntityDTOs,
    searchParamCeId
  );
  const providersPermissionObj =
    getUserPermissionOnModuleName("Providers") || {};

  const { ceList: allCeList } = useSelector((state) => state.coveredEntities);
  const providertypes =
    useSelector((state) => state.getproviderstype.records) || [];
  const { records: providersAllData } = useSelector(
    (state) => state.providersalldata
  );

  const formikRef = useRef(null);
  const [ceList, setCeList] = useState([]);
  const CEidarray = userRole.coveredEntityDTOs.map((idx) => idx.ceID);
  const [open, setOpen] = useState(true);
  const [ceSelected, setCeSelected] = useState(
    !userRole.isInternalUser && userRole.coveredEntityDTOs[0]
  );
  const [urlCeId, setUrlCeId] = useState(searchParamCeId);
  const [openPopup, setOpenPopup] = useState(false);
  const [actionTitle, setActionTitle] = useState("");
  const [clearButton, setclearButton] = useState(false);
  const [enableactionbutton, setenableactionbutton] = useState(false);
  const [npiIsLoading, setNpiIsLoading] = useState(false);
  const [providerNpiOption, setProviderNpiOption] = useState([]);
  const [hasNpi, setHasNpi] = useState(true);
  const [filterValues, setFilterValues] = useState([]);
  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "lastName, firstName",
  });
  const defaultValuesForm = {
    providerNPI: "",
    firstName: "",
    lastName: "",
    startDate: "",
    endDate: "",
    providerType: "",
    status: "Active",
  };
  const [providerSearchData, setProviderSearchData] =
    useState(defaultValuesForm);

  const onChangePagination = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const { totalElements = 0 } = providersAllData;
      const totalPages = Math.ceil(totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchProvider({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: filterValues,
      });
    },
    [filterValues, controller]
  );

  const onChangeSorting = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PROVIDER_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchProvider({ sortBy, sortOrder });
    },
    [controller, filterValues]
  );

  const onChangeFilter = async (value) => {
    const payload = {
      pageNumber: pagination.page,
      pageSize: controller.pageSize,
    };
    if (value.length) {
      const responseValue = await filterFunctionality(value, "Providers");
      if (responseValue && Array.isArray(responseValue))
        payload.filter = responseValue;
      setFilterValues(responseValue);
    } else {
      payload.filter = null;
      setFilterValues([]);
    }
    fetchProvider(payload);
  };

  const clearFunction = (resetForm) => {
    searchParamCeId && history.push(history.location.pathname);
    setUrlCeId("");
    resetForm();
    setclearButton(true);
    userRole.isInternalUser && setCeSelected();
    setFilterValues([]);
    setProviderSearchData(defaultValuesForm);
    setCeList(allCeList);
    setHasNpi(true);
    setProviderNpiOption([]);
  };

  useEffect(() => {
    if (clearButton) fetchProvider();
  }, [clearButton]);

  useEffect(() => {
    if (urlCeId) setCeSelected(getCoveredEntity({ ceId: urlCeId, ceList })[0]);
  }, [urlCeId, ceList]);

  const fetchProviderNPI = _debounce(async (payloadObj, setFieldValue) => {
    const { providerNpiValue, ceid } = payloadObj || {};
    const ceId = (ceSelected && (ceSelected.ceID || ceSelected.ceid)) || ceid;
    const payload = {
      ceid: ceId,
      npi: providerNpiValue,
    };
    if (providerNpiValue) {
      const resp = await getProviderNpi(payload, setNpiIsLoading);
      if (resp.statusCode === 200) {
        setHasNpi(false);
        setProviderNpiOption(resp.data);
        if (providerNpiValue.length === 10) {
          if (!ceid && setFieldValue && resp.data && resp.data.length === 1) {
            setFieldValue("ceid", resp.data[0].ceID);
            setCeSelected(
              allCeList.find((itm) => itm.ceID === resp.data[0].ceID)
            );
          }
          setCeList(
            !ceid && _isArray(resp.data) && resp.data.length > 0
              ? resp.data
              : allCeList
          );
        }
      } else {
        setCeList(allCeList);
      }
    } else {
      setProviderNpiOption([]);
      setCeList(allCeList);
    }
  }, 500);

  const handleSubmit = (values) => {
    setclearButton(false);
    let json = {
      ceid: values.ceid ? [values.ceid] : [],
      pageNumber: 1,
      pageSize: controller.pageSize || 25,
      sortBy: controller.sortBy,
      sortOrder: controller.sortOrder,
      providerNPI: values.providerNPI,
      firstName: values.firstName,
      lastName: values.lastName,
      startDate: values.startDate,
      endDate: values.endDate,
      providerType: values.providerType,
      status: values.status,
    };
    setProviderSearchData(json);
    setFilterValues([]);
    dispatch(
      ProvidersSearch(json, (data) => {
        setController((prev) => ({
          ...prev,
          page: data.pageNo,
          pageSize: data.pageSize,
        }));
      })
    );
  };

  useEffect(() => {
    dispatch(GetProviderstype());
    fetchProvider();
    return () => {
      dispatch({ type: "PROVIDER_SEARCH", data: [] });
    };
  }, []);

  useEffect(() => {
    setCeList(allCeList);
  }, [allCeList]);

  const fetchProvider = (payload = {}) => {
    const payloadJson = {
      ceid: !searchParamCeId
        ? ceSelected
          ? [ceSelected.ceID]
          : []
        : [Number(searchParamCeId)],
      pageNumber: controller.page || _get(providerSearchData, "pageNumber", 1),
      pageSize: controller.pageSize || 25,
      sortBy: controller.sortBy,
      sortOrder: controller.sortOrder,
      providerNPI: _get(providerSearchData, "providerNPI", ""),
      firstName: _get(providerSearchData, "firstName", ""),
      lastName: _get(providerSearchData, "lastName", ""),
      endDate: _get(providerSearchData, "endDate", ""),
      startDate: _get(providerSearchData, "startDate", ""),
      providerType: _get(providerSearchData, "providerType", ""),
      status: _get(providerSearchData, "status", ""),
      filter: filterValues || [],
      ...payload,
    };
    setProviderSearchData(payloadJson);
    dispatch(
      ProvidersSearch(payloadJson, (data) => {
        setController((prev) => ({
          ...prev,
          page: data.pageNo || data.data.pageNo,
          pageSize: data.pageSize || data.data.pageSize,
        }));
      })
    );
  };

  const handleChange = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    let { name, value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue(name, value);
  };

  const openAddProviderPopup = () => {
    setOpenPopup(true);
    setActionTitle("Add Provider");
  };

  const onChangeNpi = (value, setFieldValue) => {
    setFieldValue("providerNPI", value && value.npi);
  };

  const onNpiInputChange = (value, setFieldValue, values) => {
    setFieldValue("providerNPI", value);
    if (providerNpiOption.length > 0) {
      const existNpi = providerNpiOption.find((itm) => itm.npi == value);
      if (!_isEmpty(existNpi)) return;
    }
    const payload = {
      providerNpiValue: value,
      ceid: values.ceid,
    };
    fetchProviderNPI(payload, setFieldValue);
  };

  const formValidate = (values) => {
    const error = {};
    const regex = /^[0-9]+$/;
    if (
      values.providerNPI &&
      values.providerNPI.length > 0 &&
      !regex.test(values.providerNPI)
    ) {
      error.providerNPI = "Please enter only numbers";
    }
    return error;
  };
  return (
    <>
      {npiIsLoading ? <LoaderUI /> : ""}
      <Grid container spacing={2}>
        <Grid item md={12}>
          <BasicTypography variant="h1" title="Eligibility - Providers" />
        </Grid>
        <Grid item md={12}>
          <Formik
            innerRef={formikRef}
            initialValues={defaultValues}
            onSubmit={handleSubmit}
            validate={formValidate}
            enableReinitialize={true}
          >
            {({ values, errors, setFieldValue, resetForm, touched }) => (
              <Form>
                {open ? (
                  <div className={globalClasses.cardPrimary}>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        <Grid
                          container
                          spacing={2}
                          justifyContent="space-between"
                        >
                          <Grid item>
                            <BasicTypography variant="h4" title="Filters" />
                          </Grid>
                          <Grid item>
                            <FormControlLabel
                              control={
                                <IconButton>
                                  <IoIosCloseCircleOutline
                                    onClick={() => {
                                      setOpen(false);
                                    }}
                                  />
                                </IconButton>
                              }
                            />
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item md={12}>
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={4}>
                            <FormLabel>Covered Entity</FormLabel>
                            <Field
                              as="select"
                              className={globalClasses.formControl}
                              name="ceid"
                            >
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  disabled={!userRole.isInternalUser}
                                  disableCloseOnSelect={false}
                                  options={_isArray(ceList) ? ceList : []}
                                  inputPlaceholder={"Select Covered Entity"}
                                  disableClearable={true}
                                  value={
                                    (_isArray(ceList) &&
                                      ceList.find(
                                        (e) => e.ceID == values.ceid
                                      )) ||
                                    ""
                                  }
                                  onChange={(_e, value) => {
                                    setFieldValue(
                                      "ceid",
                                      value ? value.ceID : ""
                                    );
                                    setFieldValue(
                                      "coveredEntityInput",
                                      value ? value.ceName : ""
                                    );
                                    setUrlCeId("");
                                    if (!_isEmpty(value)) {
                                      setCeSelected(
                                        allCeList.find(
                                          (itm) =>
                                            itm.ceID === Number(value.ceID)
                                        )
                                      );
                                    }
                                  }}
                                  getOptionLabel={(option) =>
                                    option.ceName || ""
                                  }
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.ceName}
                                      </BasicTypography>
                                    );
                                  }}
                                  textFieldProps={{
                                    inputProps: {
                                      name: "ceid",
                                    },
                                  }}
                                  multiple={false}
                                />
                              )}
                            </Field>
                          </Grid>

                          <Grid item xs={12} sm={4}>
                            <FormLabel>Provider NPI</FormLabel>
                            <Field name="providerNPI">
                              {({ field }) => (
                                <AutoComplete
                                  loading={npiIsLoading}
                                  options={providerNpiOption}
                                  getOptionLabel={(option) =>
                                    option.npi || option.toString()
                                  }
                                  multiple={false}
                                  disableCloseOnSelect={false}
                                  inputPlaceholder="Enter Provider NPI"
                                  onInputChange={(e, inputValue) =>
                                    onNpiInputChange(
                                      inputValue,
                                      setFieldValue,
                                      values
                                    )
                                  }
                                  {...field}
                                  onChange={(_e, value) =>
                                    onChangeNpi(value, setFieldValue)
                                  }
                                  textFieldProps={{
                                    inputProps: {
                                      maxLength: 10,
                                      name: "providerNPI",
                                    },
                                  }}
                                />
                              )}
                            </Field>
                            {touched.providerNPI && errors.providerNPI && (
                              <BasicTypography color="error" variant="caption">
                                {errors.providerNPI}
                              </BasicTypography>
                            )}
                          </Grid>

                          <Grid item xs={12} sm={4}>
                            <FormLabel>Provider First Name</FormLabel>
                            <Field
                              name="firstName"
                              id="firstName"
                              type="text"
                              className={globalClasses.formControl}
                              placeholder="Enter Provider First Name"
                              maxLength={25}
                              onChange={(e) => {
                                const value = e.target.value;
                                if (
                                  value &&
                                  !REGEX.alphabetsAndHypen.test(value)
                                )
                                  return;
                                setFieldValue("firstName", value);
                                handleChange(e, setFieldValue);
                              }}
                            />
                          </Grid>
                          <Grid item xs={12} sm={4}>
                            <FormLabel>Provider Last Name</FormLabel>
                            <Field
                              name="lastName"
                              id="lastName"
                              type="text"
                              className={globalClasses.formControl}
                              placeholder="Enter Provider Last Name"
                              maxLength={25}
                              onChange={(e) => {
                                const value = e.target.value;
                                if (
                                  value &&
                                  !REGEX.alphabetsAndHypen.test(value)
                                )
                                  return;
                                setFieldValue("lastName", value);
                                handleChange(e, setFieldValue);
                              }}
                            />
                          </Grid>
                          <Grid item xs={4} sm={4}>
                            <FormLabel>Provider Type</FormLabel>
                            <Field
                              as="select"
                              className={globalClasses.formControl}
                              name="providerType"
                            >
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  disableCloseOnSelect={false}
                                  options={
                                    _isArray(providertypes) ? providertypes : []
                                  }
                                  inputPlaceholder={"Select Provider Type"}
                                  onChange={(_e, value) => {
                                    setFieldValue(
                                      "providerType",
                                      value ? value.prescriberPanelType : ""
                                    );
                                  }}
                                  getOptionLabel={(option) =>
                                    option.prescriberPanelType || ""
                                  }
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.prescriberPanelType}
                                      </BasicTypography>
                                    );
                                  }}
                                  value={
                                    (_isArray(providertypes) &&
                                      providertypes.find(
                                        (e) =>
                                          e.prescriberPanelType ==
                                          values.providerType
                                      )) ||
                                    ""
                                  }
                                  multiple={false}
                                />
                              )}
                            </Field>
                          </Grid>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>Provider Start Date</FormLabel>
                            <DatePicker
                              disabledDate={(date) =>
                                startDateValidation(date, values.endDate)
                              }
                              onChange={(_e, date) => {
                                if (!date) setFieldValue("endDate", "");
                                setFieldValue("startDate", date);
                              }}
                              value={
                                values.startDate !== ""
                                  ? moment(values.startDate)
                                  : ""
                              }
                            />
                          </Grid>
                          <Grid item xs={12} sm={2}>
                            <FormLabel>Provider End Date</FormLabel>
                            <DatePicker
                              onChange={(_e, date) => {
                                setFieldValue("endDate", date);
                              }}
                              disabledDate={(d) =>
                                endDateValidation(d, values.startDate)
                              }
                              value={
                                values.endDate !== ""
                                  ? moment(values.endDate)
                                  : ""
                              }
                            />
                          </Grid>

                          <Grid item xs={12} sm={4}>
                            <FormLabel>Status</FormLabel>
                            <Field as="select" name="status">
                              {({ field }) => (
                                <AutoComplete
                                  {...field}
                                  options={
                                    _isArray(statusArray) ? statusArray : []
                                  }
                                  inputPlaceholder={"Select Status"}
                                  disableCloseOnSelect={false}
                                  disableClearable={true}
                                  onChange={(e, value) => {
                                    setFieldValue(
                                      "status",
                                      value && value.status
                                    );
                                  }}
                                  getOptionLabel={(option) =>
                                    option.status || ""
                                  }
                                  value={
                                    statusArray.find(
                                      (e) => e.status == values.status
                                    ) || statusArray[0]
                                  }
                                  renderOption={(option, _other) => {
                                    return (
                                      <BasicTypography variant="subtitle2">
                                        {option.status}
                                      </BasicTypography>
                                    );
                                  }}
                                  multiple={false}
                                  textFieldProps={{
                                    inputProps: {
                                      name: "status",
                                    },
                                  }}
                                />
                              )}
                            </Field>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item md={12}>
                        <Grid container justifyContent="flex-end" spacing={2}>
                          <Grid item>
                            <Tooltip
                              placement="top"
                              title={
                                !providersPermissionObj.readWriteFlag
                                  ? "You don't have Permission."
                                  : _isEmpty(ceSelected)
                                  ? "Please select a Covered Entity to enable this button"
                                  : ""
                              }
                            >
                              <span>
                                <Button
                                  startIcon={<AddCircleOutlineIcon />}
                                  variant="outlined"
                                  size="small"
                                  component="button"
                                  className={globalClasses.grayButton}
                                  onClick={openAddProviderPopup}
                                  disabled={
                                    !_isEmpty(ceSelected)
                                      ? !providersPermissionObj.readWriteFlag
                                      : true
                                  }
                                >
                                  Add Provider
                                </Button>
                              </span>
                            </Tooltip>
                          </Grid>
                          <Grid item>
                            <Button
                              type="submit"
                              color="primary"
                              size="small"
                              variant="contained"
                              className={globalClasses.primaryBtn}
                            >
                              Search
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              type="reset"
                              size="small"
                              variant="outlined"
                              color="default"
                              className={globalClasses.secondaryBtn}
                              onClick={() => clearFunction(resetForm)}
                            >
                              Clear
                            </Button>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </div>
                ) : (
                  <Button
                    type="submit"
                    variant="contained"
                    className={globalClasses.primaryBtn}
                    onClick={() => {
                      setOpen(true);
                    }}
                  >
                    Filters
                  </Button>
                )}
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12} container justifyContent="flex-end">
          <Tooltip
            title={
              !providersPermissionObj.readWriteFlag
                ? "You don't have Permission."
                : ""
            }
          >
            <span>
              <a
                href={`/templates/AddceproviderTemplate.xlsx`}
                download="Provider_Template"
                className={classNames(
                  globalClasses.iconPlusClickableLink,
                  !providersPermissionObj.readWriteFlag
                    ? globalClasses.disabledDownloadTemp
                    : null
                )}
                disabled={providersPermissionObj.readWriteFlag ? false : true}
              >
                <img src={excel} alt="Active" />
                <span>Download Template</span>
              </a>
            </span>
          </Tooltip>
        </Grid>
        <Grid item md={12}>
          <ProvidersMaterialTable
            searchData={providerSearchData}
            coveredentity={ceList}
            providersAllData={providersAllData}
            providersexportdata={[]}
            controller={controller}
            defaultFilters={filterValues}
            onChangePagination={onChangePagination}
            onChangeSorting={onChangeSorting}
            onChangeFilter={onChangeFilter}
            setenableactionbutton={enableactionbutton}
            ceSelected={ceSelected}
            CEidarray={CEidarray}
            openPopup={openPopup}
            actionTitle={actionTitle}
            setOpenPopup={setOpenPopup}
            setActionTitle={setActionTitle}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default Providers;
