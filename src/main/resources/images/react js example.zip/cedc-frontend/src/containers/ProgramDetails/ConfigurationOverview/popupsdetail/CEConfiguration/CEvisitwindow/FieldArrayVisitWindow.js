import React, { useState, useContext } from "react";
import {
  Grid,
  Button,
  FormLabel,
  IconButton,
  FormControlLabel,
} from "@material-ui/core";
import "antd/dist/antd.css";
import { Field } from "formik";
import { useSelector } from "react-redux";
import { IoIosTrash } from "react-icons/io";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import {
  serviceAreaVisit,
  getAllCeProviders,
} from "../../../../../../context/actions/ConfigOverview";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { COContext } from "../../../../COContext";
import _get from "lodash/get";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import _isArray from "lodash/isArray";
import MultiSelectDropdown from "../../../../../../components/common/MultiSelectDropdown";
import Toggle from "../../../../../../components/common/Toggle";
import AutoComplete from "../../../../../../components/common/AutoComplete";

const FieldArrayVisitWindow = ({
  push,
  form: { values, setFieldValue },
  replace,
}) => {
  const [loader, setLoader] = useState(false);
  const dispatch = useDispatch();
  const [providers, setProviders] = useState([]);
  const globalClasses = useGlobalStyles();
  const customVariableValues = useSelector(
    (state) => state.getCustomconfigvariable.data
  );
  const customVisitWindowsFormData = _get(values, "customVisitWindows", []);
  const providerTypeValues = useSelector((state) => state.getProvidertype.data);
  const visitConfigLookUpData = useSelector(
    (state) => state.getVisitLukUp.data
  );
  const isEditable =
    _isArray(customVisitWindowsFormData) &&
    customVisitWindowsFormData.filter((key) => key.value === true).length > 0
      ? false
      : true;
  const { messageUuid } = useContext(COContext);

  useEffect(() => {
    setLoader(true);
    fetchProviders();
  }, []);

  const fetchProviders = async () => {
    const ceId = _get(values, "customVisitWindows[0][ceid]", messageUuid.ceid);
    await getAllCeProviders(ceId, setProviders);
    setLoader(false);
  };

  // Get Dependant options based on selected service area type and push in to respective window
  const getServiceOptions = async (selectedService, index) => {
    setLoader(true);
    const filterArray =
      _isArray(visitConfigLookUpData) &&
      visitConfigLookUpData.filter(
        (key) =>
          key.configurationType === selectedService ||
          Number(key.configurationTypeId) === Number(selectedService)
      );

    if (filterArray && filterArray.length > 0) {
      const json = {
        id: filterArray[0].configurationTypeId,
        ceid: _get(values, "customVisitWindows[0][ceid]", messageUuid.ceid),
      };
      dispatch(
        serviceAreaVisit(json, setLoader, async (data) => {
          if (
            _isArray(customVisitWindowsFormData) &&
            customVisitWindowsFormData.length > 0 &&
            index >= 0 &&
            customVisitWindowsFormData[index] &&
            replace
          ) {
            const obj = customVisitWindowsFormData[index];
            obj["serviceAreaType"] = selectedService;
            obj["serviceAreaTypeOptions"] = data || [];
            await replace(index, { ...obj });
          }
        })
      );
    } else {
      setLoader(false);
    }
  };

  const onClickAddAnotherAccount = () => {
    push({
      customWindowType: "",
      providerTypeValue: "",
      daysBeforeVisit: "",
      daysAfterVisit: "",
      enabled: true,
      active: true,
      value: false,
      providerValues: [],
      serviceAreaTypeValues: [],
      visitWindowId: "",
      serviceAreaTypeOptions: [],
      isNew: true,
      serviceAreaType: "",
    });
  };
  const getProviderTypeValue = (providerTypeValues, val) => {
    const value =
      providerTypeValues &&
      providerTypeValues.length > 0 &&
      _isArray(providerTypeValues) &&
      providerTypeValues.filter((key) => key.prescriberPanelTypeId === val);
    return value && value.length > 0 && _isArray(value)
      ? value[0].prescriberPanelType
      : "-";
  };

  // On delete icon click modify window as active false
  const removeAccount = (index) => {
    const obj = customVisitWindowsFormData[index];
    obj["active"] = false;
    replace(index, { ...obj });
  };

  const getSelectedName = (val, array) => {
    let name = "";
    if (_isArray(array)) {
      let index = array.findIndex(function (item) {
        return item.configItemId === val.customValueId;
      });
      if (index === -1) {
        name = val.configurationItem;
      } else {
        name = array[index].configurationItem;
      }
    }
    return name;
  };

  const selectProviderName = (val, array) => {
    let name = "";
    if (_isArray(array)) {
      let index = array.findIndex(function (item) {
        return Number(item.prescriberId) === Number(val.customValueId);
      });
      if (index === -1) {
        name = val.firstName + " " + val.lastName;
      } else {
        name = array[index].firstName + " " + array[index].lastName;
      }
    }
    return name;
  };

  const getProviderName = (providerArray, selectedProviders) => {
    const matchedProviders = [];
    if (_isArray(selectedProviders)) {
      selectedProviders.map((selectedProvider) => {
        const index = providerArray.findIndex(
          (provider) =>
            Number(provider.prescriberId) ===
            Number(selectedProvider.customValueId)
        );
        if (index !== -1) {
          matchedProviders.push(
            providerArray[index].firstName + " " + providerArray[index].lastName
          );
        }
        return selectedProvider;
      });
    }
    return matchedProviders.join(",");
  };

  const getVisitConfigLookUpData = (visitConfigLookUpDataArray, val) => {
    const value =
      visitConfigLookUpDataArray &&
      visitConfigLookUpDataArray.length > 0 &&
      _isArray(visitConfigLookUpDataArray) &&
      visitConfigLookUpDataArray.filter(
        (key) => key.configurationTypeId === Number(val)
      );
    return value && value.length > 0 && _isArray(value)
      ? value[0].configurationType
      : "-";
  };

  // To restrict user to select 'Provider Type' option not more that 2 one for each subtype
  const isConfigurationTypeDisabled = (availableWindows, configOption) => {
    const customWindows = availableWindows || [];
    let bool = false;
    const activeWindows = customWindows.map((window) => {
      if (window.active === true) return window;
    });
    if (
      configOption.customConfigVariableType === "Provider Type" &&
      activeWindows.length > 0 &&
      _isArray(activeWindows)
    ) {
      const count = activeWindows.filter(
        (window) =>
          window &&
          window.customWindowType === configOption.customConfigVariableType
      );
      if (count.length === 2) {
        bool = true;
      }
    }
    return bool;
  };

  // To restrict user to select 'Provider Type' dependent Options each once
  const isProviderConfigDisabled = (availableWindows, configOption) => {
    const customWindows = availableWindows || [];
    let bool = false;
    const activeWindows = customWindows.map((window) => {
      if (window.active === true) return window;
    });
    if (activeWindows.length > 0 && _isArray(activeWindows)) {
      const count = activeWindows.filter(
        (window) =>
          window &&
          window.customWindowType === "Provider Type" &&
          Number(window.providerTypeValue) ===
            Number(configOption.prescriberPanelTypeId)
      );
      if (count.length === 1) {
        bool = true;
      }
    }
    return bool;
  };

  const regex = /^0*([0-9][0-9]?|[12][0-9][0-9]|3[0-5][0-9]|36[0-5])$/;

  // To restrict user to select the Provider only once throughout all the configured visit windows
  const returnIsProviderOptionDisabled = (option, windows) => {
    let selectedProviders = [];
    if (_isArray(windows) && windows.length > 0) {
      const activeWindows = windows.filter(
        (windowItem) => windowItem.active === true
      );
      if (_isArray(activeWindows) && activeWindows.length > 0) {
        activeWindows.map((windowItem) => {
          if (
            windowItem &&
            windowItem.providerValues &&
            _isArray(windowItem.providerValues)
          ) {
            selectedProviders = [
              ...selectedProviders,
              ...windowItem.providerValues,
            ];
          }
        });
      }
    }
    if (selectedProviders && selectedProviders.length > 0) {
      const indexOfMatch = selectedProviders.findIndex(
        (provider) =>
          Number(provider.prescriberId) === Number(option.prescriberId) ||
          Number(provider.customValueId) === Number(option.prescriberId)
      );
      if (indexOfMatch >= 0) return true;
    }
  };

  // To restrict user to select the Service Related options only once throughout all the configured visit windows
  const returnIsServiceOptionDisabled = (option, serviceTypeId, windows) => {
    let alreadySelectedServices = [];
    if (_isArray(windows) && windows.length > 0) {
      const activeServiceTypeWindows = windows.filter(
        (windowItem) =>
          windowItem.active === true &&
          windowItem.customWindowType === "Service Area" &&
          Number(windowItem.serviceAreaType) === Number(serviceTypeId)
      );
      if (
        _isArray(activeServiceTypeWindows) &&
        activeServiceTypeWindows.length > 0
      ) {
        activeServiceTypeWindows.map((windowItem) => {
          if (
            windowItem &&
            windowItem.serviceAreaTypeValues &&
            _isArray(windowItem.serviceAreaTypeValues)
          ) {
            alreadySelectedServices = [
              ...alreadySelectedServices,
              ...windowItem.serviceAreaTypeValues,
            ];
          }
        });
      }
    }
    if (alreadySelectedServices && alreadySelectedServices.length > 0) {
      const indexOfMatch = alreadySelectedServices.findIndex(
        (service) =>
          Number(service.configItemId) === Number(option.configItemId) ||
          Number(service.customValueId) === Number(option.configItemId)
      );
      if (indexOfMatch >= 0) return true;
    }
  };

  return (
    <>
      {loader && <LoaderUI />}
      <Grid container spacing={2}>
        <Grid item md={12}>
          {(customVisitWindowsFormData || []).map((item, index) => {
            return (
              item.active &&
              (item.value ? item.customWindowType !== "" : true) && (
                <Grid container spacing={1} key={index}>
                  <Grid item xs={12} sm={2}>
                    {item.value ? (
                      <BasicTypography
                        title={
                          customVisitWindowsFormData[index][`customWindowType`]
                        }
                      />
                    ) : (
                      <Field
                        as="select"
                        className={globalClasses.formControl}
                        name={`customVisitWindows.${index}.customWindowType`}
                      >
                        {(props) => {
                          const { field } = props;
                          return (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(customVariableValues)
                                  ? customVariableValues
                                  : []
                              }
                              inputPlaceholder={"Select Value"}
                              value={
                                (_isArray(customVariableValues) &&
                                  customVariableValues.find(
                                    (e) =>
                                      e.customConfigVariableType ==
                                      customVisitWindowsFormData[index][
                                        `customWindowType`
                                      ]
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? newValue.customConfigVariableType
                                  : "";
                                setFieldValue(
                                  `customVisitWindows.${index}.customWindowType`,
                                  value
                                );
                              }}
                              getOptionLabel={(option) =>
                                option.customConfigVariableType || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.customConfigVariableType}
                                  </BasicTypography>
                                );
                              }}
                              getOptionDisabled={(option) =>
                                isConfigurationTypeDisabled(
                                  customVisitWindowsFormData,
                                  option
                                )
                              }
                              multiple={false}
                            />
                          );
                        }}
                      </Field>
                    )}
                  </Grid>
                  {customVisitWindowsFormData[index][`customWindowType`] ===
                    "Provider Type" && (
                    <Grid item xs={12} sm={4}>
                      {item.value ? (
                        <BasicTypography
                          title={getProviderTypeValue(
                            providerTypeValues,
                            customVisitWindowsFormData[index][
                              `providerTypeValue`
                            ]
                          )}
                        />
                      ) : (
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name={`customVisitWindows.${index}.providerTypeValue`}
                        >
                          {(props) => {
                            const { field } = props;
                            return (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(providerTypeValues)
                                    ? providerTypeValues
                                    : []
                                }
                                inputPlaceholder={"Select Value"}
                                value={
                                  (_isArray(providerTypeValues) &&
                                    providerTypeValues.find(
                                      (e) =>
                                        e.prescriberPanelTypeId ==
                                        customVisitWindowsFormData[index][
                                          `providerTypeValue`
                                        ]
                                    )) ||
                                  ""
                                }
                                onChange={(e, newValue) => {
                                  const value = newValue
                                    ? newValue.prescriberPanelTypeId
                                    : "";
                                  setFieldValue(
                                    `customVisitWindows.${index}.providerTypeValue`,
                                    value
                                  );
                                }}
                                getOptionLabel={(option) =>
                                  option.prescriberPanelType || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.prescriberPanelType}
                                    </BasicTypography>
                                  );
                                }}
                                getOptionDisabled={(option) =>
                                  isProviderConfigDisabled(
                                    customVisitWindowsFormData,
                                    option
                                  )
                                }
                                multiple={false}
                              />
                            );
                          }}
                        </Field>
                      )}
                    </Grid>
                  )}
                  {customVisitWindowsFormData[index][`customWindowType`] ===
                    "Service Area" && (
                    <Grid item xs={12} sm={2}>
                      {item.value ? (
                        <BasicTypography
                          title={getVisitConfigLookUpData(
                            visitConfigLookUpData,
                            customVisitWindowsFormData[index][`serviceAreaType`]
                          )}
                        />
                      ) : (
                        <Field
                          name={`customVisitWindows.${index}.serviceAreaType`}
                        >
                          {(props) => {
                            const { field } = props;

                            return (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(visitConfigLookUpData)
                                    ? visitConfigLookUpData
                                    : []
                                }
                                inputPlaceholder={"Select Value"}
                                value={
                                  (_isArray(visitConfigLookUpData) &&
                                    visitConfigLookUpData.find(
                                      (e) =>
                                        e.configurationTypeId ==
                                        customVisitWindowsFormData[index][
                                          `serviceAreaType`
                                        ]
                                    )) ||
                                  ""
                                }
                                onChange={(e, newValue) => {
                                  const value = newValue
                                    ? newValue.configurationTypeId
                                    : "";

                                  customVisitWindowsFormData[
                                    index
                                  ].serviceAreaType =
                                    visitConfigLookUpData.filter(
                                      (x) =>
                                        Number(x.configurationTypeId) ===
                                        Number(value)
                                    );
                                  setFieldValue(
                                    `customVisitWindows.${index}.serviceAreaType`,
                                    value
                                  );

                                  getServiceOptions(value, index);
                                }}
                                getOptionLabel={(option) =>
                                  option.configurationType || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.configurationType}
                                    </BasicTypography>
                                  );
                                }}
                                getOptionDisabled={(option) =>
                                  isProviderConfigDisabled(
                                    customVisitWindowsFormData,
                                    option
                                  )
                                }
                                multiple={false}
                              />
                            );
                          }}
                        </Field>
                      )}
                    </Grid>
                  )}
                  {customVisitWindowsFormData[index][`customWindowType`] ===
                    "Service Area" && (
                    <>
                      {item.value ? (
                        <BasicTypography title={"Service Area Values"} />
                      ) : (
                        <Grid item xs={12} sm={2}>
                          <Field
                            multiple
                            name={`customVisitWindows.${index}.serviceAreaTypeValues`}
                          >
                            {({ field }) => (
                              <MultiSelectDropdown
                                inputPlaceholder={
                                  _isArray(
                                    customVisitWindowsFormData[index][
                                      `serviceAreaTypeValues`
                                    ]
                                  ) &&
                                  customVisitWindowsFormData[index][
                                    `serviceAreaTypeValues`
                                  ].length > 0
                                    ? ""
                                    : "Select Value"
                                }
                                options={
                                  customVisitWindowsFormData[index][
                                    `serviceAreaTypeOptions`
                                  ] &&
                                  customVisitWindowsFormData[index][
                                    `serviceAreaTypeOptions`
                                  ].length > 0 &&
                                  _isArray(
                                    customVisitWindowsFormData[index][
                                      `serviceAreaTypeOptions`
                                    ]
                                  )
                                    ? customVisitWindowsFormData[index][
                                        `serviceAreaTypeOptions`
                                      ]
                                    : []
                                }
                                getOptionLabel={(option) =>
                                  getSelectedName(
                                    option,
                                    _get(
                                      values,
                                      `customVisitWindows.${index}.serviceAreaTypeOptions`,
                                      []
                                    )
                                  )
                                }
                                {...field}
                                value={
                                  _isArray(
                                    customVisitWindowsFormData[index][
                                      `serviceAreaTypeValues`
                                    ]
                                  )
                                    ? customVisitWindowsFormData[index][
                                        `serviceAreaTypeValues`
                                      ].map((item) =>
                                        item.customValueId
                                          ? {
                                              ...item,
                                              configItemId: item.customValueId,
                                            }
                                          : item
                                      )
                                    : []
                                }
                                getOptionSelected={(option, value) =>
                                  Number(option.configItemId) ===
                                  Number(value.configItemId)
                                }
                                onChange={(_e, value) => {
                                  setFieldValue(
                                    `customVisitWindows.${index}.serviceAreaTypeValues`,
                                    value
                                  );
                                }}
                                getOptionDisabled={(option) =>
                                  returnIsServiceOptionDisabled(
                                    option,
                                    customVisitWindowsFormData[index]
                                      .serviceAreaType,
                                    customVisitWindowsFormData
                                  )
                                }
                              />
                            )}
                          </Field>
                        </Grid>
                      )}
                    </>
                  )}

                  {customVisitWindowsFormData[index][`customWindowType`] ===
                    "Provider" && (
                    <Grid item xs={12} sm={4}>
                      {item.value ? (
                        providers.length > 0 && (
                          <BasicTypography
                            title={getProviderName(
                              providers,
                              customVisitWindowsFormData[index][
                                `providerValues`
                              ]
                            )}
                          />
                        )
                      ) : (
                        <Field
                          multiple
                          name={`customVisitWindows.${index}.providerValues`}
                        >
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder={
                                _isArray(
                                  customVisitWindowsFormData[index][
                                    `providerValues`
                                  ]
                                ) &&
                                customVisitWindowsFormData[index][
                                  `providerValues`
                                ].length > 0
                                  ? ""
                                  : "Select Provider"
                              }
                              options={
                                providers && _isArray(providers)
                                  ? providers
                                  : []
                              }
                              getOptionLabel={(option) =>
                                selectProviderName(option, providers || [])
                              }
                              {...field}
                              value={
                                _isArray(
                                  customVisitWindowsFormData[index][
                                    `providerValues`
                                  ]
                                )
                                  ? customVisitWindowsFormData[index][
                                      `providerValues`
                                    ].map((item) =>
                                      item.customValueId
                                        ? {
                                            ...item,
                                            prescriberId: item.customValueId,
                                          }
                                        : item
                                    )
                                  : []
                              }
                              getOptionSelected={(option, value) =>
                                Number(option.prescriberId) ===
                                Number(value.prescriberId)
                              }
                              onChange={(_e, value) => {
                                setFieldValue(
                                  `customVisitWindows.${index}.providerValues`,
                                  value
                                );
                              }}
                              getOptionDisabled={(option) =>
                                returnIsProviderOptionDisabled(
                                  option,
                                  customVisitWindowsFormData
                                )
                              }
                            />
                          )}
                        </Field>
                      )}
                    </Grid>
                  )}

                  <Grid item xs={6} sm={1}>
                    {item.value ? (
                      <BasicTypography
                        title={
                          customVisitWindowsFormData[index][`daysBeforeVisit`]
                        }
                      />
                    ) : (
                      <Field
                        name={`customVisitWindows.${index}.daysBeforeVisit`}
                        id="daysBeforeVisit"
                        type="number"
                        className={globalClasses.formControl}
                        placeholder="0"
                        min="0"
                        max="365"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (value && !regex.test(value)) return;
                          setFieldValue(
                            `customVisitWindows.${index}.daysBeforeVisit`,
                            value
                          );
                        }}
                        onKeyDown={(e) =>
                          (e.key === "e" || e.key === "-" || e.key === "+") &&
                          e.preventDefault()
                        }
                      />
                    )}
                  </Grid>
                  <Grid item xs={6} sm={1}>
                    <FormLabel>Days before visit</FormLabel>
                  </Grid>
                  <Grid item xs={6} sm={1}>
                    {item.value ? (
                      <BasicTypography
                        title={
                          customVisitWindowsFormData[index][`daysAfterVisit`]
                        }
                      />
                    ) : (
                      <Field
                        name={`customVisitWindows.${index}.daysAfterVisit`}
                        id="daysAfterVisit"
                        type="number"
                        className={globalClasses.formControl}
                        placeholder="365"
                        min="0"
                        max="365"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (value && !regex.test(value)) return;
                          setFieldValue(
                            `customVisitWindows.${index}.daysAfterVisit`,
                            value
                          );
                        }}
                        onKeyDown={(e) =>
                          (e.key === "e" || e.key === "-" || e.key === "+") &&
                          e.preventDefault()
                        }
                      />
                    )}
                  </Grid>
                  <Grid item xs={6} sm={1}>
                    <FormLabel>Days after visit </FormLabel>
                  </Grid>

                  <Grid item xs={6} sm={1}>
                    <FormControlLabel
                      control={
                        <Field
                          name={`customVisitWindows.${index}.enabled`}
                          component={Toggle}
                          checked={customVisitWindowsFormData[index]["enabled"]}
                          onClick={(e) =>
                            !item.value &&
                            setFieldValue(
                              `customVisitWindows[${index}]["enabled"]`,
                              e.target.checked
                            )
                          }
                        />
                      }
                    />
                  </Grid>
                  <Grid item xs={6} sm={1}>
                    {index >= 0 && (
                      <IconButton
                        onClick={() => {
                          if (!item.value) {
                            removeAccount(index);
                          }
                        }}
                      >
                        <IoIosTrash />
                      </IconButton>
                    )}
                  </Grid>
                </Grid>
              )
            );
          })}
        </Grid>
        <Grid item md={12}>
          {isEditable && (
            <Grid container justifyContent="flex-end" spacing={2}>
              <Grid item>
                <Button
                  size="small"
                  variant="outlined"
                  className={globalClasses.secondaryBtn}
                  onClick={() => onClickAddAnotherAccount()}
                >
                  Add Visit Window
                </Button>
              </Grid>
            </Grid>
          )}
        </Grid>
      </Grid>
    </>
  );
};

export default FieldArrayVisitWindow;
