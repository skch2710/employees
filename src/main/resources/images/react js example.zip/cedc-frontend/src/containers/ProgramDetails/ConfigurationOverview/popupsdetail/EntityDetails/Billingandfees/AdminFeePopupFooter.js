import React from "react";
import { useFormikContext } from "formik";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";

const AdminFeePopupFooter = (props = {}) => {
  const { handlePopupClose } = props;
  const { values, submitForm, setFieldValue } = useFormikContext();
  const globalClasses = useGlobalStyles();

  return (
    <Grid container spacing={2} justifyContent="flex-end">
      <Grid item>
        <Button
          onClick={() => {
            setFieldValue("isExit", true);
            submitForm();
          }}
          className={globalClasses.primaryBtn}
        >
          {values.isEdit ? "Save" : "Add & Exit"}
        </Button>
      </Grid>
      {!values.isEdit && (
        <Grid item>
          <Button
            className={globalClasses.secondaryBtn}
            onClick={() => {
              setFieldValue("isExit", false);
              submitForm();
            }}
          >
            Add Another
          </Button>
        </Grid>
      )}
      <Grid item>
        <Button className={globalClasses.grayButton} onClick={handlePopupClose}>
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};

export default AdminFeePopupFooter;
