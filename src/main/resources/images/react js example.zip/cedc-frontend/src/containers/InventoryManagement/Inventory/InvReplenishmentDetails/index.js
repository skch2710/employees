import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import moment from "moment";
import DatePicker from "../../../../components/common/DatePicker";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
} from "../../../../Styles/useGlobalStyles";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { pagination } from "../../../../utils/constants";
import { getinventoryInnerSubGridList } from "../../../../context/actions/Inventory";
import { getInvInnerSubgridFiltersObject } from "../helper";
import { GET_INVENTORY_INNER_SUBGRIDLIST } from "../../../../context/constants";
import DataNotFound from "../../../../components/common/DataNotFound";
import useFileExport from "./useFileExport";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";
import { getUserPreveleges } from "../../../../utils/common";

const InvReplenishmentDetails = ({ InnerGridRowdata }) => {
  const {
    claimRx,
    ceID,
    dispensedDate,
    ndc,
    phID,
    wholesalerID,
    refillCode,
    claimCreatedDate,
    dos,
  } = InnerGridRowdata || {};
  const globalClasses = useGlobalStyles();
  const phiAccess = getUserPreveleges("PHI Access");
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const iconsAndButtons = useTableIconsAndButtons();
  const [controller, setController] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});

  const { records: InvsubgridList, loading } = useSelector(
    (state) => state.getinventorySubInnerGrid
  );

  const fetchInvSubGridItemInfo = (payload = {}) => {
    dispatch(
      getinventoryInnerSubGridList(
        {
          rxNumber: InnerGridRowdata.claimRx,
          ceID: InnerGridRowdata.ceID,
          export: false,
          sortBy: "",
          sortOrder: "asc",
          filter: [],
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          dispensedDate: InnerGridRowdata.dispensedDate,
          ndc: InnerGridRowdata.ndc,
          phID: InnerGridRowdata.phID,
          wholesalerID: InnerGridRowdata.wholesalerID,
          refillCode: InnerGridRowdata.refillCode,
          claimCreatedDate: InnerGridRowdata.claimCreatedDate,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            pageNumber: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (claimRx) {
      fetchInvSubGridItemInfo();
    }
    return () => {
      dispatch({ type: GET_INVENTORY_INNER_SUBGRIDLIST, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(InvsubgridList.totalElements / rowsPerPage) || 1;
      if (controller.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.pageNumber;
      fetchInvSubGridItemInfo({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = INVENTORY_INNERSUB_TABLE[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchInvSubGridItemInfo({ sortOrder, sortBy });
    },
    [controller]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getInvInnerSubgridFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchInvSubGridItemInfo({
      ...controller,
      filter: filterPayload,
    });
  };

  const actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: InvsubgridList && InvsubgridList.totalElements < 1,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(InvsubgridList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(InvsubgridList),
      onClick: () =>
        exportToExcel({
          dispensedDate,
          ndc,
          claimRx,
          ceID,
          phID,
          wholesalerID,
          refillCode,
          claimCreatedDate,
          controller,
          columnFilters,
        }),
    },
  ];
  const INVENTORY_INNERSUB_TABLE = [
    {
      title: "Action Date",
      field: "actionDate",
      defaultFilter: enableFilters && columnFiltersRef.current.actionDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.actionDate}>
            <span>{rowData.actionDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.actionDate
                ? moment(columnFiltersRef.current.actionDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Action",
      field: "action",
      defaultFilter: enableFilters && columnFiltersRef.current.action,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.action}>
            <span>{rowData.action}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.action}
          placeholder="Action"
        />
      ),
    },
    {
      title: "Captured Date",
      field: "capturedDate",
      defaultFilter: enableFilters && columnFiltersRef.current.capturedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.capturedDate}>
            <span>{rowData.capturedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            inputReadOnly
            className={globalClasses.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.capturedDate
                ? moment(columnFiltersRef.current.capturedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Ref.No.",
      field: "refNo",
      defaultFilter: enableFilters && columnFiltersRef.current.refNo,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.refNo}>
            <span>{rowData.refNo}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.refNo}
          placeholder="Ref.No."
        />
      ),
    },
    {
      title: "Store #",
      field: "storeNumber",
      defaultFilter: enableFilters && columnFiltersRef.current.storeNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.storeNumber}>
            <span>{rowData.storeNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.storeNumber}
          placeholder="Store #"
        />
      ),
    },
    {
      title: "Dispensed Qty",
      field: "dispensedQty",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensedQty}>
            <span>{rowData.dispensedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensedQty}
          placeholder="Dispensed Qty"
        />
      ),
    },
    {
      title: "Replenished Qty",
      field: "replenishedQty",
      defaultFilter: enableFilters && columnFiltersRef.current.replenishedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishedQty}>
            <span>{rowData.replenishedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishedQty}
          placeholder="Replenished Qty"
        />
      ),
    },
    {
      title: "Returned Qty",
      field: "returnedQty",
      defaultFilter: enableFilters && columnFiltersRef.current.returnedQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.returnedQty}>
            <span>{rowData.returnedQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.returnedQty}
          placeholder="Returned Qty"
        />
      ),
    },
    {
      title: "True Up Qty",
      field: "trueUpQty",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUpQty,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpQty}>
            <span>{rowData.trueUpQty}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUpQty}
          placeholder="True Up Qty"
        />
      ),
    },
    {
      title: "Replenished %",
      field: "replenishedPerc",
      defaultFilter: enableFilters && columnFiltersRef.current.replenishedPerc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishedPerc}>
            <span>{rowData.replenishedPerc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishedPerc}
          placeholder="Replenished %"
        />
      ),
    },
    {
      title: "Total Price",
      field: "totalPrice",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.totalPrice,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.totalPrice}>
                <span>{rowData.totalPrice}</span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalPrice}
          placeholder="Total Price"
        />
      ),
    },
    {
      title: "Wholesaler",
      field: "wholesaler",
      defaultFilter: enableFilters && columnFiltersRef.current.wholesaler,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.wholesaler}>
            <span>{rowData.wholesaler}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.wholesaler}
          placeholder="Wholesaler"
        />
      ),
    },
    {
      title: "Status",
      field: "status",
      defaultFilter: enableFilters && columnFiltersRef.current.status,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.status}>
            <span>{rowData.status}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.status}
          placeholder="Status"
        />
      ),
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <BasicTypography variant="h5">
                RX Number :{" "}
                <span
                  className={
                    phiAccess &&
                    phiAccess.readOnlyFlag &&
                    globalClasses.phiAccessColor
                  }
                >
                  {claimRx}
                </span>
              </BasicTypography>
            </Grid>
            <Grid item xs={12} sm={4}>
              <BasicTypography
                variant="h5"
                title={`Fill Number : ${refillCode}`}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <BasicTypography
                variant="h5"
                title={`Claim Date of Service : ${dos}`}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <BasicTypography
                variant="h5"
                title={`Claim Captured Date : ${claimCreatedDate}`}
              />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Grid className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Replenishment Claim Details (${getTableHeaderCount(
                  InvsubgridList.totalElements
                )})`}
              />
            }
            columns={INVENTORY_INNERSUB_TABLE}
            data={InvsubgridList.content || []}
            page={controller.pageNumber - 1}
            totalCount={InvsubgridList.totalElements || 0}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={actions}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              exportAllData: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(InvsubgridList)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default memo(InvReplenishmentDetails);
