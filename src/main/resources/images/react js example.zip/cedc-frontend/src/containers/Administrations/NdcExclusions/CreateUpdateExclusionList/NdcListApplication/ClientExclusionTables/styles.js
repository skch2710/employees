import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../../../utils/helper";

export const useNdcTablesStyles = makeStyles((_theme) => ({
  actionButtonContainer: {
    paddingTop: "70px",
  },
  gridTableContainer: {
    width: "43%",
  },
  gridActionBtnContainer: {
    width: "12%",
  },
}));

export const useNdcDetailsTablesStyles = makeStyles((_theme) => ({
  muiToolbar: (props) => {
    return {
      marginRight: getGridActionButtonsMarginRight(props),
      marginTop: "-38px",
      marginBottom: "6px",
      paddingLeft: "6px",
      minHeight: "30px",
    };
  },
}));
