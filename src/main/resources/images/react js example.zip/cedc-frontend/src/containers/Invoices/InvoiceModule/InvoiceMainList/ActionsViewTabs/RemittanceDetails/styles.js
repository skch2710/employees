import { makeStyles } from "@material-ui/core";

export const useRemittanceDetailsStyle = makeStyles((theme) => {
  return {
    summaryWrapper: {
      border: `1px solid ${theme.colors.primary.default}`,
      borderRadius: "5px",
      boxShadow: `0 0 18px 0 ${theme.colors.monochrome.cardBoxShadow}`,
      lineHeight: "1.62857143",
      marginBottom: "16px",
    },
    summaryTitleWrapper: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 15px",
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
      "& svg": {
        color: theme.colors.white.default,
      },
    },
    collapseContainer: {
      padding: "10px 0",
    },
    radioContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    radio: {
      margin: "0 !important",
    },
    commonHeaderStyle: {
      backgroundColor: theme.colors.primary.default,
      color: theme.colors.white.default,
    },
    ceRemittanceTotals: {
      "& tr": {
        borderBottom: `1px solid ${theme.colors.monochrome.border}`,
        padding: "3px",
      },
      "& td": {
        fontSize: "13px",
        padding: "2px 19px 7px 0px",
        color: theme.colors.monochrome.offBlack,
      },
      width: "100%",
      margin: "14px 0px 0px 0px",
      borderBottom: `1px solid ${theme.colors.monochrome.border}`,
    },
    totalValues: {
      textAlign: "right",
    },
    labelstextColor: {
      color: theme.colors.monochrome.offBlack,
      fontWeight: "600",
    },
    valueTextColor: {
      color: theme.colors.monochrome.offBlack,
      textAlign: "right",
    },
    ceNetDueValue: {
      padding: "5px",
      color: theme.colors.monochrome.offWhite,
      textAlign: "right",
      fontWeight: "bold",
      paddingRight:"19px"
    },
    ceNetDueLabel: {
      padding: "2px",
      color: theme.colors.monochrome.offWhite,
      fontWeight: "bold",
    },
    netDueCe: {
      background: theme.colors.green.secondary
    },
    summaryTable: {
      margin: "14px 0px 0px 0px",
      width: "100%",
    },
    pdfAlignment: {
      textAlign: "end",
    },
    directPlusFees: {
      textAlign: "end",
      color: theme.colors.monochrome.offBlack,
    },
    directPlusFeesTitle: {
      color: theme.colors.monochrome.offBlack,
      padding: "0px 0px 9px 0px",
      textAlign:"right",
    },
    dollarSymbol: {
      paddingRight: "16px",
    },
    tableDollarValues:{
      textAlign:"right"
    },
    directPlusFeesGrid: {
      padding: "0px 24px 7px 18px",
    },
    directPlusFeesvalues: {
      textAlign: "right",
      color: theme.colors.monochrome.offBlack,
    },
    totals: {
      fontWeight: "600",
      color: theme.colors.monochrome.offBlack,
      textAlign: "right",
      //padding: "0px 14px 9px 14px",
      "& td": {
        fontWeight: "600",
        color: theme.colors.monochrome.offBlack,  
        fontSize: "11px",
        textAlign: "right",
        paddingRight:"12px !important"
      },
    },
    totalTitle: {
      textAlign: "left !important",
    },
    totalValuesInBold: {
      textAlign: "right",
      fontWeight: "bold",
      color: theme.colors.monochrome.offBlack,
    },
    detailsSummary: {
      borderBottom: `1px solid ${theme.colors.monochrome.border}`,
    },
    insuredClaimsText: {
      color: theme.colors.primary.default,
    },
    exportPdf: {
      border: `1px solid ${theme.colors.monochrome.border}`,
      float: "right",
      padding: "1px 6px 2px 2px",
      fontSize: "12px",
      textTransform: "capitalize",
    },
    tableTitle: {
      paddingRight: "30px",
      paddingLeft:"15px"
    },
    dollarPadding:{
      paddingRight:"45px"
    }
  };
});

