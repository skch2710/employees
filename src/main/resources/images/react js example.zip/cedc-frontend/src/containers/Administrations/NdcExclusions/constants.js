export const NDC_TABS = {
  NDC_BASIC_DETAILS: 1,
  NDC_SELECTION: 2,
  NDC_LIST_APPLICATION: 3,
  NDC_LIST_REVIEW: 4,
};

export const INDEX_TO_NDC_TABS = {
  1: "NDC_BASIC_DETAILS",
  2: "NDC_SELECTION",
  3: "NDC_LIST_APPLICATION",
  4: "NDC_LIST_REVIEW",
};

export const NDC = "ndc";
export const COVERED_ENTITY = "coveredEntity";
export const PHARMACY_STORE = "phStore";

export const NDC_SELECTION_SEARCH_RESULT_FILE_EXPORT_NAME = "Search Results";
