import { makeStyles } from "@material-ui/core";

export const usePhBasicDetailsStyle = makeStyles((theme) => {
  return {
    basicDetailsWrapper: {
      border: `1px solid ${theme.colors.monochrome.cardBorder}`,
      borderRadius: "10px",
      boxShadow: `0 0 18px 0 ${theme.colors.monochrome.cardBoxShadow}`,
      lineHeight: "1.42857143",
    },
    basicDetailsTitleWrapper: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 15px",
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
    },
    collapseContainer: {
      padding: "10px 15px",
    },
    toggle: {
      display: "flex",
      alignItems: "center",
      gap: "5px",
    },
  };
});
