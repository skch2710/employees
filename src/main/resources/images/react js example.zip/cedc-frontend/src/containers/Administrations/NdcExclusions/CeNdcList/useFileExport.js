import FileSaver from "file-saver";
import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import { getNdcListExport } from "../../../../context/actions/NdcExclusions";
import { notNull } from "../../../../utils/constants";
import { getDefaultNdcListExportPayload } from "../helpers";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { controllers, columnFilters, formRef, formSubmittedValues } = props;
    const { isSubmitting, values } = (formRef && formRef.current) || {};
    dispatch(
      getNdcListExport(
        {
          ...getDefaultNdcListExportPayload(formSubmittedValues),
          sortBy: controllers.sortBy,
          sortOrder: controllers.sortOrder,
          filter: columnFilters,
          export: true,
          isList: false,
          isCoveredEntity: true,
          isPhGroup: false,
          ...(isSubmitting ? { ...[values.ceID] } : {}),
        },
        (result) => {
          var data =
            result.content &&
            result.content.map(
              ({
                status,
                listName,
                coveredEntity,
                hrsaId,
                listAppliedDate,
                listTerminationDate,
                createdBy,
                lastUpdatedBy,
                lastUpdatedDate,
              }) => ({
                Status: notNull(status),
                "List Name": notNull(listName),
                "Covered Entity": notNull(coveredEntity),
                "Covered Entity HRSA ID": notNull(hrsaId),
                "List Applied Date": notNull(listAppliedDate),
                "List Termination Date": notNull(listTerminationDate),
                "Created By": notNull(createdBy),
                "Last Updated By": notNull(lastUpdatedBy),
                "Last Updated Date": notNull(lastUpdatedDate),
              })
            );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Covered Entity List" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
