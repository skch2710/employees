import React, { useState, useEffect, useContext } from "react";
import { useDispatch } from "react-redux";
import { Formik, Form, Field } from "formik";
import { getACHConfigurationDefaultValues } from "../../../../../../utils/constants";
import { Button, Grid, Switch, FormLabel } from "@material-ui/core";
import Tooltip from "@material-ui/core/Tooltip";
import {
  getRulesList,
  getOperandsList,
  saveEligibilityRules,
} from "../../../../../../context/actions/EligibilityRules";
import {
  fetchTermsGridTableData,
  getCoEligibilityConfig,
  getEligibilityRules,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";

const CeEligibilityRules = ({ permissionObj, clickOnAdd }) => {
  const defaultValues = getACHConfigurationDefaultValues();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const {
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    messageUuid,
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext);
  const CEID = messageUuid && messageUuid.ceid !== null && messageUuid.ceid;
  const { ceEligibility } = menusStatuses;

  const [initialState, setInitialState] = useState([]);
  const [rulesList, setRulesList] = useState([]);
  const [additionalRules, setAdditionalRules] = useState([]);
  const [operands, setOperands] = useState([]);

  const rulesFromAPI = [];
  const additionalRulesFromAPI = [];

  const updatedRules = (data) => {
    data.map((item, index) => {
      if (index < 8) {
        rulesFromAPI.push({
          rule: item.description,
          id: item.id,
          ruleId: null,
          status: false,
          disable: false,
          selected: false,
          selectedItems: [],
          isActive: false,
        });
      } else {
        additionalRulesFromAPI.push({
          rule: item.description,
          id: item.id,
          ruleId: null,
          status: false,
          isActive: false,
        });
      }
    });

    let defaultState = [];
    data.map((item, index) => {
      if (index < 8) {
        defaultState.push({
          rule: item.description,
          id: item.id,
          ruleId: null,
          status: false,
          disable: false,
          selected: false,
          selectedItems: [],
          isActive: false,
        });
      }
    });
    setInitialState(defaultState);
  };

  const setRulesAndConditions = (data) => {
    let dupData = JSON.parse(JSON.stringify(rulesFromAPI));
    let i = 0;
    dupData.map((item) => {
      if (i < data.length && data[i].ruleId === item.id) {
        item.isActive = true;
        item.selected = true;
        item.status = true;
        item.ruleId = data[i].id;
        let dependencyList = [];
        for (let id1 = 1; id1 <= 10; id1++) {
          let oper = "operId" + id1;
          let rule = "ruleId" + id1;
          if (data[i][oper] && data[i][rule]) {
            let obj = { condition: data[i][oper], dependency: data[i][rule] };
            dupData.map((item1) => {
              if (item1.id === data[i][rule]) {
                item1.disable = true;
                item1.selected = true;
              }
            });
            dependencyList.push(obj);
          } else if (data[i][oper]) {
            let obj = { condition: data[i][oper], dependency: 0 };
            dupData.map((item1) => {
              if (item1.id !== item.id) item1.disable = true;
            });
            dependencyList.push(obj);
          }
        }
        item.selectedItems = dependencyList;
        i += 1;
      }
    });
    setRulesList(dupData);

    let dupAdditional = JSON.parse(JSON.stringify(additionalRulesFromAPI));

    for (let index = 0; index < data.length; index++) {
      if (data[index].ruleId > 8) {
        i = index;
        break;
      }
    }
    dupAdditional.map((item) => {
      if (i < data.length && item.id === data[i].ruleId) {
        item.selected = true;
        item.status = true;
        item.ruleId = data[i].id;
        i += 1;
      }
    });
    setAdditionalRules(dupAdditional);
  };

  // status: Toggle ON/OFF
  // disable: dependency disable or not
  //selected: true when dependency selected either on toggle or on dropdown
  //selectedItems: track all the conditions and rules for a particular dependency

  const fetchRulesAndConditions = async () => {
    const rules = await dispatch(getRulesList());
    updatedRules(rules);

    const conditions = await dispatch(getOperandsList());
    setOperands(conditions);

    const rulesAndConditions = await dispatch(
      getEligibilityRules({ ceID: CEID })
    );
    rulesAndConditions && setRulesAndConditions(rulesAndConditions);
  };

  useEffect(() => {
    fetchRulesAndConditions();
  }, []);

  const handleChangeToggle = (index) => {
    let data = [...rulesList];
    data[index].status = !data[index].status;
    // if toggle is ON
    if (data[index].status === true) {
      data[index].selected = true;
      let addElement = { condition: 0, dependency: 0 };
      data[index].selectedItems = [];
      data[index].selectedItems.push(addElement);

      setRulesList(data);
    }
    // if toggle is OFF
    else {
      if (data[index].selectedItems[0].condition === 3) {
        data.map((item, i) => {
          if (index != i) item.disable = false;
        });
      }
      const dependencies = [];
      data[index].selectedItems.map((item) => {
        dependencies.push(item.dependency);
      });
      data.map((item) => {
        if (dependencies.includes(item.id)) {
          item.selected = false;
          item.disable = false;
        }
      });
      data[index].selected = false;
      data[index].selectedItems = [];
      data[index].isActive = false;
      setRulesList(data);
    }
  };

  const handleChangeCondition = (e, index, i) => {
    const targetValue = parseInt(e.target.value);

    //previous only
    if (rulesList[index].selectedItems[i].condition === 3) {
      let data = [...rulesList];
      data.map((item, i) => {
        if (index != i) item.disable = false;
      });
      setRulesList(data);
    }
    //present and, or
    if (targetValue === 1 || targetValue === 2) {
      let data = [...rulesList];
      data[index].selectedItems[i].condition = targetValue;
      setRulesList(data);
    }

    //present only
    else if (targetValue === 3) {
      let data = JSON.parse(JSON.stringify(initialState));
      let addElement = [{ condition: 3, dependency: 0 }];
      data.map((item, i) => {
        if (i === index) {
          item.selected = true;
          item.status = true;
          item.selectedItems = addElement;
        } else item.disable = true;
      });
      setRulesList(data);
    }
    //remove condition
    else if (e.target.value === "REMOVE") {
      let data = [...rulesList];
      const removedRuleId = data[index].selectedItems[i].dependency;
      data.map((item, j) => {
        if (j === index) {
          item.selectedItems.splice(i, 1);
          let length = item.selectedItems.length;
          if (item.selectedItems[length - 1].condition !== 0) {
            let newDependency = { condition: 0, dependency: 0 };
            item.selectedItems.push(newDependency);
          }
        }
      });

      // data.splice(data[index].selectedItems[i], 1)
      // data[index].selectedItems[i].condition = "REMOVE";
      // data[index].selectedItems[i].dependency = 0;

      data.map((item) => {
        if (item.id === removedRuleId) {
          item.selected = false;
          item.disable = false;
          item.status = false;
        }
      });
      setRulesList(data);
    }
  };

  const handleChangeDependency = (e, index, i) => {
    // to enable previous dependency
    let data = [...rulesList];
    const prevDependency = rulesList[index].selectedItems[i].dependency;
    if (prevDependency != "") {
      data.map((item) => {
        if (item.id === prevDependency) {
          item.disable = false;
          item.selected = false;
        }
      });
    }
    // to disable present dependency
    const presentDependency = parseInt(e.target.value);

    data.map((item) => {
      if (item.id === presentDependency) {
        item.disable = true;
        item.selected = true;
      }
    });
    // to display new dropdown for conditions
    data[index].selectedItems[i].dependency = parseInt(e.target.value);
    if (data[index].selectedItems.length - 2 < i && returnLength() > 0) {
      let addElement = { condition: 0, dependency: 0 };
      data[index].selectedItems.push(addElement);
    }
    setRulesList(data);
  };
  // return count of selected dependencies
  const returnLength = () => {
    let length = 0;
    rulesList.map((item) => {
      if (item.selected === false) length += 1;
    });
    return length;
  };

  const handleChangeAdditionalRule = (index) => {
    let data = [...additionalRules];
    data[index].status = !data[index].status;
    setAdditionalRules(data);
  };

  const handleFormSubmit = async (values) => {
    let saveRulesJson = [];
    let data = [...rulesList];
    data.map((item) => {
      if (item.status) {
        let obj = {};
        obj.id = item.ruleId;
        obj.ceid = CEID;
        obj.ruleId = item.id;
        let count = 0;
        for (let i = 0; i < item.selectedItems.length; i++) {
          let iterateItems = item.selectedItems[i];
          if (iterateItems.condition !== 0) {
            count += 1;
            let val = i + 1;
            obj["operId" + val] = iterateItems.condition;
            if (iterateItems.condition === 3) obj["ruleId" + val] = null;
            else
              obj["ruleId" + val] =
                iterateItems.dependency == 0 ? null : iterateItems.dependency;
          }
        }
        for (let i = count + 1; i <= 10; i++) {
          obj["operId" + i] = null;
          obj["ruleId" + i] = null;
        }
        obj["isActive"] = true;
        // if (editRules) obj.id = 5;
        saveRulesJson.push(obj);
      } else if (item.ruleId != null && item.isActive === false) {
        let obj = {};
        obj.id = item.ruleId;
        obj.ceid = CEID;
        obj.ruleId = item.id;

        for (let i = 1; i <= 10; i++) {
          obj["operId" + i] = null;
          obj["ruleId" + i] = null;
        }
        obj["isActive"] = false;
        saveRulesJson.push(obj);
      }
    });
    let data1 = [...additionalRules];
    data1.map((item) => {
      if (item.status) {
        let obj = {};
        obj.id = item.ruleId;
        obj.ceid = CEID;
        obj.ruleId = item.id;
        for (let i = 1; i <= 10; i++) {
          obj["operId" + i] = null;
          obj["ruleId" + i] = null;
        }
        obj["isActive"] = true;
        // if (editRules) obj.id = 5;
        saveRulesJson.push(obj);
      } else if (item.ruleId != null && item.isActive === false) {
        let obj = {};
        obj.id = item.ruleId;
        obj.ceid = CEID;
        obj.ruleId = item.id;

        for (let i = 1; i <= 10; i++) {
          obj["operId" + i] = null;
          obj["ruleId" + i] = null;
        }
        obj["isActive"] = false;
        saveRulesJson.push(obj);
      }
    });
    saveRules(saveRulesJson, values);
  };

  const saveRules = async (payload, values) => {
    const res = await dispatch(saveEligibilityRules(payload));
    if (res.statusCode === 200) {
      !clickOnAdd && dispatch(getCoEligibilityConfig(messageUuid.ceid));
      if (clickOnAdd || ceEligibility) {
        dispatch(
          updateSectionStatus({
            ceId: messageUuid.ceid,
            sectionId: 4,
            callback,
          })
        );
      }
      // setRulesAndConditions(res.data);
      if (values.stopNavigation) setOpenAddCePopup(false);
      else setPopupActiveMenu(MENUS.CE_ORDERING_CONFIGURATION);
    }
  };

  const callback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({
        ...prev,
        ceEligibility: false,
      }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  return (
    <Formik initialValues={defaultValues} onSubmit={handleFormSubmit}>
      {({ setFieldValue, handleSubmit }) => (
        <>
          <Form>
            <Grid container spacing={2}>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <BasicTypography
                      variant="h4"
                      title="Entity Details > Eligibility Rules"
                    />
                  </Grid>
                  <Grid item md={12}>
                    <BasicTypography variant="subtitle2">
                      Select all eligibility requirements that will be used to
                      determine eligibility for the Covered Entity's 340B
                      Program
                    </BasicTypography>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2}>
                  {rulesList.map((eachField, index) => {
                    return (
                      <Grid item md={12} key={index}>
                        <Grid container spacing={2}>
                          <Grid item md={3}>
                            <Field
                              name={eachField.id}
                              component={Switch}
                              checked={eachField.status}
                              onChange={() => handleChangeToggle(index)}
                              size="small"
                              color="primary"
                              disabled={eachField.disable}
                            />
                            <label style={{ fontSize: "11px" }}>
                              {eachField.rule}
                            </label>
                          </Grid>
                          <Grid item md={9}>
                            <Grid container spacing={1}>
                              {eachField.selectedItems.map((eachItem, i) => {
                                return (
                                  <Grid item md={4}>
                                    <Grid container spacing={1}>
                                      <Grid item md={4}>
                                        <Field as="select" name="and">
                                          {(props) => {
                                            const { field } = props;
                                            return (
                                              <select
                                                {...field}
                                                className={
                                                  globalClasses.formControl
                                                }
                                                onChange={(e) =>
                                                  handleChangeCondition(
                                                    e,
                                                    index,
                                                    i
                                                  )
                                                }
                                                value={
                                                  eachField.selectedItems[i]
                                                    .condition
                                                }
                                              >
                                                <option
                                                  value={0}
                                                  disabled
                                                  selected
                                                >
                                                  Select Logical Condition
                                                </option>
                                                {operands.map((item) => {
                                                  if (item.operid < 3) {
                                                    return (
                                                      <option
                                                        value={item.operid}
                                                      >
                                                        {item.opcode}
                                                      </option>
                                                    );
                                                  }
                                                  if (
                                                    i == 0 &&
                                                    item.operid == 3 &&
                                                    (index <= 1 || index == 3)
                                                  ) {
                                                    return (
                                                      <option
                                                        value={item.operid}
                                                      >
                                                        {item.opcode}
                                                      </option>
                                                    );
                                                  }
                                                })}
                                                <option
                                                  value="REMOVE"
                                                  disabled={
                                                    eachItem.dependency === 0
                                                  }
                                                >
                                                  Remove Condition
                                                </option>
                                              </select>
                                            );
                                          }}
                                        </Field>
                                      </Grid>
                                      {eachItem.condition !== 3 &&
                                        eachItem.condition !== 0 && (
                                          <Grid item md={8}>
                                            <Field as="select" name="and">
                                              {(props) => {
                                                const { field } = props;

                                                return (
                                                  <select
                                                    {...field}
                                                    className={
                                                      globalClasses.formControl
                                                    }
                                                    onChange={(e) =>
                                                      handleChangeDependency(
                                                        e,
                                                        index,
                                                        i
                                                      )
                                                    }
                                                    value={
                                                      eachField.selectedItems[i]
                                                        .dependency
                                                    }
                                                  >
                                                    <option
                                                      value={0}
                                                      disabled
                                                      selected
                                                    >
                                                      Select Additional
                                                      Dependencies
                                                    </option>

                                                    {rulesList.map(
                                                      (keysItem, indexVal) => {
                                                        // condition 1 -> display only unselected dependencies,
                                                        // condition 2 -> also display the already selected item in present dropdown and to maintain order
                                                        if (
                                                          keysItem.selected ===
                                                            false ||
                                                          keysItem.id ===
                                                            eachItem.dependency
                                                        ) {
                                                          return (
                                                            <option
                                                              key={indexVal}
                                                              value={
                                                                keysItem.id
                                                              }
                                                            >
                                                              {keysItem.rule}
                                                            </option>
                                                          );
                                                        }
                                                      }
                                                    )}
                                                  </select>
                                                );
                                              }}
                                            </Field>
                                          </Grid>
                                        )}
                                    </Grid>
                                  </Grid>
                                );
                              })}
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    );
                  })}
                  {additionalRules.map((eachRule, index) => {
                    return (
                      <Grid item md={12} key={index}>
                        <Field
                          name={eachRule.id}
                          component={Switch}
                          checked={eachRule.status}
                          onChange={() => handleChangeAdditionalRule(index)}
                          size="small"
                          color="primary"
                        />
                        <FormLabel>{eachRule.rule}</FormLabel>
                      </Grid>
                    );
                  })}
                </Grid>
              </Grid>
              <Grid item md={12}>
                <Grid container spacing={2} justifyContent="flex-end">
                  <Grid item>
                    <Button
                      type={
                        permissionObj !== null && !permissionObj.readWriteFlag
                          ? "submit"
                          : "button"
                      }
                      color="primary"
                      size="small"
                      variant="contained"
                      className={globalClasses.primaryBtn}
                      onClick={() => {
                        setFieldValue("stopNavigation", false);
                        handleSubmit();
                      }}
                    >
                      Next
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => {
                        setPopupActiveMenu(MENUS.CE_ORDERING_CONFIGURATION);
                      }}
                    >
                      Skip
                    </Button>
                  </Grid>
                  <Grid item>
                    <Tooltip
                      title={
                        permissionObj !== null && !permissionObj.readWriteFlag
                          ? "You don't have Permission."
                          : ""
                      }
                    >
                      <span>
                        <Button
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          disabled={
                            permissionObj !== null &&
                            permissionObj.readWriteFlag
                              ? false
                              : true
                          }
                          onClick={() => {
                            setFieldValue("stopNavigation", true);
                            handleSubmit();
                          }}
                        >
                          Save and Exit
                        </Button>
                      </span>
                    </Tooltip>
                  </Grid>
                  <Grid item>
                    <Button
                      type="reset"
                      size="small"
                      variant="outlined"
                      className={globalClasses.secondaryBtn}
                      onClick={() => setOpenAddCePopup(false)}
                    >
                      Cancel
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        </>
      )}
    </Formik>
  );
};

export default CeEligibilityRules;
