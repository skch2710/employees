export const ACCESS_BY_MAPPING = {
  1: "Processed Date",
  2: "Date of Service",
};
