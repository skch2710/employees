import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Tabs, Tab, Grid } from "@material-ui/core";
import LoaderUI from "../../../../components/common/Loader/Loader";
import _isEmpty from "lodash/isEmpty";
import PatientBasicDetails from "./PatientBasicDetails";
import VisitInformation from "./VisitInformation";
import CashPlanConfig from "./CashPlanConfig";
import {
  addPatientDefaultValues,
  getPatientVisitDefaultValue,
} from "../constant";
import PatientVisitInfoTable from "../PatientVisitInfoTable";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import {
  fetchMemberConfigFile,
  getPatientVisitInfo,
} from "../../../../context/actions/Patients";
import _get from "lodash/get";
import { usePatientStyles } from "../style";
import { TabPanel, a11yProps } from "../../../../components/common/Tabs";

const AddPatientForm = (props) => {
  const {
    searchFormRef,
    submitActionType,
    setOpenPopup,
    ceList,
    recordForEdit,
    title,
    patientSearchData,
    defaultFilters,
    isVisitDateExist,
    setIsVisitDateExist,
  } = props || {};
  const classes = usePatientStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const formRef = useRef(null);
  const [value, setValue] = useState(0);
  const viewPatient = title && title === "View Patient";
  const editPatient = title && title === "Edit Patient";
  const addPatient = title && title === "Add Patient";
  const [formData, setFormData] = useState(
    addPatientDefaultValues(searchFormRef, ceList)
  );
  const [isMRNExist, setIsMRNExist] = useState("");
  const [isSlidingScaleExist, setIsSlidingScaleExist] = useState(false);
  const [memberConfigFile, setMemberConfigFile] = useState({});

  useEffect(() => {
    if (viewPatient || editPatient)
      setFormData(
        addPatientDefaultValues(recordForEdit, ceList, memberConfigFile)
      );
    if (editPatient && !_isEmpty(recordForEdit) && recordForEdit.personId)
      dispatch(getPatientVisitInfo(getPatientVisitDefaultValue(recordForEdit)));
  }, [recordForEdit]);

  useEffect(() => {
    setIsVisitDateExist("");
  }, []);

  const addPatientLoading = useSelector((state) => state.addPatient.loading);

  const handleChange = (_e, newValue) => {
    if (formRef && formRef.current == null && value == 1) {
      setFormData(formData);
      formRef.current = { values: formData };
    } else {
      setFormData(formRef && formRef.current && formRef.current.values);
    }
    setValue(newValue);
  };

  useEffect(() => {
    if (formData.ceid) {
      getMemberConfigFile(formData.ceid);
    }
  }, [formData.ceid]);

  const getMemberConfigFile = async (ceId) => {
    const memberConfigFile = await dispatch(fetchMemberConfigFile(ceId));
    !_isEmpty(memberConfigFile) && setMemberConfigFile(memberConfigFile);
  };

  return (
    <>
      {addPatientLoading ? <LoaderUI /> : ""}
      <Grid container spacing={2}>
        <Grid item md={3}>
          <Tabs orientation="vertical" value={value} onChange={handleChange}>
            <Tab
              label="Patient Basic Details"
              classes={{ wrapper: classes.tabLabel }}
              {...a11yProps(0)}
            />
            <Tab
              label="Visit Info"
              classes={{ wrapper: classes.tabLabel }}
              {...a11yProps(1)}
            />
            <Tab
              label="Cash Plan Configuration"
              classes={{ wrapper: classes.tabLabel }}
              {...a11yProps(2)}
            />
          </Tabs>
        </Grid>
        <Grid item md={9}>
          <TabPanel value={value} index={0}>
            <PatientBasicDetails
              setFormData={setFormData}
              formData={formData}
              setValue={setValue}
              setOpenPopup={setOpenPopup}
              viewPatient={viewPatient}
              editPatient={editPatient}
              formRef={formRef}
              isMRNExist={isMRNExist}
              setIsMRNExist={setIsMRNExist}
              patientSearchData={patientSearchData}
            />
          </TabPanel>
          <TabPanel value={value} index={1}>
            {addPatient ? (
              <VisitInformation
                setValue={setValue}
                setOpenPopup={setOpenPopup}
                setFormData={setFormData}
                formData={formData}
                formRef={formRef}
                isVisitDateExist={isVisitDateExist}
                setIsVisitDateExist={setIsVisitDateExist}
                memberConfigFile={memberConfigFile}
                addPatient={addPatient}
              />
            ) : (
              <PatientVisitInfoTable
                patientRowData={recordForEdit}
                setOpenPopup={setOpenPopup}
                setValue={setValue}
                viewPatient={viewPatient}
                editPatient={editPatient}
              />
            )}
          </TabPanel>
          <TabPanel value={value} index={2}>
            <CashPlanConfig
              setOpenPopup={setOpenPopup}
              submitActionType={submitActionType}
              setFormData={setFormData}
              formData={formData}
              viewPatient={viewPatient}
              editPatient={editPatient}
              patientSearchData={patientSearchData}
              defaultFilters={defaultFilters}
              formRef={formRef}
              title={title}
              isMRNExist={isMRNExist}
              isVisitDateExist={isVisitDateExist}
              isSlidingScaleExist={isSlidingScaleExist}
              setIsSlidingScaleExist={setIsSlidingScaleExist}
            />
          </TabPanel>
        </Grid>
      </Grid>
    </>
  );
};

export default AddPatientForm;
