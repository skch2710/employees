export const getCeBasicDetailsDefaultValues = () => {
    return {
      ceName: "",
      addressLine1: "",
      addressLine2: "",
      cityName: "",
      stateId: "",
      zipCode: "",
      hrsaID: "",
      ceTypeId: "",
      startDate: "",
      endDate: "",
      effectiveDate: "",
      contractTerm: "",
      fullName: "",
      emailAddress: "",
      contactNumber: "",
      title: "",
    };
  };
  
 
  export const CeBaicDetailsDefaultValuesFromRes = (res = {}) => {
    return {
      ceName: res.ceName || "",
      addressLine1: res.addressLine1 || "",
      addressLine2: res.addressLine2 || "",
      cityName: res.city || "",
      stateId: res.stateId || "",
      zipCode: res.zip || "",
      hrsaID: res.hrsaId || "",
      ceTypeId: res.ceTypeId || "",
      startDate: res.startDate || "",
      endDate: res.endDate || "",
      effectiveDate: res.effectiveDate || "",
      contractTerm: res.contractTerm || "",
      fullName: res.fullname || "",
      emailAddress: res.emailAddress || "",
      contactNumber: res.contactNumber || "",
      title: res.title || "",
    };
  };
  
  
  export const getbasicDetailsGetData = (basicDetailsGetData = {}) => {
    return {
      ceName: basicDetailsGetData.ceName || "",
      addressLine1: basicDetailsGetData.addressLine1 || "",
      addressLine2: basicDetailsGetData.addressLine2 || "",
      cityName: basicDetailsGetData.city || "",
      stateId: basicDetailsGetData.stateId || "",
      zipCode: basicDetailsGetData.zip || "",
      hrsaID: basicDetailsGetData.hrsaId || "",
      ceTypeId: basicDetailsGetData.ceTypeId || "",
      startDate: basicDetailsGetData.startDate || "",
      endDate: basicDetailsGetData.endDate || "",
      effectiveDate: basicDetailsGetData.effectiveDate || "",
      contractTerm: basicDetailsGetData.contractTerm || "",
      fullName: basicDetailsGetData.fullname || "",
      emailAddress: basicDetailsGetData.emailAddress || "",
      contactNumber: basicDetailsGetData.contactNumber || "",
      title: basicDetailsGetData.title || "",
    };
  };