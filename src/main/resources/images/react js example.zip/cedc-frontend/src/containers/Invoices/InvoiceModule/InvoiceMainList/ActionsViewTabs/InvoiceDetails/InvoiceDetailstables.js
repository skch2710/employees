import React, { useState, useRef, forwardRef } from "react";
import MaterialTable, { MTableToolbar, MTableBody } from "material-table";
import {
  Paper,
  Tooltip,
  useTheme,
  TableCell,
  TableFooter,
  TableRow,
  Grid,
} from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { getTableHeaderCount } from "../../../../../../utils/helper";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { formatValue } from "../../../../../../utils/common";
import { useInvoiceDetailsStyle } from "./styles";
import DataNotFound from "../../../../../../components/common/DataNotFound";

const InvoiceDetailstables = forwardRef(({ data }, ref) => {
  const globalClasses = useGlobalStyles();
  const classes = useInvoiceDetailsStyle();
  const theme = useTheme();
  const iconsAndButtons = useTableIconsAndButtons();

  const [enableFilters, setEnableFilters] = useState(false);
  const tableRef = useRef(null);
  const columnFiltersRef = useRef({});

  const sumOfColumns = (props) => {
    let totalObj = {
      InsuredClaimsSum: 0,
      TotalInvoicedSum: 0,
      DispensingFeeSum: 0,
      DrugCostSum: 0,
      grossSavingsSum: 0,
    };
    props.renderData.forEach((rowData) => {
      totalObj.InsuredClaimsSum += Number(rowData.tfbInsuredClaims);
      totalObj.TotalInvoicedSum += Number(rowData.totalInvoiced);
      totalObj.DispensingFeeSum += Number(rowData.dispensingFee);
      totalObj.DrugCostSum += Number(rowData.drugCost);
      totalObj.grossSavingsSum += Number(rowData.grossSavings);
    });
    return (
      <>
        <MTableBody {...props} />
        <TableFooter>
          <TableRow className={classes.totals}>
            <TableCell className={classes.totalTitle} colSpan={1}>
              Total
            </TableCell>
            <TableCell colSpan={1}></TableCell>
            <TableCell colSpan={1}>
              {formatValue(totalObj.InsuredClaimsSum)}
            </TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.TotalInvoicedSum)}
                </Grid>
              </Grid>
            </TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.DispensingFeeSum)}
                </Grid>
              </Grid>
            </TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.DrugCostSum)}
                </Grid>
              </Grid>
            </TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.grossSavingsSum)}
                </Grid>
              </Grid>
            </TableCell>
          </TableRow>
        </TableFooter>
      </>
    );
  };

  const INVOICE_DETAILS_LIST_COLUMN = [
    {
      title: "Pharmacy Store",
      field: "phName",
      defaultFilter: enableFilters && columnFiltersRef.current.phName,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.phName}>
            <span>{rowData.phName} </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.phName}
          placeholder="Pharmacy Store"
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "pharmacyNPI",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyNPI,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNPI}>
            <span>{rowData.pharmacyNPI}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyNPI}
          placeholder="Pharmacy NPI"
        />
      ),
    },
    {
      title: "# of 340B Insured Claims",
      field: "tfbInsuredClaims",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.tfbInsuredClaims,

      render: (rowData) => {
        return (
          <Tooltip title={rowData.tfbInsuredClaims}>
            <span className={globalClasses.tableNumericPadding}>
              {formatValue(rowData.tfbInsuredClaims)}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.tfbInsuredClaims}
          placeholder="Insured Claims"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Pharmacy EAC",
      field: "totalInvoiced",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.totalInvoiced,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.totalInvoiced}>
                <span className={globalClasses.tableNumericPadding}>
                  {formatValue(rowData.totalInvoiced)}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalInvoiced}
          placeholder="Pharmacy EAC"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },

    {
      title: "Dispensing Fees",
      field: "dispensingFee",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.dispensingFee,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.dispensingFee}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.dispensingFee)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingFee}
          placeholder="Dispensing Fees"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "340B Drug Cost",
      field: "drugCost",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.drugCost,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.drugCost}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.drugCost)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugCost}
          placeholder="340B Drug Cost"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Covered Entity Gross Savings",
      field: "grossSavings",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.grossSavings,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.grossSavings}>
                <span className={globalClasses.tableNumericPadding}>
                  {" "}
                  {formatValue(rowData.grossSavings)}{" "}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.grossSavings}
          placeholder="Covered Entity Gross Savings"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];
  return (
    <div className={classes.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            className={classes.tableTitle}
            title={`Contracted Pharmacies (${getTableHeaderCount(
              data.length
            )})`}
          />
        }
        tableRef={tableRef}
        columns={INVOICE_DETAILS_LIST_COLUMN}
        data={data}
        totalCount={data.length}
        icons={{
          SortArrow: () => TableCustomSortArrow(),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={ACTIONS}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
          Body: (props) => sumOfColumns(props),
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !data ? <DataNotFound /> : "",
          },
        }}
        isLoading={!data}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paging: false,
          showFirstLastPageButtons: false,
          exportButton: false,
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          sorting: true,
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          maxBodyHeight: 200,
          minBodyHeight: 100,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
});

export default InvoiceDetailstables;
