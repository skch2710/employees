import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { getPOClaimExport } from "../../../../context/actions/PurchaseOrders";
import { notNull } from "../../../../utils/constants";
import { CLAIMS_EXPORT_FILE_NAME } from "../constants";

const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { poID, poItemID, controller, columnFilters } = props;
    dispatch(
      getPOClaimExport(
        {
          poID,
          poItemID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
        },
        function (result) {
          var data = result.content.map(
            ({
              itemInvoiceNumber,
              ndc,
              drugName,
              itemPkgs,
              pkgSize,
              poItemStatus,
              claimsMappingFlag,
              noClaimReason,
              wholesalerAccountDivisionCode,
              claimID,
              invoiceDate340BDirect,
              dateOfService,
              rxNumber,
              reFillNo,
              replenishedUnits,
              dispensedUnits,
              dispensingStore,
              receivingStore,
              memberFirstName,
              memberLastName,
              memberID,
              physicianFirstName,
              physicianLastName,
              prescriberID,
              manufacturere,
            }) => ({
              "810 Invoice #": notNull(itemInvoiceNumber),
              NDC: notNull(ndc),
              "Drug Name": notNull(drugName),
              "Item Pkgs": notNull(itemPkgs),
              "Pkg size": notNull(pkgSize),
              "PO Item status": notNull(poItemStatus),
              "Claims Mapped": notNull(claimsMappingFlag),
              "Reason No Claims": notNull(noClaimReason),
              "Wholesaler Account": notNull(wholesalerAccountDivisionCode),
              "Claim ID": notNull(claimID),
              "340B Direct Invoice Date": notNull(invoiceDate340BDirect),
              "Date of Service": notNull(dateOfService),
              "Rx No": notNull(rxNumber),
              "Refill No": notNull(reFillNo),
              "Replenished Units": notNull(replenishedUnits),
              "Dispensed Units": notNull(dispensedUnits),
              "Dispensing Store": notNull(dispensingStore),
              "Receiving Store": notNull(receivingStore),
              "Patient First Name": notNull(memberFirstName),
              "Patient Last Name": notNull(memberLastName),
              "Patient ID": notNull(memberID),
              "Physician First Name": notNull(physicianFirstName),
              "Physician Last Name": notNull(physicianLastName),
              "Physician ID": notNull(prescriberID),
              Manufacturer: notNull(manufacturere),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, CLAIMS_EXPORT_FILE_NAME + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
