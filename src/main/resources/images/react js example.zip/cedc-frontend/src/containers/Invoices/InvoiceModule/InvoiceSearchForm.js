import React, { useState, useEffect } from "react";
import { Formik, Form, Field, FieldArray } from "formik";
import {
  Paper,
  Grid,
  Button,
  IconButton,
  FormLabel,
  Typography,
  Checkbox,
} from "@material-ui/core";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import _get from "lodash/get";
import { IoIosCloseCircleOutline } from "react-icons/io";
import BasicPopup from "../../../components/Popup/BasicPopup";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import AutoComplete from "../../../components/common/AutoComplete";
import {
  getPharmacyGroups,
  getPharmacyStore,
} from "../../../context/actions/Invoice";
import { QUARTER_OPTIONS } from "./constants";
import { getFilteredInvoiceDefaultValue } from "./constants";
import { getAdditionalDateFilterOptions, getMonthsList } from "./helper";
import { useInvoiceStyles } from "./styles";
import { LABELS, setAutoCompleteInputVal } from "../../../utils/constants";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;

const InvoiceSearchForm = (props) => {
  const {
    handleSubmit,
    formRef,
    handleClear,
    ceList = [],
    enableFilters,
    setEnableFilters,
  } = props;
  const dispatch = useDispatch();

  const classes = useInvoiceStyles();
  const globalClasses = useGlobalStyles();

  const defaultValues = getFilteredInvoiceDefaultValue();
  const [pharmacyList, setPharmacyList] = useState([]);
  const [filtersOpen, setFiltersOpen] = useState(true);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);

  const resetStates = () => {
    setPharmacyGroups([]);
  };

  useEffect(() => {
    if (ceList && ceList.length > 0) {
      fetchPharmacyGroups(ceList[0].ceID, true);
    }
  }, [ceList]);

  const onClear = (values) => {
    resetStates();
    handleClear && handleClear(values);
    fetchPharmacyGroups(ceList.length > 0 ? ceList[0].ceID : [0]);
    setEnableFilters(false);
    const payload = {
      ceid: ceList.length > 0 ? [ceList[0].ceID] : [0],
      phGroupId: [0],
    };
    fetchPharmacyStore(payload);
  };

  const fetchPharmacyGroups = (value, disableLoader = false) => {
    const data = {
      ceid: [value],
    };
    dispatch(
      getPharmacyGroups(data, disableLoader, (groups = []) => {
        _isArray(groups) && setPharmacyGroups([...groups]);
      })
    );
  };

  const fetchPharmacyStore = (payload, disableLoader = false) => {
    dispatch(
      getPharmacyStore(payload, disableLoader, (stores = []) => {
        setPharmacyList(stores);
      })
    );
  };

  // Form validation
  const formValidate = (values) => {
    let error = {};
    if (values.ceId == 0) {
      error.ceId = "Please select the Covered Entity";
    }
    return error;
  };

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      validate={formValidate}
      innerRef={formRef}
      enableReinitialize={true}
    >
      {({ values, errors, touched, setFieldValue, initialValues }) => {
        return (
          <Form>
            {filtersOpen ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <Grid container spacing={2} justifyContent="space-between">
                      <Grid item>
                        <BasicTypography variant="h4" title="Filters" />
                      </Grid>
                      <Grid item>
                        <IconButton
                          classes={{
                            root: classes.closeFilterIcon,
                          }}
                        >
                          <IoIosCloseCircleOutline
                            onClick={() => {
                              setFiltersOpen(false);
                            }}
                          />
                        </IconButton>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Covered Entity</FormLabel>
                        <Field
                          as="select"
                          name="ceId"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disabled={ceList.length > 1 ? false : true}
                              disableCloseOnSelect={false}
                              options={_isArray(ceList) ? ceList : []}
                              inputPlaceholder={"Select Covered Entity"}
                              value={
                                (_isArray(ceList) &&
                                  values.ceId &&
                                  ceList.find(
                                    (e) => e.ceID == values.ceId[0]
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue
                                  ? Number(newValue.ceID)
                                  : 0;
                                fetchPharmacyGroups(value);
                                setPharmacyList([]);
                                setFieldValue("phGroupId", 0);
                                setFieldValue("ceId", [value]);
                                setFieldValue("phID", 0);
                              }}
                              getOptionLabel={(option) => option.ceName || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.ceName}
                                  </BasicTypography>
                                );
                              }}
                              textFieldProps={{
                                inputProps: {
                                  name: "ceId",
                                },
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                        {errors.ceId && touched.ceId && (
                          <Typography color="error" variant="caption">
                            {errors.ceId}
                          </Typography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                        {
                          <Field as="select" name="phGroupId">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(pharmacyGroups) ? pharmacyGroups : []
                                }
                                inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                                onChange={(_e, value) => {
                                  setFieldValue("phGroupId", value);
                                  const payload = {
                                    ceid: _get(
                                      values,
                                      "ceID.ceID",
                                      values.ceId
                                    ),
                                    phGroupId: [_get(value, "phGroupId", 0)],
                                  };
                                  fetchPharmacyStore(payload);
                                  setFieldValue("phID", "");
                                }}
                                getOptionLabel={(option) =>
                                  option.phGroupName || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.phGroupName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                        {errors.phGroupId && touched.phGroupId && (
                          <Typography color="error" variant="caption">
                            {errors.phGroupId}
                          </Typography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                        {
                          <Field as="select" name="phID">
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                disableCloseOnSelect={false}
                                options={
                                  _isArray(pharmacyList) ? pharmacyList : []
                                }
                                disabled={!values.phGroupId}
                                inputPlaceholder={`Select ${LABELS.PharmacyStore}`}
                                onChange={(e, value) => {
                                  setFieldValue("phID", value);
                                }}
                                getOptionLabel={(option) => option.phName || ""}
                                renderOption={(option) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.phName}
                                    </BasicTypography>
                                  );
                                }}
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Invoice Period</FormLabel>
                        <Grid container spacing={1}>
                          <Grid item md>
                            <Field as="select" name="invoicePeriodStartDate">
                              {({ field }) => (
                                <DatePicker
                                  placeholder="MM/DD/YYYY"
                                  disabledDate={(date) =>
                                    !date ||
                                    (values.invoicePeriodEndDate &&
                                      !date.isSameOrBefore(
                                        values.invoicePeriodEndDate,
                                        "day"
                                      ))
                                  }
                                  {...field}
                                  onChange={(_e, date) => {
                                    if (!date)
                                      setFieldValue("invoicePeriodEndDate", "");
                                    setFieldValue(
                                      "invoicePeriodStartDate",
                                      date
                                    );
                                  }}
                                  value={
                                    values.invoicePeriodStartDate
                                      ? moment(
                                          values.invoicePeriodStartDate,
                                          "MM/DD/YYYY"
                                        )
                                      : ""
                                  }
                                />
                              )}
                            </Field>
                          </Grid>
                          <Grid item md>
                            <Field as="select" name="invoicePeriodEndDate">
                              {({ field }) => (
                                <DatePicker
                                  placeholder="MM/DD/YYYY"
                                  disabledDate={(date) =>
                                    !date ||
                                    !date.isSameOrAfter(
                                      values.invoicePeriodStartDate,
                                      "day"
                                    )
                                  }
                                  {...field}
                                  onChange={(_e, date) => {
                                    setFieldValue("invoicePeriodEndDate", date);
                                  }}
                                  value={
                                    values.invoicePeriodEndDate
                                      ? moment(
                                          values.invoicePeriodEndDate,
                                          "MM/DD/YYYY"
                                        )
                                      : ""
                                  }
                                />
                              )}
                            </Field>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid container spacing={2} justifyContent="flex-end">
                      <Grid item>
                        <Button
                          type="submit"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                        >
                          Search
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          onClick={() => onClear(initialValues)}
                        >
                          Clear
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            ) : (
              <Button
                type="submit"
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setFiltersOpen(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
};

export default InvoiceSearchForm;
