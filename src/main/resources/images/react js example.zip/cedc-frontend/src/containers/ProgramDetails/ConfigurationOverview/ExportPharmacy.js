import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { getPharmaciesexport } from "../../../context/actions/Pharmacies";
import { useStyles } from "../../../mui-styles/commonTableMuiStyle";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { LABELS,notNull } from "../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver"; 
const fileName = "Pharmacies List"; 
const ExportPharmacy = ({
  ciId,
  sortBy,
  sortOrder,
  endDate,
  startDate,
  status,
  phNetwork,
  phStore,
  count, 
}) => {
  const dispatch = useDispatch();
  const [values, setValues] = useState("");
  const classes = useStyles();

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const dataa = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8" });
    FileSaver.saveAs(dataa, fileName + ".xlsx");
  };
  let heads = [];
  let rows = [];

  const ExportTOPDF = (data) => {
    const listheads = data.map((i) => {
      let keys_heads = {};
      keys_heads[LABELS.CoveredEntity] = Object.keys(i)[0];
      keys_heads["Pharmacy Name"] = Object.keys(i)[1];
      keys_heads["Pharmacy Network"] = Object.keys(i)[2];
      keys_heads["Go-Live Date"] = Object.keys(i)[3];
      keys_heads["Start Date"] = Object.keys(i)[4];
      keys_heads["End Date"] = Object.keys(i)[5];
      keys_heads["Brand Dispensing Fee Third Party $+%"] = Object.keys(i)[6];
      keys_heads["Brand Dispensing Fee Cash $+%"] = Object.keys(i)[7];
      keys_heads["Generic Dispensing Fee Third Party $+%"] = Object.keys(i)[8];
      keys_heads["Generic Dispensing Fee Cash $+%"] = Object.keys(i)[9];
      keys_heads["Specialty Dispensing Fee Third Party $+%"] =
        Object.keys(i)[10];
      keys_heads["Specialty Dispensing Fee Cash $+%"] = Object.keys(i)[11];
      keys_heads["Program Type"] = Object.keys(i)[12];
      keys_heads["Billing Model"] = Object.keys(i)[13];
      keys_heads["Wholesaler"] = Object.keys(i)[14];
      keys_heads["Participating in Cash Program"] = Object.keys(i)[15];
      keys_heads["Configuration Status"] = Object.keys(i)[16];
      heads.push(keys_heads);
    });

    const listrows = data.map((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };
  const handleChange = (e) => {
    setValues(e.target.value);
    let json = {
      ceID: [ciId],
      endDate: endDate,
      phGroupID: 0,
      phID: 0,
      sortBy: sortBy,
      sortOrder: sortOrder,
      startDate: startDate,
      status: status,
      export: true,
    };
    dispatch(
      getPharmaciesexport(json, function (result) {
        var data = result.content.map(
          ({
            coveredEntity,
            pharmacyName,
            pharmacyNetwork,
            goLiveDate,
            startDate,
            endDate,
            brandDispensingFeeThirdParty,
            brandDispensingFeeTCash,
            genericDispensingFeeThirdParty,
            genericDispensingFeeCash,
            specialityDispensingFeeThirdParty,
            specialityDispensingFeeCash,
            programType,
            billingModel,
            wholesaler,
            participatinginCashProgram,
            configStatus,
          }) => ({
            [LABELS.CoveredEntity]: notNull(coveredEntity),
            [LABELS.PharmacyStore]: notNull(pharmacyName),
            [LABELS.PharmacyChain]: notNull(pharmacyNetwork),
            "Go-Live Date": notNull(goLiveDate),
            "Start Date": notNull(startDate),
            "End Date": notNull(endDate),
            "Brand Dispensing Fee Third Party $+%": notNull(
              brandDispensingFeeThirdParty
            ),
            "Brand Dispensing Fee Cash $+%": notNull(brandDispensingFeeTCash),
            "Generic Dispensing Fee Third Party $+%": notNull(
              genericDispensingFeeThirdParty
            ),
            "Generic Dispensing Fee Cash $+%": notNull(
              genericDispensingFeeCash
            ),
            "Specialty Dispensing Fee Third Party $+%": notNull(
              specialityDispensingFeeThirdParty
            ),
            "Specialty Dispensing Fee Cash $+%": notNull(
              specialityDispensingFeeCash
            ),
            "Program Type": notNull(programType),
            "Billing Model": notNull(billingModel),
            Wholesaler: notNull(wholesaler),
            "Participating in Cash Program": notNull(
              participatinginCashProgram
            ),
            "Configuration Status": notNull(configStatus),
          })
        );

        if (e.target.value == "excel") {
          setTimeout(ExportToExcel(data), 5000);
          setValues("");
        }
        if (e.target.value == "pdf") {
          setTimeout(ExportTOPDF(data), 5000);
          const doc = new jsPDF();
          doc.autoTable({
            head: [heads[0]],
            columnStyles: {
              0: { columnWidth: 11 },
              1: { columnWidth: 11 },
              2: { columnWidth: 11 },
              3: { columnWidth: 11 },
              4: { columnWidth: 11 },
              5: { columnWidth: 11 },
              6: { columnWidth: 11 },
              7: { columnWidth: 11 },
              8: { columnWidth: 11 },
              9: { columnWidth: 11 },
              10: { columnWidth: 11 },
              11: { columnWidth: 11 },
              12: { columnWidth: 11 },
              13: { columnWidth: 11 },
              14: { columnWidth: 11 },
              15: { columnWidth: 11 },
              16: { columnWidth: 11 },
            },
            theme: "grid",
            tableWidth: "auto",
            fontStyle: "normal",
            body: [...rows],
          });
          doc.save("pharmacies_sheet.pdf");
          setValues("");
        }
      })
    );
  };

  return (
    <form>
      <fieldset disabled={count > 0 ? false : true} className={classes.exportAlign}>
        <select onChange={handleChange} value={values}>
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default ExportPharmacy;
