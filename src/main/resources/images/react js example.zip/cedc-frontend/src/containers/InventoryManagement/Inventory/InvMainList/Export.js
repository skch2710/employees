import React from "react";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { LABELS, notNull } from "../../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { useDispatch } from "react-redux";
import {
  getDefaultPOListPayload,
  PO_ORDER_EXPORT_FILE_NAME,
} from "../constants";
import { usePOStyles } from "../styles";
import { getPurchaseListExport } from "../../../../context/actions/PurchaseOrders";

const InvListExport = ({ controller, count, columnFilters, formRef }) => {
  const dispatch = useDispatch();
  const classes = usePOStyles();
  const [values, setValues] = React.useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    FileSaver.saveAs(fileData, PO_ORDER_EXPORT_FILE_NAME + ".xlsx");
  };

  const ExportToPDF = (data) => {
    const headers = data.map((items) => {
      return {
        po: Object.keys(items)[0],
        "PO Date": Object.keys(items)[1],
        "Order Type": Object.keys(items)[2],
        [LABELS.PharmacyStore]: Object.keys(items)[3],
        "Wholesaler Account Number": Object.keys(items)[4],
        "Wholesaler Name": Object.keys(items)[5],
        "PO Status": Object.keys(items)[6],
        "PO Total Order Amount": Object.keys(items)[7],
        "PO Total Billed Amount": Object.keys(items)[8],
      };
    });
    const dataRows = data.map((i) => Object.values(i));
    return { headers, dataRows };
  };

  const handleChange = (e) => {
    const { isSubmitting, values } = (formRef && formRef.current) || {};
    setValues(e.target.value);
    dispatch(
      getPurchaseListExport(
        {
          ...getDefaultPOListPayload(),
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
          ...(isSubmitting ? values : {}),
        },
        (result) => {
          var data = result.content.map(
            ({
              poID,
              poDate,
              pharmacy,
              wholeSalerAccountDivisionCode,
              poStatus,
              totalOrderAmount,
              totalBilledAmount,
              wholesaler,
              orderType,
            }) => ({
              "PO#": notNull(poID),
              "PO Date": notNull(poDate),
              "Order Type": notNull(orderType),
              "Pharmacy Name": notNull(pharmacy),
              "Wholesaler Account Number": notNull(
                wholeSalerAccountDivisionCode
              ),
              "Wholesaler Name": notNull(wholesaler),
              "PO Status": notNull(poStatus),
              "PO Total Order Amount": notNull(totalOrderAmount),
              "PO Total Billed Amount": notNull(totalBilledAmount),
            })
          );
          if (e.target.value === "excel") {
            ExportToExcel(data);
          }
          if (e.target.value === "pdf") {
            const { headers, dataRows } = ExportToPDF(data);
            const doc = new jsPDF();
            doc.autoTable({
              head: [headers[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...dataRows],
            });
            doc.save(`${PO_ORDER_EXPORT_FILE_NAME}.pdf`);
          }
          setValues("");
        }
      )
    );
  };

  return (
    <form>
      <fieldset
        disabled={count > 0 ? false : true}
        className={classes.exportContainer}
      >
        <select
          className={classes.exportSelect}
          onChange={handleChange}
          value={values}
        >
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default InvListExport;
