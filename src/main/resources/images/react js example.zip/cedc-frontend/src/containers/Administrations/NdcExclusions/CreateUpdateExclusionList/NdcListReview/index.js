import { Button, FormLabel, Grid } from "@material-ui/core";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import React, { useContext, useEffect, useState } from "react";
import { BsChevronRight, BsPencilSquare } from "react-icons/bs";
import { useDispatch } from "react-redux";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import IcoPdf from "../../../../../assets/ico-pdf.png";
import Toggle from "../../../../../components/common/Toggle";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  fetchNdcSectionStatus,
  getListReviewTabExportPdf,
  getNdcListHistory,
  getNdcListReview,
  getReviewNdcHistory,
} from "../../../../../context/actions/NdcExclusions";
import { getUserSession } from "../../../../../utils/helper";
import { NdcContext } from "../../NdcContext";
import { NDC_TABS } from "../../constants";
import AppliedClientExclusionTable from "./AppliedClientsExclusionTable";
import DynamicListParamsTable from "./DynamicListParamsTable";
import NdcDraftExclusionTable from "./NdcDraftExclusionTable";
import { useNdcListReviewStyles } from "./styles";

const NdcListReview = () => {
  const userSession = getUserSession();
  const globalClasses = useGlobalStyles();
  const classes = useNdcListReviewStyles();
  const dispatch = useDispatch();
  const { handleConfigPopup, ndcData, setProgress, setActiveNdcConfigTab } =
    useContext(NdcContext) || {};

  const [ndcListReview, setNdcListReview] = useState({});
  const [ndcListHistory, setNdcListHistory] = useState([]);
  const [historyObj, setHistoryObj] = useState({
    listId: ndcData.listId,
    listHistoryId: ndcData.listHistoryId,
  });

  useEffect(() => {
    fetchNdcListReview();
    fetchNdcListHistory();
  }, []);

  const fetchNdcListReview = async () => {
    const res = await dispatch(getNdcListReview(historyObj.listHistoryId));
    setNdcListReview(res || {});
  };

  const fetchNdcListHistory = async () => {
    const res = await dispatch(
      getNdcListHistory({ listId: historyObj.listId })
    );
    setNdcListHistory(_isArray(res) ? res : []);
  };

  const onclickViewHistory = async (listObj) => {
    setHistoryObj(listObj);
    const res = await dispatch(getNdcListReview(listObj.listHistoryId));
    setNdcListReview(res || {});
  };

  const handleClickComplete = async () => {
    const resp = await dispatch(getReviewNdcHistory(ndcData.listHistoryId));
    if (resp) {
      getNdcSectionStatus(ndcData.listId);
    }
  };

  const getNdcSectionStatus = async (listId) => {
    const res = await dispatch(fetchNdcSectionStatus(listId));
    !_isEmpty(res) && setProgress(res);
    handleConfigPopup({ state: false });
  };

  const downloadPdf = () => {
    const payload = {
      listId: historyObj.listId,
      listHistoryId: historyObj.listHistoryId,
      userId: userSession.userId,
      roleId: userSession.userRole.role.roleId,
      isInternalUser: userSession.isInternalUser,
    };
    dispatch(getListReviewTabExportPdf(payload));
  };

  const handleNdcApplicationNavigation = () => {
    setActiveNdcConfigTab(NDC_TABS.NDC_LIST_APPLICATION);
  };

  return (
    <Grid container direction="column" spacing={2}>
      <Grid item md={12}>
        <Grid container justifyContent="space-between">
          <Grid item>
            <BasicTypography variant="subtitle" title={"NDC List Review"} />
          </Grid>
          <Grid item>
            <Button
              size="small"
              color="default"
              className={classes.exportPdf}
              onClick={() => downloadPdf()}
            >
              <span>
                <img src={IcoPdf} alt="Active" className="" />
              </span>
              <span>Export</span>
            </Button>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        {/* Details Info */}
        <Grid container spacing={4}>
          <Grid item md={7}>
            <Grid container spacing={4}>
              <Grid item xs={12} sm={4}>
                <FormLabel>NDC Exclusion List Name</FormLabel>
                <BasicTypography
                  variant="subtitle2"
                  className={globalClasses.textEllipsis}
                >
                  {ndcListReview.ndcExclListName || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>List Effective Start Date</FormLabel>
                <BasicTypography variant="subtitle2">
                  {ndcListReview.listEffecStartDate || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>List Effective End Date</FormLabel>
                <BasicTypography variant="subtitle2">
                  {ndcListReview.listEffecEndDate || "--"}
                </BasicTypography>
              </Grid>

              <Grid item xs={12} sm={4}>
                <Grid container spacing={1}>
                  <Grid item>
                    <Toggle
                      rootStyles={{ margin: 0 }}
                      name="applyAutomaticExclusion"
                      checked={
                        ndcListReview.applyAutoExclusion === "Y" ? true : false
                      }
                    />
                  </Grid>
                  <Grid item md={true}>
                    <BasicTypography variant="subtitle2">
                      {ndcListReview.applyAutoExclusion === "Y"
                        ? "Apply Automatic Exclusion"
                        : "No automatic exclusion applied"}
                    </BasicTypography>
                  </Grid>
                </Grid>
              </Grid>

              <Grid item xs={12} sm={4}>
                <FormLabel>
                  Exclusion Type
                  <span
                    className={classes.iconWrapper}
                    onClick={handleNdcApplicationNavigation}
                  >
                    <BsPencilSquare className={classes.editIcon} />
                  </span>
                </FormLabel>
                <BasicTypography variant="subtitle2">
                  {ndcListReview.exclusionType || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>
                  {ndcListReview.exclusionType}
                  <span
                    className={classes.iconWrapper}
                    onClick={handleNdcApplicationNavigation}
                  >
                    <BsPencilSquare className={classes.editIcon} />
                  </span>
                </FormLabel>
                <BasicTypography variant="subtitle2">
                  {ndcListReview.exclusionTypeDetail || "--"}
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item md={5}>
            <Grid container className={classes.listHistoryCard}>
              <Grid item xs={12} className={classes.listHistoryPadding}>
                <BasicTypography variant="h4" title="List History" />
              </Grid>
              <Grid item xs={12}>
                <Grid container>
                  {ndcListHistory.map((item) => (
                    <Grid
                      item
                      xs={12}
                      key={item.listHistoryId}
                      className={classes.historyItemsContainer}
                    >
                      <Grid
                        container
                        className={`${classes.listHistoryPadding} ${classes.listHistoryItem}`}
                      >
                        <Grid item xs={9}>
                          <Grid container>
                            <Grid
                              item
                              xs={12}
                              className={classes.historyItemUser}
                            >
                              <span>{item.user} - </span>
                              {item && item.status && (
                                <span
                                  className={
                                    item.status === "Active"
                                      ? classes.activeHistoryItem
                                      : classes.inactiveHistoryItem
                                  }
                                >
                                  {item.status}
                                </span>
                              )}
                            </Grid>
                            <Grid item xs={12} className={classes.timeStamp}>
                              Timestamp:{item.lastModifiedDate}
                            </Grid>
                          </Grid>
                        </Grid>
                        <Grid
                          item
                          xs={3}
                          className={classes.viewHistoryLinkItem}
                          style={{}}
                        >
                          <span
                            className={classes.viewHistoryLink}
                            onClick={() =>
                              onclickViewHistory({
                                listId: item.listId,
                                listHistoryId: item.listHistoryId,
                              })
                            }
                          >
                            View <BsChevronRight />
                          </span>
                        </Grid>
                      </Grid>
                    </Grid>
                  ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        {/* Dynamic List params Grid */}
        <Grid container spacing={4}>
          <Grid item md={12}>
            <DynamicListParamsTable historyObj={historyObj} />
          </Grid>
        </Grid>
        {/* Applied & Draft Exclusion Grids */}
        <Grid container spacing={4} justifyContent="space-between">
          <Grid item xs={6}>
            <AppliedClientExclusionTable historyObj={historyObj} />
          </Grid>
          <Grid item xs={6}>
            <NdcDraftExclusionTable historyObj={historyObj} />
          </Grid>
        </Grid>
        {/* Form Submit and Cancel Buttons */}
        <Grid container spacing={2} justifyContent="flex-end">
          <Grid item>
            <Button
              type="submit"
              size="small"
              variant="contained"
              className={globalClasses.primaryBtn}
              onClick={() => handleClickComplete()}
            >
              Complete
            </Button>
          </Grid>
          <Grid item>
            <Button
              type="reset"
              size="small"
              variant="contained"
              className={globalClasses.grayButton}
              onClick={() => handleConfigPopup({ state: false })}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default NdcListReview;
