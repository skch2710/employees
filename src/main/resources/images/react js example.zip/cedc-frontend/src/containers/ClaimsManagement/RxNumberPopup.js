import React from "react";
import { Grid, FormLabel, Button, Divider } from "@material-ui/core";
import classNames from "classnames";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import _get from "lodash/get";
import { useClaimsStyles } from "./style";
import ClaimsTimeline from "./ClaimsTimeline";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import { LABELS } from "../../utils/constants";

const RxNumberPopup = ({ popupInfo = {}, handleClose } = {}) => {
  const { timelineData } = popupInfo || {};
  const classes = useClaimsStyles();
  const globalClasses = useGlobalStyles();

  return (
    <Grid container spacing={2} direction="column">
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <FormLabel className={globalClasses.noPaddingForLabels}>
                  Patient Name :
                </FormLabel>
              </Grid>
              <Grid item>
                <BasicTypography
                  variant="subtitle2"
                  classes={{ root: classes.rxInfo }}
                  className={globalClasses.phiAccessColor}
                >
                  {popupInfo.patientName}
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <FormLabel className={globalClasses.noPaddingForLabels}>
                  Action :
                </FormLabel>
              </Grid>
              <Grid item>
                <BasicTypography
                  variant="subtitle2"
                  classes={{ root: classes.rxInfo }}
                >
                  {popupInfo.action}
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <FormLabel className={globalClasses.noPaddingForLabels}>
                  Claim Status :
                </FormLabel>
              </Grid>
              <Grid item>
                <BasicTypography variant="subtitle2">
                  <span
                    className={classNames({
                      [classes.statusTag]: popupInfo.claimStatus,
                    })}
                  >
                    {popupInfo.claimStatus}
                  </span>
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={3}></Grid>
          <Grid item xs={12} sm={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <FormLabel className={globalClasses.noPaddingForLabels}>
                  Rx Number :
                </FormLabel>
              </Grid>
              <Grid item>
                <BasicTypography
                  variant="subtitle2"
                  classes={{ root: classes.rxInfo }}
                  className={globalClasses.phiAccessColor}
                >
                  {popupInfo.rxNumber}
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <FormLabel className={globalClasses.noPaddingForLabels}>
                  Action Date :
                </FormLabel>
              </Grid>
              <Grid item>
                <BasicTypography
                  variant="subtitle2"
                  classes={{ root: classes.rxInfo }}
                >
                  {popupInfo.actionDate}
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <FormLabel className={globalClasses.noPaddingForLabels}>
                  Note :
                </FormLabel>
              </Grid>
              <Grid item>
                <BasicTypography
                  variant="subtitle2"
                  classes={{ root: classes.rxInfo }}
                >
                  {popupInfo.notes}
                </BasicTypography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <ClaimsTimeline timelineData={timelineData} />
      </Grid>
      <Grid item md={12}>
        <div
          className={classNames(
            globalClasses.cardPrimary,
            classes.cardCustomStyles
          )}
        >
          <Grid container spacing={2}>
            <Grid item md={12}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={9}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={3}>
                      <Grid container spacing={2} direction="column">
                        <Grid item>
                          <BasicTypography variant="h4">
                            Basic Details
                          </BasicTypography>
                        </Grid>
                        <Grid item>
                          <Grid container spacing={1} direction="column">
                            <Grid item>
                              <FormLabel>Covered Entity</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.coveredEntity}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.pharmacy}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Provider</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.prescriber}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Location Name</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.entityLocation}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Rx Number</FormLabel>
                              <BasicTypography
                                variant="subtitle2"
                                className={globalClasses.phiAccessColor}
                              >
                                {popupInfo.rxNumber}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Claim Written Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.rxDateWritten}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Claim Dispense Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.dataFilled}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Visit Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.visitDate}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <Grid container spacing={2} direction="column">
                        <Grid item>
                          <BasicTypography variant="h4">
                            Drug and Costs
                          </BasicTypography>
                        </Grid>
                        <Grid item>
                          <Grid container spacing={1} direction="column">
                            <Grid item>
                              <FormLabel>Rx Number</FormLabel>
                              <BasicTypography
                                variant="subtitle2"
                                className={globalClasses.phiAccessColor}
                              >
                                {popupInfo.rxNumber}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Refill Number</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.refillNumber}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Quantity Dispensed</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.dispensedQuantity}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Brand/Generic</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.brandGeneric}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>NDC</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.ndc}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Drug Name</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.drugName}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Savings</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.savings}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Drug Cost</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.drugCost}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Dispensing Fee</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.dispensingFee}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>340BDirect+ Admin Fees</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.adminFee}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <Grid container spacing={2} direction="column">
                        <Grid item>
                          <BasicTypography variant="h4">
                            Replenishment & Invoice
                          </BasicTypography>
                        </Grid>
                        <Grid item>
                          <Grid container spacing={1} direction="column">
                            <Grid item>
                              <FormLabel>PO Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.podate}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Invoice Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {popupInfo.invoiceDate}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                        <Grid item>
                          <BasicTypography variant="h4">
                            Eligibility
                          </BasicTypography>
                        </Grid>
                        <Grid item>
                          <Grid container spacing={1} direction="column">
                            {_isArray(popupInfo.eligibility) &&
                              popupInfo.eligibility.map((item = {}) => {
                                return (
                                  <Grid item>
                                    <FormLabel>Eligibility Metric</FormLabel>
                                    <BasicTypography variant="subtitle2">
                                      {`${item.eligibilityRule} - ${item.eligibilityRuleStatus}`}
                                    </BasicTypography>
                                  </Grid>
                                );
                              })}
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <Grid container spacing={2} direction="column">
                        <Grid item>
                          <BasicTypography variant="h4">
                            Claim History
                          </BasicTypography>
                        </Grid>
                        <Grid item>
                          <Grid container spacing={1} direction="column">
                            {_isArray(popupInfo.claimHistory) &&
                              popupInfo.claimHistory.map((item = {}) => {
                                return (
                                  <Grid item>
                                    <FormLabel>
                                      {`Refill #${item.refillNumber} ${item.refillStatus}`}
                                    </FormLabel>
                                    <BasicTypography variant="subtitle2">
                                      {item.refillDate}
                                    </BasicTypography>
                                  </Grid>
                                );
                              })}
                          </Grid>
                        </Grid>
                        <Grid item>
                          <BasicTypography variant="h4">
                            Visit History
                          </BasicTypography>
                        </Grid>
                        <Grid item>
                          <Grid container spacing={1} direction="column">
                            <Grid item>
                              <FormLabel>Visit Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(popupInfo, "visitHistory.visitDate", "")}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Hospital Service</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(
                                  popupInfo,
                                  "visitHistory.hospitalService",
                                  ""
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Admit Type</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(popupInfo, "visitHistory.admitType", "")}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Servicing Facility</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(
                                  popupInfo,
                                  "visitHistory.servicingFacility",
                                  ""
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Patient Location</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(
                                  popupInfo,
                                  "visitHistory.assignedPatientLocation",
                                  ""
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Provider NPI</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(
                                  popupInfo,
                                  "visitHistory.prescriberNPI",
                                  ""
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Provider First Name</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(
                                  popupInfo,
                                  "visitHistory.prescriberFirstName",
                                  ""
                                )}
                              </BasicTypography>
                            </Grid>
                            <Grid item>
                              <FormLabel>Provider Last Name</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {_get(
                                  popupInfo,
                                  "visitHistory.prescriberLastName",
                                  ""
                                )}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item>
                  <Divider
                    orientation="vertical"
                    classes={{ root: globalClasses.divider }}
                  />
                </Grid>
                <Grid item xs={12} md>
                  <Grid container spacing={2} direction="column">
                    <Grid item>
                      <BasicTypography
                        variant="h5"
                        classes={{ root: classes.auditHistoryTitle }}
                      >
                        Previously Audited By
                      </BasicTypography>
                    </Grid>
                    <Grid item>
                      <Grid container spacing={1} direction="column">
                        {_isArray(popupInfo.auditHistory) &&
                          popupInfo.auditHistory.map((item = {}) => {
                            return (
                              <>
                                <Divider
                                  orientation="horizontal"
                                  classes={{ root: globalClasses.divider }}
                                />
                                <Grid item>
                                  <Grid container direction="column">
                                    <Grid item>
                                      <BasicTypography
                                        classes={{
                                          root: classes.auditedByName,
                                        }}
                                      >
                                        {item.auditedBy}
                                      </BasicTypography>
                                    </Grid>
                                    <Grid item>
                                      <BasicTypography variant="subtitle2">
                                        {`Timestamp: ${item.auditedDate}`}
                                      </BasicTypography>
                                    </Grid>
                                  </Grid>
                                </Grid>
                              </>
                            );
                          })}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid item md={12}>
              <Grid container justifyContent="flex-end" spacing={2}>
                <Grid item>
                  <Button
                    disabled
                    size="small"
                    variant="contained"
                    className={globalClasses.primaryBtn}
                  >
                    Capture
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    disabled
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                  >
                    Capture + Refills
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    disabled
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                  >
                    Reprocess
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    disabled
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                  >
                    Uncapture
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    disabled
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                  >
                    Uncapture + Refills
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    size="small"
                    variant="outlined"
                    className={globalClasses.grayButton}
                    onClick={handleClose}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </div>
      </Grid>
    </Grid>
  );
};
export default RxNumberPopup;
