import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { DatePicker } from "antd";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
} from "../../../../Styles/useGlobalStyles";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import { LABELS, pagination } from "../../../../utils/constants";
import { isEmptyGrid } from "../../../../utils/helper";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { getinvoiceInnerList } from "../../../../context/actions/Invoice";
import { useInvoiceInfoStyle } from "./styles";
import { getInvoiceInnergridFiltersObject } from "../helper";
import { GET_INVOICE_INNER_LIST } from "../../../../context/constants";
import LoaderUI from "../../../../components/common/Loader/Loader";
import DataNotFound from "../../../../components/common/DataNotFound";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import tableIcons from "../MaterialTableIcons";
import useFileExport from "./useFileExport";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import ClientLevelDetailsInfo from "../ClientLevelDetailsInfo";
import { getUserPreveleges } from "../../../../utils/common";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const PharmacyGroupInfo = ({ MainGridData }) => {
  const { ceId, billingPeriod, invoicePeriodStartDate, invoicePeriodEndDate } =
    MainGridData || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const iconsAndButtons = useTableIconsAndButtons();
  const { exportToExcel } = useFileExport();

  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "phGroupName",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [showItemHistory, setShowItemHistory] = useState(false);
  const [showClaims, setShowClaims] = useState(false);
  const [rowData, setRowData] = useState({});
  const [showInnerSubGridItemInfo, setShowInnerSubGridItemInfo] =
    useState(false);
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);

  const { records: invoiceInfoList, loading } = useSelector(
    (state) => state.getInvoiceInnerGrid
  );

  const classes = useInvoiceInfoStyle({
    totalElements: invoiceInfoList.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.page,
  });

  const fetchInvoiceInnerItemInfo = (payload = {}) => {
    dispatch(
      getinvoiceInnerList(
        {
          invoicePeriodStartDate: invoicePeriodStartDate,
          invoicePeriodEndDate: invoicePeriodEndDate,
          ceId: [ceId],
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          billingPeriod: billingPeriod,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setController((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  useEffect(() => {
    if (billingPeriod) {
      fetchInvoiceInnerItemInfo();
    }
    return () => {
      dispatch({ type: GET_INVOICE_INNER_LIST, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(invoiceInfoList.invoiceInfoList / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchInvoiceInnerItemInfo(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controller.sortOrder,
          sortBy: controller.sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, controller, invoiceInfoList]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = INV_INFO_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchInvoiceInnerItemInfo(
        {
          pageNumber: controller.page,
          pageSize: controller.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getInvoiceInnergridFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchInvoiceInnerItemInfo({
      ...controller,
      filter: filterPayload,
    });
  };

  const actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      disabled: invoiceInfoList && invoiceInfoList.totalElements < 1,
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(invoiceInfoList),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(invoiceInfoList),
      onClick: () =>
        exportToExcel({
          ceId,
          billingPeriod,
          invoicePeriodStartDate,
          invoicePeriodEndDate,
          controller,
          columnFilters,
        }),
    },
  ];
  const INV_INFO_COLUMNS = [
    {
      title: LABELS.PharmacyChain,
      field: "phGroupName",
      defaultFilter: enableFilters && columnFiltersRef.current.phGroupName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.phGroupName}>
            <span>{rowData.phGroupName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.phGroupName}
          placeholder={LABELS.PharmacyChain}
        />
      ),
    },
    {
      title: "Billing Period",
      field: "invoicePeriodStartDate",
      render: (InvoiceMainListData) => {
        return (
          <Tooltip
            title={`${InvoiceMainListData.invoicePeriodStartDate} - ${InvoiceMainListData.invoicePeriodEndDate}`}
          >
            <span>{`${InvoiceMainListData.invoicePeriodStartDate} - ${InvoiceMainListData.invoicePeriodEndDate}`}</span>
          </Tooltip>
        );
      },
      defaultFilter: enableFilters && columnFiltersRef.current.billingPeriod,
      customFilterAndSearch: () => true,
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            className={classes.formControl}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            placement="topLeft"
            placeholder="MM/DD/YYYY"
            format="MM/DD/YYYY"
            value={
              columnFiltersRef.current.invoicePeriodStartDate
                ? moment(columnFiltersRef.current.invoicePeriodStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Total Invoiced",
      field: "totalInvoiced",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.totalInvoiced,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.totalInvoiced}>
            <span>{rowData.totalInvoiced}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalInvoiced}
          placeholder="Total Invoiced"
        />
      ),
    },
    {
      title: "Dispensing Fees",
      field: "dispensingFee",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensingFee,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingFee}>
            <span>{rowData.dispensingFee}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingFee}
          placeholder="Dispensing Fees"
        />
      ),
    },
    {
      title: "True Up Fees",
      field: "trueUp",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.trueUp,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUp}>
            <span>{rowData.trueUp}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUp}
          placeholder="True Up Fees"
        />
      ),
    },
    {
      title: "340BDirect+ Fees",
      field: "direct340BTrxnFee",
      type: "numeric",
      defaultFilter:
        enableFilters && columnFiltersRef.current.direct340BTrxnFee,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.direct340BTrxnFee}>
            <span>{rowData.direct340BTrxnFee}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.direct340BTrxnFee}
          placeholder="340BDirect+ Fees"
        />
      ),
    },
  ];

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title=""
        columns={INV_INFO_COLUMNS}
        data={invoiceInfoList.content}
        page={controller.page - 1}
        totalCount={invoiceInfoList.totalElements || 0}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        icons={{
          SortArrow: () => TableCustomSortArrow(controller),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={actions}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controller.pageSize,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          pageSizeOptions: isEmptyGrid(invoiceInfoList)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
        detailPanel={[
          {
            render: (rowData) => {
              return <ClientLevelDetailsInfo InnerGridRowdata={rowData} />;
            },
          },
        ]}
      />
    </div>
  );
};

export default memo(PharmacyGroupInfo);
