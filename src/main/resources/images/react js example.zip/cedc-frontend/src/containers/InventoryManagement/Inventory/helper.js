export const getInvInnergridFiltersObject = (filters) => {
  const containsToFields = ["claimRx", "dispensedQty", "replenishmentPercentage" , "latestStatus"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "startWith"
        : "=",
      value: filter.value,
    };
  });
};

export const getInvInnerSubgridFiltersObject = (filters) => {
  const containsToFields = ["capturedDate", "actionDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getInvFiltersObject = (filters) => {
  const containsToFields = ["ndc"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "contains"
        : "startWith",
      value: filter.value,
    };
  });
};


export const getScheduleTypeIds = (values) => {
  return values && values.length
    ? { drugDEAClassID: values.map((drug) => drug.drugDEAClassID) }
    : {};
};
