import React, {
  useContext,
  useState,
  useRef,
  forwardRef,
  useImperativeHandle,
  useCallback,
  memo,
} from "react";
import { Grid, Paper, Tooltip, useTheme } from "@material-ui/core";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEqual from "lodash/isEqual";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import { useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import { LABELS, pagination } from "../../../utils/constants";
import { checkDateValue, checkValue } from "../../../utils/common";
import useTermsExport from "./Export/TermsGridExport/useTermsExport";
import { COContext } from "../COContext";
import { MENUS } from "./PopupSidebar/constants";
import {
  getCoveredEntity,
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  getUserSession,
  isEmptyGrid,
} from "../../../utils/helper";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import { getTermsFiltersObject } from "./helper";
import DataNotFound from "../../../components/common/DataNotFound";
import TableProgressBar from "../../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import DatePicker from "../../../components/common/DatePicker";
import Pagination from "../../../components/common/Pagination";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
  getTableActionCellStyles,
} from "../../../Styles/useGlobalStyles";

const TermsGridTable = memo(
  forwardRef((props = {}, ref) => {
    const {
      getTermsGridTableData,
      handleCeForOverview,
      formSubmittedValues,
      setclickOnAdd,
    } = props;
    const tableRef = useRef(null);
    const iconsAndButtons = useTableIconsAndButtons();
    const userSession = getUserSession();
    const globalClasses = useGlobalStyles();
    const { loading, records: termsGridTableData } = useSelector(
      (state) => state.coTermsList
    );
    const { ceList } = useSelector((state) => state.coveredEntities);
    const {
      setOpenAddCePopup,
      setPopupActiveMenu,
      setMessageUuid,
      setCoveredEntityName,
      setCeId,
      setClickedOnPartial,
    } = useContext(COContext);
    const columnFiltersRef = useRef({});

    const { exportToExcel } = useTermsExport();
    const [enableFilters, setEnableFilters] = useState(false);
    const [controllers, setControllers] = useState({
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "",
      sortBy: "",
    });
    const [columnFilters, setColumnFilters] = useState([]);
    const theme = useTheme();

    const pharmacyPermissionObj =
      getUserPermissionOnModuleName("Pharmacies") || {};
    const coPermissionObj =
      getUserPermissionOnModuleName("Configuration Overview") || {};

    useImperativeHandle(ref, () => ({
      // This function will be called when submit button clicked from search component
      submitForm(resp) {
        columnFiltersRef.current = {};
        setControllersOnResp(resp);
      },
      // This function will be called when clear button clicked from search component
      clearForm(payload) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        getTermsGridTableData(payload, (resp) => setControllersOnResp(resp));
      },
    }));

    const setControllersOnResp = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          pageNumber: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };


    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        const rowsPerPage = Number(pageSize);
        const totalPages =
          Math.ceil(termsGridTableData.totalElements / rowsPerPage) || 1;
        if (controllers.pageNumber > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
          currentPage = controllers.pageNumber;
        getTermsGridTableData(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: controllers.sortOrder,
            sortBy: controllers.sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp)
        );
      },
      [columnFilters, termsGridTableData, controllers, formSubmittedValues]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = TERMS_COLUMNS[orderedColumnId].field;
        setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        getTermsGridTableData(
          {
            pageNumber: controllers.pageNumber,
            pageSize: controllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        );
      },
      [controllers, formSubmittedValues, columnFilters, termsGridTableData]
    );

    const handleColumnFilter = (filters = []) => {
      const filterPayload = getTermsFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      getTermsGridTableData(
        {
          ...formSubmittedValues,
          ...controllers,
          filter: filterPayload,
          pageNumber: pagination.page,
        },
        (resp) => setControllersOnResp(resp)
      );
    };

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(termsGridTableData) && _isEmpty(columnFilters),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportButton({
          disabled: isEmptyGrid(termsGridTableData),
        }),
        isFreeAction: true,
        disabled: isEmptyGrid(termsGridTableData),
        onClick: () =>
          exportToExcel({ controllers, formSubmittedValues, columnFilters }),
      },
      {
        icon: iconsAndButtons.AddCeButton(),
        tooltip: "Add Covered Entity",
        tooltip: userSession.isInternalUser
          ? coPermissionObj !== null && !coPermissionObj.readWriteFlag
            ? "You don't have Permission."
            : ""
          : "You don't have Permission.",
        disabled: userSession.isInternalUser
          ? coPermissionObj !== null && coPermissionObj.readWriteFlag
            ? false
            : true
          : true,
        isFreeAction: true,
        onClick: () => {
          setCoveredEntityName("Add Covered Entity");
          setclickOnAdd(true);
          setMessageUuid(false);
          setCeId("");
          setOpenAddCePopup(true);
        },
      },
      (rowData) => {
        return {
          icon: iconsAndButtons.AddPharmacy({
            pharmacyPermissionObj,
            statusId: rowData.ceConfigStatusId,
          }),
          isFreeAction: false,
          tooltip: "Add Pharmacy",
          disabled:
            rowData.ceConfigStatusId === 2 &&
            !pharmacyPermissionObj.readWriteFlag
              ? true
              : rowData.ceConfigStatusId === 1
              ? true
              : false,

          onClick: (_event, rowData) => {
            if (
              rowData.ceConfigStatusId === 2 &&
              pharmacyPermissionObj.readWriteFlag
            ) {
              const currentCoveredEntity =
                getCoveredEntity({
                  ceId: rowData.ceid,
                  ceList,
                })[0] || {};
              setMessageUuid({
                ...currentCoveredEntity,
                ceid: rowData.ceid,
                ceName: rowData.ceName,
              });
              setCeId(rowData.ceid);
              setPopupActiveMenu(MENUS.PH_VIEW_PHARMACIES);
              setOpenAddCePopup(true);
              setCoveredEntityName(rowData.ceName);
            }
          },
        };
      },
    ];

    const TERMS_COLUMNS = [
      {
        title: LABELS.CoveredEntity,
        field: "ceName",
        defaultFilter: enableFilters && columnFiltersRef.current.ceName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={checkValue(rowData.ceName)}>
              <span>{checkValue(rowData.ceName)}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.ceName}
            placeholder="Covered Entity"
          />
        ),
      },
      {
        title: "Configuration Status",
        field: "configStatus",
        defaultFilter: enableFilters && columnFiltersRef.current.configStatus,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip
              title={
                rowData.configStatus === "Complete"
                  ? "Click to view the configured sections"
                  : "Click to complete the configuration"
              }
            >
              <span style={{ cursor: "pointer" }}>
                {rowData.ceConfigStatusId === 2 ? (
                  <a
                    className={`${globalClasses.clickableLink}, ${globalClasses.textDecoration}`}
                    onClick={() => handleCeForOverview(rowData)}
                  >
                    {rowData.configStatus}
                  </a>
                ) : rowData.ceConfigStatusId === 1 &&
                  coPermissionObj.readWriteFlag ? (
                  <a
                    className={`${globalClasses.clickableLink}, ${globalClasses.textDecoration}`}
                    onClick={() => {
                      setClickedOnPartial(true);
                      setCeId(rowData.ceid);
                      setMessageUuid({ ceid: rowData.ceid });
                      setCoveredEntityName(rowData.ceName);
                      setclickOnAdd(false);
                      handleCeForOverview({});
                      setOpenAddCePopup(true);
                    }}
                  >
                    {rowData.configStatus}
                  </a>
                ) : (
                  <span>{rowData.configStatus} </span>
                )}
              </span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <select
              {...props}
              className={globalClasses.formControl}
              onChange={(e) => {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  e.target.value
                );
              }}
              defaultValue={columnFiltersRef.current.configStatus || ""}
            >
              <option value={""}>Select option</option>
              <option value={1}>Partial</option>
              <option value={2}>Complete</option>
            </select>
          );
        },
      },
      {
        title: "Effective Date",
        field: "effectiveDate",
        defaultFilter: enableFilters && columnFiltersRef.current.effectiveDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.effectiveDate || ""}>
              <span>{rowData.effectiveDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.effectiveDate
                  ? moment(columnFiltersRef.current.effectiveDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "340BDirect+ Fee Start Date",
        field: "contractStartDate",
        defaultFilter:
          enableFilters && columnFiltersRef.current.contractStartDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={checkDateValue(rowData.contractStartDate)}>
              <span>{checkDateValue(rowData.contractStartDate)}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.contractStartDate
                  ? moment(columnFiltersRef.current.contractStartDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "340BDirect+ Fee End Date",
        field: "contractEndDate",
        defaultFilter:
          enableFilters && columnFiltersRef.current.contractEndDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.contractEndDate || ""}>
              <span>{rowData.contractEndDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.contractEndDate
                  ? moment(columnFiltersRef.current.contractEndDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "Primary Contact",
        field: "fullname",
        defaultFilter: enableFilters && columnFiltersRef.current.fullname,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.fullname || ""}>
              <span>{rowData.fullname || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.fullname}
            placeholder="Primary Contact"
          />
        ),
      },
      {
        title: "Email Address",
        field: "emailAddress",
        defaultFilter: enableFilters && columnFiltersRef.current.emailAddress,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.emailAddress || ""}>
              <span>{rowData.emailAddress || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.emailAddress}
            placeholder="Email Address"
          />
        ),
      },
      {
        title: "Primary Phone",
        field: "contactNumber",
        defaultFilter: enableFilters && columnFiltersRef.current.contactNumber,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.contactNumber}>
              <span>{rowData.contactNumber}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.contactNumber}
            placeholder="Primary Phone"
          />
        ),
      },
      {
        title: "Active Providers",
        field: "activeProviders",
        defaultFilter:
          enableFilters && columnFiltersRef.current.activeProviders,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.activeProviders || ""}>
              <span>{rowData.activeProviders || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.activeProviders}
            placeholder="Active Providers"
          />
        ),
      },
      {
        title: "Active Patients",
        field: "activeMembers",
        defaultFilter: enableFilters && columnFiltersRef.current.activeMembers,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.activeMembers || ""}>
              <span>{rowData.activeMembers || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.activeMembers}
            placeholder="Active Patients"
          />
        ),
      },
      {
        title: "Active Pharmacies",
        field: "activePharmacies",
        defaultFilter:
          enableFilters && columnFiltersRef.current.activePharmacies,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.activePharmacies || ""}>
              <span>{rowData.activePharmacies || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.activePharmacies}
            placeholder="Active Pharmacies"
          />
        ),
      },
      {
        title: "Percentage",
        field: "percentageOnly",
        defaultFilter: enableFilters && columnFiltersRef.current.percentageOnly,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.percentageOnly || ""}>
              <span>{rowData.percentageOnly || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.percentageOnly}
            placeholder="Percentage"
          />
        ),
      },
      {
        title: "Flat Fee + Percentage",
        field: "flatFeePlusPercentage",
        defaultFilter:
          enableFilters && columnFiltersRef.current.flatFeePlusPercentage,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.flatFeePlusPercentage || ""}>
              <span>{rowData.flatFeePlusPercentage || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.flatFeePlusPercentage}
            placeholder="Flat Fee + Percentage"
          />
        ),
      },
      {
        title: "Flat Fee",
        field: "flatFeePerClient",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.flatFeePerClient,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.flatFeePerClient || ""}>
                  <span>{rowData.flatFeePerClient || ""}</span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.flatFeePerClient}
            placeholder="Flat Fee"
          />
        ),
        headerStyle: {
          ...getTableHeaderStyles(theme),
          ...getTableNumericHeaderStyles(),
        },
      },
      {
        title: "Flat Fee per Claim",
        field: "flatFeePerTransaction",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.flatFeePerTransaction,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.flatFeePerTransaction || ""}>
                  <span>{rowData.flatFeePerTransaction || ""}</span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.flatFeePerTransaction}
            placeholder="Flat Fee per Claim"
          />
        ),
      },
      {
        title: "Pharmacy Chain Gross Savings",
        field: "pharmacyChainGrossSavings",
        defaultFilter:
          enableFilters && columnFiltersRef.current.pharmacyChainGrossSavings,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyChainGrossSavings || ""}>
              <span>{rowData.pharmacyChainGrossSavings || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pharmacyChainGrossSavings}
            placeholder="Pharmacy Chain Gross Savings"
          />
        ),
      },
    ];

    return (
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Covered Entities (${getTableHeaderCount(
                termsGridTableData.totalElements
              )})`}
            />
          }
          columns={TERMS_COLUMNS}
          data={termsGridTableData.content || []}
          page={controllers.pageNumber - 1}
          totalCount={termsGridTableData.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          tableRef={tableRef}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            toolbarButtonAlignment: "right",
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(termsGridTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>
    );
  })
);

export default TermsGridTable;
