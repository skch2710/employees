import React from "react";
import { useFormikContext } from "formik";
import { Button, Grid } from "@material-ui/core";
import { useAchTableStyles } from "./style";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";

const AddAchPopupFooter = (props = {}) => {
  const { setShowAddAchPopup } = props;
  const { submitForm, setFieldValue } = useFormikContext();
  const globalClasses = useGlobalStyles();
  const classes = useAchTableStyles();

  return (
    <Grid container md={12}>
      <Grid item md={12} className={classes.addAchPopupFooterBtnContainer}>
        <Button
          onClick={() => {
            setFieldValue("isExit", true);
            submitForm();
          }}
          className={globalClasses.primaryBtn}
        >
          Save & Exit
        </Button>
        <Button
          className={globalClasses.secondaryBtn}
          onClick={() => {
            setFieldValue("isExit", false);
            submitForm();
          }}
        >
          Save And Add Another
        </Button>
        <Button
          className={globalClasses.cancelBtn}
          onClick={() => setShowAddAchPopup(false)}
        >
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};

export default AddAchPopupFooter;
