import React, { useState, useRef, forwardRef } from "react";
import MaterialTable, { MTableToolbar, MTableBody } from "material-table";
import {
  Paper,
  Tooltip,
  useTheme,
  TableCell,
  TableFooter,
  TableRow,
  Grid,
} from "@material-ui/core";
import _get from "lodash/get";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import { formatValue } from "../../../../../../utils/common";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { getTableHeaderCount } from "../../../../../../utils/helper";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { useRemittanceDetailsStyle } from "./styles";
import DataNotFound from "../../../../../../components/common/DataNotFound";

const RemittanceDetailsGrids = forwardRef(({ res = {} }, ref) => {
  const data = res.remittanceDetailsList;
  const globalClasses = useGlobalStyles();
  const classes = useRemittanceDetailsStyle();
  const theme = useTheme();
  const iconsAndButtons = useTableIconsAndButtons();

  const [enableFilters, setEnableFilters] = useState(false);
  const tableRef = useRef(null);
  const columnFiltersRef = useRef({});

  const sumOfColumns = (props) => {
    let totalObj = {
      InsuredClaimsSum: 0,
      ConnectionFeePayableToPharmacySum: 0,
      UnInsuredClaimsSum: 0,
      TrueUpSum: 0,
      TotalCEReceivableSum: 0,
    };
    props.renderData.forEach((rowData) => {
      totalObj.InsuredClaimsSum += Number(
        rowData.insuredClaimsPharmacyRemittance
      );
      totalObj.UnInsuredClaimsSum += Number(
        rowData.uninsuredClaimsPharmacyRemittance
      );
      totalObj.ConnectionFeePayableToPharmacySum += Number(
        rowData.connectionFeePayableToPharmacy
      );
      totalObj.TrueUpSum += Number(rowData.trueUp);
      totalObj.TotalCEReceivableSum += Number(rowData.totalCEReceivable);
    });
    return (
      <>
        <MTableBody {...props} />
        <TableFooter>
          <TableRow className={classes.totals}>
            <TableCell className={classes.totalTitle} colSpan={1}>
              Total
            </TableCell>
            <TableCell colSpan={1}></TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.InsuredClaimsSum)}
                </Grid>
              </Grid>
            </TableCell>
             { _get(res, "isConnectionFeePayable", 0) !== 0 && (
              <TableCell colSpan={1}>
                <Grid container spacing={1} justifyContent="space-between">
                  <Grid item md={2}>
                    $
                  </Grid>
                  <Grid item md={10}>
                    {formatValue(totalObj.ConnectionFeePayableToPharmacySum)}
                  </Grid>
                </Grid>
              </TableCell>
            )}

            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.UnInsuredClaimsSum)}
                </Grid>
              </Grid>
            </TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.TrueUpSum)}
                </Grid>
              </Grid>
            </TableCell>
            <TableCell colSpan={1}>
              <Grid container spacing={1} justifyContent="space-between">
                <Grid item md={2}>
                  $
                </Grid>
                <Grid item md={10}>
                  {formatValue(totalObj.TotalCEReceivableSum)}
                </Grid>
              </Grid>
            </TableCell>
          </TableRow>
        </TableFooter>
      </>
    );
  };

  const REMITTANCE_DETAILS_LIST_COLUMN = [
    {
      title: "Pharmacy Store",
      field: "phName",
      defaultFilter: enableFilters && columnFiltersRef.current.phName,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.phName}>
            <span>{rowData.phName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.phName}
          placeholder="Pharmacy Store"
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "pharmacyNPI",
      defaultFilter: enableFilters && columnFiltersRef.current.pharmacyNPI,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNPI}>
            <span>{rowData.pharmacyNPI}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyNPI}
          placeholder="Pharmacy NPI"
        />
      ),
    },
    {
      title: "Insured Claims - Pharmacy Remittance",
      field: "insuredClaimsPharmacyRemittance",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter:
        enableFilters &&
        columnFiltersRef.current.insuredClaimsPharmacyRemittance,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.insuredClaimsPharmacyRemittance}>
                <span className={globalClasses.tableNumericPadding}>
                  {formatValue(rowData.insuredClaimsPharmacyRemittance)}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.insuredClaimsPharmacyRemittance}
          placeholder="Insured Claims - Pharmacy Remittance"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },

    {
      title: "Connection Fee payable to Pharmacy",
      field: "connectionFeePayableToPharmacy",
      hidden : _get(res, "isConnectionFeePayable", 0) === 0,
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter:
        enableFilters &&
        columnFiltersRef.current.connectionFeePayableToPharmacy,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.connectionFeePayableToPharmacy}>
                <span className={globalClasses.tableNumericPadding}>
                  {formatValue(rowData.connectionFeePayableToPharmacy)}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.connectionFeePayableToPharmacy}
          placeholder="Connection Fee payable to Pharmacy"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Uninsured Claims - Pharmacy Remittance",
      field: "uninsuredClaimsPharmacyRemittance",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter:
        enableFilters &&
        columnFiltersRef.current.uninsuredClaimsPharmacyRemittance,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.uninsuredClaimsPharmacyRemittance}>
                <span className={globalClasses.tableNumericPadding}>
                  {formatValue(rowData.uninsuredClaimsPharmacyRemittance)}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.uninsuredClaimsPharmacyRemittance}
          placeholder="Uninsured Claims - Pharmacy Remittance"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "True Up",
      field: "trueUp",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.trueUp,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.trueUp}>
                <span className={globalClasses.tableNumericPadding}>
                  {formatValue(rowData.trueUp)}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.trueUp}
          placeholder="TrueUp"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
    {
      title: "Total Covered Entity Receivable",
      field: "totalCEReceivable",
      cellStyle: {
        ...getTableCellStyles(theme),
        textAlign: "right",
      },
      defaultFilter:
        enableFilters && columnFiltersRef.current.totalCEReceivable,
      render: (rowData) => {
        return (
          <Grid container spacing={1} justifyContent="space-between">
            <Grid item md={2}>
              $
            </Grid>
            <Grid item md={10}>
              <Tooltip title={rowData.totalCEReceivable}>
                <span className={globalClasses.tableNumericPadding}>
                  {formatValue(rowData.totalCEReceivable)}
                </span>
              </Tooltip>
            </Grid>
          </Grid>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.totalCEReceivable}
          placeholder="Total Covered Entity Receivable"
        />
      ),
      headerStyle: {
        ...getTableHeaderStyles(theme),
        ...getTableNumericHeaderStyles(),
      },
    },
  ];

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  return (
    <div className={classes.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            className={classes.tableTitle}
            title={`Contracted Pharmacies (${getTableHeaderCount(
              data.length
            )})`}
          />
        }
        tableRef={tableRef}
        columns={REMITTANCE_DETAILS_LIST_COLUMN}
        data={data}
        totalCount={data.length}
        icons={{
          SortArrow: () => TableCustomSortArrow(),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={ACTIONS}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
          Body: (props) => sumOfColumns(props),
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !data ? <DataNotFound /> : "",
          },
        }}
        isLoading={!data}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paging: false,
          showFirstLastPageButtons: false,
          exportButton: false,
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          sorting: true,
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          maxBodyHeight: 200,
          minBodyHeight: 100,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
});

export default RemittanceDetailsGrids;
