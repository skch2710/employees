import React, { forwardRef, memo, useContext, useState } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { TiFilter } from "react-icons/ti";
import moment from "moment";
import { useSelector } from "react-redux";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import TableCustomSortArrow from '../../../../../../components/common/TableCustomSortArrow'
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import { pagination } from "../../../../../../utils/constants";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import {
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import DatePicker from "../../../../../../components/common/DatePicker";
import { NdcContext } from "../../../NdcContext";
import Pagination from "../../../../../../components/common/Pagination";
import _get from "lodash/get";

const NdcClientExceptionsTable = memo(
  forwardRef((_props = {}, ref) => {
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const { ndcClientExceptionData = {} } = useContext(NdcContext) || {};
    const iconsAndButtons = useTableIconsAndButtons();
    const { loading } = useSelector(
      (state) => state.ndcClientExceptionListLoading
    );

    const [enableFilters, setEnableFilters] = useState(false);

    const handleDraftExport = (data = []) => {
      const filteredData = data.map((row = {}) => ({
        "Covered Entity": row.ceName || "",
        "HRSA ID": row.hrsaId || "",
        "Pharmacy Chain": row.pharmacyChain || "",
        "Pharmacy Store": row.pharmacyStore || "",
        "Pharmacy NPI": row.pharmacyNpi || "",
        "Exception Applied Start Date": row.exceptionAppliedStartDate || "",
        "Exception Applied End Date": row.exceptionAppliedEndDate || "",
      }));
      const ws = XLSX.utils.json_to_sheet(filteredData);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "NDC Client Exception List.xlsx");
    };

    const NDC_CLIENT_EXCEPTIONS_COLUMNS = [
      {
        title: "Covered Entity",
        field: "ceName",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ceName}>
              <span>{rowData.ceName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Covered Entity" />
        ),
      },
      {
        title: "HRSA ID",
        field: "hrsaId",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.hrsaId}>
              <span>{rowData.hrsaId}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="HRSA ID" />
        ),
      },
      {
        title: "Pharmacy Chain",
        field: "pharmacyChain",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyChain}>
              <span>{rowData.pharmacyChain}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Pharmacy Chain" />
        ),
      },
      {
        title: "Pharmacy Store",
        field: "pharmacyStore",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyStore}>
              <span>{rowData.pharmacyStore}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Pharmacy Store" />
        ),
      },
      {
        title: "Pharmacy NPI",
        field: "pharmacyNpi",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyNpi}>
              <span>{rowData.pharmacyNpi}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Pharmacy NPI" />
        ),
      },
      {
        title: "Exception Applied Start Date",
        field: "exceptionAppliedStartDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.exceptionAppliedStartDate}>
              <span>{rowData.exceptionAppliedStartDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
      {
        title: "Exception Applied End Date",
        field: "exceptionAppliedEndDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.exceptionAppliedEndDate}>
              <span>{rowData.exceptionAppliedEndDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
    ];

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(ndcClientExceptionData),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(ndcClientExceptionData),
        isFreeAction: true,
        onClick: () => handleDraftExport(ref.current.dataManager.filteredData),
      },
    ];

    return (
      <>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Client Exceptions (${getTableHeaderCount(
                _get(ndcClientExceptionData, "totalElements", 0)
              )})`}
            />
          }
          tableRef={ref}
          columns={NDC_CLIENT_EXCEPTIONS_COLUMNS}
          data={_get(ndcClientExceptionData, "content", [])}
          totalCount={_get(ndcClientExceptionData, "totalElements", 0)}
          icons={{
            SortArrow: () => TableCustomSortArrow(),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            Pagination: (props) => <Pagination {...props} />,
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            selection: true,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: pagination.limit,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(ndcClientExceptionData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </>
    );
  })
);

export default NdcClientExceptionsTable;
