import React from "react";
import { Grid } from "@material-ui/core";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";

const NotAbleToAccess = ({ text }) => {
  return (
    <Grid Container>
      <Grid Item md={12}>
        <BasicTypography
          variant="h5"
          title={text || "Not able to access! Please fill Basic Details"}
        />
      </Grid>
    </Grid>
  );
};

export default NotAbleToAccess;
