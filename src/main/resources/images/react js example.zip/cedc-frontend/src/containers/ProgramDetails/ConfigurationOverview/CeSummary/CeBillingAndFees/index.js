import React, { useCallback, useContext, useEffect, useState } from "react";
import {
  Collapse,
  Divider,
  FormLabel,
  Grid,
  IconButton,
  Paper,
} from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  fetchCeFrequency,
  getBillingFeeContacts,
  getCeAdminBillingFees,
} from "../../../../../context/actions/ConfigOverview/EntityConfiguration/CeBillingAndFees";
import { pagination } from "../../../../../utils/constants";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { BsPencilSquare } from "react-icons/bs";
import AdminFeesTable from "../../popupsdetail/EntityDetails/Billingandfees/AdminFeesTable";
import BillingContactTable from "../../popupsdetail/EntityDetails/Billingandfees/BillingContactTable";
import { useCeSummaryStyle } from "../styles";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";

const CeBillingAndFees = (props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};
  const readWritePermission = getUserPermissionOnModuleName(
    "Configuration Overview"
  ).readWriteFlag;

  const { records: billingContactTableData } =
    useSelector((state) => state.coBillingContactList) || {};

  const { frequency = [] } = useSelector((state) => state.ceFrequency);
  const [isCollapsed, setIsCollapsed] = useState(true);

  const fetchBillingContactTableData = async (payload = {}, callback) => {
    const resp = await dispatch(
      getBillingFeeContacts({
        ceid: selectedCeForOverview.ceid,
        pageNumber: 1,
        pageSize: pagination.billingLimit,
        sortBy: "userId",
        sortOrder: "desc",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(resp) && callback && callback(resp);
  };

  const getAdminFeeTableData = async (payload = {}, callback) => {
    const resp = await dispatch(
      getCeAdminBillingFees({
        ceid: [selectedCeForOverview.ceid],
        pageNumber: 1,
        pageSize: pagination.limit,
        sortBy: "",
        sortOrder: "",
        filter: [],
        export: false,
        ...payload,
      })
    );
    resp && callback && callback(resp);
  };

  useEffect(() => {
    if (selectedCeForOverview.ceid) {
      fetchBillingContactTableData();
      getAdminFeeTableData();
      dispatch(
        fetchCeFrequency(selectedCeForOverview.ceid, { disableLoader: true })
      );
    }
  }, [selectedCeForOverview]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography
              variant="h3"
              title="340BDirect+ Admin Billing and Fees"
            />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={!userSession.isInternalUser || !readWritePermission}
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(selectedCeForOverview.ceName);
                    clickOnPencil(
                      MENUS.CE_BILLING_AND_FEES,
                      selectedCeForOverview.ceid
                    );
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  <BillingContactTable
                    billingContactTableData={billingContactTableData}
                    fetchBillingContactTableData={fetchBillingContactTableData}
                    isAddUserEnable={false}
                  />
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="340BDirect+ Admin Billing and Fees"
                      />
                    </Grid>
                    <Grid item container spacing={2}>
                      <Grid item md={4}>
                        <FormLabel>
                          340B Direct+ Billing Invoice Frequency
                        </FormLabel>
                        <BasicTypography variant="subtitle2">
                          {!_isEmpty(frequency) && frequency[0].freqId === 1
                            ? "Monthly"
                            : !_isEmpty(frequency) && frequency[0].freqId === 2
                            ? "Bi-Monthly"
                            : "--"}
                        </BasicTypography>
                      </Grid>

                      <Grid item md={4}>
                        <FormLabel>Invoice Effective Date</FormLabel>
                        <BasicTypography variant="subtitle2">
                          {(!_isEmpty(frequency) &&
                            frequency[0].invoiceEffectiveDate) ||
                            "--"}
                        </BasicTypography>
                      </Grid>

                      <Grid item md={4}>
                        <FormLabel>First Admin Fee Billing Cycle</FormLabel>
                        <BasicTypography variant="subtitle2">
                          {(!_isEmpty(frequency) &&
                            frequency[0].firstAdminFeeBillingCycle) ||
                            "--"}
                        </BasicTypography>
                      </Grid>
                    </Grid>
                    <Grid item md={12}>
                      <AdminFeesTable
                        getAdminFeeTableData={getAdminFeeTableData}
                        isConfigurable={false}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CeBillingAndFees;
