import React, { memo, useCallback, useState } from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import RemittanceDetailsGrids from "./RemittanceDetailsGrids";
import {
  formatValue,
  formatValueInAccordion,
} from "../../../../../../utils/common";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useRemittanceDetailsStyle } from "./styles";
import classNames from "classnames";

const RemittanceDetailsAccordion = ({ res }) => {
  const classes = useRemittanceDetailsStyle();
  const globalClasses = useGlobalStyles();
  const [isCollapsed, setIsCollapsed] = useState(true);
  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);
  return (
    <Paper className={`${classes.summaryWrapper} ${classes.invoiceTableStyle}`}>
      <Grid container>
        <Grid item xs={12} className={classes.commonHeaderStyle}>
          <div className={classes.summaryTitleWrapper}>
            <BasicTypography
              className={classes.commonHeaderStyle}
              variant="h3"
              title={res.phGroupName}
            />
            <div className={classes.actionBtnContainer}>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item xs={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <RemittanceDetailsGrids res={res} />
            </div>
            <Grid xs={12} container className={classes.directPlusFeesGrid}>
              <Grid xs={12} container direction="column">
                <Grid item>
                  <Grid xs={12} container>
                    <Grid xs={9} item>
                      <BasicTypography
                        variant="h6"
                        className={classNames(
                          classes.directPlusFeesTitle,
                          classes.tableTitle
                        )}
                        title="Total 340BDirect+ Fees"
                      />
                    </Grid>
                    <Grid xs={1} item>
                      <BasicTypography
                        variant="h6"
                        className={classNames(
                          classes.directPlusFeesTitle,
                          classes.dollarPadding
                        )}
                        title="$"
                      />
                    </Grid>
                    <Grid xs={2}>
                      <BasicTypography
                        variant="h6"
                        className={classes.directPlusFeesTitle}
                        title={formatValue(res.totalTfbDirectFees)}
                      />
                    </Grid>
                  </Grid>
                  <Grid xs={12} container>
                    <Grid xs={9} item>
                      <BasicTypography
                        variant="h6"
                        className={classNames(
                          classes.totals,
                          classes.tableTitle
                        )}
                        title={res.phGroupName + "  Net Remittance  "}
                      />
                    </Grid>
                    <Grid xs={1} item>
                      <BasicTypography
                        variant="h6"
                        className={classNames(
                          classes.totals,
                          classes.dollarPadding
                        )}
                        title="$"
                      />
                    </Grid>
                    <Grid xs={2}>
                      <BasicTypography
                        variant="h6"
                        className={classes.totals}
                        title={formatValue(res.netRemittance)}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default memo(RemittanceDetailsAccordion);
