import Button from "@material-ui/core/Button";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Grid from "@material-ui/core/Grid";
import Tooltip from "@material-ui/core/Tooltip";
import { Field, Form, Formik } from "formik";
import _get from "lodash/get";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import React, { useContext, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import BasicPopup from "../../../../../components/Popup/BasicPopup";
import LoaderUI from "../../../../../components/common/Loader/Loader";
import MultiSelectDropdown from "../../../../../components/common/MultiSelectDropdown";
import Toggle from "../../../../../components/common/Toggle";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import { getPhDrugManufacturers } from "../../../../../context/actions/Common";
import {
  fetchNdcSectionStatus,
  getClaimTypes,
  getClientExceptionsData,
  getClientExclusionData,
  getExclusionPhGroups,
  getExclusionTypeValues,
  getExclusionWholesalers,
  getNdcClientRelationshipList,
  getNdcListApplicationData,
  saveNdcListApplication,
} from "../../../../../context/actions/NdcExclusions";
import {
  SET_NDC_CLIENT_EXCLUSIONS,
  SET_NDC_CLIENT_RELATIONSHIP,
} from "../../../../../context/reducers/NdcExclusions/constants";
import { LABELS, pagination } from "../../../../../utils/constants";
import {
  getCeIdsArray,
  getClaimTypeIdArray,
  getUserSession,
  getExcludedData,
} from "../../../../../utils/helper";
import { NdcContext } from "../../NdcContext";
import { NDC_TABS } from "../../constants";
import ClientExclusionTables from "./ClientExclusionTables";
import ClientRelationshipTable from "./ClientRelationshipTable";
import {
  getClientExclusionSearchPayload,
  getClientRelationshipTable,
  getClientSearchFormDefaultValues,
  getCoveredEntityInitialValues,
  getExclusionTypeValueDropdownOption,
  getListApplicationSaveLists,
  getManufacturerInitialValues,
  getPhGroupInitialValues,
  getWholesalerInitialValues,
} from "./helper";
import { useNdcListAppTabStyles } from "./styles";
import AutoComplete from "../../../../../components/common/AutoComplete";

const NdcListApplication = () => {
  const globalClasses = useGlobalStyles();
  const classes = useNdcListAppTabStyles();
  const {
    handleConfigPopup,
    setActiveNdcConfigTab,
    setActiveInactiveTabs,
    ndcData = {},
    setNdcData,
    setNdcClientExceptionData,
    ndcClientExceptionData,
    activeInactiveTabs,
    setProgress,
  } = useContext(NdcContext) || {};
  const formRef = useRef(null);
  const exclTypeChangeContext = useRef({});
  const { ceList } = useSelector((state) => state.coveredEntities);

  const userSession = getUserSession();
  const dispatch = useDispatch();
  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [loading, setLoading] = useState(false);
  const [exclusionTypes, setExclusionTypes] = useState([]);
  const [exclusionTypeValues, setExclusionTypeValues] = useState([]);
  const [claimTypes, setClaimTypes] = useState([]);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);
  const [wholesalerList, setWholeSalerList] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [listApplicationData, setListApplicationData] = useState({});
  const [loadingPrevData, setLoadingPrevData] = useState(false);
  const [typeChangeConfirm, setTypeChangeConfirm] = useState(false);

  const defaultValues = getClientSearchFormDefaultValues();

  const [initialValues, setInitialValues] = useState(defaultValues);

  const { records: clientExclusionsResult } = useSelector(
    (state) => state.ndcClientExclusionsList
  );

  const getApplicationDetails = async (listHistoryId = 0) => {
    setLoadingPrevData(true);
    const listAppData = await dispatch(
      getNdcListApplicationData(listHistoryId)
    );
    if (!_isEmpty(listAppData)) {
      setListApplicationData(listAppData);
      let response = [];
      let dropdownValueArray = [];
      if (listAppData.ndcExcTypeId === 1) {
        response = await dispatch(getPhDrugManufacturers());
        if (_isArray(response)) {
          dropdownValueArray = getExclusionTypeValueDropdownOption({
            type: "manufacturer",
            array: response,
          });
          setManufacturers(response);
        }
      } else if (listAppData.ndcExcTypeId === 2) {
        response = (await getExclusionWholesalers()) || [];
        if (_isArray(response)) {
          dropdownValueArray = getExclusionTypeValueDropdownOption({
            type: "wholesaler",
            array: response,
          });
          setWholeSalerList(response);
        }
      } else if (listAppData.ndcExcTypeId === 3) {
        dropdownValueArray =
          getExclusionTypeValueDropdownOption({
            type: "ce",
            array: ceList,
          }) || [];
      } else if (listAppData.ndcExcTypeId === 4) {
        response = (await getExclusionPhGroups(getCeIdsArray(ceList))) || [];
        if (_isArray(response)) {
          dropdownValueArray = getExclusionTypeValueDropdownOption({
            type: "phGroup",
            array: response,
          });
          setPharmacyGroups(response);
        }
      }
      setExclusionTypeValues(dropdownValueArray);

      const defaultFormValuesObject = {
        ...listAppData,
        claimTypeId: listAppData.claimTypeList,
        applyExclusionsAutomatically:
          listAppData.applyExclAutomatically === "Y" ? true : false,
        ...(listAppData.ndcExcTypeId === 1 && listAppData.ndcExcTypeDtlId
          ? getManufacturerInitialValues({
              value: listAppData.ndcExcTypeDtlId,
              manufacturers: response,
            })
          : {}),
        ...(listAppData.ndcExcTypeId === 2 && listAppData.ndcExcTypeDtlId
          ? getWholesalerInitialValues({
              value: listAppData.ndcExcTypeDtlId,
              wholesalerList: response,
            })
          : {}),
        ...(listAppData.ndcExcTypeId === 3 && listAppData.ndcExcTypeDtlId
          ? getCoveredEntityInitialValues({
              value: listAppData.ndcExcTypeDtlId,
              ceList,
            })
          : {}),
        ...(listAppData.ndcExcTypeId === 4 && listAppData.ndcExcTypeDtlId
          ? getPhGroupInitialValues({
              value: listAppData.ndcExcTypeDtlId,
              pharmacyGroups: response,
            })
          : {}),
      };
      setInitialValues(defaultFormValuesObject);
      setFormSubmittedValues(defaultFormValuesObject);
      getClientExclusionTableData({
        listId: listAppData.listId,
        listHistoryId: listAppData.listHistoryId,
        isEdit: !_isEmpty(listAppData),
      });
      getClientRelationTableData({
        ...defaultFormValuesObject,
        ...listAppData,
      });
    }
    setLoadingPrevData(false);
  };

  useEffect(() => {
    if (userSession.isInternalUser) {
      fetchExclusionTypes();
      fetchClaimTypes();
      if (!_isEmpty(ndcData)) {
        getApplicationDetails(ndcData.listHistoryId);
        getClientExceptionTableData(ndcData.listId);
      }
    }
    return () => {
      dispatch({
        type: SET_NDC_CLIENT_RELATIONSHIP,
        data: {},
      });
      dispatch({
        type: SET_NDC_CLIENT_EXCLUSIONS,
        data: {},
      });
    };
  }, []);

  const getClientExclusionTableData = async (payload = {}, callback) => {
    const searchPayload = getClientExclusionSearchPayload({
      ...payload,
      listId: payload.listId ? [payload.listId] : [],
      listHistoryId: payload.listHistoryId ? payload.listHistoryId : 0,
      isEdit: payload.isEdit ? payload.isEdit : !_isEmpty(listApplicationData),
    });
    const tableData = await dispatch(getClientExclusionData(searchPayload));
    if (!_isEmpty(tableData)) {
      const tableUpdatedRows = getExcludedData({
        originalList: _get(tableData, "content", []),
        draftList: _get(ndcClientExceptionData, "content", []),
        identifierKey: "clientId",
      });
      const tableDataNew = {
        content: tableUpdatedRows,
        totalElements: tableUpdatedRows.length,
      };

      dispatch({
        type: SET_NDC_CLIENT_EXCLUSIONS,
        data: tableDataNew,
      });

      callback && callback(tableUpdatedRows);
    }
  };

  const getClientExceptionTableData = async (listId = "") => {
    const searchPayload = getClientExclusionSearchPayload({
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      export: true,
      listId: [listId],
    });
    const tableData = await dispatch(getClientExceptionsData(searchPayload));
    if (!_isEmpty(tableData)) {
      setNdcClientExceptionData({
        content: tableData.content,
        totalElements: tableData.totalElements,
      });
    }
  };

  // const fetchPharmacyGroups = async (ceIds) => {
  //   const ceIdArray = isAllCeSelected(ceIds)
  //     ? getCeIdsArray(ceList)
  //     : getCeIdsArray(ceIds);
  //   const resp = await dispatch(getPharmacyGroups(ceIdArray));
  //   !_isEmpty(resp) && _isArray(resp) && setPharmacyGroups(resp);
  // };

  // const fetchPharmacies = async (ceIds, phGroupIds) => {
  //   const ceIdArray = isAllCeSelected(ceIds)
  //     ? getCeIdsArray(ceList)
  //     : getCeIdsArray(ceIds);
  //   const resp = await dispatch(
  //     getPharmacyStore({
  //       phGroupId: getPhGroupIdArray(phGroupIds),
  //       ceid: ceIdArray,
  //     })
  //   );
  //   _isArray(resp) && setPharmacyList(resp);
  // };

  const fetchExclusionTypes = async () => {
    const exclusionTypesResponse = (await getExclusionTypeValues()) || [];
    if (_isArray(exclusionTypesResponse)) {
      setExclusionTypes([...exclusionTypesResponse]);
    }
  };

  const fetchClaimTypes = async () => {
    const claimTypesResponse = (await getClaimTypes()) || [];
    if (_isArray(claimTypesResponse)) {
      setClaimTypes([...claimTypesResponse]);
    }
  };

  const getExclusionTypeName = (val) => {
    let name = "Exclusion Type";
    if (Number(val) === 1) {
      name = "Select Manufacturer";
    } else if (Number(val) === 2) {
      name = "Select Wholesaler";
    } else if (Number(val) === 3) {
      name = "Select Covered Entity";
    } else if (Number(val) === 4) {
      name = "Select Pharmacy Chain";
    } else {
      name = "Exclusion Type";
    }
    return name;
  };

  const confirmExclusionTypeChange = (props) => {
    if (listApplicationData.listId) {
      exclTypeChangeContext.current = props;
      setTypeChangeConfirm(true);
    } else handleExclusionTypeDropdown(props);
  };

  const handleExclusionTypeDropdown = async ({
    value,
    setFieldValue,
    resetForm,
    values,
    resetValues = {},
  }) => {
    setLoading(true);
    let listIds = {};
    if (!_isEmpty(resetValues)) {
      listIds = {
        listId: resetValues.listId,
        listHistoryId: resetValues.listHistoryId,
      };
    }
    resetForm({
      values: {
        ...resetValues,
        ...listIds,
        ...values,
        ndcExcTypeDtlId: "",
        claimTypeId: [],
      },
    });
    setFieldValue("ndcExcTypeId", value);
    let exclusionTypeValues = [];
    if (Number(value) === 1) {
      const resp = await dispatch(getPhDrugManufacturers());
      if (_isArray(resp)) {
        exclusionTypeValues = resp.map((item) => ({
          label: item.drugManufacturerName,
          value: item.drugManufacturerId,
        }));
        setManufacturers(resp);
      }
    } else if (Number(value) === 2) {
      const resp = (await getExclusionWholesalers()) || [];
      if (_isArray(resp)) {
        exclusionTypeValues = resp.map((item = {}) => ({
          label: item.wholesalerName,
          value: item.wholesalerId,
        }));
        setWholeSalerList(resp);
      }
    } else if (Number(value) === 3) {
      exclusionTypeValues = ceList.map((item = {}) => ({
        label: item.ceName,
        value: item.ceID,
      }));
    } else if (Number(value) === 4) {
      const resp = (await getExclusionPhGroups(getCeIdsArray(ceList))) || [];
      if (_isArray(resp)) {
        exclusionTypeValues = resp.map((item) => ({
          label: item.phGroupName,
          value: item.phGroupId,
        }));
        setPharmacyGroups(resp);
      }
    } else {
      exclusionTypeValues = [];
    }
    setExclusionTypeValues(exclusionTypeValues);
    if (!_isEmpty(resetValues)) {
      dispatch({
        type: SET_NDC_CLIENT_RELATIONSHIP,
        data: {},
      });
      dispatch({
        type: SET_NDC_CLIENT_EXCLUSIONS,
        data: {},
      });
      setNdcClientExceptionData({
        content: [],
        totalElements: 0,
      });
    }
    setLoading(false);
  };

  const handleExclusionValueDropdown = ({
    value,
    exclusionType,
    applyExclusionsAutomatically,
  }) => {
    const payload = {};
    if (Number(exclusionType) === 1) {
      const drugObj =
        manufacturers.find(
          (man = {}) => man.drugManufacturerId === Number(value)
        ) || {};
      payload.drugManufacturerID = [drugObj];
    } else if (Number(exclusionType) === 2) {
      const wholesalerObj =
        wholesalerList.find((wh = {}) => wh.wholesalerId === Number(value)) ||
        {};
      payload.wholesalerID = [wholesalerObj];
    } else if (Number(exclusionType) === 3) {
      const ceObj =
        ceList.find((item = {}) => Number(item.ceID) === Number(value)) || {};
      payload.ceID = [ceObj];
    } else if (Number(exclusionType) === 4) {
      const phGrObj =
        pharmacyGroups.find(
          (phGr = {}) => Number(phGr.phGroupId) === Number(value)
        ) || {};
      payload.phGroupId = [phGrObj];
    }
    if (!applyExclusionsAutomatically && listApplicationData.listId) {
      const formData = { ...payload, ...listApplicationData };
      getClientRelationTableData(formData);
      setFormSubmittedValues(formData);
    } else {
      const formData = { ...payload, ...ndcData };
      getClientExclusionTableData(formData);
      setFormSubmittedValues(formData);
    }
  };

  // const fetchWholeSalers = async (values = {}) => {
  //   const payload = {
  //     ceId: getCeIdsArray(values.ceID),
  //     phGroupId: getPhGroupIdArray(values.phGroupId),
  //     phId: getPhIdArray(values.phId),
  //   };
  //   const resp = await dispatch(getWholeSalers(payload));
  //   !_isEmpty(resp) && _isArray(resp) && setWholeSalerList(resp);
  // };

  // const fetchManufacturers = async () => {
  //   const resp = await dispatch(getPhDrugManufacturers({ showLoader: false }));
  //   !_isEmpty(resp) && _isArray(resp) && setManufacturers(resp);
  // };

  const getClientRelationTableData = async (values = {}, callback) => {
    const payload = getClientRelationshipTable({
      ...values,
      listId: values && values.listId ? [values.listId] : [],
      listHistoryId: values && values.listHistoryId ? ndcData.listHistoryId : 0,
    });
    const tableData = await dispatch(getNdcClientRelationshipList(payload));
    if (!_isEmpty(tableData)) callback && callback(tableData);
  };

  const handleSubmit = async (values) => {
    const payload = {
      autoExclApplyId: values.autoExclApplyId || 0,
      isAutoExclusionList: values.applyExclusionsAutomatically ? "Y" : "N",
      listId: ndcData.listId || 0,
      listHistoryId: ndcData.listHistoryId || 0,
      ndcExcTypeId: values.ndcExcTypeId || initialValues.ndcExcTypeId,
      ndcExcTypeDtlId: values.ndcExcTypeDtlId || initialValues.ndcExcTypeDtlId,
      claimTypeId:
        getClaimTypeIdArray(values.claimTypeId) || initialValues.claimTypeId,
      ndcExclusionListClientMapDTO: getListApplicationSaveLists({
        list: _get(clientExclusionsResult, "content", []),
        autoExclApplyId: values.autoExclApplyId,
      }),
      clientExceptionsListDTOs: getListApplicationSaveLists({
        list: _get(ndcClientExceptionData, "content", []),
        autoExclApplyId: values.autoExclApplyId,
      }),
      createdById: userSession.userId,
      modifiedById: userSession.userId,
    };
    const res = await dispatch(saveNdcListApplication(payload));
    if (!_isEmpty(res)) {
      setNdcData((prev) => ({
        ...prev,
        listHistoryId: _get(res, "autoPlus.listHistoryId", prev.listHistoryId),
      }));
      getNdcSectionStatus(ndcData.listId);
      setActiveNdcConfigTab(NDC_TABS.NDC_LIST_REVIEW);
      if (!activeInactiveTabs[NDC_TABS.NDC_LIST_REVIEW]) {
        setActiveInactiveTabs((prev) => {
          return {
            ...prev,
            [NDC_TABS.NDC_LIST_REVIEW]: true,
          };
        });
      }
    }
  };

  const getNdcSectionStatus = async (listId) => {
    const res = await dispatch(fetchNdcSectionStatus(listId));
    !_isEmpty(res) && setProgress(res);
  };

  const validateForm = (values) => {
    const errors = {};
    if (!values.ndcExcTypeId) {
      errors.ndcExcTypeId = "Please select the Exclusion Type";
    }
    if (!values.ndcExcTypeDtlId) {
      let errorMsg = "";
      if (Number(values.ndcExcTypeId) === 1)
        errorMsg = "Please select the Manufacturer";
      else if (Number(values.ndcExcTypeId) === 2)
        errorMsg = "Please select the Wholesaler";
      if (Number(values.ndcExcTypeId) === 3)
        errorMsg = "Please select the Covered Entity";
      else if (Number(values.ndcExcTypeId) === 4)
        errorMsg = "Please select the Pharmacy Chain";
      errors.ndcExcTypeDtlId = errorMsg;
    }
    if (!values.claimTypeId.length) {
      errors.claimTypeId = "Please select the Claims Type";
    }
    return errors;
  };

  return (
    <>
      {loading || loadingPrevData ? <LoaderUI /> : null}
      <Formik
        initialValues={initialValues}
        onSubmit={handleSubmit}
        enableReinitialize={true}
        innerRef={formRef}
        validate={validateForm}
      >
        {({
          values,
          errors,
          touched,
          setFieldValue,
          resetForm,
          submitForm,
        }) => {
          return (
            <Form>
              <Grid container direction="column" spacing={2}>
                <Grid item md={12}>
                  <BasicTypography
                    variant="inherit"
                    title="NDC List Application"
                  />
                </Grid>
                <Grid item md={12}>
                  <div className={classes.greyCard}>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        <BasicTypography
                          variant="caption"
                          title="Automatic List Application"
                        />
                      </Grid>
                      <Grid item md={12}>
                        <Grid item xs={12} sm={4}>
                          <FormControlLabel
                            control={
                              <Field
                                name="applyExclusionsAutomatically"
                                component={Toggle}
                                type="checkbox"
                                checked={values.applyExclusionsAutomatically}
                                onChange={() =>
                                  setFieldValue(
                                    "applyExclusionsAutomatically",
                                    !values.applyExclusionsAutomatically
                                  )
                                }
                              />
                            }
                            labelPlacement="end"
                          />
                          <Tooltip
                            title={LABELS.NdcAutomaticExclusionToggle}
                            placement="bottom"
                          >
                            <FormLabel>
                              Apply Exclusions Automatically?
                            </FormLabel>
                          </Tooltip>
                        </Grid>
                      </Grid>
                    </Grid>
                  </div>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item sm={4} md={3}>
                      <FormLabel required>Exclusion Type</FormLabel>
                      <Field
                        as="select"
                        className={globalClasses.formControl}
                        name="ndcExcTypeId"
                      >
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={
                              _isArray(exclusionTypes) ? exclusionTypes : []
                            }
                            inputPlaceholder={"Select Exclusion Type"}
                            disableCloseOnSelect={false}
                            value={
                              (_isArray(exclusionTypes) &&
                                exclusionTypes.find(
                                  (e) => e.ndcExcTypeId == values.ndcExcTypeId
                                )) ||
                              ""
                            }
                            onChange={(_e, value) => {
                              confirmExclusionTypeChange({
                                value: value && value.ndcExcTypeId,
                                setFieldValue,
                                resetForm,
                                values,
                              });
                            }}
                            textFieldProps={{
                              inputProps: {
                                name: "ndcExcTypeId",
                              },
                            }}
                            getOptionLabel={(option) => {
                              return option.ndcExcType;
                            }}
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.ndcExcType}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                          />
                        )}
                      </Field>
                      {errors.ndcExcTypeId && touched.ndcExcTypeId && (
                        <BasicTypography color="error" variant="caption">
                          {errors.ndcExcTypeId}
                        </BasicTypography>
                      )}
                    </Grid>
                    {values && values.ndcExcTypeId && (
                      <Grid item sm={4} md={3}>
                        <FormLabel required>
                          {getExclusionTypeName(values.ndcExcTypeId)}
                        </FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="ndcExcTypeDtlId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={
                                _isArray(exclusionTypeValues)
                                  ? exclusionTypeValues
                                  : []
                              }
                              inputPlaceholder={`${getExclusionTypeName(
                                values.ndcExcTypeId
                              )}`}
                              disableCloseOnSelect={false}
                              value={
                                (_isArray(exclusionTypeValues) &&
                                  exclusionTypeValues.find(
                                    (e) => e.value == values.ndcExcTypeDtlId
                                  )) ||
                                ""
                              }
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "ndcExcTypeDtlId",
                                  value ? value.value : ""
                                );
                                handleExclusionValueDropdown({
                                  value: value ? value.value : "",
                                  exclusionType: values.ndcExcTypeId,
                                  applyExclusionsAutomatically:
                                    values.applyExclusionsAutomatically,
                                });
                              }}
                              textFieldProps={{
                                inputProps: {
                                  name: "ndcExcTypeDtlId",
                                },
                              }}
                              getOptionLabel={(option) => {
                                return option.label;
                              }}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.label}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                        {errors.ndcExcTypeDtlId && touched.ndcExcTypeDtlId && (
                          <BasicTypography color="error" variant="caption">
                            {errors.ndcExcTypeDtlId}
                          </BasicTypography>
                        )}
                      </Grid>
                    )}
                    <Grid item sm={4} md={3}>
                      <FormLabel required>Claim Type</FormLabel>
                      <Field name="claimTypeId">
                        {({ field }) => (
                          <MultiSelectDropdown
                            {...field}
                            disableCloseOnSelect={false}
                            allOptionLabel="All Claims"
                            options={_isArray(claimTypes) ? claimTypes : []}
                            inputPlaceholder="Select Claim Type"
                            onChange={(_e, value) => {
                              setFieldValue("claimTypeId", value);
                            }}
                            getOptionSelected={(option, value) =>
                              option.claimTypeId === value.claimTypeId
                            }
                            getOptionLabel={(option) => option.claimType || ""}
                          />
                        )}
                      </Field>
                      {errors.claimTypeId && touched.claimTypeId && (
                        <BasicTypography color="error" variant="caption">
                          {errors.claimTypeId}
                        </BasicTypography>
                      )}
                    </Grid>
                  </Grid>
                </Grid>
                {/* // !Might be needed in future
                <Grid item sm={12}>
                  <div className={globalClasses.cardPrimary}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <BasicTypography variant="h4" title="Search Criteria" />
                      </Grid>
                      <Grid item xs={12} sm={4} md={3}>
                        <FormLabel>Covered Entity</FormLabel>
                        <Field
                          className={globalClasses.formControl}
                          name="ceID"
                        >
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disabled={Number(values.ndcExcTypeId) === 3}
                              options={_isArray(ceList) ? ceList : []}
                              inputPlaceholder={
                                values &&
                                values.ceID &&
                                _isArray(values.ceID) &&
                                values.ceID.length > 0
                                  ? ""
                                  : "Select Covered Entity"
                              }
                              onChange={(_e, value) => {
                                setFieldValue("ceID", value);
                                if (
                                  value.length &&
                                  Number(values.ndcExcTypeId) !== 4
                                ) {
                                  fetchPharmacyGroups(value);
                                } else {
                                  setPharmacyGroups([]);
                                }
                                Number(values.ndcExcTypeId) !== 4 &&
                                  setFieldValue("phGroupId", []);
                                setFieldValue("phID", []);
                                Number(values.ndcExcTypeId) !== 2 &&
                                  setFieldValue("wholesalerID", []);
                                Number(values.ndcExcTypeId) !== 1 &&
                                  setFieldValue("drugManufacturerID", []);
                              }}
                              getOptionLabel={(option) => option.ceName || ""}
                              getOptionSelected={(option, value) =>
                                option.ceID === value.ceID
                              }
                              inputValue={values.coveredEntityInput}
                              onInputChange={(_e, value) =>
                                setAutoCompleteInputVal({
                                  value,
                                  callback: (newValue) => {
                                    setFieldValue(
                                      "coveredEntityInput",
                                      newValue
                                    );
                                  },
                                })
                              }
                              textFieldProps={{
                                inputProps: {
                                  name: "ceID",
                                },
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4} md={3}>
                        <FormLabel>Pharmacy Chain</FormLabel>
                        <Field name="phGroupId">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disabled={Number(values.ndcExcTypeId) === 4}
                              options={pharmacyGroups || []}
                              inputPlaceholder={
                                values &&
                                values.phGroupId &&
                                _isArray(values.phGroupId) &&
                                values.phGroupId.length > 0
                                  ? ""
                                  : "Select Pharmacy Chain"
                              }
                              onChange={(_e, value) => {
                                setFieldValue("phGroupId", value);
                                if (value.length) {
                                  fetchPharmacies(values.ceID, value);
                                } else {
                                  setPharmacyList([]);
                                }
                                Number(values.ndcExcTypeId) !== 4 &&
                                  setFieldValue("phID", []);
                                Number(values.ndcExcTypeId) !== 2 &&
                                  setFieldValue("wholesalerID", []);
                                Number(values.ndcExcTypeId) !== 1 &&
                                  setFieldValue("drugManufacturerID", []);
                              }}
                              getOptionLabel={(option = {}) =>
                                option.phGroupName || ""
                              }
                              inputValue={values.phGroupInput}
                              onInputChange={(_e, value) =>
                                setAutoCompleteInputVal({
                                  value,
                                  callback: (newValue) => {
                                    setFieldValue("phGroupInput", newValue);
                                  },
                                })
                              }
                              textFieldProps={{
                                inputProps: {
                                  name: "phGroupId",
                                },
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4} md={3}>
                        <FormLabel>Pharmacy Store</FormLabel>
                        <Field name="phID">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disableCloseOnSelect={false}
                              options={
                                _isArray(pharmacyList) ? pharmacyList : []
                              }
                              inputPlaceholder={` Select ${LABELS.PharmacyStore}`}
                              onChange={(_e, value) => {
                                setFieldValue("phID", value);
                                Number(values.ndcExcTypeId) !== 2 &&
                                  setFieldValue("wholesalerID", []);
                                Number(values.ndcExcTypeId) !== 1 &&
                                  setFieldValue("drugManufacturerID", []);
                                fetchWholeSalers({ ...values, phId: value });
                              }}
                              getOptionLabel={(option) => option.phName || ""}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4} md={3}>
                        <FormLabel>Wholesaler</FormLabel>
                        <Field name="wholesalerID">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disabled={Number(values.ndcExcTypeId) === 2}
                              options={
                                _isArray(wholesalerList) ? wholesalerList : []
                              }
                              inputPlaceholder={
                                values &&
                                values.wholesalerID &&
                                _isArray(values.wholesalerID) &&
                                values.wholesalerID.length > 0
                                  ? ""
                                  : "Select Wholesaler"
                              }
                              disableCloseOnSelect={false}
                              onChange={(_e, value) => {
                                setFieldValue("wholesalerID", value);
                              }}
                              getOptionLabel={(option) =>
                                option.wholesalerName || ""
                              }
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4} md={3}>
                        <FormLabel>Manufacturer</FormLabel>
                        <Field name="drugManufacturerID">
                          {({ field }) => (
                            <MultiSelectDropdown
                              {...field}
                              disabled={Number(values.ndcExcTypeId) === 1}
                              options={
                                _isArray(manufacturers) ? manufacturers : []
                              }
                              inputPlaceholder={
                                values &&
                                values.drugManufacturerID &&
                                _isArray(values.drugManufacturerID) &&
                                values.drugManufacturerID.length > 0
                                  ? ""
                                  : "Select Manufacturer"
                              }
                              disableCloseOnSelect={false}
                              onChange={(_e, value) => {
                                setFieldValue("drugManufacturerID", value);
                              }}
                              getOptionLabel={(option = {}) =>
                                option.drugManufacturerName || ""
                              }
                            />
                          )}
                        </Field>
                      </Grid>

                      <Grid item xs={12}>
                        <Grid container spacing={2} justifyContent="flex-end">
                          <Grid item>
                            <Button
                              size="small"
                              color="primary"
                              variant="contained"
                              className={globalClasses.primaryBtn}
                              onClick={() => {
                                setFieldValue("saveType", "search");
                                submitForm(values);
                              }}
                            >
                              Search
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              size="small"
                              variant="outlined"
                              color="default"
                              className={globalClasses.secondaryBtn}
                              onClick={() =>
                                handleClear({
                                  initialValues,
                                  resetForm,
                                  setFieldValue,
                                })
                              }
                            >
                              Clear
                            </Button>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </div>
                </Grid> */}

                {listApplicationData.listId &&
                  !values.applyExclusionsAutomatically && (
                    <Grid item sm={12}>
                      <ClientRelationshipTable
                        getClientRelationTableData={getClientRelationTableData}
                        formSubmittedValues={formSubmittedValues}
                      />
                    </Grid>
                  )}

                {/* Comparable Grids Section */}
                <Grid item>
                  <ClientExclusionTables
                    searchTableProps={{
                      formSubmittedValues,
                      getClientExclusionTableData,
                    }}
                  />
                </Grid>

                {/* Tab Submit Buttons */}
                <Grid item>
                  <Grid container spacing={2} justifyContent="flex-end">
                    <Grid item>
                      <Button
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                        onClick={() => {
                          setFieldValue("saveType", "save");
                          submitForm(values);
                        }}
                      >
                        Save And Continue
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        size="small"
                        variant="contained"
                        className={globalClasses.grayButton}
                        onClick={() => handleConfigPopup({ state: false })}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Form>
          );
        }}
      </Formik>
      <BasicPopup
        show={typeChangeConfirm}
        title="Exclusion Type Change Confirmation"
        handleClose={() => setTypeChangeConfirm(false)}
        submitProps={{
          buttonTitle: "Yes",
          handleSubmit: () => {
            handleExclusionTypeDropdown(exclTypeChangeContext.current);
            setTypeChangeConfirm(false);
          },
        }}
        cancelProps={{
          buttonTitle: "No",
          handleCancel: () => {
            exclTypeChangeContext.current = {};
            setTypeChangeConfirm(false);
          },
        }}
        dialogProps={{
          maxWidth: "sm",
        }}
      >
        <BasicTypography variant="h5">
          Are you sure to clear the already configured exceptions?
        </BasicTypography>
      </BasicPopup>
    </>
  );
};

export default NdcListApplication;
