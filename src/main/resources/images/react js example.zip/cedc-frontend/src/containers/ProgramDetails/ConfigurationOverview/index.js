import React, {
  useEffect,
  useState,
  Suspense,
  useRef,
  useContext,
  useCallback,
} from "react";
import { Element, scroller } from "react-scroll";
import { Button, Grid } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import LoaderUI from "../../../components/common/Loader/Loader";
import _noop from "lodash/noop";
import _isEmpty from "lodash/isEmpty";
import _debounce from "lodash/debounce";
import {
  fetchTermsGridTableData,
  exportConfigDataToPdf,
} from "../../../context/actions/ConfigOverview";
import { getDropdownValue } from "../../../context/actions/providers";
import { COContext } from "../COContext";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { coScreenStyles } from "./styles";
import COSearchForm from "./COSearchForm";
import { defaultCoSearchPayload, resetReduxSummaryStates } from "./helper";
import TermsGridTable from "./TermsGridTable";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../utils/helper";
import { TiExport } from "react-icons/ti";
import TermDetails from "./CeSummary/TermDetails";
import CeBasicDetails from "./CeSummary/CeBasicDetails";
import CeBillingAndFees from "./CeSummary/CeBillingAndFees";
import CeAchConfig from "./CeSummary/CeAchConfig";
import CeEligibilityConfig from "./CeSummary/CeEligibilityConfig";
import Pharmacies from "../Pharmacies";
import CeLocations from "./CeSummary/CeLocations";
import CeProviders from "./CeSummary/CeProviders";
import CeMembers from "./CeSummary/CeMembers";
import CeServiceAreaConfig from "./CeSummary/CeServiceAreaConfig";
import { SET_CO_TERMS_LIST } from "../../../context/reducers/ConfigOverview/constants";
import CeVisitWindowConfig from "./CeSummary/CeVisitWindowConfig";
import { SET_PHARMACIES_LIST } from "../../../context/reducers/Pharmacies/constants";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { ALL_CE_OPTION } from "../../../utils/constants";
import _get from "lodash/get";
import CeOrderingConfigSummary from "./CeSummary/CeOrderingConfigSummary";

const ConfigOverview = (props = {}) => {
  const { setclickOnAdd } = props;
  const dispatch = useDispatch();
  const classes = coScreenStyles();
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();
  const actionRef = useRef(null);

  const {
    setCeList: setContextCeList,
    openAddCePopup,
    setTermsGridPayload,
  } = useContext(COContext);
  const achPermissions =
    getUserPermissionOnModuleName("ACH Configuration") || {};
  const providersPermissions = getUserPermissionOnModuleName("Providers") || {};
  const membersPermissions = getUserPermissionOnModuleName("Patients") || {};

  const { ceList } = useSelector((state) => state.coveredEntities);

  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [selectedCeForOverview, setSelectedCeForOverview] = useState({});
  const [isAllCollapsed, setIsAllCollapsed] = useState(true);

  const loader = useSelector(
    (state) => state.getLocationListDataValues.loading
  );
  const { loading: termsGridLoading } = useSelector(
    (state) => state.coTermsList
  );

  useEffect(() => {
    if (ceList.length && !openAddCePopup) {
      getTermsGridTableData({ ceId: ceList }, (res) => {
        if (!userSession.isInternalUser) {
          setSelectedCeForOverview(res.content[0]);
        }
      });
      if (userSession.isInternalUser) {
        setFormSubmittedValues({
          ceId: ALL_CE_OPTION,
          ceList: ceList,
        });
      }
      setContextCeList(ceList);
    }
  }, [ceList]);

  useEffect(() => {
    return () => {
      dispatch({ type: SET_CO_TERMS_LIST, data: {} });
      dispatch({ type: SET_PHARMACIES_LIST, data: {} });
      resetReduxSummaryStates(dispatch);
    };
  }, []);

  const getTermsGridTableData = async (payload = {}, callback) => {
    const termsPayload = defaultCoSearchPayload({
      ...payload,
      ceList: _isEmpty(payload.ceList) ? ceList : payload.ceList,
    });
    setTermsGridPayload(termsPayload);
    const tableData = await dispatch(fetchTermsGridTableData(termsPayload));
    if (!_isEmpty(tableData)) {
      if (
        userSession.isInternalUser &&
        tableData.totalElements === 1 &&
        tableData.content[0].ceConfigStatusId === 2
      ) {
        setSelectedCeForOverview(tableData.content[0]);
        scroller.scrollTo("coSummary", {
          smooth: true,
          offset: -240,
        });
      }
      if (
        userSession.isInternalUser &&
        !_isEmpty(selectedCeForOverview) &&
        tableData.totalElements > 1
      )
        setSelectedCeForOverview({});
      callback && callback(tableData);
    }
  };

  const handleSubmit = useCallback((values) => {
    getTermsGridTableData(values, (resp) => {
      actionRef.current && actionRef.current.submitForm(resp);
    });
    setFormSubmittedValues(values);
    userSession.isInternalUser && setSelectedCeForOverview({});
  }, []);

  const handleClear = useCallback((values) => {
    setFormSubmittedValues(values);
    actionRef.current && actionRef.current.clearForm(values);
    userSession.isInternalUser && setSelectedCeForOverview({});
  }, []);

  const handleCeForOverview = useCallback(
    _debounce((ce = {}) => {
      scroller.scrollTo("coSummary", {
        smooth: true,
        offset: -60,
      });
      setSelectedCeForOverview((prev) => {
        if (prev.ceid !== ce.ceid) resetReduxSummaryStates(dispatch);
        return ce;
      });
    }, 100),
    []
  );

  const handleConfigExport = ({ ceid = "" } = {}) => {
    const { phGroupId, pharmacy } = formSubmittedValues || {};
    const roleId = _get(userSession, "userRole.role.roleId", "");
    dispatch(
      exportConfigDataToPdf({
        ceId: ceid,
        phGroupId: phGroupId || 0,
        phId: pharmacy || 0,
        roleId,
      })
    );
  };

  return (
    <Suspense fallback={<LoaderUI />}>
      {loader ||
        (!userSession.isInternalUser && termsGridLoading && <LoaderUI />)}
      <Grid container spacing={2}>
        <Grid item sm={12}>
          <BasicTypography
            variant="h1"
            title="Program Details - Configuration Overview"
          />
        </Grid>
        <Grid item sm={12}>
          <COSearchForm handleSubmit={handleSubmit} handleClear={handleClear} />
        </Grid>
        {userSession.isInternalUser && (
          <Grid item md={12}>
            <TermsGridTable
              getTermsGridTableData={getTermsGridTableData}
              handleCeForOverview={handleCeForOverview}
              formSubmittedValues={formSubmittedValues}
              ref={actionRef}
              setclickOnAdd={setclickOnAdd}
            />
          </Grid>
        )}
        {!userSession.isInternalUser && (
          <Grid item md={12}>
            <TermDetails />
          </Grid>
        )}
        <Grid item sm={12}>
          <Element name="coSummary">
            {!_isEmpty(selectedCeForOverview) && (
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Grid container spacing={1}>
                    <Grid item md={6} sm={12}>
                      <BasicTypography
                        variant="h2"
                        styleProps={{ padding: "16px 0 10px" }}
                      >
                        {`${
                          !_isEmpty(selectedCeForOverview)
                            ? `${selectedCeForOverview.ceName} - `
                            : ""
                        }Configuration Overview`}
                      </BasicTypography>
                    </Grid>
                    <Grid
                      item
                      md={6}
                      sm={12}
                      className={classes.configGlobalActionBtnContainer}
                    >
                      <Grid container spacing={2} justifyContent="flex-end">
                        <Grid item>
                          <Button
                            startIcon={<TiExport />}
                            variant="outlined"
                            size="small"
                            component="button"
                            className={globalClasses.grayButton}
                            onClick={() =>
                              handleConfigExport(selectedCeForOverview)
                            }
                          >
                            Export Covered Entity Config
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            variant="outlined"
                            size="small"
                            component="button"
                            className="text-capitalize"
                            onClick={() => setIsAllCollapsed(true)}
                          >
                            Expand All
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            variant="outlined"
                            size="small"
                            component="button"
                            className="text-capitalize"
                            onClick={() => setIsAllCollapsed(false)}
                          >
                            Collapse All
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <CeBasicDetails
                    ceId={selectedCeForOverview.ceid}
                    isAllCollapsed={isAllCollapsed}
                  />
                </Grid>
                <Grid item md={12}>
                  <CeBillingAndFees
                    isAllCollapsed={isAllCollapsed}
                    selectedCeForOverview={selectedCeForOverview}
                  />
                </Grid>
                {achPermissions.readOnlyFlag && (
                  <Grid item md={12}>
                    <CeAchConfig
                      isAllCollapsed={isAllCollapsed}
                      selectedCeForOverview={selectedCeForOverview}
                    />
                  </Grid>
                )}
                <Grid item md={12}>
                  <CeEligibilityConfig
                    isAllCollapsed={isAllCollapsed}
                    selectedCeForOverview={selectedCeForOverview}
                  />
                </Grid>
                <Grid item md={12}>
                  <CeOrderingConfigSummary
                    isAllCollapsed={isAllCollapsed}
                    selectedCeForOverview={selectedCeForOverview}
                  />
                </Grid>
                <Grid item md={12}>
                  <CeLocations
                    isAllCollapsed={isAllCollapsed}
                    selectedCeForOverview={selectedCeForOverview}
                  />
                </Grid>
                {providersPermissions.readOnlyFlag && (
                  <Grid item md={12}>
                    <CeProviders
                      selectedCeForOverview={selectedCeForOverview}
                    />
                  </Grid>
                )}
                {membersPermissions.readOnlyFlag && (
                  <Grid item md={12}>
                    <CeMembers selectedCeForOverview={selectedCeForOverview} />
                  </Grid>
                )}
                <Grid item md={12}>
                  <CeServiceAreaConfig
                    isAllCollapsed={isAllCollapsed}
                    selectedCeForOverview={selectedCeForOverview}
                  />
                </Grid>
                <Grid item md={12}>
                  <CeVisitWindowConfig
                    isAllCollapsed={isAllCollapsed}
                    selectedCeForOverview={selectedCeForOverview}
                  />
                </Grid>
                <Grid item md={12}>
                  <Pharmacies
                    isFromMainModule={false}
                    ceId={selectedCeForOverview.ceid}
                    coSearchPayload={formSubmittedValues}
                  />
                </Grid>
              </Grid>
            )}
          </Element>
        </Grid>
      </Grid>
    </Suspense>
  );
};

export default ConfigOverview;
