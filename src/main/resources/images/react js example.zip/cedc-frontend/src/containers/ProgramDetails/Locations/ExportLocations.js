import FileSaver from "file-saver";
import "jspdf-autotable";
import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import { locationsExport } from "../../../context/actions/Locations";
import { notNull } from "../../../utils/constants";

const ExportLocations = () => {
  const dispatch = useDispatch();

  const exportToExcel = ({
    Co,
    CEidarray,
    messageUuid,
    searchData,
    columnFilters,
    tabPayload,
    sortBy,
    sortOrder,
  }) => {
    const {
      startDate,
      endDate,
      site340B,
      entityLocationId,
      city,
      state,
      parentId,
      locationStatus,
      locations = [],
      locationHRSAID,
      status
    } = searchData || {};
    let payload = {
      ceid: Co
        ? [messageUuid && messageUuid.ceid !== null && messageUuid.ceid]
        : searchData
        ? [searchData.ceid]
        : CEidarray,
      sortBy: sortBy,
      sortOrder: sortOrder,
      startDate: startDate || "",
      endDate: endDate || "",
      entityLocationId:
        entityLocationId ||
        locations.map((location) => location.entityLocationId) ||
        [],
      export: true,
      filter: columnFilters || [],
      site340B: site340B || "",
      pageNumber: 1,
      pageSize: 25,
      locationStatus: tabPayload || locationStatus || "",
      locationHrsaId: locationHRSAID || "",
      city: city,
      stateId: state || 0,
      parentId: parentId || 0,
      status: status || ""
    };
    dispatch(
      locationsExport(payload, (res) => {
        var data = res.content.map(
          ({
            coveredEntity,
            locationName,
            locationHrsaId,
            site340b,
            addressLine1,
            addressLine2,
            city,
            state,
            zip,
            startDate,
            endDate,
            source,
            locationStatus,
          }) => ({
            Source: notNull(source),
            "Participating 340B Site": notNull(
              site340b === "true" ? "Yes" : "No"
            ),
            "Covered Entity": notNull(coveredEntity),
            "Provider Location": notNull(locationName),
            "Provider Location HRSA ID": notNull(locationHrsaId),
            "Address Line 1": notNull(addressLine1),
            "Address Line 2": notNull(addressLine2),
            City: notNull(city),
            State: notNull(state),
            Zip: notNull(zip),
            "Provider Start Date": notNull(startDate),
            "Provider End Date": notNull(endDate),
            "Provider Status": notNull(locationStatus),
          })
        );

        const fileName =
          parentId && parentId > 0 ? "Address Variations" : "Locations List";
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, {
          bookType: "xlsx",
          type: "array",
        });
        const fileData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(fileData, fileName + ".xlsx");
      })
    );
  };
  return { exportToExcel };
};

export default ExportLocations;
