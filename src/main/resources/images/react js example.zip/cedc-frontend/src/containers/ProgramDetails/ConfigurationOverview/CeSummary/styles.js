import { makeStyles } from "@material-ui/core";

export const useCeSummaryStyle = makeStyles((theme) => {
  return {
    summaryWrapper: {
      border: `1px solid ${theme.colors.monochrome.cardBorder}`,
      borderRadius: "10px",
      boxShadow: `0 0 18px 0 ${theme.colors.monochrome.cardBoxShadow}`,
      lineHeight: "1.42857143",
    },
    summaryTitleWrapper: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 15px",
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
    },
    collapseContainer: {
      padding: "10px 15px",
    },
    radioContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    radio: {
      margin: "0 !important",
    },
  };
});
