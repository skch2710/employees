import { makeStyles } from "@material-ui/core";

export const useCeServiceAreaConfigStyle = makeStyles((_theme) => {
  return {};
});
