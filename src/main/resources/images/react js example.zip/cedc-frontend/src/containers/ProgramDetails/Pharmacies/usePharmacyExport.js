import { useDispatch } from "react-redux";
import _isEmpty from "lodash/isEmpty";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { defaultPhSearchPayload } from "./helper";
import { fetchPharmaciesTableData } from "../../../context/actions/Pharmacies";
import { ALL_CE_OPTION, notNull, LABELS } from "../../../utils/constants";

const usePharmacyExport = () => {
  const dispatch = useDispatch();
  const exportToExcel = async (props) => {
    const { controllers, columnFilters, formSubmittedValues, ceList } = props;
    const tableData = await dispatch(
      fetchPharmaciesTableData(
        defaultPhSearchPayload({
          sortBy: controllers.sortBy,
          sortOrder: controllers.sortOrder,
          filter: columnFilters,
          export: true,
          ceList,
          ceId: ALL_CE_OPTION,
          ...formSubmittedValues,
        })
      )
    );
    if (!_isEmpty(tableData)) {
      var data = tableData.content.map(
        ({
          coveredEntity,
          pharmacyName,
          pharmacyNetwork,
          goLiveDate,
          startDate,
          endDate,
          brandDispensingFeeThirdParty,
          genericDispensingFeeThirdParty,
          specialtyBrandDispensingFeeThirdParty,
          specialtyGenericDispensingFeeThirdParty,
          cashFlatFeeBoth,
          specialtyBrandDispensingFeeCash,
          specialtyGenericDispensingFeeCash,
          brandDispensingFeeCash,
          genericDispensingFeeCash,
          programType,
          billingModel,
          wholesaler,
          participatingInCashProgram,
          configStatus,
        }) => ({
          [LABELS.CoveredEntity]: notNull(coveredEntity),
          [LABELS.PharmacyStore]: notNull(pharmacyName),
          "Configuration Status": notNull(configStatus),
          [LABELS.PharmacyChain]: notNull(pharmacyNetwork),
          "Go-Live Date": notNull(goLiveDate),
          "Start Date": notNull(startDate),
          "End Date": notNull(endDate),
          "Third Party Brand $+%": notNull(brandDispensingFeeThirdParty),
          "Third Party Generic $+%": notNull(genericDispensingFeeThirdParty),
          "Third Party Specialty Brand $+%": notNull(
            specialtyBrandDispensingFeeThirdParty
          ),
          "Third Party Specialty Generic $+%": notNull(
            specialtyGenericDispensingFeeThirdParty
          ),
          "Cash Flat Fee $+%": notNull(cashFlatFeeBoth),
          "Cash Specialty Brand $+%": notNull(specialtyBrandDispensingFeeCash),
          "Cash Specialty Generic $+%": notNull(
            specialtyGenericDispensingFeeCash
          ),
          "Cash Brand $+%": notNull(brandDispensingFeeCash),
          "Cash Generic $+%": notNull(genericDispensingFeeCash),
          "Program Type": notNull(programType),
          "Billing Model": notNull(billingModel),
          Wholesaler: notNull(wholesaler),
          "Participating in Cash Program": notNull(participatingInCashProgram),
        })
      );
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "Pharmacy List" + ".xlsx");
    }
  };

  return { exportToExcel };
};

export default usePharmacyExport;
