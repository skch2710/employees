import React, { useEffect, useContext, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import {
  Grid,
  Button,
  Collapse,
  IconButton,
  Paper,
  FormLabel,
} from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import { getCeWholesalers } from "../../../../../../context/actions/ConfigOverview";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import WholesalersGrid from "./WholesalersGrid";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useCeOrderingConfigStyles } from "./styles";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { ORDERING_CONFIG_MODULE } from "../../../../../../utils/constants";
import MultiSelectDropdown from "../../../../../../components/common/MultiSelectDropdown";
import { Field, Form, Formik } from "formik";
import { getPharmacyGroups } from "../../../../../../context/actions/Common";
import { getPhGroupIdArray } from "../../../../../../utils/helper";
import _isArray from "lodash/isArray";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import { GLOBAL_LOADING } from "../../../../../../context/constants";

const CeOrderingConfiguration = ({
  isFromWizard = false,
  module = "",
  selectedCeId = null,
}) => {
  const globalClasses = useGlobalStyles();
  const classes = useCeOrderingConfigStyles();
  const dispatch = useDispatch();

  const { loading } = useSelector((state) => state.globalLoader);
  const { setPopupActiveMenu, setOpenAddCePopup, messageUuid } =
    useContext(COContext);

  const [wholesalersData, setWholesalersData] = useState([]);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);

  const ceId = isFromWizard
    ? !_isEmpty(messageUuid) && messageUuid.ceid
    : selectedCeId;

  useEffect(async () => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    fetchPharmacyGroupsData(ceId);
    await fetchWholesalersData(ceId);
  }, []);

  const toggleCollapse = (phChainId) => {
    const tempWholesalersData = wholesalersData.map((phItem) => {
      if (phItem.phGroupId === phChainId) {
        phItem["isClosed"] = !phItem["isClosed"];
      }
      return phItem;
    });
    setWholesalersData([...tempWholesalersData]);
  };

  const fetchPharmacyGroupsData = async (ceId = 0) => {
    const res = await dispatch(getPharmacyGroups([ceId], true));
    _isArray(res) && setPharmacyGroups(res);
  };

  const fetchWholesalersData = async (ceId = 0, phGroupIds = []) => {
    if (ceId) {
      const json = {
        ceId: ceId,
        phGroupId: getPhGrpIds(phGroupIds),
      };
      const res = await dispatch(getCeWholesalers(json));
      _isArray(res) && setWholesalersData(res);
    }
  };

  const getPhGrpIds = (phGroupIds = pharmacyGroups) => {
    return phGroupIds.length === pharmacyGroups.length
      ? [-1]
      : getPhGroupIdArray(phGroupIds);
  };

  return (
    <>
      <Grid container spacing={2}>
        {isFromWizard && (
          <Grid item md={12}>
            <BasicTypography
              variant="h4"
              title="Entity Details > Ordering Configuration"
            />
          </Grid>
        )}
        <Grid item md={12}>
          <Formik
            initialValues={{
              phGroupId: pharmacyGroups,
            }}
            enableReinitialize={true}
          >
            {({ setFieldValue, values }) => {
              return (
                <Form>
                  <Grid container spacing={4}>
                    {isFromWizard && (
                      <Grid item sm={12}>
                        <Grid container spacing={4} alignItems="flex-end">
                          <Grid item xs={6}>
                            <FormLabel>Pharmacy Chain</FormLabel>
                            <Field name="phGroupId">
                              {({ field }) => (
                                <MultiSelectDropdown
                                  {...field}
                                  inputPlaceholder="Select Pharmacy Chain"
                                  options={pharmacyGroups}
                                  getOptionLabel={(option) =>
                                    `${option.phGroupName}`
                                  }
                                  getOptionSelected={(option, value) =>
                                    Number(option.phGroupId) ===
                                    Number(value.phGroupId)
                                  }
                                  onChange={(_e, value) => {
                                    setFieldValue("phGroupId", value);
                                  }}
                                />
                              )}
                            </Field>
                          </Grid>
                          <Grid item>
                            <Button
                              color="primary"
                              size="small"
                              variant="contained"
                              className={globalClasses.primaryBtn}
                              disabled={!values.phGroupId.length}
                              onClick={() => {
                                fetchWholesalersData(ceId, values.phGroupId);
                              }}
                            >
                              Search
                            </Button>
                          </Grid>
                        </Grid>
                      </Grid>
                    )}
                    <Grid item md={12}>
                      {wholesalersData &&
                      _isArray(wholesalersData) &&
                      wholesalersData.length > 0
                        ? wholesalersData.map((phItem) => {
                            return (
                              <Paper
                                className={classes.collapseWrapper}
                                key={phItem.phGroupId}
                              >
                                <Grid container>
                                  <Grid item md={12}>
                                    <div
                                      className={classes.collapseTitleWrapper}
                                    >
                                      <BasicTypography
                                        variant="h5"
                                        title={phItem.phGroupName}
                                        className={classes.collapseTitleText}
                                      />
                                      <div
                                        className={classes.actionBtnContainer}
                                      >
                                        <IconButton size="small">
                                          {!phItem.isClosed ? (
                                            <AiOutlineMinus
                                              onClick={() =>
                                                toggleCollapse(phItem.phGroupId)
                                              }
                                            />
                                          ) : (
                                            <AiOutlinePlus
                                              onClick={() =>
                                                toggleCollapse(phItem.phGroupId)
                                              }
                                            />
                                          )}
                                        </IconButton>
                                      </div>
                                    </div>
                                  </Grid>
                                  <Grid item md={12}>
                                    <Collapse
                                      in={!phItem.isClosed}
                                      timeout="auto"
                                      unmountOnExit
                                    >
                                      <WholesalersGrid
                                        module={
                                          module || ORDERING_CONFIG_MODULE.CO
                                        }
                                        wholesalers={phItem.wholesalers}
                                      />
                                    </Collapse>
                                  </Grid>
                                </Grid>
                              </Paper>
                            );
                          })
                        : !loading && (
                            <Grid container>
                              <Grid item xs={12}>
                                <DataNotFound />
                              </Grid>
                            </Grid>
                          )}
                      {isFromWizard && (
                        <Grid
                          item
                          xs={12}
                          className={classes.wizardButtonsContainer}
                        >
                          <Grid container spacing={2} justifyContent="flex-end">
                            <Grid item>
                              <Button
                                color="primary"
                                size="small"
                                variant="contained"
                                className={globalClasses.primaryBtn}
                                onClick={() =>
                                  setPopupActiveMenu(MENUS.CE_LOCATIONS)
                                }
                              >
                                Next
                              </Button>
                            </Grid>
                            <Grid item>
                              <Button
                                size="small"
                                variant="outlined"
                                className={globalClasses.secondaryBtn}
                                onClick={() =>
                                  setPopupActiveMenu(MENUS.CE_LOCATIONS)
                                }
                              >
                                Skip
                              </Button>
                            </Grid>
                            <Grid item>
                              <Button
                                size="small"
                                variant="outlined"
                                className={globalClasses.secondaryBtn}
                                onClick={() => setOpenAddCePopup(false)}
                              >
                                Save and Exit
                              </Button>
                            </Grid>
                            <Grid item>
                              <Button
                                size="small"
                                variant="outlined"
                                className={globalClasses.secondaryBtn}
                                onClick={() => setOpenAddCePopup(false)}
                              >
                                Cancel
                              </Button>
                            </Grid>
                          </Grid>
                        </Grid>
                      )}
                    </Grid>
                  </Grid>
                </Form>
              );
            }}
          </Formik>
        </Grid>
      </Grid>
    </>
  );
};
export default CeOrderingConfiguration;
