import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { useDispatch } from "react-redux";
import {
  Collapse,
  Divider,
  FormLabel,
  Grid,
  IconButton,
  Paper,
  Typography,
} from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { BsPencilSquare } from "react-icons/bs";
import { COContext } from "../../COContext";
import { MENUS } from "../../ConfigurationOverview/PopupSidebar/constants";
import { usePhBillingAndFeesStyle } from "./styles";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { fetchClientFrequency } from "../../../../context/actions/PharmacyConfiguration";
import { pagination } from "../../../../utils/constants";
import AdminFeesTable from "../../ConfigurationOverview/popupsdetail/Pharmacyconfigurations/PhBillingAndFees/AdminFee/AdminFeesTable";
import DispensingFeesTable from "../../ConfigurationOverview/popupsdetail/Pharmacyconfigurations/PhBillingAndFees/DispensingFee/DispensingFeesTable";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../utils/helper";
import {
  fetchPhAdminFeesTableData,
  fetchPhDispensingFeesTableData,
} from "../../../../context/actions/Pharmacies";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";

const PhBillingAndFees = memo((props = {}) => {
  const { selectedPharmacy, isAllCollapsed } = props;
  const { clientId, ceid } = selectedPharmacy || {};
  const { clickOnPencil, setCurrentPharmacy, setCoveredEntityName } =
    useContext(COContext) || {};
  const userSession = getUserSession();
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = usePhBillingAndFeesStyle();
  const readWritePermission =
    getUserPermissionOnModuleName("Pharmacies").readWriteFlag;

  const [isCollapsed, setIsCollapsed] = useState(true);
  const [frequency, setFrequency] = useState({});

  const getAdminFeeTableData = async (payload = {}, callback) => {
    const resp = await dispatch(
      fetchPhAdminFeesTableData({
        clientId: clientId || 0,
        pageNumber: 1,
        pageSize: pagination.limit,
        sortBy: "",
        sortOrder: "",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(resp) && callback && callback(resp);
  };

  const getDispensingFeesTableData = async (payload = {}, callback) => {
    const tableData = await dispatch(
      fetchPhDispensingFeesTableData({
        clientId: clientId || 0,
        pageNumber: 1,
        pageSize: pagination.limit,
        sortBy: "",
        sortOrder: "",
        filter: [],
        export: false,
        ...payload,
      })
    );
    !_isEmpty(tableData) && callback && callback(tableData);
  };

  const getFrequency = async () => {
    const resp = await dispatch(fetchClientFrequency(clientId));
    if (!_isEmpty(resp) && _isArray(resp)) {
      setFrequency(resp[0]);
    }
  };

  useEffect(() => {
    if (clientId) {
      getAdminFeeTableData();
      getDispensingFeesTableData();
      getFrequency();
    }
  }, [clientId]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  });

  return (
    <Paper className={classes.billingFeesWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={classes.titleWrapper}>
            <BasicTypography variant="h3" title="Billing and Fees" />
            <div className={classes.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={!userSession.isInternalUser || !readWritePermission}
              >
                <BsPencilSquare
                  onClick={() => {
                    setCurrentPharmacy(selectedPharmacy);
                    setCoveredEntityName(selectedPharmacy.coveredEntity);
                    clickOnPencil(MENUS.PH_BILLING_AND_FEES, ceid);
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography variant="h5" title="Admin Fees" />
                    </Grid>
                    <Grid item md={12}>
                      <FormLabel>
                        340B Direct+ Billing Invoice Frequency
                      </FormLabel>
                      <Typography variant="subtitle2">
                        {frequency.freqId === 1
                          ? "Monthly"
                          : frequency.freqId === 2
                          ? "Bi-Monthly"
                          : "--"}
                      </Typography>
                    </Grid>
                    <Grid item md={12}>
                      <AdminFeesTable
                        getAdminFeeTableData={getAdminFeeTableData}
                        isConfigurable={false}
                      />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <DispensingFeesTable
                    getDispensingFeesTableData={getDispensingFeesTableData}
                    isConfigurable={false}
                  />
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
});

export default PhBillingAndFees;
