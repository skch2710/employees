import React from "react";
import { Formik, Form, Field } from "formik";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { Button, FormLabel, Grid, Typography } from "@material-ui/core";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";

const ParticipatePopup = ({
  handleParticipatePopup,
  isTerminatePopup,
  popupMessage,
}) => {
  const globalClasses = useGlobalStyles();
  const defaultValues = { opaLocEndDate: "" };

  const formValidate = (values) => {
    let errors = {};
    if (isTerminatePopup && values.opaLocEndDate === "") {
      errors.opaLocEndDate = "Please select the OPA Location End Date";
    }
    return errors;
  };

  const handleSubmit = (values) => {
    handleParticipatePopup({ state: true, endDate: values });
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={defaultValues}
        validate={formValidate}
        onSubmit={handleSubmit}
      >
        {({ values, errors, touched, setFieldValue }) => {
          return (
            <Form>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <BasicTypography
                    variant="h4"
                    title={
                      popupMessage
                        ? popupMessage
                        : isTerminatePopup
                        ? "Do you want to Block the location?"
                        : "Do you want to confirm the Location into the Program?"
                    }
                  />
                </Grid>

                {isTerminatePopup && (
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>OPA Location End Date</FormLabel>
                    <Field as="select" name="opaLocEndDate">
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(e, date) =>
                            setFieldValue("opaLocEndDate", date || "")
                          }
                          disabledDate={(date) =>
                            date.isBefore(new Date(), "day")
                          }
                          value={
                            values.opaLocEndDate !== ""
                              ? moment(values.opaLocEndDate)
                              : ""
                          }
                        />
                      )}
                    </Field>
                    {isTerminatePopup &&
                      touched.opaLocEndDate &&
                      errors.opaLocEndDate && (
                        <Typography color="error" variant="caption">
                          {errors.opaLocEndDate}
                        </Typography>
                      )}
                  </Grid>
                )}

                <Grid item xs={12}>
                  <Grid container spacing={2} justifyContent="flex-end">
                    <Grid item>
                      <Button
                        type="submit"
                        size="small"
                        variant="outlined"
                        className={globalClasses.primaryBtn}
                      >
                        Yes
                      </Button>
                    </Grid>

                    <Grid item>
                      <Button
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() =>
                          handleParticipatePopup({ state: false, endDate: {} })
                        }
                      >
                        No
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Form>
          );
        }}
      </Formik>
    </>
  );
};

export default ParticipatePopup;
