import React, { memo, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import _get from "lodash/get";
import _isEmpty from "lodash/isEmpty";
import { Divider, FormLabel, Grid, Paper } from "@material-ui/core";
import { useCeSummaryStyle } from "../styles";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import { defaultCoSearchPayload } from "../../helper";
import { fetchTermsSingleData } from "../../../../../context/actions/ConfigOverview";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import { LABELS } from "../../../../../utils/constants";

const TermDetails = memo((_props) => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const [termData, setTermData] = useState({});
  const { ceList } = useSelector((state) => state.coveredEntities);

  const fetchTermData = async () => {
    const tableData = await dispatch(
      fetchTermsSingleData(defaultCoSearchPayload({ ceList: ceList }))
    );
    if (!_isEmpty(tableData)) {
      const data = _get(tableData, "content[0]") || {};
      setTermData(data);
    }
  };

  useEffect(() => {
    if (ceList.length) {
      fetchTermData();
    }
  }, [ceList]);
  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Terms" />
          </div>
        </Grid>
        <Grid item md={12}>
          <Divider classes={{ root: globalClasses.divider }} />
          <div className={commonSummaryClasses.collapseContainer}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <FormLabel>{LABELS.CoveredEntity}</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.ceName || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Effective Date</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.effectiveDate || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Contract Start Date</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.contractStartDate || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Contract End Date</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.contractEndDate || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Primary Contact Name</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.fullname || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Primary Email</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.emailAddress || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Primary Phone</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.contactNumber || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Active Providers</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.activeProviders || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Active Patients</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.activeMembers || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Active Pharmacies</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.activePharmacies || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Flat Fee + Percentage</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.flatFeePlusPercentage || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Percentage Only</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.percentageOnly || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Flat Fee Per Client</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.flatFeePerClient || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Flat Fee per Transaction</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.flatFeePerTransaction || "--"}
                </BasicTypography>
              </Grid>
              <Grid item xs={12} sm={4}>
                <FormLabel>Configuration Status</FormLabel>
                <BasicTypography variant="subtitle2">
                  {termData.configStatus || "--"}
                </BasicTypography>
              </Grid>
            </Grid>
          </div>
        </Grid>
      </Grid>
    </Paper>
  );
});

export default TermDetails;
