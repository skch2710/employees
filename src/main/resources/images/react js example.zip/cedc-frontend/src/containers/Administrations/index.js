import React, { lazy, Suspense, memo, useEffect } from "react";
import { Redirect, Route, Switch, useRouteMatch } from "react-router-dom";
import { useDispatch } from "react-redux";
import LoaderUI from "../../components/common/Loader/Loader";
import { NdcContextProvider } from "./NdcExclusions/NdcContext";
import { getListNames } from "../../context/actions/NdcExclusions";

const NdcExclusions = lazy(() => import("./NdcExclusions"));
const BinExclusions = lazy(() => import("./BinExclusions"));

const Administrations = memo(() => {
  const { path } = useRouteMatch();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getListNames());
  }, []);

  return (
    <Suspense fallback={<LoaderUI />}>
      <Switch>
        <Redirect exact from={`${path}`} to={`${path}/ndcexclusions`} />
        <Route
          path={`${path}/ndcexclusions`}
          render={() => (
            <NdcContextProvider>
              <NdcExclusions />
            </NdcContextProvider>
          )}
        />
        <Route path={`${path}/binexclusions`} component={BinExclusions} />
      </Switch>
    </Suspense>
  );
});

export default Administrations;
