import React from "react";
import { useFormikContext } from "formik";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import { getUserSession } from "../../../../../utils/helper";

const AccuracyConfirmationPopupFooter = (props = {}) => {
  const { setShowAccuracyPopup, formValues } = props;
  const { submitForm, errors } = useFormikContext();
  const globalClasses = useGlobalStyles();
  const userSession = getUserSession();
  const internalUser = userSession.isInternalUser;

  return (
    <Grid container spacing={2} justifyContent="flex-end">
      <Grid item>
        <Button
          disabled={errors.confirmedData}
          onClick={submitForm}
          className={globalClasses.primaryBtn}
        >
          {!internalUser ? "OK" : "Confirm"}
        </Button>
      </Grid>

      <Grid item>
        <Button
          variant="outlined"
          className={globalClasses.secondaryBtn}
          onClick={() => setShowAccuracyPopup(false)}
        >
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};

export default AccuracyConfirmationPopupFooter;
