import React from "react";
import { useDispatch } from "react-redux";
import jsPDF from "jspdf";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { GLOBAL_FILTERS_MAP } from "./constant";
import { notNull } from "../../utils/constants";
import { getUserListExport } from "../../context/actions/Usermanagement";

const useUsersExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props = {}) => {
    const {
      Co,
      coCeid,
      sortBy,
      sortorder,
      clearButton,
      defaultFilters,
      searchBy,
      globalFilterValue,
      getCeIds,
    } = props;
    let json = {
      ceID: Co ? coCeid : getCeIds(),
      sortBy: sortBy,
      sortOrder: sortorder,
      export: true,
      filter: defaultFilters,
    };
    if (!clearButton && searchBy)
      json[GLOBAL_FILTERS_MAP[searchBy]] = globalFilterValue;
    dispatch(
      getUserListExport(json, (result) => {
        const data = result.content.map(
          ({
            firstName,
            lastName,
            emailID,
            userType,
            customized,
            entityName,
            createdDate,
            lastLoginDate,
          }) => ({
            "First Name": firstName,
            "Last Name": notNull(lastName),
            "Email ID": notNull(emailID),
            "Role Type": notNull(userType),
            Customized: notNull(customized == "true" ? "Yes" : "No"),
            "Covered Entity": notNull(entityName),
            "Created Date": notNull(createdDate),
            "Last Login Date": notNull(lastLoginDate),
          })
        );
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
        const updatedData = new Blob([excelBuffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
        });
        FileSaver.saveAs(updatedData, "Users List" + ".xlsx");
      })
    );
  };

  const exportToPdf = (props = {}) => {
    const {
      Co,
      coCeid,
      sortBy,
      sortorder,
      clearButton,
      defaultFilters,
      searchBy,
      globalFilterValue,
      getCeIds,
    } = props;
    let json = {
      ceID: Co ? coCeid : getCeIds(),
      sortBy: sortBy,
      sortOrder: sortorder,
      export: true,
      filter: defaultFilters,
    };
    if (!clearButton && searchBy)
      json[GLOBAL_FILTERS_MAP[searchBy]] = globalFilterValue;
    dispatch(
      getUserListExport(json, (result) => {
        const data = result.content.map(
          ({
            firstName,
            lastName,
            emailID,
            userType,
            customized,
            entityName,
            createdDate,
            lastLoginDate,
          }) => ({
            "First Name": firstName,
            "Last Name": notNull(lastName),
            "Email ID": notNull(emailID),
            "Role Type": notNull(userType),
            Customized: notNull(customized == "true" ? "Yes" : "No"),
            "Covered Entity": notNull(entityName),
            "Created Date": notNull(createdDate),
            "Last Login Date": notNull(lastLoginDate),
          })
        );
        const heads = data.map((items) => {
          return {
            "First Name": Object.keys(items)[0],
            "Last Name": Object.keys(items)[1],
            Email: Object.keys(items)[2],
            "Role Type": Object.keys(items)[3],
            Customized: Object.keys(items)[4],
            "Covered Entity": Object.keys(items)[5],
            "Created Date": Object.keys(items)[6],
            "Last Login Date": Object.keys(items)[7],
          };
        });
        const rows = data.map((item) => {
          return Object.values(item);
        });
        const doc = new jsPDF();
        doc.autoTable({
          head: [heads[0]],
          columnStyles: {
            0: { columnWidth: 25 },
            1: { columnWidth: 15 },
            2: { columnWidth: 15 },
            3: { columnWidth: 30 },
            4: { columnWidth: 25 },
            5: { columnWidth: 25 },
            6: { columnWidth: 25 },
            7: { columnWidth: 25 },
            8: { columnWidth: 25 },
          },
          theme: "grid",
          tableWidth: "auto",
          fontStyle: "normal",
          body: [...rows],
        });
        doc.save("Users Sheet.pdf");
      })
    );
  };

  return { exportToExcel, exportToPdf };
};

export default useUsersExport;
