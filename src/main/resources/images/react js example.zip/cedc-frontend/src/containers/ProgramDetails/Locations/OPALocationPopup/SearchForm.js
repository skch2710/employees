import React, { useEffect, useState } from "react";
import { Field, Form, Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { Button, FormLabel, Grid } from "@material-ui/core";
import _isArray from "lodash/isArray";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import AutoComplete from "../../../../components/common/AutoComplete";
import { useLocationStyles } from "../styles";

const SearchForm = (props = {}) => {
  const { handleSubmit, handleClear } = props;
  const globalClasses = useGlobalStyles();
  const statesList = useSelector((state) => state.ce_states_list.records) || [];
  const defaultValues = { city: "", state: "", zip: "" }; //getSearchFormDefaultValues();
  const classes = useLocationStyles();

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleSubmit}
      enableReinitialize={true}
    >
      {({ values, setFieldValue, initialValues }) => {
        return (
          <Form>
            <div className={globalClasses.cardPrimary}>
              <Grid container spacing={2} direction="column">
                <Grid item>
                  <Grid container spacing={2} justifyContent="space-between">
                    <Grid item>
                      <BasicTypography variant="h5">
                        OPA Search Criteria
                      </BasicTypography>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={3}>
                      <FormLabel>City</FormLabel>
                      <Field
                        name="city"
                        type="text"
                        placeholder="Enter City Name"
                        className={globalClasses.formControl}
                        maxLength={15}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <FormLabel>State</FormLabel>
                      <Field as="select" name="state">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={_isArray(statesList) ? statesList : []}
                            inputPlaceholder={"Select State"}
                            disableCloseOnSelect={false}
                            onChange={(e, value) => {
                              setFieldValue(
                                "state",
                                value ? value.stateName : ""
                              );
                            }}
                            getOptionLabel={(option) => option.stateName || ""}
                            value={
                              statesList.find(
                                (e) => e.stateName == values.state
                              ) || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.stateName}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                          />
                        )}
                      </Field>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <FormLabel>Zip</FormLabel>
                      <Field
                        name="zip"
                        type="text"
                        placeholder="Enter Zip"
                        className={globalClasses.formControl}
                        maxLength={15}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={3}
                      className={classes.opaLocationSearchGrid}
                    >
                      <Grid
                        xs={12}
                        container
                        spacing={2}
                        justifyContent="flex-end"
                      >
                        <Grid item>
                          <Button
                            type="submit"
                            size="small"
                            variant="contained"
                            className={globalClasses.primaryBtn}
                          >
                            Search
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            type="reset"
                            size="small"
                            variant="outlined"
                            className={globalClasses.secondaryBtn}
                            onClick={() => {
                              handleClear(initialValues);
                            }}
                          >
                            Clear
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </div>
          </Form>
        );
      }}
    </Formik>
  );
};

export default SearchForm;
