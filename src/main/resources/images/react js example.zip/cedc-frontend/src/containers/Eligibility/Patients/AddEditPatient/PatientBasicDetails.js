import React from "react";
import { useDispatch } from "react-redux";
import {
  Grid,
  Button,
  FormControlLabel,
  Switch,
  FormLabel,
  Typography,
  Tooltip,
} from "@material-ui/core";
import _isNull from "lodash/isNull";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import { Formik, Form, Field } from "formik";
import { getMNRExist } from "../../../../context/actions/Patients";
import { usePatientStyles } from "../style";
import {
  REGEX,
  TEXT_ELLIPSIS_MAX_LENGTH,
  getGender,
} from "../../../../utils/constants";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import { CustomTextRenderer } from "../../../../components/common/CustomTextRenderer";
import Toggle from "../../../../components/common/Toggle";
import { endDateValidation, getUserPreveleges } from "../../../../utils/common";
import AutoComplete from "../../../../components/common/AutoComplete";
import _isArray from "lodash/isArray";
import _get from "lodash/get";
import classNames from "classnames";

const PatientBasicDetails = (patientProps) => {
  const {
    setOpenPopup,
    setValue,
    formRef,
    setFormData,
    formData,
    viewPatient,
    editPatient,
    isMRNExist,
    setIsMRNExist,
  } = patientProps || {};
  const globalClasses = useGlobalStyles();
  const phiAccess = getUserPreveleges("PHI Access");
  const dispatch = useDispatch();
  const classes = usePatientStyles();
  const genderOptions = _isArray(getGender()) ? getGender() : [];
  const handleMRN = (e, setFieldValue) => {
    const regEx = /^\S*$/;
    let { name, value } = e.target;
    if (!regEx.test(value)) return;
    setFieldValue(name, value);
    if (value) {
      dispatch(
        getMNRExist(value, (res) => {
          if (res.statusCode == 404) setIsMRNExist(res.errorMessage);
          else if (res.statusCode == 200) setIsMRNExist("");
        })
      );
    }
  };

  const handleFormData = (values, isSubmitting) => {
    if (isSubmitting) setFormData(values);
    setValue(1);
  };

  const formValidate = (values) => {
    const errors = {};
    if (_isNull(values.mrn) || values.mrn === "") {
      setIsMRNExist("");
      errors.mrn = "Please enter MRN";
    }
    if (!(isMRNExist === "")) {
      errors.mrn = isMRNExist;
    }
    if (_isNull(values.firstName) || values.firstName === "") {
      errors.firstName = "Please enter the Patient First Name";
    }
    if (values.lastName === "") {
      errors.lastName = "Please enter the Patient Last Name";
    }
    if (_isNull(values.dateOfBirth) || values.dateOfBirth === "") {
      errors.dateOfBirth = "Please Select the Patient DOB";
    }
    if (values.gender === "") {
      errors.gender = "Please select Gender";
    }
    return errors;
  };

  const handleChange = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    let { name, value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue(name, value);
  };

  const getCoveredEntityName = (ceName) => {
    return (
      <div className={classes.coveredEntityNameWrapper}>
        <Tooltip title={ceName}>
          <div className={classes.coveredEntityName}>{ceName}</div>
        </Tooltip>
      </div>
    );
  };

  return (
    <Formik
      enableReinitialize={true}
      initialValues={formData}
      validate={formValidate}
      innerRef={formRef}
      onSubmit={handleFormData}
    >
      {({ values, errors, touched, setFieldValue }) => (
        <>
          <Grid container spacing={2}>
            <Grid item>
              <BasicTypography variant="h4" title="Patient Basic Details" />
            </Grid>
            <Grid item>
              <Form>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <FormLabel>Covered Entity</FormLabel>
                    {viewPatient ? (
                      <BasicTypography variant="subtitle2">
                        {values.ceName}
                      </BasicTypography>
                    ) : (
                      getCoveredEntityName(values.ceName)
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>340B ID</FormLabel>
                    {viewPatient ? (
                      <Typography variant="subtitle2">
                        {values.ID340B}
                      </Typography>
                    ) : (
                      <Field
                        name="340bId"
                        id="340bId"
                        value={values.ID340B}
                        disabled
                        className={globalClasses.formControl}
                        placeholder="Enter 340B ID"
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!viewPatient}>MRN</FormLabel>
                    {viewPatient ? (
                      <Typography
                        variant="subtitle2"
                        className={classNames({
                          [globalClasses.phiAccessColor]: _get(
                            phiAccess,
                            "readOnlyFlag",
                            false
                          ),
                        })}
                      >
                        {values.mrn}
                      </Typography>
                    ) : (
                      <Field
                        name="mrn"
                        id="mrn"
                        maxLength={20}
                        type="text"
                        disabled={editPatient}
                        className={globalClasses.formControl}
                        placeholder="Enter MRN "
                        onChange={(e) => {
                          handleMRN(e, setFieldValue);
                        }}
                      />
                    )}
                    {((touched.mrn && errors.mrn) || isMRNExist) && (
                      <Typography color="error" variant="caption">
                        {isMRNExist ? isMRNExist : errors.mrn}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!viewPatient}>
                      Patient First Name
                    </FormLabel>
                    {viewPatient ? (
                      <Typography
                        variant="subtitle2"
                        className={classNames({
                          [globalClasses.phiAccessColor]: _get(
                            phiAccess,
                            "readOnlyFlag",
                            false
                          ),
                        })}
                      >
                        {values.firstName}
                      </Typography>
                    ) : (
                      <Field
                        name="firstName"
                        type="text"
                        maxLength={50}
                        className={globalClasses.formControl}
                        placeholder="Enter Patient First Name"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (value && !REGEX.alphabetsAndHypen.test(value))
                            return;
                          setFieldValue("firstName", value);
                          handleChange(e, setFieldValue);
                        }}
                      />
                    )}
                    {touched.firstName && errors.firstName && (
                      <Typography color="error" variant="caption">
                        {errors.firstName}
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Patient Middle Name</FormLabel>
                    {viewPatient ? (
                      <Typography variant="subtitle2">
                        {values.middleName}
                      </Typography>
                    ) : (
                      <Field
                        name="middleName"
                        type="text"
                        maxLength={1}
                        className={globalClasses.formControl}
                        placeholder="Enter Patient Middle Name"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (value && !REGEX.alphabetsAndHypen.test(value))
                            return;
                          setFieldValue("middleName", value);
                          handleChange(e, setFieldValue);
                        }}
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!viewPatient}>
                      Patient Last Name
                    </FormLabel>
                    {viewPatient ? (
                      <Typography
                        variant="subtitle2"
                        className={classNames({
                          [globalClasses.phiAccessColor]: _get(
                            phiAccess,
                            "readOnlyFlag",
                            false
                          ),
                        })}
                      >
                        {values.lastName}
                      </Typography>
                    ) : (
                      <Field
                        name="lastName"
                        type="text"
                        maxLength={50}
                        className={globalClasses.formControl}
                        placeholder="Enter Patient Last Name"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (value && !REGEX.alphabetsAndHypen.test(value))
                            return;
                          setFieldValue("lastName", value);
                          handleChange(e, setFieldValue);
                        }}
                      />
                    )}
                    {touched.lastName && errors.lastName && (
                      <Typography color="error" variant="caption">
                        {errors.lastName}
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Suffix</FormLabel>
                    {viewPatient ? (
                      <CustomTextRenderer
                        value={values.suffix || "...."}
                        variant={"subtitle2"}
                        maxLength={TEXT_ELLIPSIS_MAX_LENGTH}
                      />
                    ) : (
                      <Field
                        name="suffix"
                        id="suffix"
                        type="text"
                        maxLength={50}
                        className={globalClasses.formControl}
                        placeholder="Enter Suffix"
                        onChange={(e) => handleChange(e, setFieldValue)}
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!viewPatient}>Patient DOB</FormLabel>
                    {viewPatient ? (
                      <Typography
                        variant="subtitle2"
                        className={classNames({
                          [globalClasses.phiAccessColor]: _get(
                            phiAccess,
                            "readOnlyFlag",
                            false
                          ),
                        })}
                      >
                        {values.dateOfBirth}
                      </Typography>
                    ) : (
                      <Field as="select" name="dateOfBirth">
                        {({ field }) => (
                          <DatePicker
                            className={globalClasses.formControl}
                            {...field}
                            onChange={(_e, date) => {
                              setFieldValue("dateOfBirth", date);
                            }}
                            disabledDate={(current) =>
                              current.isAfter(moment())
                            }
                            value={
                              values.dateOfBirth
                                ? moment(values.dateOfBirth, "MM/DD/YYYY")
                                : ""
                            }
                          />
                        )}
                      </Field>
                    )}
                    {touched.dateOfBirth && errors.dateOfBirth && (
                      <Typography color="error" variant="caption">
                        {errors.dateOfBirth}
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required={!viewPatient}>Gender</FormLabel>

                    {viewPatient ? (
                      <Typography
                        variant="subtitle2"
                        className={classNames({
                          [globalClasses.phiAccessColor]: _get(
                            phiAccess,
                            "readOnlyFlag",
                            false
                          ),
                        })}
                      >
                        {values.gender === "M"
                          ? "Male"
                          : values.gender === "F"
                          ? "Female"
                          : values.gender === "D"
                          ? "D"
                          : ""}
                      </Typography>
                    ) : (
                      <Field as="select" name="gender">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={genderOptions}
                            inputPlaceholder={"Select Gender"}
                            disableCloseOnSelect={false}
                            value={
                              genderOptions.find(
                                (el) => el.value == values.gender
                              ) || ""
                            }
                            onChange={(_e, value) => {
                              setFieldValue("gender", _get(value, "value", ""));
                            }}
                            getOptionLabel={(option) => {
                              return option.label || "";
                            }}
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.label}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                            textFieldProps={{
                              inputProps: {
                                name: "gender",
                              },
                            }}
                          />
                        )}
                      </Field>
                    )}
                    {touched.gender && errors.gender && (
                      <Typography color="error" variant="caption">
                        {errors.gender}
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Admit/Visit Date</FormLabel>
                    {viewPatient ? (
                      <div>{values.effectiveDate}</div>
                    ) : (
                      <DatePicker
                        value={
                          values.effectiveDate !== ""
                            ? moment(values.effectiveDate)
                            : ""
                        }
                        disabled
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Recent Visit Date</FormLabel>
                    {viewPatient ? (
                      <Typography variant="subtitle2">
                        {values.recentVisitDate}
                      </Typography>
                    ) : (
                      <DatePicker
                        value={
                          values.recentVisitDate !== ""
                            ? moment(values.recentVisitDate)
                            : ""
                        }
                        disabled
                      />
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormLabel>Eligibility Termination Date</FormLabel>
                    {viewPatient ? (
                      <Typography variant="subtitle2">
                        {values.terminationDate}
                      </Typography>
                    ) : (
                      <Field as="select" name="terminationDate">
                        {({ field }) => (
                          <DatePicker
                            className={globalClasses.formControl}
                            disabledDate={(d) =>
                              endDateValidation(d, values.effectiveDate)
                            }
                            {...field}
                            onChange={(_e, date) => {
                              setFieldValue("terminationDate", date);
                            }}
                            value={
                              values.terminationDate
                                ? moment(values.terminationDate, "MM/DD/YYYY")
                                : ""
                            }
                            disabled
                          />
                        )}
                      </Field>
                    )}
                  </Grid>

                  <Grid item xs={12} sm={4}>
                    <FormControlLabel
                      control={
                        <Field
                          name="personTypeId"
                          component={Toggle}
                          type="checkbox"
                          onChange={(e) =>
                            setFieldValue(
                              "personTypeId",
                              e.target.checked ? 1 : 2
                            )
                          }
                          checked={values.personTypeId === 1 ? true : false}
                          disabled={viewPatient}
                        />
                      }
                    />
                    <Tooltip
                      placement="bottom"
                      title="Exclude patients from claims being processed."
                    >
                      <FormLabel>Exclude?</FormLabel>
                    </Tooltip>
                  </Grid>

                  <Grid item md={12}>
                    <Grid container justifyContent="flex-end" spacing={2}>
                      <Grid item>
                        <Button
                          type="submit"
                          color="primary"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                        >
                          Next
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          color="default"
                          className={globalClasses.secondaryBtn}
                          onClick={() => {
                            setOpenPopup(false);
                          }}
                        >
                          Cancel
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Form>
            </Grid>
          </Grid>
        </>
      )}
    </Formik>
  );
};

export default PatientBasicDetails;
