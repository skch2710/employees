import { makeStyles } from "@material-ui/core/styles";

export const useBasicDetailsStyles = makeStyles((theme) => {
  return {
    switchGridContainer: {
      display: "flex",
      alignItems: "flex-end",
    },
    switchContainer: {
      display: "flex",
      justifyContent: "space-between",
      width: "100%",
      height: "30px",
    },
    switchLabel: {
      color: theme.colors.monochrome.input,
      fontSize: "13px",
    },
    actionBtnGridItem: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
  };
});

export const useUploadDocumentStyles = makeStyles((theme) => {
  return {
    uploadPlaceholderContainer: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      justifyContent: "center",
      gap: "22px",
    },
    iconContainer: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
    },
    progressContainer: {
      border: `2px dashed ${theme.colors.monochrome.border}`,
      borderRadius: 2,
      display: "flex",
      justifyContent: "center",
      padding: "20px",
    },
  };
});

export const getDroppableStyle = ({
  isDragActive,
  isDragAccept,
  isDragReject,
  theme,
}) => {
  return {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "20px",
    borderWidth: 2,
    borderRadius: 2,
    borderColor: theme.colors.monochrome.border,
    borderStyle: "dashed",
    backgroundColor: theme.colors.monochrome.bg,
    color: theme.colors.monochrome.placeholder,
    transition: "border .3s ease-in-out",
    cursor: "auto",
    ...(isDragActive ? { borderColor: theme.colors.blue[900] } : {}),
    ...(isDragAccept ? { borderColor: theme.colors.green.default } : {}),
    ...(isDragReject ? { borderColor: theme.colors.red[500] } : {}),
  };
};
