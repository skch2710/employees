import React, {
  useEffect,
  useState,
  useRef,
  useContext,
  useCallback,
  useImperativeHandle,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import MaterialTable, { MTableToolbar } from "material-table";
import { Button, Grid, Paper, Tooltip } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import DatePicker from "../../../components/common/DatePicker";
import {
  deleteLocation,
  getLocationList,
  getOPASearchResultTableData,
  opaLocationSave,
  changeParticipatingStatus,
} from "../../../context/actions/Locations";
import AddLocationPopup from "./AddLocationPopup";
import ExportLocations from "./ExportLocations";
import { pagination } from "../../../utils/constants";
import _isEqual from "lodash/isEqual";
import _isEmpty from "lodash/isEmpty";
import _isArray from "lodash/isArray";
import moment from "moment";
import { useLocationStyles } from "./styles";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../Styles/useGlobalStyles";
import {
  getTableHeaderCount,
  getUserSession,
  isEmptyGrid,
} from "../../../utils/helper";
import DataNotFound from "../../../components/common/DataNotFound";
import TableProgressBar from "../../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import BasicPopup from "../../../components/Popup/BasicPopup";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../components/common/Pagination";
import SearchForm from "./OPALocationPopup/SearchForm";
import RegisteredParticipatedTables from "./OPALocationPopup/RegisteredParticipatedTables";
import { MdVerified } from "react-icons/md";
import {
  ADDRESS_TABS,
  ALL,
  OPPORTUNITY_ADDRESS,
  PARTICIPATING,
  TERMINATED,
  getLocationsFiltersObject,
  getRegisteredOPATablePayload,
} from "./constants";
import { COContext } from "../COContext";
import { SET_OPA_REGISTERED_LOCATIONS_LIST } from "../../../context/reducers/Locations/constants";
import ParticipatePopup from "./ParticipatePopup";
import AddressDrillDown from "./AddressDrillDown";
import AddressDrillDownPopupFooter from "./AddressDrillDown/AdressDrillDownPopupFooter";
import { forwardRef } from "react";
import { getCeLocations } from "../../../context/actions/ConfigOverview";
import { getCeLocationPayloadJson } from "../ConfigurationOverview/CeSummary/CeLocations/helper";

const LocationsListTable = forwardRef((props = {}, ref) => {
  const {
    controllers,
    setControllers,
    Co,
    setOpenPopup,
    setActionTitle,
    setSubmitActionType,
    permissionObj,
    submitActionType,
    openPopup,
    actionTitle,
    ceSelected,
    messageUuid,
    searchData = {},
    columnFilters,
    setColumnFilters,
    clickOnAdd,
    tabSelected,
    fetchLocations,
    tabPayload,
    fetchNewLocationsCount,
    setTabSelected,
    setDefaultValues,
    initialValues
  } = props;
  const tableRef = useRef(null);

  const dispatch = useDispatch();
  const theme = useTheme();
  const globalClasses = useGlobalStyles();

  const [editData, setEditData] = useState(null);
  const [filter, setFilter] = useState(false);
  const columnFiltersRef = useRef({});
  const { exportToExcel } = ExportLocations();
  const iconsAndButtons = useTableIconsAndButtons();
  const { setParticipatingLocationsData, participatingLocationsData } =
    useContext(COContext);

  const { records: locationsTableData, loading } =
    useSelector((state) => state.getLocationListDataValues) || {};
  const statesList = useSelector((state) => state.ce_states_list.records) || [];

  const classes = useLocationStyles();
  const [OPALocationPopup, setOPALocationOpenPopup] = useState(false);
  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [showParticipatePopup, setShowParticipatePopup] = useState(false);
  const [isTerminatePopup, setIsTerminatePopup] = useState(false);
  const [addressDrillDownPopup, setAddressDrillDownPopup] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const userSession = getUserSession();

  const actionRef = useRef(null);

  useEffect(() => {
    if (editData && !openPopup) setEditData(null);
  }, [openPopup]);

  useEffect(() => {
    if (!_isEqual(columnFilters, columnFiltersRef.current)) {
      const updatedObj = {};
      columnFilters.forEach((eachVal) => {
        updatedObj[eachVal.column.field] = eachVal.value;
      });
      columnFiltersRef.current = { ...updatedObj };
    }
  }, [columnFilters]);

  useImperativeHandle(ref, () => ({
    submitForm(resp) {
      columnFiltersRef.current = {};
      setColumnFilters([]);
      setControllersOnResp(resp, { sortOrder: "asc", sortBy: "locationName" });
    },
    clearForm(values) {
      columnFiltersRef.current = {};
      setColumnFilters([]);
      values.ceid = initialValues.ceid;
      fetchLocations(values, (resp) =>
        setControllersOnResp(resp, { sortOrder: "asc", sortBy: "locationName" })
      );
    },
  }));

  const onNextButtonClick = () => {
    setActiveTab(activeTab + 1);
  };

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNo: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const getSearchTableData = async (payload = {}, callback) => {
    const ceSelectedNew = Co
      ? {
          ceID: messageUuid && messageUuid.ceid,
          ceCode: messageUuid && messageUuid.hrsaId,
        }
      : ceSelected;
    const searchPayload = getRegisteredOPATablePayload(payload, ceSelectedNew);
    const tableData = await dispatch(
      getOPASearchResultTableData(searchPayload)
    );
    if (!_isEmpty(tableData)) callback && callback(tableData);
  };

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getLocationsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchLocations(
      {
        ...searchData,
        ...controllers,
        filter: filterPayload,
        pageNo: pagination.page,
        locationStatus: tabPayload,
      },
      (resp) => setControllersOnResp(resp)
    );
  };
  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = Number(newPage) + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(locationsTableData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNo > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNo;
      fetchLocations(
        {
          ...searchData,
          pageNo: currentPage,
          pageSize: rowsPerPage,
          sortOrder: controllers.sortOrder,
          sortBy: controllers.sortBy,
          filter: columnFilters,
          locationStatus: tabPayload,
        },
        (resp) => setControllersOnResp(resp)
      );
    },
    [columnFilters, locationsTableData, controllers, searchData]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = COVERED_ENTITY_LOCATIONS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchLocations(
        {
          ...searchData,
          pageNo: controllers.pageNo,
          pageSize: controllers.pageSize,
          sortOrder,
          sortBy,
          filter: columnFilters,
          locationStatus: tabPayload,
        },
        (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
      );
    },
    [controllers, searchData, columnFilters, locationsTableData]
  );

  const handleParticipatePopup = ({ state, endDate }) => {
    if (state) {
      if (!isTerminatePopup) {
        const payload = {
          ceId: editData.ceid,
          entityLocationId: editData.entityLocationId,
          isTerminated: editData.locationStatus === "Terminated",
          modifiedById: userSession.userId,
        };
        dispatch(
          changeParticipatingStatus(payload, (res) => {
            if (res.statusCode === 200) {
              setEditData(null);
              setShowParticipatePopup(false);
              fetchLocations();
            }
          })
        );
      } else {
        const payload = {
          ceId: editData.ceid,
          entityLocationId: editData.entityLocationId,
          modifiedById: userSession.userId,
          endDate: endDate.opaLocEndDate,
        };
        dispatch(
          deleteLocation(payload, (res) => {
            if (res.statusCode === 200) {
              setShowParticipatePopup(false);
              setIsTerminatePopup(false);
              fetchLocations();
            }
          })
        );
      }
    } else {
      setEditData(null);
      setShowParticipatePopup(false);
      setIsTerminatePopup(false);
    }
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const COVERED_ENTITY_LOCATIONS = [
    {
      title: "Verified",
      field: "verified",
      filtering: false,
      sorting: false,
      customFilterAndSearch: () => false,
      render: (rowData) => {
        return rowData.source == "OPA File" ? (
          <MdVerified className={classes.verifiedIcon} />
        ) : null;
      },
    },
    {
      title: "Source",
      field: "source",
      defaultFilter: filter && columnFiltersRef.current.source,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.source}>
            <span>{rowData.source}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.source}
          placeholder="Source"
        />
      ),
    },

    {
      title: " Participating 340B Site",
      field: "site340b",
      defaultFilter: filter && columnFiltersRef.current.site340b,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip
            title={
              rowData.site340b
                ? rowData.site340b === "true"
                  ? "Yes"
                  : "No"
                : ""
            }
          >
            <span>
              {rowData.site340b
                ? rowData.site340b === "true"
                  ? "Yes"
                  : "No"
                : ""}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={columnFiltersRef.current.site340b || ""}
          >
            <option value={""}>Select option</option>
            <option value="true">Yes</option>
            <option value="false">No</option>
          </select>
        );
      },
    },
    {
      title: "Covered Entity",
      field: "coveredEntity",
      defaultFilter: filter && columnFiltersRef.current.coveredEntity,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity}>
            <span>{rowData.coveredEntity}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.coveredEntity}
          placeholder="Covered Entity"
        />
      ),
    },

    {
      title: "Provider Location",
      field: "locationName",
      defaultFilter: filter && columnFiltersRef.current.locationName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationName}>
            <span>{rowData.locationName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationName}
          placeholder="Provider Location"
        />
      ),
    },
    {
      title: "Provider Location HRSA ID",
      field: "locationHrsaId",
      defaultFilter: filter && columnFiltersRef.current.locationHrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationHrsaId}>
            <span>{rowData.locationHrsaId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationHrsaId}
          placeholder="Provider Location HRSA ID"
        />
      ),
    },
    {
      title: "Address Line 1",
      field: "addressLine1",
      defaultFilter: filter && columnFiltersRef.current.addressLine1,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine1}>
            <span>{rowData.addressLine1}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addressLine1}
          placeholder="Address Line 1"
        />
      ),
    },
    {
      title: "Address Line 2",
      field: "addressLine2",
      defaultFilter: filter && columnFiltersRef.current.addressLine2,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine2}>
            <span>{rowData.addressLine2}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.addressLine2}
          placeholder="Address Line 2"
        />
      ),
    },
    {
      title: "City",
      field: "city",
      defaultFilter: filter && columnFiltersRef.current.city,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.city}>
            <span>{rowData.city}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.city}
          placeholder="City"
        />
      ),
    },
    {
      title: "State",
      field: "state",
      defaultFilter: filter && columnFiltersRef.current.state,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.state}>
            <span>{rowData.state}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.state}
          placeholder="State"
        />
      ),
    },
    {
      title: "Zip",
      field: "zip",
      defaultFilter: filter && columnFiltersRef.current.zip,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.zip}>
            <span>{rowData.zip}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.zip}
          placeholder="Zip"
        />
      ),
    },
    {
      title: "Provider Start Date",
      field: "startDate",
      defaultFilter: filter && columnFiltersRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.startDate
                ? moment(columnFiltersRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Provider End Date",
      field: "endDate",
      defaultFilter: filter && columnFiltersRef.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.endDate
                ? moment(columnFiltersRef.current.endDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Provider Status",
      field: "locationStatus",
      defaultFilter: filter && columnFiltersRef.current.locationStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationStatus}>
            <span>{rowData.locationStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.locationStatus}
          placeholder="Provider Status"
        />
      ),
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(locationsTableData),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(locationsTableData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(locationsTableData),
      onClick: () =>
        exportToExcel({
          Co: Co,
          ceSelected,
          messageUuid,
          searchData,
          columnFilters,
          tabPayload,
          ...controllers,
        }),
    },
    {
      icon: iconsAndButtons.AddCustomButton({
        title: "Add Location from OPA",
        disabled:
          !ceSelected.ceID ||
          (permissionObj !== null && permissionObj.readWriteFlag
            ? false
            : true),
      }),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : !ceSelected
          ? "Please select a Covered Entity to enable this button"
          : "",
      isFreeAction: true,
      disabled:
        !ceSelected.ceID ||
        (permissionObj !== null && permissionObj.readWriteFlag ? false : true),
      onClick: () => {
        setOPALocationOpenPopup(true);
        getSearchTableData({});
      },
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : !ceSelected
          ? "Please select a Covered Entity to enable this button"
          : "",
      disabled: true,
      isFreeAction: true,
    },
    tabSelected !== OPPORTUNITY_ADDRESS && {
      icon: iconsAndButtons.Plus(),
      tooltip: "Address Drilldown",
      isFreeAction: false,
      disabled:
        permissionObj !== null && permissionObj.readOnlyFlag ? false : true,
      onClick: (_event, rowData) => {
        setAddressDrillDownPopup(true);
        setEditData(rowData);
      },
    },
    tabSelected !== PARTICIPATING
      ? (rowData) => {
          const isDisabled =
            rowData.locationStatus === "Participating" ? true : false;
          return {
            icon: iconsAndButtons.Location(),
            tooltip:
              permissionObj !== null && !permissionObj.readWriteFlag
                ? "You don't have Permission."
                : isDisabled
                ? "Participating"
                : "Participate",
            isFreeAction: false,
            disabled:
              !isDisabled &&
              permissionObj !== null &&
              permissionObj.readWriteFlag
                ? false
                : true,
            onClick: (_event, rowData) => {
              setShowParticipatePopup(true);
              setEditData(rowData);
            },
          };
        }
      : "",

    tabSelected !== TERMINATED && tabSelected !== OPPORTUNITY_ADDRESS
      ? (rowData) => {
          return {
            icon: iconsAndButtons.Edit(),
            tooltip:
              permissionObj !== null && !permissionObj.readWriteFlag
                ? "You don't have Permission."
                : "Edit",
            isFreeAction: false,
            disabled:
              (permissionObj !== null && permissionObj.readWriteFlag
                ? false
                : true) || rowData.source === "OPA File",
            onClick: (_event, rowData) => {
              setOpenPopup(true);
              setEditData(rowData);
              setActionTitle(`Edit Covered Entity Location`);
              setSubmitActionType("Edit Location");
            },
          };
        }
      : "",

    tabSelected !== TERMINATED
      ? (rowData) => {
          const isTerminated =
            rowData.locationStatus === "Terminated" ? true : false;

          return {
            icon: iconsAndButtons.Block({ isBlocked: isTerminated }),
            tooltip:
              permissionObj !== null && !permissionObj.terminateFlag
                ? "You don't have Permission."
                : isTerminated
                ? "Terminated"
                : "Terminate",
            isFreeAction: false,
            disabled:
              !isTerminated &&
              permissionObj !== null &&
              permissionObj.terminateFlag
                ? false
                : true,
            onClick: (_event, rowData) => {
              setEditData(rowData);
              setShowParticipatePopup(true);
              setIsTerminatePopup(true);
            },
          };
        }
      : "",
  ];

  const ActionsCo = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: locationsTableData && locationsTableData.totalElements < 1,
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(locationsTableData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(locationsTableData),
      onClick: () =>
        exportToExcel({
          Co: Co,
          ceSelected,
          messageUuid,
          searchData,
          columnFilters,
          ...controllers,
        }),
    },
    {
      icon: iconsAndButtons.AddCustomButton({
        title: "Add Location from OPA",
      }),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : "Add Location from OPA",
      isFreeAction: true,
      onClick: () => {
        setOPALocationOpenPopup(true);
        getSearchTableData({});
      },
      disabled:
        permissionObj !== null && permissionObj.readWriteFlag ? false : true,
    },
    {
      icon: iconsAndButtons.AddCustomButton({
        title: "Add Covered Entity Location",
      }),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : "Add Covered Entity Location",
      isFreeAction: true,
      disabled:
        permissionObj !== null && permissionObj.readWriteFlag ? false : true,
      onClick: (event, rowData) => {
        setOpenPopup(true);
        setActionTitle("Add Covered Entity Location");
        setSubmitActionType("submit");
      },
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : "Upload",
      isFreeAction: true,
      disabled: true,
    },
  ];

  const handleSubmitOPASearch = (values) => {
    getSearchTableData(values, (resp) => {
      actionRef.current && actionRef.current.submitForm(resp);
    });
    setFormSubmittedValues(values);
  };
  const handleClearOPASearch = (values) => {
    setFormSubmittedValues(values);
    actionRef.current && actionRef.current.clearForm(values);
  };
  const handleCloseOPAPopup = () => {
    setParticipatingLocationsData({ content: [], totalElements: 0 });
    dispatch({
      type: SET_OPA_REGISTERED_LOCATIONS_LIST,
      data: {},
    });
    setOPALocationOpenPopup(false);
  };
  const handleAddLocation = () => {
    const ceSelectedNew =
      Co && messageUuid
        ? {
            ceID: messageUuid && messageUuid.ceid,
            ceCode: messageUuid && messageUuid.hrsaId,
            ...messageUuid,
          }
        : ceSelected;
    let payload =
      (participatingLocationsData &&
        participatingLocationsData.content.map((values) => {
          return {
            ceid: ceSelectedNew && ceSelectedNew.ceID,
            entityLocationId: 0,
            locationName: values.locName || "Unspecified Location",
            locationHrsaId: values.locHrsaid,
            locSourceId: 2,
            addressLine1: values.address1,
            addressLine2: values.address2,
            city: values.city,
            endDate: values.endDate || "",
            startDate:
              values.startDate || moment(new Date()).format("MM/DD/YYYY") || "",
            zipCode: values.zip,
            stateId:
              values.stateId ||
              statesList.find((ele) => ele.stateName == values.state).stateId,
            is340bSite: false,
            modifiedById: userSession.userId,
            createdById:userSession.userId,
            addrHashKey: values.nonStandardAddrHashKey,
            standardAddrHashKey: values.standardAddrHashKey,
            modifiedDate: moment(new Date()).format("MM/DD/YYYY") || "",
            standardAddress1: values.address1,
            standardAddress2: values.address2,
            standardCity: values.city,
            standardState: values.state,
            standardZip: values.zip,
          };
        })) ||
      [];

    if (payload.length > 0) {
      dispatch(
        opaLocationSave(payload, async (res) => {
          if (res.statusCode === 200) {
            handleCloseOPAPopup();
            let locationPayload = {
              ceid: ceSelectedNew.ceID,
              locationStatus: "",
            };
            if (!Co) {
              const locationList = await dispatch(
                getLocationList({
                  ceIDs: [ceSelectedNew.ceID],
                  locationName: "",
                })
              );
              locationPayload = {
                ...locationPayload,
                locations: locationList || [],
                pageNo: pagination.page,
                filter: [],
              };
              setDefaultValues((prev) => ({
                ...prev,
                locations: locationList,
              }));
            }
            if (Co && !clickOnAdd) {
              dispatch(
                getCeLocations(
                  getCeLocationPayloadJson({
                    ceId: messageUuid.ceid,
                  })
                )
              );
            }
            fetchLocations(locationPayload, (resp) =>
              setControllersOnResp(resp)
            );
            if (!Co) {
              fetchNewLocationsCount(ceSelectedNew && ceSelectedNew.ceID);
            }
            setTabSelected(ALL);
            setColumnFilters([]);
            columnFiltersRef.current = {};
          }
        })
      );
    }
  };
  const disableSave = () => {
    if (
      !_isEmpty(participatingLocationsData) &&
      _isArray(participatingLocationsData.content) &&
      participatingLocationsData.content.length > 0
    ) {
      return false;
    } else return true;
  };
  const updateFieldsAfterSaveLocation = (resp) => {
    setControllersOnResp(resp);
    if (_isArray(resp.locations))
      setDefaultValues((prev) => ({
        ...prev,
        locations: resp.locations,
      }));
  };
  return (
    <div
      className={`${globalClasses.tableCardPrimary} ${classes.containerTablePad}`}
    >
      <MaterialTable
        tableRef={tableRef}
        title={
          <BasicTypography
            variant="h5"
            title={`Locations (${getTableHeaderCount(
              locationsTableData.totalElements
            )})`}
          />
        }
        columns={COVERED_ENTITY_LOCATIONS}
        data={locationsTableData.content || []}
        page={controllers.pageNo - 1}
        totalCount={locationsTableData.totalElements}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        actions={Co ? ActionsCo : Actions}
        localization={{
          header: {
            actions: !Co && "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        icons={{
          SortArrow: () => TableCustomSortArrow(controllers),
          Filter: ColumnFilterIcon,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: filter,
          paginationType: "stepped",
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controllers.pageSize,
          draggable: false,
          maxBodyHeight: 285,
          doubleHorizontalScroll: false,
          pageSizeOptions: isEmptyGrid(locationsTableData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
      {openPopup && (
        <BasicPopup
          title={actionTitle}
          show={openPopup}
          handleClose={() => {
            setOpenPopup(false);
          }}
          disableFooter={true}
          dialogProps={{
            maxWidth: "md",
          }}
        >
          <AddLocationPopup
            submitactiontype={submitActionType}
            setOpenPopup={setOpenPopup}
            rowData={editData}
            ceSelected={ceSelected}
            messageUuid={messageUuid}
            title={actionTitle}
            Co={Co}
            searchData={searchData}
            clickOnAdd={clickOnAdd}
            tabPayload={tabPayload}
            setTabSelected={setTabSelected}
            fetchLocations={fetchLocations}
            controllers={controllers}
            updateFieldsAfterSaveLocation={updateFieldsAfterSaveLocation}
          />
        </BasicPopup>
      )}
      {OPALocationPopup && (
        <BasicPopup
          title={"Add Covered Entity Location from OPA"}
          show={OPALocationPopup}
          handleClose={handleCloseOPAPopup}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid item md={12}>
              <SearchForm
                handleSubmit={handleSubmitOPASearch}
                handleClear={handleClearOPASearch}
              />
            </Grid>
            <Grid item>
              <RegisteredParticipatedTables
                ref={actionRef}
                ceSelected={ceSelected}
                searchTableProps={{
                  formSubmittedValues,
                  getSearchTableData,
                }}
              />
            </Grid>
            <Grid item>
              <Grid container spacing={2} justifyContent="flex-end">
                <Grid item>
                  <Button
                    type="submit"
                    size="small"
                    variant="contained"
                    disabled={disableSave()}
                    className={globalClasses.primaryBtn}
                    onClick={handleAddLocation}
                  >
                    Save
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    type="reset"
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={handleCloseOPAPopup}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </BasicPopup>
      )}
      {showParticipatePopup && (
        <BasicPopup
          show={showParticipatePopup}
          disableFooter={true}
          disableHeader={true}
          dialogProps={{
            maxWidth: "sm",
          }}
        >
          <ParticipatePopup
            handleParticipatePopup={handleParticipatePopup}
            isTerminatePopup={isTerminatePopup}
          />
        </BasicPopup>
      )}

      {addressDrillDownPopup && (
        <BasicPopup
          title={
            !_isEmpty(editData) &&
            `${editData.coveredEntity} - ${editData.ceCode}`
          }
          show={addressDrillDownPopup}
          handleClose={() => {
            setAddressDrillDownPopup(false);
            setEditData(null);
            setActiveTab(0);
          }}
          dialogProps={{
            maxWidth: "lg",
            classes: {
              paper: classes.dialogPaper,
            },
          }}
          disableFooter={true}
          isCustomFooter={true}
          footerActionElement={
            <AddressDrillDownPopupFooter
              closePopup={() => {
                setAddressDrillDownPopup(false);
                setEditData(null);
                setActiveTab(0);
              }}
              hideNext={activeTab === ADDRESS_TABS.LOCATION_HISTORY}
              onNextButtonClick={onNextButtonClick}
            />
          }
        >
          <AddressDrillDown
            locationData={editData}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />
        </BasicPopup>
      )}
    </div>
  );
});

export default LocationsListTable;
