import React, { useCallback } from "react";
import { useFormikContext } from "formik";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";

const EditNdcDatesPopupFooter = (props = {}) => {
  const { handleEditNdcDatesPopup } = props;
  const { submitForm } = useFormikContext();
  const globalClasses = useGlobalStyles();

  const handleCancel = useCallback(() => {
    handleEditNdcDatesPopup(false);
  }, []);

  return (
    <Grid container spacing={2} justifyContent="flex-end">
      <Grid item>
        <Button onClick={submitForm} className={globalClasses.primaryBtn}>
          Add
        </Button>
      </Grid>
      <Grid item>
        <Button className={globalClasses.grayButton} onClick={handleCancel}>
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};

export default EditNdcDatesPopupFooter;
