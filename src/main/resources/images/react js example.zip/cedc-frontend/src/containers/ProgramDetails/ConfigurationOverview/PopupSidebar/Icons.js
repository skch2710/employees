import React from "react";
import { FaHospital } from "react-icons/fa";
import { MdLocalPharmacy } from "react-icons/md";
import { TbUpload } from "react-icons/tb";
import { usePopupSidebarStyles } from "./styles";

const Icons = ({ menu }) => {
  const classes = usePopupSidebarStyles();
  if (menu === "entityDetails")
    return <FaHospital className={classes.sideBarIcon} />;
  else if (menu === "ceConfiguration")
    return <TbUpload className={classes.sideBarIcon} />;
  else if (menu === "phConfiguration")
    return <MdLocalPharmacy className={classes.sideBarIcon} />;
  return null;
};

export default Icons;
