import React, { forwardRef } from "react";
import { Button } from "@material-ui/core";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import BackupOutlinedIcon from "@material-ui/icons/BackupOutlined";
//react-icons
import { RiDeleteBin5Line } from "react-icons/ri";
import { BiEditAlt } from "react-icons/bi";
import { FaSort } from "react-icons/fa";
import { MdOutlineFilterList } from "react-icons/md";
import { BsDownload } from "react-icons/bs";
import { MdOutlineMedicalServices } from "react-icons/md";
import { getUserPermissionOnModuleName } from "../../../utils/helper";

const pharmacyPermissionObj = getUserPermissionOnModuleName("Pharmacies");

const tableIcons = {
  ExportButton: forwardRef((props, ref) => (
    <Button
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Export
    </Button>
  )),
  AddButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Add Covered Entity
    </Button>
  )),
  AddUserButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Add User
    </Button>
  )),
  UploadButton: forwardRef((props, ref) => (
    <Button
      startIcon={<BackupOutlinedIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Upload Locations
    </Button>
  )),
  Delete: forwardRef((props, ref) => (
    <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
  )),
  export: forwardRef((props, ref) => (
    <BsDownload fontSize="small" color="action" {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => (
    <BiEditAlt fontSize="small" color="action" {...props} ref={ref} />
  )),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => (
    <MdOutlineFilterList {...props} ref={ref} />
  )),
  addPharmacyCompleted: forwardRef((props, ref) => (
    <MdOutlineMedicalServices
      fontSize="small"
      color={pharmacyPermissionObj.readWriteFlag ? "#2196f3" : "#cccccc"}
      {...props}
      ref={ref}
    />
  )),
  addPharmacyPartial: forwardRef((props, ref) => (
    <MdOutlineMedicalServices fontSize="small" {...props} ref={ref} />
  )),
};

export default tableIcons;
