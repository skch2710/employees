import _isArray from "lodash/isArray";
import { pagination } from "../../../../../utils/constants";
import moment from "moment";

export const getSearchFormDefaultValues = () => {
  return {
    drugManufacturerId: "",
    gcn: "",
    ndc: "",
    drugName: "",
  };
};

export const getNdcSearchPayload = (values = {}) => {
  return {
    drugManufacturerId: values.drugManufacturerId&&[values.drugManufacturerId.drugManufacturerId] || [],
    gcn: values.gcn || "",
    ndc: _isArray(values.ndc) ? values.ndc : values.ndc ? [values.ndc] : [],
    drugName: values.drugName || "",
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "",
    sortBy: values.sortBy || "",
    filter: values.filter || [],
    export: values.export || false,
  };
};

export const getNdcSelectionDraftTablePayload = (values = {}) => {
  return {
    listHistoryId: values.listHistoryId || 0,
    listId: values.listId || 0,
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
    filter: [],
    export: values.export || true,
  };
};

export const getNdcSelectionSearchFiltersObject = (filters = []) => {
  const dateFields = [];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getNdcDetailsFiltersObject = (filters = []) => {
  const dateFields = ["ndcEffectiveStartDate", "ndcEffectiveEndDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getDraftPayloadToSave = (draftList = []) => {
  if (_isArray(draftList)) {
    return draftList.map(
      ({
        drugId,
        ndcEffectiveStartDate,
        ndcEffectiveEndDate,
        ndcExcDtlId,
        gcn,
        ndc,
        drugManufacturerId,
        drugTherapeuticClassId,
      } = {}) => ({
        drugId: drugId,
        startDate: ndcEffectiveStartDate,
        endDate: ndcEffectiveEndDate,
        ndcExcdtlId: ndcExcDtlId || 0,
        gcn: gcn || "",
        ndc: ndc || "",
        drugManufacturerId: drugManufacturerId || 0,
        drugTherapeuticClassId: drugTherapeuticClassId || 0,
      })
    );
  }
  return [];
};

export const getDraftExclusionListFiltersObject = (filters = []) => {
  const dateFields = ["ndcEffectiveStartDate", "ndcEffectiveEndDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getNdcDynamicListParamsSearchPayload = (values = {}) => {
  return {
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "asc",
    sortBy: values.sortBy || "",
    filter: values.filter || [],
    export: values.export || false,
    listHistoryId: values.listHistoryId || 0,
  };
};

export const getDlpFiltersObject = (filters = []) => {
  const dateFields = [
    "modifiedDate",
    "dynamicListEffecEndDate",
    "dynamicListEffecStartDate",
  ];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getMinDate = (selectedRows = []) => {
  const startDatesArray =
    selectedRows.map((row = {}) => {
      if (row.exclusionAppliedStartDate) {
        return moment(row.exclusionAppliedStartDate);
      }
      return moment();
    }) || [];
  return moment.max(startDatesArray).format("MM/DD/YYYY");
};
