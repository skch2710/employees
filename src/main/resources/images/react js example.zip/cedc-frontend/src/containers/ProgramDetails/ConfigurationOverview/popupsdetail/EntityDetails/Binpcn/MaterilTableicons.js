import React, { forwardRef } from "react";
import Button from "@material-ui/core/Button";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
//react-icons
import { RiDeleteBin5Line } from "react-icons/ri";
import { BiEditAlt } from "react-icons/bi";
import { FaSort } from "react-icons/fa";
import { AiOutlinePlus } from "react-icons/ai";
import { MdOutlineFilterList } from "react-icons/md";
import { BiUpload } from "react-icons/bi";

const tableIcons = {
  AddButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Add Bin Block
    </Button>
  )),
  Delete: forwardRef((props, ref) => (
    <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => (
    <BiEditAlt fontSize="small" color="action" {...props} ref={ref} />
  )),
  plus: forwardRef((props, ref) => (
    <AiOutlinePlus fontSize="small" color="action" {...props} ref={ref} />
  )),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => (
    <MdOutlineFilterList {...props} ref={ref} />
  )),
};

export default tableIcons;
