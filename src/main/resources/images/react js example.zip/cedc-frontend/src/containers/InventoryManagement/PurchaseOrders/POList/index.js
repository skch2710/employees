import React, {
  memo,
  useState,
  useRef,
  forwardRef,
  useCallback,
  useImperativeHandle,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip, useTheme, Grid } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { pagination } from "../../../../utils/constants";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getPoFiltersObject } from "../helper";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import POClaims from "../POClaims";
import POHistory from "../POHistory";
import { useSelector } from "react-redux";
import POItemInfo from "../POItemInfo";
import DataNotFound from "../../../../components/common/DataNotFound";
import useFileExport from "./useFileExport";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import DatePicker from "../../../../components/common/DatePicker";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const POList = forwardRef(
  (
    {
      formRef,
      fetchPurchaseOrders,
      formSubmittedValues,
      poControllers,
      setPoControllers,
    },
    ref
  ) => {
    const globalClasses = useGlobalStyles();
    const theme = useTheme();
    const { exportToExcel } = useFileExport();
    const iconsAndButtons = useTableIconsAndButtons();

    const [enableFilters, setEnableFilters] = useState(false);
    const [columnFilters, setColumnFilters] = useState([]);
    const [showClaims, setShowClaims] = useState(false);
    const [showHistory, setShowHistory] = useState(false);
    const [showPoItemInfo, setShowPoItemInfo] = useState(false);
    const [rowData, setRowData] = useState({});
    const columnFiltersRef = useRef({});
    const tableRef = useRef(null);
    const { loading, records: poList = {} } =
      useSelector((state) => state.purchaseOrders) || {};

    const setControllers = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setPoControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          page: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    // On click of clear filter button this clearForm function will get executed to reset pagination, page size and fetch default list.
    useImperativeHandle(ref, () => ({
      clearForm() {
        columnFiltersRef.current = {};
        setColumnFilters([]);
      },
      submitForm(resp) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        setControllers(resp);
      },
    }));

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        // If search button was pressed then and only then the values of form will get passed as payload to api on pagination change.
        const {
          page: controllerPage,
          pageSize: controllerPageSize,
          sortOrder,
          sortBy,
        } = poControllers;

        const rowsPerPage = Number(pageSize);
        const totalPages = Math.ceil(poList.totalElements / rowsPerPage) || 1;

        if (controllerPage > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllerPageSize)
          currentPage = controllerPage;

        fetchPurchaseOrders(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: sortOrder,
            sortBy: sortBy,
            filter: columnFilters,
            ...formSubmittedValues, // Here we are checking form is submitted or not and adding payload accordingly.
          },
          (resp) => setControllers(resp)
        );
      },
      [columnFilters, formRef, poControllers, formSubmittedValues, poList]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = poControllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = PO_LIST[orderedColumnId].field;
        setPoControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        fetchPurchaseOrders(
          {
            pageNumber: poControllers.page,
            pageSize: poControllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllers(resp, { sortOrder, sortBy })
        );
      },
      [poControllers, formRef, formSubmittedValues, columnFilters]
    );

    const handleColumnFilter = (filters) => {
      const filterPayload = getPoFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      fetchPurchaseOrders(
        {
          ...poControllers,
          filter: filterPayload,
          ...formSubmittedValues,
        },
        (resp) => setControllers(resp)
      );
    };

    const PO_LIST = [
      {
        title: "PO#",
        field: "poID",
        type: "numeric",
        defaultFilter: enableFilters && columnFiltersRef.current.poID,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.poID}>
              <span>{rowData.poID}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.poID}
            placeholder="PO#"
          />
        ),
      },
      {
        title: "PO Date",
        field: "poDate",
        defaultFilter: enableFilters && columnFiltersRef.current.poDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.poDate}>
              <span>{rowData.poDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.poDate
                  ? moment(columnFiltersRef.current.poDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "Pharmacy Store",
        field: "pharmacy",
        defaultFilter: enableFilters && columnFiltersRef.current.pharmacy,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacy}>
              <span>{rowData.pharmacy}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pharmacy}
            placeholder="Pharmacy Store"
          />
        ),
      },
      {
        title: "Wholesaler Account Number",
        field: "wholesalerAccountID",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.wholesalerAccountID,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.wholesalerAccountID}>
              <span>{rowData.wholesalerAccountID}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.wholesalerAccountID}
            placeholder="Wholesaler Account Number"
          />
        ),
      },
      {
        title: "Wholesaler",
        field: "wholesaler",
        defaultFilter: enableFilters && columnFiltersRef.current.wholesaler,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.wholesaler}>
              <span>{rowData.wholesaler}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.wholesaler}
            placeholder="Wholesaler"
          />
        ),
      },
      {
        title: "PO Status",
        field: "poStatus",
        defaultFilter: enableFilters && columnFiltersRef.current.poStatus,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.poStatus}>
              <span>{rowData.poStatus}</span>
            </Tooltip>
          );
        },
        render: (rowData) => {
          return (
            <Tooltip title={rowData.poStatus}>
              <span>{rowData.poStatus}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.poStatus}
            placeholder="PO Status"
          />
        ),
      },
      {
        title: "PO Total Order Amount",
        field: "totalOrderAmount",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.totalOrderAmount,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.totalOrderAmount}>
                  <span>{rowData.totalOrderAmount}</span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.totalOrderAmount}
            placeholder="PO Total Order Amount"
          />
        ),
      },
      {
        title: "PO Total Billed Amount",
        field: "totalBilledAmount",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.totalBilledAmount,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.totalBilledAmount}>
                  <span>{rowData.totalBilledAmount}</span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.totalBilledAmount}
            placeholder="PO Total Billed Amount"
          />
        ),
      },
    ];

    const actions = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        isFreeAction: true,
        disabled: isEmptyGrid(poList),
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportButton({
          disabled: isEmptyGrid(poList),
        }),
        isFreeAction: true,
        disabled: isEmptyGrid(poList),
        onClick: () =>
          exportToExcel({
            formSubmittedValues,
            formRef,
            poControllers,
            columnFilters,
          }),
      },
      {
        icon: iconsAndButtons.Plus(),
        tooltip: "PO Item Info",
        isFreeAction: false,
        onClick: (_event, rowData) => {
          setRowData(rowData);
          setShowPoItemInfo(true);
        },
      },
      {
        icon: iconsAndButtons.History(),
        tooltip: "Order History",
        isFreeAction: false,
        onClick: (_event, rowData) => {
          setRowData(rowData);
          setShowHistory(true);
        },
      },
      {
        icon: iconsAndButtons.Claim(),
        tooltip: "Claims",
        isFreeAction: false,
        onClick: (_event, rowData) => {
          setRowData(rowData);
          setShowClaims(true);
        },
      },
    ];

    return (
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Purchase Order Data (${getTableHeaderCount(
                poList.totalElements
              )})`}
            />
          }
          tableRef={tableRef}
          columns={PO_LIST}
          data={poList.content || []}
          page={poControllers.page - 1}
          totalCount={poList.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(poControllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={actions}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: poControllers.pageSize,
            maxBodyHeight: 400,
            minBodyHeight: 100,
            showEmptyDataSourceMessage: true,
            pageSizeOptions: isEmptyGrid(poList)
              ? []
              : pagination.pageSizeOptions,
          }}
        />
        <BasicPopup
          title={"Order History"}
          show={showHistory}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
          handleClose={() => setShowHistory(false)}
        >
          <POHistory po={rowData} />
        </BasicPopup>
        <BasicPopup
          title={"Purchase Order Claims"}
          show={showClaims}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
          handleClose={() => setShowClaims(false)}
        >
          <POClaims po={rowData} />
        </BasicPopup>
        <BasicPopup
          title={"Item Info"}
          show={showPoItemInfo}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
          handleClose={() => setShowPoItemInfo(false)}
        >
          <POItemInfo po={rowData} />
        </BasicPopup>
      </div>
    );
  }
);

export default memo(POList);
