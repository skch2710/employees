import { Paper, Tooltip, useTheme } from "@material-ui/core";
import FileSaver from "file-saver";
import _get from "lodash/get";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, { forwardRef, memo, useState } from "react";
import TableCustomSortArrow from '../../../../../../components/common/TableCustomSortArrow'
import { TiFilter } from "react-icons/ti";
import { useSelector } from "react-redux";
import * as XLSX from "xlsx";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import DatePicker from "../../../../../../components/common/DatePicker";
import Pagination from "../../../../../../components/common/Pagination";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { pagination } from "../../../../../../utils/constants";
import {
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../../utils/helper";

const NdcSearchTable = memo(
  forwardRef((_props = {}, tableRef) => {
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const iconsAndButtons = useTableIconsAndButtons();

    const { loading, records: searchResults } =
      useSelector((state) => state.ndcClientExclusionsList) || {};

    const [enableFilters, setEnableFilters] = useState(false);

    const handleDraftExport = (data = []) => {
      const filteredData = data.map((row = {}) => ({
        "Covered Entity": row.ceName || "",
        "HRSA ID": row.hrsaId || "",
        "Pharmacy Chain": row.pharmacyChain || "",
        "Pharmacy Store": row.pharmacyStore || "",
        "Pharmacy NPI": row.pharmacyNpi || "",
        "Exclusion Applied Start Date": row.startDate || "",
        "Exclusion Applied End Date": row.endDate || "",
      }));
      const ws = XLSX.utils.json_to_sheet(filteredData);
      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
      const excelBuffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "array",
      });
      const fileData = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });
      FileSaver.saveAs(fileData, "NDC Client Exclusion List.xlsx");
    };

    const NDC_SEARCH_RESULT_COLUMNS = [
      {
        title: "Covered Entity",
        field: "ceName",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ceName}>
              <span>{rowData.ceName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Covered Entity" />
        ),
      },
      {
        title: "HRSA ID",
        field: "hrsaId",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.hrsaId}>
              <span>{rowData.hrsaId}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="HRSA ID" />
        ),
      },
      {
        title: "Pharmacy Chain",
        field: "pharmacyChain",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyChain}>
              <span>{rowData.pharmacyChain}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Pharmacy Chain" />
        ),
      },
      {
        title: "Pharmacy Store",
        field: "pharmacyStore",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyStore}>
              <span>{rowData.pharmacyStore}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Pharmacy Store" />
        ),
      },
      {
        title: "Pharmacy NPI",
        field: "pharmacyNpi",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyNpi}>
              <span>{rowData.pharmacyNpi}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput {...props} placeholder="Pharmacy NPI" />
        ),
      },
      {
        title: "Exclusion Applied Start Date",
        field: "startDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.startDate}>
              <span>{rowData.startDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
      {
        title: "Exclusion Applied End Date",
        field: "endDate",
        render: (rowData) => {
          return (
            <Tooltip title={rowData.endDate}>
              <span>{rowData.endDate}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
            />
          );
        },
      },
    ];

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(searchResults),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(searchResults),
        isFreeAction: true,
        onClick: () =>
          handleDraftExport(tableRef.current.dataManager.filteredData),
      },
    ];

    return (
      <>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Applied Client Exclusions (${getTableHeaderCount(
                _get(searchResults, "totalElements", 0)
              )})`}
            />
          }
          tableRef={tableRef}
          columns={NDC_SEARCH_RESULT_COLUMNS}
          data={_get(searchResults, "content", [])}
          totalCount={_get(searchResults, "totalElements", 0)}
          icons={{
            SortArrow: () => TableCustomSortArrow(),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            Pagination: (props) => <Pagination {...props} />,
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            selection: true,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: pagination.limit,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(searchResults)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </>
    );
  })
);

export default NdcSearchTable;
