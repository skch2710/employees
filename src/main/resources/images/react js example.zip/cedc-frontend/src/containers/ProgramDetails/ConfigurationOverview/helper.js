import _isArray from "lodash/isArray";
import { pagination } from "../../../utils/constants";
import { getCeIdsArray, isAllCeSelected } from "../../../utils/helper";
import {
  SET_BILLING_CONTACT_LIST,
  SET_CE_ACH_CONFIG,
  SET_CE_BASIC_DETAILS,
  SET_CE_FREQUENCY,
  SET_CE_LOCATIONS_LIST,
  SET_CE_PRIMARY_CONTACT_DETAILS,
  SET_VISIT_WINDOW_CONFIG,
} from "../../../context/reducers/ConfigOverview/constants";

export const getCoDefaultValues = () => ({
  ceId: [],
  phGroupId: "",
  pharmacy: "",
  startDate: "",
  endDate: "",
  effectiveDate: "",
});

export const getUpdatedSectionStatus = (data) => {
  const moduleStatuses = {
    basicDetails: false,
    billingAndFee: false,
    achConfiguration: false,
    ceEligibility: false,
    coLocation: false,
    provider: false,
    member: false,
    serviceArea: false,
    visitWindow: false,
  };

  data.length > 0 &&
    data.map((elm) => {
      if (elm.configSectionId === 1 && elm.statusId === 1)
        moduleStatuses.basicDetails = true;
      if (elm.configSectionId === 2 && elm.statusId === 1)
        moduleStatuses.billingAndFee = true;
      if (elm.configSectionId === 3 && elm.statusId === 1)
        moduleStatuses.achConfiguration = true;
      if (elm.configSectionId === 4 && elm.statusId === 1)
        moduleStatuses.ceEligibility = true;
      if (elm.configSectionId === 6 && elm.statusId === 1)
        moduleStatuses.coLocation = true;
      if (elm.configSectionId === 7 && elm.statusId === 1)
        moduleStatuses.provider = true;
      if (elm.configSectionId === 8 && elm.statusId === 1)
        moduleStatuses.member = true;
      if (elm.configSectionId === 9 && elm.statusId === 1)
        moduleStatuses.serviceArea = true;
      if (elm.configSectionId === 10 && elm.statusId === 1)
        moduleStatuses.visitWindow = true;
    });
  return moduleStatuses;
};

export const TABLE_CELL_STYLE = {
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  overflow: "hidden",
  maxWidth: 100,
  fontSize: "11px",
};

export const defaultCoSearchPayload = (values = {}) => {
  return {
    ceid: !values.ceId
      ? getCeIdsArray(values.ceList)
      : isAllCeSelected(values.ceId)
      ? getCeIdsArray(values.ceList)
      : getCeIdsArray(values.ceId),
    pageNumber: values.pageNumber || pagination.page,
    pageSize: values.pageSize || pagination.limit,
    sortOrder: values.sortOrder || "asc",
    sortBy: values.sortBy || "ceName",
    phGroupid: values.phGroupId ? Number(values.phGroupId) : 0,
    phid: values.pharmacy ? Number(values.pharmacy) : 0,
    contractStartDate: values.startDate || "",
    contractEndDate: values.endDate || "",
    effectiveDate: values.effectiveDate ? values.effectiveDate : "",
    filter: values.filter || [],
    export: values.export || false,
  };
};

export const getTermsFiltersObject = (filters = []) => {
  const dateFields = ["effectiveDate", "startDate", "endDate", "configStatus"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getUpdatedPhSectionStatus = (data) => {
  const phModuleSectionStatus = {
    phBasicDetails: false,
    phBillingAndFee: false,
    phEligibility: false,
    orderingAndRepl: false,
  };
  data.length > 0 &&
    data.map((elm) => {
      if (elm.sectionId === 12 && elm.statusId === 1)
        phModuleSectionStatus.phBasicDetails = true;
      if (elm.sectionId === 13 && elm.statusId === 1)
        phModuleSectionStatus.phBillingAndFee = true;
      if (elm.sectionId === 14 && elm.statusId === 1)
        phModuleSectionStatus.phEligibility = true;
      if (elm.sectionId === 15 && elm.statusId === 1)
        phModuleSectionStatus.orderingAndRepl = true;
    });
  return phModuleSectionStatus;
};

export const resetReduxSummaryStates = (dispatch) => {
  dispatch({
    type: SET_CE_ACH_CONFIG,
    data: [],
  });
  dispatch({
    type: SET_VISIT_WINDOW_CONFIG,
    data: {},
  });
  dispatch({
    type: SET_CE_BASIC_DETAILS,
    data: {},
  });
  dispatch({
    type: SET_CE_FREQUENCY,
    data: [],
  });
  dispatch({
    type: SET_CE_PRIMARY_CONTACT_DETAILS,
    data: {},
  });
  dispatch({
    type: SET_BILLING_CONTACT_LIST,
    data: {},
  });
  dispatch({
    type: SET_CE_LOCATIONS_LIST,
    data: {},
  });
};

export const getFirstIncompleteSection = (data = []) => {
  if (_isArray(data)) {
    return data.find((el) => el.statusId === 1) || {};
  }
  return {};
};

export const getMemberConfigValuesDefault = (data) => {
  const {
    id = 0,
    fileTypeId = 0,
    deliveryMethodId = 0,
    fileFrequencyId = 0,
    eligibilityPeriod = null,
    loadAllEncountersFlag = false,
    loadOnlyEligibleEncounters = false,
    stopNavigation = false,
    ceid = 0,
  } = data || {};
  return {
    id: id,
    fileTypeId: fileTypeId,
    deliveryMethodId: deliveryMethodId,
    fileFrequencyId: fileFrequencyId,
    eligibilityPeriod: eligibilityPeriod,
    loadAllEncountersFlag: loadAllEncountersFlag,
    loadOnlyEligibleEncounters: loadOnlyEligibleEncounters,
    stopNavigation: stopNavigation,
    ceid: ceid,
  };
};
