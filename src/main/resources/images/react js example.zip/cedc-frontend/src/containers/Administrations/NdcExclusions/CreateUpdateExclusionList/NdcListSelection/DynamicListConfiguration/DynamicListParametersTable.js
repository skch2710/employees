import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  useCallback,
} from "react";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../../Styles/useGlobalStyles";
import {
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../../utils/helper";
import { pagination } from "../../../../../../utils/constants";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../../../components/common/TableProgressBar";
import MaterialTable, { MTableToolbar } from "material-table";
import { Grid, Paper, Tooltip, useTheme } from "@material-ui/core";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import { ColumnFilterIcon } from "../../../../../../components/common/Table/usetableStyle";
import { NdcContext } from "../../../NdcContext";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import useTableIconsAndButtons from "../../../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../../../components/common/DatePicker";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import { getDynamicListParametersTableData } from "../../../../../../context/actions/NdcExclusions";
import { useNdcSelectionStyles } from "../styles";
import DlpAddEditForm from "./DlpAddEditForm";
import Pagination from "../../../../../../components/common/Pagination";
import NdcExclusionTables from "../NdcDynamicExclusionTables";
import {
  getDlpFiltersObject,
  getNdcDynamicListParamsSearchPayload,
} from "../helper";
import _get from "lodash/get";

const DynamicListTable = () => {
  const dlpColumnFiltersRef = useRef({});
  const globalClasses = useGlobalStyles();
  const classes = useNdcSelectionStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const theme = useTheme();
  const dispatch = useDispatch();
  const { ndcData, dynamicParamsTb, setDynamicParamsTb } =
    useContext(NdcContext) || {};

  const [enableDlpFilters, setEnableDlpFilters] = useState(false);
  const [showAddEditDlp, setShowAddEditDlp] = useState(false);
  const [dlpFormValues, setDlpFormValues] = useState(null);
  const [dlpFormType, setDlpFormType] = useState(null);
  const [dlpRowData, setDlpRowData] = useState({});
  const tableRef = useRef(null);
  const [dlpColumnFilters, setColumnFilters] = useState([]);
  const [showNdcExclusionsPopup, setShowNdcExclusionsPopup] = useState(false);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
    listHistoryId: ndcData.listHistoryId,
  });
  const { records: dlpGridTableData, loading } = useSelector(
    (state) => state.ndcDynamicListParams
  );

  const DLP_COLUMNS = [
    {
      title: "NDC Count",
      field: "ndcExclCount",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.ndcExclCount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcExclCount}>
            <span>{rowData.ndcExclCount}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.ndcExclCount}
          placeholder="NDC Count"
        />
      ),
    },
    {
      title: "NDC Exceptions",
      field: "ndcExcpCount",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.ndcExcpCount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndcExcpCount}>
            <span>{rowData.ndcExcpCount}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.ndcExcpCount}
          placeholder="NDC Exceptions"
        />
      ),
    },
    {
      title: "NDC Effective Start Date",
      field: "dynamicListEffecStartDate",
      defaultFilter:
        enableDlpFilters &&
        dlpColumnFiltersRef.current.dynamicListEffecStartDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dynamicListEffecStartDate}>
            <span>{rowData.dynamicListEffecStartDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              dlpColumnFiltersRef.current.dynamicListEffecStartDate
                ? moment(dlpColumnFiltersRef.current.dynamicListEffecStartDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "NDC Effective End Date",
      field: "dynamicListEffecEndDate",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.dynamicListEffecEndDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dynamicListEffecEndDate}>
            <span>{rowData.dynamicListEffecEndDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              dlpColumnFiltersRef.current.dynamicListEffecEndDate
                ? moment(dlpColumnFiltersRef.current.dynamicListEffecEndDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Source",
      field: "source",
      defaultFilter: enableDlpFilters && dlpColumnFiltersRef.current.source,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.source}>
            <span>{rowData.source}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.source}
          placeholder="Source"
        />
      ),
    },
    {
      title: "Attribute 1",
      field: "drugAttributeOneDesc",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.drugAttributeOneDesc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugAttributeOneDesc}>
            <span>{rowData.drugAttributeOneDesc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.drugAttributeOneDesc}
          placeholder="Attribute 1"
        />
      ),
    },
    {
      title: "Attribute 2",
      field: "drugAttributeTwoDesc",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.drugAttributeTwoDesc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugAttributeTwoDesc}>
            <span>{rowData.drugAttributeTwoDesc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.drugAttributeTwoDesc}
          placeholder="Attribute 2"
        />
      ),
    },
    {
      title: "Modified By",
      field: "modifiedBy",
      defaultFilter: enableDlpFilters && dlpColumnFiltersRef.current.modifiedBy,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.modifiedBy}>
            <span>{rowData.modifiedBy}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={dlpColumnFiltersRef.current.modifiedBy}
          placeholder="Modified By"
        />
      ),
    },
    {
      title: "Modified Date",
      field: "modifiedDate",
      defaultFilter:
        enableDlpFilters && dlpColumnFiltersRef.current.modifiedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.modifiedDate}>
            <span>{rowData.modifiedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              dlpColumnFiltersRef.current.modifiedDate
                ? moment(dlpColumnFiltersRef.current.modifiedDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const DLP_ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableDlpFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(dlpGridTableData) && _isEmpty(dlpColumnFilters),
      onClick: () => {
        setEnableDlpFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.AddCustomButton({
        title: "Add Dynamic List",
      }),
      isFreeAction: true,
      onClick: () => {
        handleOpenAddEditDlp(
          {
            dynamicListId: 0,
            listHistoryId: ndcData.listHistoryId,
            sourceId: "",
            drugAttributeOneId: "",
            drugAttributeTwoId: "",
            drugAttributeTwoDesc: "",
            startDate: ndcData.startDate,
            endDate: ndcData.endDate,
          },
          "Add"
        );
      },
    },
    {
      icon: iconsAndButtons.Plus(),
      tooltip: "Add Dynamic Exclusions",
      isFreeAction: false,
      onClick: (_e, rowData) => {
        setShowNdcExclusionsPopup(true);
        setDlpRowData(rowData);
      },
    },
    (rowData) => {
      const isDynamicListTerminated = rowData.dynamicListEffecEndDate
        ? moment(rowData.dynamicListEffecEndDate).isSameOrBefore(moment(), "day")
        : false;
      return {
        icon: iconsAndButtons.Edit(),
        tooltip: "Edit",
        isFreeAction: false,
        disabled: isDynamicListTerminated,
        onClick: (_event, rowData) => {
          setDlpRowData(rowData);
          handleOpenAddEditDlp(
            {
              dynamicListId: rowData.dynamicListId,
              listHistoryId: rowData.listHistoryId,
              sourceId: rowData.sourceId,
              drugAttributeOneId: rowData.drugAttributeOneId,
              drugAttributeTwoId: rowData.drugAttributeTwoId,
              drugAttributeTwoDesc: rowData.drugAttributeTwoDesc,
              startDate: rowData.dynamicListEffecStartDate,
              endDate: rowData.dynamicListEffecEndDate,
            },
            "Edit"
          );
        },
      };
    },
  ];

  useEffect(() => {
    fetchDynamicListParametersTblData({ listHistoryId: ndcData.listHistoryId });
    if (dynamicParamsTb) setDynamicParamsTb(false);
  }, [dynamicParamsTb]);

  const fetchDynamicListParametersTblData = async (payload) => {
    const searchPayload = getNdcDynamicListParamsSearchPayload({
      ...payload,
    });
    const res = await dispatch(
      getDynamicListParametersTableData(searchPayload)
    );
    setControllersOnResp(res);
  };

  const setControllersOnResp = (resp = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(dlpGridTableData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      fetchDynamicListParametersTblData({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        sortOrder: controllers.sortOrder,
        sortBy: controllers.sortBy,
        filter: dlpColumnFilters,
        listHistoryId: ndcData.listHistoryId,
      });
    },
    [dlpColumnFilters, dlpGridTableData, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = DLP_COLUMNS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchDynamicListParametersTblData({
        pageNumber: controllers.pageNumber,
        pageSize: controllers.pageSize,
        sortOrder,
        sortBy,
        filter: dlpColumnFilters,
        listHistoryId: ndcData.listHistoryId,
      });
    },
    [controllers, dlpColumnFilters, dlpGridTableData]
  );

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getDlpFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    dlpColumnFiltersRef.current = { ...updatedFiltersObj };
    fetchDynamicListParametersTblData({
      ...controllers,
      filter: filterPayload,
      pageNumber: pagination.page,
      listHistoryId: ndcData.listHistoryId,
    });
  };

  const handleOpenAddEditDlp = (initialValues, type) => {
    setDlpFormValues(initialValues);
    setDlpFormType(type);
    setShowAddEditDlp(true);
  };

  const handleCloseAddEditDlp = (type) => {
    setShowAddEditDlp(false);
    fetchDynamicListParametersTblData({
      listHistoryId: ndcData.listHistoryId,
    });
  };

  const getFormTitle = (type, values) => {
    return type === "Add"
      ? "Add Dynamic List"
      : `NDC Selection/ NDC Dynamic List/ ${values && values.source}/ Edit`;
  };

  const handleCloseNdcExclusionsPopup = () => {
    setShowNdcExclusionsPopup(false);
  };

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="h6" className={classes.dlpSectionTitle}>
          Dynamic List Configuration
        </BasicTypography>
      </Grid>
      <Grid item md={12}>
        <div className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Dynamic List Parameters (${getTableHeaderCount(
                  dlpGridTableData.totalElements
                )})`}
              />
            }
            columns={DLP_COLUMNS}
            data={loading ? [] : _get(dlpGridTableData, "content", [])}
            totalCount={dlpGridTableData.totalElements}
            page={controllers.pageNumber - 1}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            tableRef={tableRef}
            icons={{
              SortArrow: () => TableCustomSortArrow(controllers),
              Filter: ColumnFilterIcon,
            }}
            actions={DLP_ACTIONS}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
              Pagination: (props) => <Pagination {...props} />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableDlpFilters,
              paging: true,
              toolbarButtonAlignment: "right",
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              exportAllData: false,
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              actionsCellStyle: getTableActionCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controllers.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(dlpGridTableData)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
          {showAddEditDlp && (
            <BasicPopup
              show={showAddEditDlp}
              title={getFormTitle(dlpFormType, dlpRowData)}
              handleClose={handleCloseAddEditDlp}
              disableFooter={true}
              dialogProps={{
                maxWidth: dlpFormType === "Add" ? "md" : "sm",
              }}
            >
              <DlpAddEditForm
                formType={dlpFormType}
                initialValues={dlpFormValues}
                handleClose={handleCloseAddEditDlp}
                dlpRowData={dlpRowData}
              />
            </BasicPopup>
          )}
          {showNdcExclusionsPopup && (
            <BasicPopup
              show={showNdcExclusionsPopup}
              title={`NDC Selection/ NDC Dynamic List/ ${
                dlpRowData.source || ""
              }`}
              handleClose={handleCloseNdcExclusionsPopup}
              disableFooter={true}
              dialogProps={{
                maxWidth: "xl",
              }}
            >
              <NdcExclusionTables
                handleClose={handleCloseNdcExclusionsPopup}
                dlpRowData={dlpRowData}
              />
            </BasicPopup>
          )}
        </div>
      </Grid>
    </Grid>
  );
};

export default DynamicListTable;
