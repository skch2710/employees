import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const useNdcStyles = makeStyles((_theme) => ({
  dialogPaper: {
    height: "85vh",
  },
}));

export const useNdcSearchFormStyles = makeStyles((theme) => {
  return {
    cardContainer: {
      padding: "20px",
    },
    filterHeading: {
      color: theme.colors.monochrome.title,
      fontFamily: theme.fontFamily,
    },
    selectedCheckBox: {
      color: theme.colors.primary.default,
    },
    closeFilterIcon: {
      padding: "5px",
    },
    formActionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
    endDate: {
      margin: "22px 0px 0px 0px !important ",
    },
    radioInput: {
      margin: "0 !important",
    },
    radioAndLabelContainer: {
      display: "flex",
      gap: "5px",
      alignItems: "center",
      width: "max-content",
      "& label": {
        color: `${theme.colors.monochrome.input} !important`,
        fontFamily: theme.fontFamily,
      },
    },
    radioGridContainer: {
      display: "flex",
      alignItems: "flex-end",
      flexBasis: "auto",
    },
    gridContentContainer: {
      height: "30px",
      display: "flex",
      alignItems: "center",
      gap: "4px",
      color: theme.colors.monochrome.input,
      marginRight: "12px",
    },
    ToggleButtonGroup: {
      "& .MuiToggleButton-root.Mui-selected": {
        color: theme.colors.monochrome.offWhite,
        backgroundColor: theme.colors.primary.default,
      },
      "& .MuiToggleButton-root": {
        color: theme.colors.primary.default,
        border: `1px solid ${theme.colors.primary.default}`,
        lineHeight: "0.65",
        textTransform: "capitalize",
      },
    },
    listHistoryCards: {
      background: theme.colors.grey.cardBackground,
      borderTop: `1px solid ${theme.colors.secondary.default}`,
    },
    listHistoryActive: { color: theme.colors.green.default },
    listHistoryInActive: { color: theme.colors.error.default },
    viewLink: {
      color: theme.colors.blue.default,
      cursor: "pointer",
      textDecoration: "underline",
    },
  };
});

export const useConfirmationPopupStyles = makeStyles((theme) => {
  return {
    checkbox: {
      color: theme.colors.green[500],
      "&$checked": {
        color: theme.colors.green[500],
      },
    },
    btnLabelContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    dialogPaper: {
      height: "75vh",
    },
    confirmationPopup: {
      height: "auto",
    },
  };
});