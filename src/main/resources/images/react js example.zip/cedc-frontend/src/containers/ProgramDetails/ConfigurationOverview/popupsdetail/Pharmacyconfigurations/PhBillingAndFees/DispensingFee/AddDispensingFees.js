import {
  FormControlLabel,
  FormLabel,
  Grid,
  Typography,
} from "@material-ui/core";
import { Field, useFormikContext } from "formik";
import _isArray from "lodash/isArray";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useGlobalStyles } from "../../../../../../../Styles/useGlobalStyles";
import DatePicker from "../../../../../../../components/common/DatePicker";
import Toggle from "../../../../../../../components/common/Toggle";
import BasicTypography from "../../../../../../../components/common/Typography/BasicTypography";
import {
  fetchAppliedAcTypeOptions,
  fetchCeReimbursementModels,
  fetchDispenseFeeCalcOptions,
  fetchDispensingFeeTypes,
  getDrugTypeOptions,
  getFormularyTypeOptions,
} from "../../../../../../../context/actions/PharmacyConfiguration";
import { REGEX } from "../../../../../../../utils/constants";
import { useDispensingFeesStyles } from "../styles";
import AutoComplete from "../../../../../../../components/common/AutoComplete";
import _get from "lodash/get";

const AddDispensingFees = () => {
  const { values, setFieldValue, errors, touched, handleChange } =
    useFormikContext();
  const globalClasses = useGlobalStyles();
  const classes = useDispensingFeesStyles();
  const dispatch = useDispatch();

  const [dispensingFeeTypeOptions, setDispensingFeeTypeOptions] = useState([]);
  const [formularyTypeOptions, setFormularyTypeOptions] = useState([]);
  const [drugTypeOptions, setDrugTypeOptions] = useState([]);
  const [ceReimbursementModelOptions, setCeReimbursementModelOptions] =
    useState([]);
  const [dispenseFeeCalcOptions, setDispenseFeeCalcOptions] = useState([]);
  const [appliedAcTypeOptions, setAppliedAcTypeOptions] = useState([]);

  const getDispensingFeeTypes = async () => {
    const types = await dispatch(fetchDispensingFeeTypes());
    _isArray(types) && setDispensingFeeTypeOptions(types);
  };

  const getCeReimbursementModels = async () => {
    const models = await fetchCeReimbursementModels();
    _isArray(models) && setCeReimbursementModelOptions(models);
  };

  const getDispenseFeeCalcOptions = async () => {
    const calculations = await fetchDispenseFeeCalcOptions();
    _isArray(calculations) && setDispenseFeeCalcOptions(calculations);
  };

  const getAppliedAcTypeOptions = async () => {
    const appliedAcTypes = await fetchAppliedAcTypeOptions();
    _isArray(appliedAcTypes) && setAppliedAcTypeOptions(appliedAcTypes);
  };

  const fetchFormularyTypes = async () => {
    const types = await getFormularyTypeOptions();
    _isArray(types) && setFormularyTypeOptions(types);
  };

  const fetchDrugTypes = async () => {
    const types = await getDrugTypeOptions();
    _isArray(types) && setDrugTypeOptions(types);
  };

  useEffect(() => {
    getDispensingFeeTypes();
    fetchFormularyTypes();
    fetchDrugTypes();
    getCeReimbursementModels();
    getDispenseFeeCalcOptions();
    getAppliedAcTypeOptions();
  }, []);
  return (
    <Grid container direction="column" spacing={2}>
      <Grid item md={12}>
        <BasicTypography variant="h5">Dispensing Fees</BasicTypography>
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <FormLabel required>Dispensing Fee Type</FormLabel>
            {
              <Field as="select" name="dispensingFeeType">
                {({ field }) => (
                  <AutoComplete
                    {...field}
                    options={
                      _isArray(dispensingFeeTypeOptions)
                        ? dispensingFeeTypeOptions
                        : []
                    }
                    inputPlaceholder={"Select Dispensing Fee Type"}
                    disableCloseOnSelect={false}
                    onChange={(_e, value) => {
                      handleChange(_e, value);
                      setFieldValue(
                        "dispensingFeeType",
                        _get(value, "dispensingFeeTypeId", "")
                      );
                      setFieldValue("drugType", 0);
                    }}
                    value={
                      (_isArray(dispensingFeeTypeOptions) &&
                        dispensingFeeTypeOptions.find(
                          (e) =>
                            e.dispensingFeeTypeId == values.dispensingFeeType
                        )) ||
                      ""
                    }
                    getOptionLabel={(option) => option.dispensingFeeType || ""}
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.dispensingFeeType}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "dispensingFeeType",
                      },
                    }}
                  />
                )}
              </Field>
            }
            {errors.dispensingFeeType && touched.dispensingFeeType && (
              <Typography color="error" variant="caption">
                {errors.dispensingFeeType}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Formulary Type</FormLabel>
            {
              <Field as="select" name="formularyType">
                {({ field }) => (
                  <AutoComplete
                    {...field}
                    options={
                      _isArray(formularyTypeOptions) ? formularyTypeOptions : []
                    }
                    inputPlaceholder={"Select Formulary Type"}
                    disableCloseOnSelect={false}
                    onChange={(_e, value) => {
                      handleChange(_e, value);
                      setFieldValue(
                        "formularyType",
                        _get(value, "formularyTypeId", "")
                      );
                      setFieldValue("drugType", 0);
                    }}
                    value={
                      (_isArray(formularyTypeOptions) &&
                        formularyTypeOptions.find(
                          (e) => e.formularyTypeId == values.formularyType
                        )) ||
                      ""
                    }
                    getOptionLabel={(option) => option.formularyType || ""}
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.formularyType}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "formularyType",
                      },
                    }}
                  />
                )}
              </Field>
            }
            {errors.formularyType && touched.formularyType && (
              <Typography color="error" variant="caption">
                {errors.formularyType}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Drug Type</FormLabel>
            {
              <Field as="select" name="drugType">
                {({ field }) => (
                  <AutoComplete
                    {...field}
                    options={_isArray(drugTypeOptions) ? drugTypeOptions : []}
                    inputPlaceholder={"Select Drug Type"}
                    disableCloseOnSelect={false}
                    onChange={(_e, value) => {
                      setFieldValue(
                        "drugType",
                        _get(value, "brandGenericId", "")
                      );
                    }}
                    value={
                      (_isArray(drugTypeOptions) &&
                        drugTypeOptions.find(
                          (e) => e.brandGenericId == values.drugType
                        )) ||
                      ""
                    }
                    getOptionDisabled={(option) =>
                      option.brandGenericId === 3 &&
                      (Number(values.formularyType) === 2 ||
                        Number(values.dispensingFeeType) === 1)
                    }
                    getOptionLabel={(option) => option.brandGeneric || ""}
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.brandGeneric}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "drugType",
                      },
                    }}
                  />
                )}
              </Field>
            }
            {errors.drugType && touched.drugType && (
              <Typography color="error" variant="caption">
                {errors.drugType}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4} className={classes.switchGridContainer}>
            <div className={globalClasses.switchContainer}>
              <FormControlLabel
                control={
                  <Field
                    name="isVaryFees"
                    type="checkbox"
                    id="isVaryFees"
                    component={Toggle}
                    checked={values.isVaryFees}
                    onChange={(e) =>
                      setFieldValue("isVaryFees", e.target.checked)
                    }
                  />
                }
                classes={{
                  label: classes.switchLabel,
                }}
              />
              <FormLabel
                htmlFor="isVaryFees"
                className={globalClasses.noPaddingForLabels}
              >
                Vary Fee by Indicator
              </FormLabel>
            </div>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Reimbursement Model</FormLabel>
            {
              <Field as="select" name="ceReimbursementModel">
                {({ field }) => (
                  <AutoComplete
                    {...field}
                    options={
                      _isArray(ceReimbursementModelOptions)
                        ? ceReimbursementModelOptions
                        : []
                    }
                    inputPlaceholder={
                      "Select Reimbursement Model"
                    }
                    disableCloseOnSelect={false}
                    onChange={(_e, value) => {
                      setFieldValue(
                        "ceReimbursementModel",
                        _get(value, "ceReimbursementModelId", "")
                      );
                    }}
                    value={
                      (_isArray(ceReimbursementModelOptions) &&
                        ceReimbursementModelOptions.find(
                          (e) =>
                            e.ceReimbursementModelId ==
                            values.ceReimbursementModel
                        )) ||
                      ""
                    }
                    getOptionLabel={(option) =>
                      option.ceReimbursementModel || ""
                    }
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.ceReimbursementModel}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "ceReimbursementModel",
                      },
                    }}
                  />
                )}
              </Field>
            }
            {errors.ceReimbursementModel && touched.ceReimbursementModel && (
              <Typography color="error" variant="caption">
                {errors.ceReimbursementModel}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Dispensing Fee Calculation</FormLabel>
            {
              <Field as="select" name="dispenseFeeCalc">
                {({ field }) => (
                  <AutoComplete
                    {...field}
                    options={
                      _isArray(dispenseFeeCalcOptions)
                        ? dispenseFeeCalcOptions
                        : []
                    }
                    inputPlaceholder={"Select Dispensing Fee Calculation"}
                    disableCloseOnSelect={false}
                    onChange={(_e, value) => {
                      setFieldValue(
                        "dispenseFeeCalc",
                        _get(value, "dispensingFeeCalculationId", "")
                      );
                    }}
                    value={
                      (_isArray(dispenseFeeCalcOptions) &&
                        dispenseFeeCalcOptions.find(
                          (e) =>
                            e.dispensingFeeCalculationId ==
                            values.dispenseFeeCalc
                        )) ||
                      ""
                    }
                    getOptionLabel={(option) =>
                      option.dispensingFeeCalculation || ""
                    }
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.dispensingFeeCalculation}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "dispenseFeeCalc",
                      },
                    }}
                  />
                )}
              </Field>
            }
            {errors.dispenseFeeCalc && touched.dispenseFeeCalc && (
              <Typography color="error" variant="caption">
                {errors.dispenseFeeCalc}
              </Typography>
            )}
          </Grid>
          {Number(values.dispenseFeeCalc) === 1 && (
            <Grid item xs={12} md={4}>
              <FormLabel required>Percentage</FormLabel>
              <div className={classes.percentageWrapper}>
                <span>%</span>
                <Field
                  name="percentage"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter Percentage"
                  onChange={(e) => {
                    const { value } = e.target;
                    const regEx = /^[0-9]*\.{0,1}[0-9]{0,2}$/g;
                    if (value && !regEx.test(value)) return;
                    setFieldValue("percentage", value.toString());
                  }}
                />
              </div>
              {errors.percentage && touched.percentage && (
                <Typography color="error" variant="caption">
                  {errors.percentage}
                </Typography>
              )}
            </Grid>
          )}
          <Grid item xs={12} md={4}>
            <FormLabel required>Applied AC Type</FormLabel>
            {
              <Field as="select" name="appliedAcType">
                {({ field }) => (
                  <AutoComplete
                    {...field}
                    options={
                      _isArray(appliedAcTypeOptions) ? appliedAcTypeOptions : []
                    }
                    inputPlaceholder={"Select Dispense Fee Calc"}
                    disableCloseOnSelect={false}
                    onChange={(_e, value) => {
                      setFieldValue(
                        "appliedAcType",
                        _get(value, "eacTypeId", "")
                      );
                    }}
                    value={
                      (_isArray(appliedAcTypeOptions) &&
                        appliedAcTypeOptions.find(
                          (e) => e.eacTypeId == values.appliedAcType
                        )) ||
                      ""
                    }
                    getOptionLabel={(option) => option.eacType || ""}
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.eacType}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "appliedAcType",
                      },
                    }}
                  />
                )}
              </Field>
            }
            {errors.appliedAcType && touched.appliedAcType && (
              <Typography color="error" variant="caption">
                {errors.appliedAcType}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>BIN</FormLabel>
            <Field
              name="bin"
              type="text"
              className={globalClasses.formControl}
              placeholder="Enter BIN"
              maxLength={10}
              onChange={(e) => {
                const value = e.target.value;
                if (value && !REGEX.excludeLeadingAndTrailingSpaces.test(value))
                  return;
                setFieldValue("bin", value);
              }}
            />
            {errors.bin && touched.bin && (
              <Typography color="error" variant="caption">
                {errors.bin}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>PCN</FormLabel>
            <Field
              name="pcn"
              type="text"
              className={globalClasses.formControl}
              placeholder="Enter PCN"
              maxLength={15}
              onChange={(e) => {
                const value = e.target.value;
                if (value && !REGEX.excludeLeadingAndTrailingSpaces.test(value))
                  return;
                setFieldValue("pcn", value);
              }}
            />
            {errors.pcn && touched.pcn && (
              <Typography color="error" variant="caption">
                {errors.pcn}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Group</FormLabel>
            <Field
              name="group"
              type="text"
              placeholder="Enter Group"
              maxLength={15}
              className={globalClasses.formControl}
              onChange={(e) => {
                const value = e.target.value;
                if (value && !REGEX.excludeLeadingAndTrailingSpaces.test(value))
                  return;
                setFieldValue("group", value);
              }}
            />
            {errors.group && touched.group && (
              <Typography color="error" variant="caption">
                {errors.group}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Dispensing Fee % of EAC</FormLabel>
            <Field
              name="dispensingFeePercentage"
              type="text"
              placeholder="Enter Dispensing Fee % of EAC"
              className={globalClasses.formControl}
              onChange={(e) => {
                const { value } = e.target;
                const regEx = /^[0-9]*\.{0,1}[0-9]{0,2}$/g;
                if (value && !regEx.test(value)) return;
                setFieldValue("dispensingFeePercentage", value.toString());
              }}
            />
            {errors.dispensingFeePercentage &&
              touched.dispensingFeePercentage && (
                <Typography color="error" variant="caption">
                  {errors.dispensingFeePercentage}
                </Typography>
              )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Flat Dispensing Fee</FormLabel>
            <Field
              name="flatDispensingFee"
              type="text"
              className={globalClasses.formControl}
              placeholder="Enter Flat Dispensing Fee"
              onChange={(e) => {
                const { value } = e.target;
                const regEx = /^[0-9]*$/g;
                if (value && !regEx.test(value)) return;
                setFieldValue("flatDispensingFee", value.toString());
              }}
            />
            {errors.flatDispensingFee && touched.flatDispensingFee && (
              <Typography color="error" variant="caption">
                {errors.flatDispensingFee}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={2}>
            <FormLabel required>340BDirect+ Fee Start Date</FormLabel>
            <Field as="select" name="startDate">
              {({ field }) => (
                <DatePicker
                  {...field}
                  disabledDate={(date) =>
                    !date ||
                    (values.expDate &&
                      !date.isSameOrBefore(values.expDate, "day"))
                  }
                  onChange={(_e, date) => {
                    if (!date) setFieldValue("expDate", "");
                    setFieldValue("startDate", date);
                  }}
                  value={
                    values.startDate
                      ? moment(values.startDate, "MM/DD/YYYY")
                      : ""
                  }
                  getPopupContainer={(triggerNode) => {
                    return triggerNode.parentNode;
                  }}
                />
              )}
            </Field>
            {errors.startDate && touched.startDate && (
              <Typography color="error" variant="caption">
                {errors.startDate}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={2}>
            <FormLabel required>340BDirect+ Fee End Date</FormLabel>
            <Field as="select" name="expDate">
              {({ field }) => (
                <DatePicker
                  {...field}
                  disabledDate={(date) =>
                    !date || !date.isSameOrAfter(values.startDate, "day")
                  }
                  onChange={(_e, date) => {
                    setFieldValue("expDate", date);
                  }}
                  value={
                    values.expDate ? moment(values.expDate, "MM/DD/YYYY") : ""
                  }
                  getPopupContainer={(triggerNode) => {
                    return triggerNode.parentNode;
                  }}
                />
              )}
            </Field>
            {errors.expDate && touched.expDate && (
              <Typography color="error" variant="caption">
                {errors.expDate}
              </Typography>
            )}
          </Grid>
          <Grid item xs={12} md={4}>
            <FormLabel required>Access By</FormLabel>
            <div className={classes.radioContainer}>
              <div className={classes.radioAndLabelContainer}>
                <Field
                  id="processedDate"
                  name="accessBy"
                  type="radio"
                  value="1"
                  className={classes.radioInput}
                />
                <FormLabel
                  htmlFor="processedDate"
                  className={globalClasses.noPaddingForLabels}
                >
                  Processed Date
                </FormLabel>
              </div>
              <div className={classes.radioAndLabelContainer}>
                <Field
                  id="dateOfService"
                  name="accessBy"
                  type="radio"
                  value="2"
                  className={classes.radioInput}
                />
                <FormLabel
                  htmlFor="dateOfService"
                  className={globalClasses.noPaddingForLabels}
                >
                  Date of Service
                </FormLabel>
              </div>
            </div>
            {errors.accessBy && touched.accessBy && (
              <Typography color="error" variant="caption">
                {errors.accessBy}
              </Typography>
            )}
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default AddDispensingFees;
