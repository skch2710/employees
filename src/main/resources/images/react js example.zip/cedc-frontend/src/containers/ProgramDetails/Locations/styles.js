import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const useLocationStyles = makeStyles((theme) => {
  return {
    tableHeader: {
      background: theme.colors.monochrome.tableHeaderBackground,
      color: theme.colors.monochrome.tableHeaderText,
      fontSize: "11px",
      whiteSpace: "nowrap",
      border: "none",
      textAlign: "center",
      padding: "5px 0",
    },
    exportContainer: {
      textAlign: "right",
      padding: "8px 10px 0 0",
    },
    adminType: {
      fontWeight: "bold",
      fontSize: "0.75rem",
      borderRadius: 8,
      padding: "4px 10px",
      display: "inline-block",
      marginTop: "2px",
      color: "#FFFFFF",
      width: "120px",
      textAlign: "center",
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
    title: {
      color: "#43425D",
    },
    subtitle: {
      color: "#071B72F8",
    },
    btnStyle: {
      marginTop: "10px",
      marginLeft: "-8px",
    },
    multiselectTag: {
      margin: "1px !important",
    },
    emailErrorMsg: {
      color: "red",
      fontSize: "12px",
    },
    selectedCheckBox: {
      color: theme.colors.blue[500],
    },
    uploadSuccess: {
      margin: "0 8px",
      color: "#394577",
      display: "flex",
      alignItems: "center",
      columnGap: "5px",
      "& > p": {
        margin: 0,
      },
    },
    uploadError: {
      margin: 0,
      color: "#e57776",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      columnGap: "5px",
      "& > p": {
        margin: 0,
      },
    },
    headerErrorsContainer: {
      display: "flex",
      flexDirection: "column",
      rowGap: "5px",
      "& > p": {
        margin: 0,
      },
    },
    headerErrors: {
      margin: "8px 0 0",
      color: "red",
    },
    successErrorContainer: {
      display: "flex",
      alignItems: "center",
      columnGap: "10px",
    },
    achAccounts: {
      maxHeight: "250px",
      overflowY: "scroll",
      padding: "15px",
      margin: "15px",
      border: "1px solid #e7e7e7",
      backgroundColor: "#fcfcfc",
    },
    opaLocationSearchGrid: {
      display: "flex",
      alignItems: "self-end",
    },
    verifiedIcon: {
      color: theme.colors.primary.default,
      width: "16px",
      height: "16px",
    },
    ToggleButtonGroup: {
      "& .MuiToggleButton-root.Mui-selected": {
        color: theme.colors.monochrome.offWhite,
        backgroundColor: theme.colors.primary.default,
      },
      "& .MuiToggleButton-root": {
        color: theme.colors.primary.default,
        border: `1px solid ${theme.colors.primary.default}`,
        lineHeight: "0.65",
        textTransform: "capitalize",
      },
      "& .MuiBadge-anchorOriginTopRightRectangle": {
        right: "5px",
        top: "-10px",
        color: theme.colors.monochrome.offWhite,
        backgroundColor: theme.colors.orange.default,
      },
    },

    dialogTitle: {
      background: theme.colors.pink.bg,
    },
    containerTablePad: {
      padding: "10px",
      "& .MuiToolbar-gutters": {
        "& .MuiButton-sizeSmall": {
          fontSize: "12px !important",
        },
      },
    },
  };
});

export const userListStyle = makeStyles(() => ({
  usertitle: {
    color: "#222B45",
    display: "flex",
  },
  userlistBtn: {
    backgroundColor: "#03125396 !important",
    color: "#FFFFFF",
    marginRight: "20px",
    marginTop: "9px",
  },

  btnAlignStyle: {
    display: "flex",
    marginRight: "450px",
    marginTop: "-41px",
  },
}));
export const userListTableStyle = makeStyles(() => ({
  roletypeStyle: {
    fontWeight: "bold",
    fontSize: "0.75rem",
    borderRadius: 8,
    padding: "4px 10px",
    display: "inline-block",
    marginTop: "2px",
    color: "#FFFFFF",
    width: "120px",
    textAlign: "center",
  },

  paginationAlign: {
    marginTop: "-65px;",
  },
  selectpagesize: {
    padding: "0px 8px 0px 0px",
  },
  pagination: {
    padding: "10px",
  },
}));

export const addEditFormStyle = makeStyles((_theme) => ({
  root: {
    "& .MuiButton-label": {
      textTransform: "none",
    },
    "& .MuiFormLabel-asterisk": {
      color: "red",
      marginLeft: "3px",
    },
    "& .MuiFormLabel-root": {
      fontSize: "13px",
      color: "#7C8197",
      paddingBottom: "5px",
    },
  },
  formControl: {
    color: "#434653 ",
    width: "98% !important",
    padding: "0 0 0 7px !important",
    border: "1px solid #ebebeb  !important",
    borderRadius: "4px !important",
    boxShadow: "1px 1px 3px rgb(41 84 106 / 7%) !important",
    height: "35px !important",
    fontSize: "small !important",
    // marginTop: "10px !important"
  },
  radiobtnAlign: {
    display: "-webkit-inline-box",
    marginTop: "26px",
    fontSize: "small",
  },
  labelAlign1: {
    marginLeft: "13px",
  },
  labelAlign2: {
    marginLeft: "7px",
  },
  btnStyle: {
    marginTop: "8px",
  },
  userpermissionStyle: {
    marginTop: "20px",
  },
}));
export const AddressDrillDownStyles = makeStyles((theme) => ({
  tabsContainer: {
    borderBottom: `1px solid ${theme.colors.monochrome.border}`,
  },
  tabsIndicator: {
    background: theme.colors.blue[800],
  },
  tabsLabel: {
    textTransform: "capitalize",
    color: theme.colors.blue[800],
  },
  selectedTab: { color: theme.colors.blue[800] },
  tabPanelContainer: {
    padding: "0 12px",
    height: "100%",
  },
  locationName: {
    color: theme.colors.monochrome.title,
  },
  locationAddress: {
    color: theme.colors.monochrome.label,
    paddingTop: "5px",
  },
  headerContainer: {
    padding: "0 12px",
  },
}));
