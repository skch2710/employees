import React, { memo, useContext, useEffect, useState } from "react";
import { Field, Form, Formik } from "formik";
import {
  Button,
  Checkbox,
  FormLabel,
  Grid,
  IconButton,
} from "@material-ui/core";
import DatePicker from "../../../components/common/DatePicker";
import LoaderUI from "../../../components/common/Loader/Loader";
import moment from "moment";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import _isEqual from "lodash/isEqual";
import _get from "lodash/get";
import _debounce from "lodash/debounce";
import { useDispatch, useSelector } from "react-redux";
import { IoIosCloseCircleOutline } from "react-icons/io";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import {
  getNdcAllDropdowns,
  getClientDropDownValues,
  getNdcFiltersTherapeuticClass,
  getNdcFiltersManufacturer,
  getTherapeuticClassValues,
  getManufacturerValues,
} from "../../../context/actions/NdcExclusions";
import { REGEX } from "../../../utils/constants";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import {
  getFilteredNdcListDefaultValue,
  getNdcAllDropdownPayload,
  conditionsCheck,
} from "./helpers";
import AutoComplete from "../../../components/common/AutoComplete";
import {
  ALL_CE_OPTION,
  LABELS,
  setAutoCompleteInputVal,
} from "../../../utils/constants";
import { getUserSession } from "../../../utils/helper";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { useNdcSearchFormStyles } from "./styles";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import MultiSelectDropdown from "../../../components/common/MultiSelectDropdown";
import { useRowState } from "react-table";
import { endDateValidation, startDateValidation } from "../../../utils/common";

const NdcSearchForm = memo((props = {}) => {
  const { handleSubmit, handleClear, ndcLists } = props;
  const dispatch = useDispatch();
  const [defaultValues, setDefaultValues] = useState(
    getFilteredNdcListDefaultValue()
  );
  const globalClasses = useGlobalStyles();
  const classes = useNdcSearchFormStyles();
  const userSession = getUserSession();
  const { ceList } = useSelector((state) => state.coveredEntities);
  const [showFilters, setShowFilters] = useState(true);
  const [coveredEntityAllOptions, setCoveredEntityAllOptions] = useState([]);
  const [pharmacyGroups, setPharmacyGroups] = useState([]);
  const [pharmaciesList, setPharmaciesList] = useState([]);
  const [exclusionTypeValues, setExclusionTypeValues] = useState([]);
  const [manufacturerValues, setManufacturerValues] = useState([]);
  const [wholesalerValues, setWholesalerValues] = useState([]);
  const [therapeuticValues, setTherapeuticValues] = useState([]);
  const [ndcValues, setNdcValues] = useState();
  const [gcnValues, setGcnValues] = useState();
  const [loading, setLoading] = useState(false);
  const [fetchNdcFilter, setFetchNdcFilter] = useState(false);

  const [mainCoveredEntityAllOptions, setMainCoveredEntityAllOptions] =
    useState([]);
  const [mainPharmacyGroups, setMainPharmacyGroups] = useState([]);
  const [mainPharmaciesList, setMainPharmaciesList] = useState([]);
  const [mainWholesalerValues, setMainWholesalerValues] = useState([]);
  const [mainExclusionTypeValues, setMainExclusionTypeValues] = useState([]);

  const resetStates = () => {
    setPharmacyGroups(pharmacyGroups);
    setPharmaciesList(pharmaciesList);
    setExclusionTypeValues(exclusionTypeValues);
    setManufacturerValues(manufacturerValues);
    setWholesalerValues(wholesalerValues);
    setTherapeuticValues(therapeuticValues);
    setNdcValues(ndcValues);
    setGcnValues(gcnValues);
  };

  const allDropdowns = ({ resp, option, optionValue }) => {
    _isArray(resp.coveredEntities) &&
      setCoveredEntityAllOptions(
        option === "ceId" ? optionValue : resp.coveredEntities
      );
    _isArray(resp.pharmacyGroup) &&
      setPharmacyGroups(
        option === "phGroupId" ? optionValue : resp.pharmacyGroup
      );
    _isArray(resp.pharmacies) &&
      setPharmaciesList(option === "pharmacy" ? optionValue : resp.pharmacies);
    _isArray(resp.exclusionType) &&
      setExclusionTypeValues(
        option === "exclusionType" ? optionValue : resp.exclusionType
      );
    _isArray(resp.wholesaler) &&
      setWholesalerValues(
        option === "wholesaler" ? optionValue : resp.wholesaler
      );
    _isArray(resp.ndcDetails) &&
      setNdcValues(option === "ndc" ? optionValue : resp.ndcDetails);
    _isArray(resp.gcn) &&
      setGcnValues(option === "gcn" ? optionValue : resp.gcn);
  };

  const manufacturerDropDownValues = ({ resp, option, optionValue }) => {
    setManufacturerValues(
      option === "manufacturer"
        ? optionValue
        : !_isEmpty(resp)
        ? resp.drugManufacturer
        : []
    );
  };

  const therapeuticClassDropDownValues = ({ resp, option, optionValue }) => {
    setTherapeuticValues(
      option === "therapeuticClass" ? optionValue : resp.therapeutic
    );
  };

  const clientDropdowns = (res) => {
    _isArray(res.coveredEntities) &&
      setCoveredEntityAllOptions(res.coveredEntities);
    _isArray(res.coveredEntities) &&
      setMainCoveredEntityAllOptions(res.coveredEntities);
    _isArray(res.pharmacyGroup) && setMainPharmacyGroups(res.pharmacyGroup);
    _isArray(res.pharmacyGroup) && setPharmacyGroups(res.pharmacyGroup);
    _isArray(res.wholesaler) && setMainWholesalerValues(res.wholesaler);
    _isArray(res.exclusionType) &&
      setMainExclusionTypeValues(res.exclusionType);
    _isArray(res.pharmacies) && setPharmaciesList(res.pharmacies);
    _isArray(res.pharmacies) && setMainPharmaciesList(res.pharmacies);
    _isArray(res.wholesaler) && setWholesalerValues(res.wholesaler);
    _isArray(res.exclusionType) && setExclusionTypeValues(res.exclusionType);
  };

  const clientMainDropDownData = () => {
    setCoveredEntityAllOptions(mainCoveredEntityAllOptions);
    setMainPharmacyGroups(mainPharmacyGroups);
    setMainPharmaciesList(mainPharmaciesList);
    setMainWholesalerValues(mainWholesalerValues);
    setMainExclusionTypeValues(mainExclusionTypeValues);
  };

  const allOptions = (values) => {
    const newValues = {
      ...values,
      phGroupId: conditionsCheck({
        options: pharmacyGroups,
        values: values,
        key: "phGroupId",
      }),
      ceId: conditionsCheck({
        options: coveredEntityAllOptions,
        values: values,
        key: "ceId",
      }),
      pharmacy: conditionsCheck({
        options: pharmaciesList,
        values: values,
        key: "pharmacy",
      }),
      manufacturer: conditionsCheck({
        options: manufacturerValues,
        values: values,
        key: "manufacturer",
      }),
      therapeuticClass: conditionsCheck({
        options: therapeuticValues,
        values: values,
        key: "therapeuticClass",
      }),
      exclusionType: conditionsCheck({
        options: exclusionTypeValues,
        values: values,
        key: "exclusionType",
      }),
      wholesaler: conditionsCheck({
        options: wholesalerValues,
        values: values,
        key: "wholesaler",
      }),
      listId: conditionsCheck({
        options: ndcLists,
        values: values,
        key: "listId",
      }),
    };
    return newValues;
  };

  const onClear = (values) => {
    resetStates();
    handleClear && handleClear(allOptions(values));
    fetchTherapeuticClassValues();
    fetchManufacturerValues();
    fetchClientDropDownValues();
  };

  const fetchAllDropDownValues = (values, option, optionValue) => {
    let isAPItrigger = false;
    if (!values.hasOwnProperty("ceId") && !userSession.isInternalUser) {
      values.ceId = ceList;
    }
    const payload = {
      ...getNdcAllDropdownPayload(allOptions(values)),
    };

    // Extract Form Fields to an Array From Search Payload
    const filterPayload = (({ status, ...otherKeys }) => otherKeys)(payload);

    // Loop All Fields
    for (const key in filterPayload) {
      // Check each field lenght : if greater than 0 need to trigger API
      // When All selected also field length is 0
      if (filterPayload[key].length !== 0) {
        isAPItrigger = true;
      }
    }

    if (isAPItrigger) {
      setLoading(true);
      dispatch(
        getNdcAllDropdowns(
          payload,
          (resp) => allDropdowns({ resp, option, optionValue }),
          setLoading
        )
      );
      if (option === "therapeuticClass") {
        dispatch(
          getNdcFiltersManufacturer(payload, (resp) =>
            manufacturerDropDownValues({ resp, option, optionValue })
          )
        );
      } else if (option === "manufacturer") {
        dispatch(
          getNdcFiltersTherapeuticClass(payload, (resp) =>
            therapeuticClassDropDownValues({ resp, option, optionValue })
          )
        );
      } else if (option !== "therapeuticClass" && option !== "manufacturer") {
        dispatch(
          getNdcFiltersManufacturer(payload, (resp) =>
            manufacturerDropDownValues({ resp, option, optionValue })
          )
        );
        dispatch(
          getNdcFiltersTherapeuticClass(payload, (resp) =>
            therapeuticClassDropDownValues({ resp, option, optionValue })
          )
        );
      }

      if (!userSession.isInternalUser) {
        setDefaultValues((prev) => ({
          ...prev,
          ceId: ceList,
        }));
      }
    } else {
      fetchTherapeuticClassValues();
      fetchManufacturerValues();
      fetchClientDropDownValues();
    }
  };

  const fetchTherapeuticClassValues = async () => {
    const res = await dispatch(getTherapeuticClassValues());
    _isArray(res) && setTherapeuticValues(res);
  };

  const fetchManufacturerValues = async () => {
    const res = await dispatch(getManufacturerValues());
    _isArray(res) && setManufacturerValues(res);
  };

  const fetchClientDropDownValues = async () => {
    const res = await dispatch(getClientDropDownValues());
    res && clientDropdowns(res);
  };

  useEffect(() => {
    if (ndcLists.length) {
      fetchManufacturerValues();
      fetchTherapeuticClassValues();
      fetchClientDropDownValues();
      setDefaultValues((prev) => ({
        ...prev,
        listId: ndcLists,
      }));
      // May needed
      // if (!fetchNdcFilter && !_isEmpty(ndcLists)) {
      //   setFetchNdcFilter(true);
      // }
    }
  }, [ndcLists]);

  const handleBeforeSubmit = (values) => {
    handleSubmit(allOptions(values));
  };

  return (
    <Formik
      initialValues={defaultValues}
      onSubmit={handleBeforeSubmit}
      enableReinitialize={true}
    >
      {({ values, setFieldValue, initialValues, setValues }) => {
        return (
          <Form>
            {loading && <LoaderUI />}
            {showFilters ? (
              <div className={globalClasses.cardPrimary}>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <Grid container spacing={2} justifyContent="space-between">
                      <Grid item>
                        <BasicTypography variant="h4" title="Filters" />
                      </Grid>
                      <Grid item>
                        <IconButton
                          classes={{
                            root: classes.closeFilterIcon,
                          }}
                        >
                          <IoIosCloseCircleOutline
                            onClick={() => {
                              setShowFilters(false);
                            }}
                          />
                        </IconButton>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>List Name</FormLabel>
                        <Field name="listId">
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder="Select List Name"
                              options={ndcLists}
                              getOptionLabel={(option) => `${option.listName}`}
                              getOptionSelected={(option, value) =>
                                Number(option.listId) === Number(value.listId)
                              }
                              {...field}
                              onChange={(_e, value) => {
                                setFieldValue("listId", value);
                                if (!_isEmpty(value)) {
                                  fetchAllDropDownValues({
                                    ...values,
                                    listId: value,
                                  });
                                } else {
                                  clientMainDropDownData();
                                  setValues(getFilteredNdcListDefaultValue());
                                }
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      {ceList && ceList.length === 1 ? (
                        <Grid item xs={12} sm={4}>
                          <FormLabel>{LABELS.CoveredEntity}</FormLabel>
                          {
                            <Field
                              name="ceId"
                              id="ceId"
                              type="text"
                              disabled={ceList.length > 1 ? false : true}
                              className={globalClasses.formControl}
                              value={ceList[0].ceName}
                            />
                          }
                        </Grid>
                      ) : (
                        <Grid item xs={12} sm={4}>
                          <FormLabel>{LABELS.CoveredEntity}</FormLabel>
                          <Field name="ceId">
                            {({ field }) => (
                              <MultiSelectDropdown
                                inputPlaceholder={
                                  userSession.isInternalUser
                                    ? "Select Covered Entity"
                                    : ""
                                }
                                options={coveredEntityAllOptions}
                                disabled={!userSession.isInternalUser}
                                getOptionLabel={(option) => `${option.ceName}`}
                                getOptionSelected={(option, value) =>
                                  option.ceID === value.ceID
                                }
                                {...field}
                                onChange={(_e, value) => {
                                  setFieldValue("ceId", value);
                                  if (!_isEmpty(value)) {
                                    fetchAllDropDownValues(
                                      {
                                        ...values,
                                        ceId: value,
                                      },
                                      "ceId",
                                      coveredEntityAllOptions
                                    );
                                  } else {
                                    clientMainDropDownData();
                                    fetchTherapeuticClassValues();
                                    fetchManufacturerValues();
                                    fetchClientDropDownValues();
                                  }
                                }}
                              />
                            )}
                          </Field>
                        </Grid>
                      )}

                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                        <Field name="phGroupId">
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder="Select Pharmacy Chain"
                              options={pharmacyGroups}
                              getOptionLabel={(option) =>
                                `${option.pharmacyGroup}`
                              }
                              {...field}
                              onChange={(_e, value) => {
                                setFieldValue("phGroupId", value);
                                if (!_isEmpty(value)) {
                                  fetchAllDropDownValues(
                                    {
                                      ...values,
                                      phGroupId: value,
                                    },
                                    "phGroupId",
                                    pharmacyGroups
                                  );
                                } else {
                                  clientMainDropDownData();
                                  fetchTherapeuticClassValues();
                                  fetchManufacturerValues();
                                  fetchClientDropDownValues();
                                }
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                        <Field name="pharmacy">
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder="Select Pharmacy Store"
                              options={pharmaciesList}
                              getOptionLabel={(option) =>
                                `${option.pharmacyName}`
                              }
                              {...field}
                              onChange={(_e, value) => {
                                setFieldValue("pharmacy", value);
                                if (!_isEmpty(value)) {
                                  fetchAllDropDownValues(
                                    {
                                      ...values,
                                      pharmacy: value,
                                    },
                                    "pharmacy",
                                    pharmaciesList
                                  );
                                } else {
                                  clientMainDropDownData();
                                  fetchTherapeuticClassValues();
                                  fetchManufacturerValues();
                                  fetchClientDropDownValues();
                                }
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Manufacturer</FormLabel>
                        <Field name="manufacturer">
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder="Select manufacturer"
                              options={manufacturerValues}
                              getOptionLabel={(option) =>
                                `${option.manufacturer}`
                              }
                              getOptionSelected={(option, value) =>
                                Number(option.manufacturerId) ===
                                Number(value.manufacturerId)
                              }
                              {...field}
                              onChange={(_e, value) => {
                                setFieldValue("manufacturer", value);
                                if (!_isEmpty(value)) {
                                  fetchAllDropDownValues(
                                    {
                                      ...values,
                                      manufacturer: value,
                                    },
                                    "manufacturer",
                                    manufacturerValues
                                  );
                                } else {
                                  clientMainDropDownData();
                                  fetchTherapeuticClassValues();
                                  fetchManufacturerValues();
                                  fetchClientDropDownValues();
                                }
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Wholesaler</FormLabel>
                        <Field name="wholesaler">
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder="Select Wholesaler"
                              options={wholesalerValues}
                              getOptionLabel={(option) =>
                                `${option.wholesaler}`
                              }
                              {...field}
                              onChange={(_e, value) => {
                                setFieldValue("wholesaler", value);
                                if (!_isEmpty(value)) {
                                  fetchAllDropDownValues(
                                    {
                                      ...values,
                                      wholesaler: value,
                                    },
                                    "wholesaler",
                                    wholesalerValues
                                  );
                                }
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={2}>
                        <FormLabel>Start and End Date</FormLabel>
                        <Field name="startDate">
                          {({ field }) => (
                            <DatePicker
                              placeholder="MM/DD/YYYY"
                              disabledDate={(date) =>
                                startDateValidation(date, values.endDate)
                              }
                              {...field}
                              onChange={(_e, date) => {
                                if (!date) setFieldValue("endDate", "");
                                setFieldValue("startDate", date);
                              }}
                              value={
                                values.startDate
                                  ? moment(values.startDate, "MM/DD/YYYY")
                                  : ""
                              }
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={2} className={classes.endDate}>
                        <Field name="endDate">
                          {({ field }) => (
                            <DatePicker
                              placeholder="MM/DD/YYYY"
                              disabledDate={(d) =>
                                endDateValidation(d, values.startDate)
                              }
                              {...field}
                              onChange={(_e, date) => {
                                setFieldValue("endDate", date);
                              }}
                              value={
                                values.endDate
                                  ? moment(values.endDate, "MM/DD/YYYY")
                                  : ""
                              }
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Therapeutic Class</FormLabel>
                        <Field name="therapeuticClass">
                          {({ field }) => (
                            <MultiSelectDropdown
                              inputPlaceholder="Select Therapeutic Class"
                              options={therapeuticValues}
                              getOptionLabel={(option) =>
                                `${option.therapeuticClass}`
                              }
                              getOptionSelected={(option, value) =>
                                option.drugTherapeuticClassId ===
                                value.drugTherapeuticClassId
                              }
                              {...field}
                              onChange={(_e, value) => {
                                setFieldValue("therapeuticClass", value);
                                if (!_isEmpty(value)) {
                                  fetchAllDropDownValues(
                                    {
                                      ...values,
                                      therapeuticClass: value,
                                    },
                                    "therapeuticClass",
                                    therapeuticValues
                                  );
                                }
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>NDC</FormLabel>
                        <Field
                          name="ndc"
                          id="ndc"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter NDC"
                          maxLength={11}
                          onChange={(e) => {
                            const { value } = e.target;
                            if (value && !REGEX.onlyNumbers.test(value)) return;
                            setFieldValue("ndc", value);
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>GCN</FormLabel>
                        <Field
                          name="gcn"
                          id="gcn"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter GCN"
                          maxLength={11}
                          onChange={(e) => {
                            const { value } = e.target;
                            if (value && !REGEX.onlyNumbers.test(value)) return;
                            setFieldValue("gcn", value);
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Exclusion Type</FormLabel>
                        {
                          <Field
                            as="select"
                            className={globalClasses.formControl}
                            name="exclusionType"
                          >
                            {({ field }) => (
                              <AutoComplete
                                {...field}
                                options={
                                  _isArray(exclusionTypeValues)
                                    ? exclusionTypeValues
                                    : []
                                }
                                inputPlaceholder={"Select Exclusion Type"}
                                disableCloseOnSelect={false}
                                onChange={(e, value) => {
                                  setFieldValue(
                                    "exclusionTypeInput",
                                    value ? value.exclusionType : ""
                                  );
                                  setFieldValue("exclusionType", value || "");
                                }}
                                getOptionLabel={(option) =>
                                  option.exclusionType || ""
                                }
                                renderOption={(option, _other) => {
                                  return (
                                    <BasicTypography variant="subtitle2">
                                      {option.exclusionType}
                                    </BasicTypography>
                                  );
                                }}
                                inputValue={values.exclusionTypeInput || ""}
                                onInputChange={(_e, value) =>
                                  setAutoCompleteInputVal({
                                    value,
                                    callback: (newValue) => {
                                      setFieldValue(
                                        "exclusionTypeInput",
                                        newValue
                                      );
                                    },
                                  })
                                }
                                multiple={false}
                              />
                            )}
                          </Field>
                        }
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Active/Inactive/All </FormLabel>
                        <Grid
                          item
                          xs={3}
                          sm={1}
                          className={classes.radioGridContainer}
                        >
                          <div className={classes.gridContentContainer}>
                            <div className={classes.radioAndLabelContainer}>
                              <Field
                                name="activeInactiveAll"
                                type="radio"
                                value="Active"
                                className={classes.radioInput}
                              />
                              <FormLabel>Active</FormLabel>
                            </div>
                          </div>
                          <div className={classes.gridContentContainer}>
                            <div className={classes.radioAndLabelContainer}>
                              <Field
                                name="activeInactiveAll"
                                type="radio"
                                value="InActive"
                                className={classes.radioInput}
                              />
                              <FormLabel>Inactive</FormLabel>
                            </div>
                          </div>
                          <div className={classes.gridContentContainer}>
                            <div className={classes.radioAndLabelContainer}>
                              <Field
                                name="activeInactiveAll"
                                type="radio"
                                value=""
                                className={classes.radioInput}
                              />
                              <FormLabel>All</FormLabel>
                            </div>
                          </div>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid container spacing={2} justifyContent="flex-end">
                      <Grid item>
                        <Button
                          type="submit"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                        >
                          Search
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          onClick={() => onClear(initialValues)}
                        >
                          Clear
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            ) : (
              <Button
                variant="contained"
                className={globalClasses.primaryBtn}
                onClick={() => {
                  setShowFilters(true);
                }}
              >
                Filters
              </Button>
            )}
          </Form>
        );
      }}
    </Formik>
  );
});

export default NdcSearchForm;
