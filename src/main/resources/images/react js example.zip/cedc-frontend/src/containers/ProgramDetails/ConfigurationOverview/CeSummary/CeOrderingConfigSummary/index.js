import React, { useCallback, useEffect, useState } from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import _isEmpty from "lodash/isEmpty";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import { useCeSummaryStyle } from "../styles";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import CeOrderingConfiguration from "../../popupsdetail/EntityDetails/CeOrderingConfiguration";
import { ORDERING_CONFIG_MODULE } from "../../../../../utils/constants";

const CeOrderingConfigSummary = (props = {}) => {
  const { isAllCollapsed, selectedCeForOverview } = props;
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const [isCollapsed, setIsCollapsed] = useState(true);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Ordering Configuration" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <CeOrderingConfiguration
                selectedCeId={selectedCeForOverview["ceid"]}
                module={ORDERING_CONFIG_MODULE.CO}
              />
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default CeOrderingConfigSummary;
