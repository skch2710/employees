import React, { useState, useRef, useEffect } from "react";
import { useDispatch } from "react-redux";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../Styles/useGlobalStyles";
import _isEmpty from "lodash/isEmpty";
import MaterialTable, { MTableToolbar } from "material-table";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getTableHeaderCount, isEmptyGrid } from "../../../../utils/helper";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import { pagination } from "../../../../utils/constants";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import Pagination from "../../../../components/common/Pagination";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import { fetchLocationHistory } from "../../../../context/actions/Locations";
import { useSelector } from "react-redux";
import DataNotFound from "../../../../components/common/DataNotFound";
import { getLocationHistoryFiltersObject } from "./helper";
import { LOCATION_HISTORY } from "../../../../context/reducers/Locations/constants";

const LocationHistory = (props) => {
  const { locationData } = props;
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const theme = useTheme();
  const dispatch = useDispatch();

  const [filter, setFilter] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
  });
  const filterValuesRef = useRef({});
  const tableRef = useRef(null);

  const { records: locationHistoryData, loading } =
    useSelector((state) => state.getLocationHistoryData) || {};

  const LOCATION_HISTORY_COLUMNS = [
    {
      title: "Source",
      field: "source",
      defaultFilter: filter && filterValuesRef.current.source,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.source}>
            <span>{rowData.source}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.source}
          placeholder="Source"
        />
      ),
    },

    {
      title: "Participating 340B Site",
      field: "site340b",
      defaultFilter: filter && filterValuesRef.current.site340b,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.site340b === true ? "Yes" : "No"}>
            <span>{rowData.site340b === true ? "Yes" : "No"}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={filterValuesRef.current.site340b || ""}
          >
            <option value="">Select Option</option>
            <option value="true">Yes</option>
            <option value="false">No</option>
          </select>
        );
      },
    },
    {
      title: "Covered Entity",
      field: "coveredEntity",
      defaultFilter: filter && filterValuesRef.current.coveredEntity,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity}>
            <span>{rowData.coveredEntity}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.coveredEntity}
          placeholder="Covered Entity"
        />
      ),
    },

    {
      title: "Location Name",
      field: "locationName",
      defaultFilter: filter && filterValuesRef.current.locationName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationName}>
            <span>{rowData.locationName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.locationName}
          placeholder="Location Name"
        />
      ),
    },
    {
      title: "Location HRSA ID",
      field: "locationHrsaId",
      defaultFilter: filter && filterValuesRef.current.locationHrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationHrsaId}>
            <span>{rowData.locationHrsaId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.locationHrsaId}
          placeholder="Location HRSA ID"
        />
      ),
    },

    {
      title: "Address Line 1",
      field: "addressLine1",
      defaultFilter: filter && filterValuesRef.current.addressLine1,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine1}>
            <span>{rowData.addressLine1}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.addressLine1}
          placeholder="Address Line 1"
        />
      ),
    },

    {
      title: "Address Line 2",
      field: "addressLine2",
      defaultFilter: filter && filterValuesRef.current.addressLine2,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.addressLine2}>
            <span>{rowData.addressLine2}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.addressLine2}
          placeholder="Address Line 2"
        />
      ),
    },

    {
      title: "City",
      field: "city",
      defaultFilter: filter && filterValuesRef.current.city,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.city}>
            <span>{rowData.city}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.city}
          placeholder="City"
        />
      ),
    },

    {
      title: "State",
      field: "state",
      defaultFilter: filter && filterValuesRef.current.state,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.state}>
            <span>{rowData.state}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.state}
          placeholder="State"
        />
      ),
    },

    {
      title: "Zip",
      field: "zip",
      defaultFilter: filter && filterValuesRef.current.zip,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.zip}>
            <span>{rowData.zip}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.zip}
          placeholder="Zip"
        />
      ),
    },

    {
      title: "OPA Location Start Date",
      field: "startDate",
      defaultFilter: filter && filterValuesRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValuesRef.current.startDate
                ? moment(filterValuesRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "OPA Location End Date",
      field: "endDate",
      defaultFilter: filter && filterValuesRef.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValuesRef.current.endDate
                ? moment(filterValuesRef.current.endDate)
                : ""
            }
          />
        );
      },
    },

    {
      title: "New Status",
      field: "locationStatus",
      defaultFilter: filter && filterValuesRef.current.locationStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locationStatus}>
            <span>{rowData.locationStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.locationStatus}
          placeholder="New Status"
        />
      ),
    },

    {
      title: "Old Status",
      field: "locPreviousStatus",
      defaultFilter: filter && filterValuesRef.current.locPreviousStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.locPreviousStatus}>
            <span>{rowData.locPreviousStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.locPreviousStatus}
          placeholder="Old Status"
        />
      ),
    },
    {
      title: "Modified Date",
      field: "lastModifiedDate",
      defaultFilter: filter && filterValuesRef.current.lastModifiedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastModifiedDate}>
            <span>{rowData.lastModifiedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValuesRef.current.lastModifiedDate
                ? moment(filterValuesRef.current.lastModifiedDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Modified By",
      field: "modifiedBy",
      defaultFilter: filter && filterValuesRef.current.modifiedBy,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.modifiedBy}>
            <span>{rowData.modifiedBy}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.modifiedBy}
          placeholder="Modified By"
        />
      ),
    },
    {
      title: "Comments",
      field: "comments",
      defaultFilter: filter && filterValuesRef.current.comments,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.comments}>
            <span>{rowData.comments}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValuesRef.current.comments}
          placeholder="Comments"
        />
      ),
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(locationHistoryData),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(locationHistoryData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(locationHistoryData),
      onClick: () =>
        getLocationHistory({
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortOrder: controllers.sortOrder,
          sortBy: controllers.sortBy,
          filter: columnFilters,
          export: true,
        }),
    },
  ];

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  // TO DO
  const onChangePagination = (prevPage, pageSize) => {
    let currentPage = prevPage + 1;
    const totalPages = Math.ceil(locationHistoryData.totalElements / pageSize);
    if (controllers.pageNumber > totalPages) currentPage = totalPages;
    else if (prevPage === 0 && pageSize !== controllers.pageSize)
      currentPage = controllers.pageNumber;
    getLocationHistory(
      {
        pageNumber: currentPage,
        pageSize: pageSize,
        sortOrder: controllers.sortOrder,
        sortBy: controllers.sortBy,
        filter: columnFilters,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const onChangeSorting = (orderedColumnId) => {
    const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
    const sortBy = LOCATION_HISTORY_COLUMNS[orderedColumnId].field;
    setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
    getLocationHistory(
      {
        pageNumber: controllers.pageNumber,
        pageSize: controllers.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      },
      (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
    );
  };

  const onChangeColumnFilters = (filters = []) => {
    const filterPayload = getLocationHistoryFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    filterValuesRef.current = { ...updatedFiltersObj };
    getLocationHistory(
      {
        ...controllers,
        pageNumber: pagination.page,
        filter: filterPayload,
      },
      (resp) => setControllersOnResp(resp)
    );
  };

  const getLocationHistory = async (payload = {}, callback) => {
    const payloadJson = {
      pageNumber: payload.pageNumber || pagination.page,
      pageSize: payload.pageSize || pagination.limit,
      sortBy: payload.sortBy || "",
      sortOrder: payload.sortOrder || "",
      filter: payload.filter || [],
      export: payload.export || false,
      entityLocationId: locationData.entityLocationId,
      ...payload,
    };

    const tableData = await dispatch(fetchLocationHistory(payloadJson));
    if (!_isEmpty(tableData)) {
      callback && callback(tableData);
    }
  };

  useEffect(() => {
    getLocationHistory();
    return () => dispatch({ type: LOCATION_HISTORY, data: {} });
  }, []);

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Location Variation History (${getTableHeaderCount(
              locationHistoryData.totalElements
            )})`}
          />
        }
        tableRef={tableRef}
        columns={LOCATION_HISTORY_COLUMNS}
        data={locationHistoryData.content || []}
        page={controllers.pageNumber - 1}
        totalCount={locationHistoryData.totalElements}
        onChangePage={onChangePagination}
        onOrderChange={onChangeSorting}
        onFilterChange={onChangeColumnFilters}
        actions={Actions}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        icons={{
          SortArrow: () => TableCustomSortArrow(controllers),
          Filter: ColumnFilterIcon,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: filter,
          paginationType: "stepped",
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controllers.pageSize,
          draggable: false,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          doubleHorizontalScroll: false,
          pageSizeOptions: isEmptyGrid(locationHistoryData)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};
export default LocationHistory;
