import React, { useCallback, useRef, useState, useContext } from "react";
import { Tooltip, useTheme } from "@material-ui/core";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEmpty from "lodash/isEmpty";
import { Paper } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../../../../components/common/TableCustomSortArrow";
import {
  POLLING_COUNT,
  STRING_MODIFICATIONS,
  pagination,
} from "../../../../../../../utils/constants";
import { useDispensingFeesTableStyles } from "../styles";
import DataNotFound from "../../../../../../../components/common/DataNotFound";
import BasicTypography from "../../../../../../../components/common/Typography/BasicTypography";
import {
  createDispensingFeePayload,
  getAddEditDispensingFeeDefaultFormValues,
  getDispensingFeesFiltersObject,
} from "../helper";
import AddDispensingFees from "./AddDispensingFees";
import { ACCESS_BY_MAPPING } from "../constants";
import {
  dispensingFeeMessageUuidTest,
  saveDispensingFees,
  validateDispensingFee,
} from "../../../../../../../context/actions/PharmacyConfiguration";
import BasicPopup from "../../../../../../../components/Popup/BasicPopup";
import DispensingFeePopupFooter from "./DispensingFeePopupFooter";
import { COContext } from "../../../../../COContext";
import DatePicker from "../../../../../../../components/common/DatePicker";
import moment from "moment";
import {
  getPrePostFixString,
  getTableHeaderCount,
  getUserSession,
  isEmptyGrid,
} from "../../../../../../../utils/helper";
import TableProgressBar from "../../../../../../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../../../../../../components/common/TableIcons";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableActionCellStyles,
} from "../../../../../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../../../../components/common/Pagination";

const DispensingFeesTable = (props = {}) => {
  const { getDispensingFeesTableData, isConfigurable = true } = props;
  const theme = useTheme();
  const dispatch = useDispatch();
  const userSessionData = getUserSession();
  const { currentPharmacy = {} } = useContext(COContext);
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const [defaultFormValues, setDefaultFormValues] = useState(
    getAddEditDispensingFeeDefaultFormValues()
  );
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const [showAddFee, setShowAddFee] = useState(false);
  const [showPreviousFeeTerminationPopup, setShowPreviousFeeTerminationPopup] =
    useState(false);
  const [showPreventNewFeePopup, setShowPreventNewFeePopup] = useState(false);
  const [isEditFee, setIsEditFee] = useState(false);
  const dispensingFeePayload = useRef({});

  const columnFiltersRef = useRef({});
  const { loading, records: dispensingFeesTableData } =
    useSelector((state) => state.phDispensingFeesList) || {};
  const classes = useDispensingFeesTableStyles({
    totalElements:
      !_isEmpty(dispensingFeesTableData) &&
      dispensingFeesTableData.totalElements,
    pageSize: controllers.pageSize,
    pageNumber: controllers.pageNumber,
  });

  const DISPENSING_FEES = [
    {
      title: "Access By",
      field: "feeAccessTypeId",
      defaultFilter: enableFilters && columnFiltersRef.current.feeAccessTypeId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={ACCESS_BY_MAPPING[rowData.feeAccessTypeId]}>
            <span>{ACCESS_BY_MAPPING[rowData.feeAccessTypeId]}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={columnFiltersRef.current.feeAccessTypeId || ""}
          >
            <option value={""}>Select option</option>
            <option value="1">Processed Date</option>
            <option value="2">Date of Service</option>
          </select>
        );
      },
    },
    {
      title: "Dispensing Fee Type",
      field: "dispensingFeeType",
      defaultFilter:
        enableFilters && columnFiltersRef.current.dispensingFeeType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingFeeType}>
            <span>{rowData.dispensingFeeType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingFeeType}
          placeholder="Dispensing Fee Type"
        />
      ),
    },
    {
      title: "Formulary Type",
      field: "formularyType",
      defaultFilter: enableFilters && columnFiltersRef.current.formularyType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.formularyType}>
            <span>{rowData.formularyType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.formularyType}
          placeholder="Formulary Type"
        />
      ),
    },
    {
      title: "B/G",
      field: "drugType",
      defaultFilter: enableFilters && columnFiltersRef.current.drugType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugType}>
            <span>{rowData.drugType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugType}
          placeholder="B/G"
        />
      ),
    },
    {
      title: "Reimbursement Model",
      field: "ceReimbursementModel",
      defaultFilter:
        enableFilters && columnFiltersRef.current.ceReimbursementModel,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceReimbursementModel}>
            <span>{rowData.ceReimbursementModel}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ceReimbursementModel}
          placeholder="Reimbursement Model"
        />
      ),
    },
    {
      title: "Dispensing Fee Calculation",
      field: "dispenseFeeCalc",
      defaultFilter: enableFilters && columnFiltersRef.current.dispenseFeeCalc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispenseFeeCalc}>
            <span>{rowData.dispenseFeeCalc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispenseFeeCalc}
          placeholder="Dispensing Fee Calculation"
        />
      ),
    },
    {
      title: "Applied AC Type",
      field: "appliedEacType",
      defaultFilter: enableFilters && columnFiltersRef.current.appliedEacType,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.appliedEacType}>
            <span>{rowData.appliedEacType}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.appliedEacType}
          placeholder="Applied AC Type"
        />
      ),
    },
    {
      title: "BIN",
      field: "bin",
      defaultFilter: enableFilters && columnFiltersRef.current.bin,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bin}>
            <span>{rowData.bin}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.bin}
          placeholder="BIN"
        />
      ),
    },
    {
      title: "PCN",
      field: "pcn",
      defaultFilter: enableFilters && columnFiltersRef.current.pcn,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pcn}>
            <span>{rowData.pcn}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pcn}
          placeholder="PCN"
        />
      ),
    },
    {
      title: "Group",
      field: "group",
      customFilterAndSearch: () => true,
      defaultFilter: enableFilters && columnFiltersRef.current.group,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.group}>
            <span>{rowData.group}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.group}
          placeholder="Group"
        />
      ),
    },
    {
      title: "Dispensing Fee % of EAC",
      field: "dispensingFeePercentageOfEac",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        enableFilters && columnFiltersRef.current.dispensingFeePercentageOfEac,
      render: (rowData) => {
        return (
          <Tooltip
            title={getPrePostFixString({
              value: rowData.dispensingFeePercentageOfEac,
              string: "%",
            })}
          >
            <span>
              {getPrePostFixString({
                value: rowData.dispensingFeePercentageOfEac,
                string: "%",
              })}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingFeePercentageOfEac}
          placeholder="Dispensing Fee % of EAC"
        />
      ),
    },
    {
      title: "Flat Dispensing Fee",
      field: "flatDispensingFee",
      type: "numeric",
      customFilterAndSearch: () => true,
      defaultFilter:
        enableFilters && columnFiltersRef.current.flatDispensingFee,
      render: (rowData) => {
        return (
          <Tooltip
            title={getPrePostFixString({
              value: rowData.flatDispensingFee,
              string: "$",
              type: STRING_MODIFICATIONS.PREFIX,
            })}
          >
            <span>
              {getPrePostFixString({
                value: rowData.flatDispensingFee,
                string: "$",
                type: STRING_MODIFICATIONS.PREFIX,
              })}
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.flatDispensingFee}
          placeholder="Flat Dispensing Fee"
        />
      ),
    },
    {
      title: "Dispending Fee Start Date",
      field: "startDate",
      defaultFilter: enableFilters && columnFiltersRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.startDate
                ? moment(columnFiltersRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Dispensing Fee End Date",
      field: "expirationDate",
      defaultFilter: enableFilters && columnFiltersRef.current.expirationDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.expirationDate}>
            <span>{rowData.expirationDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.expirationDate
                ? moment(columnFiltersRef.current.expirationDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(dispensingFeesTableData.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;

      getDispensingFeesTableData(
        {
          pageNumber: currentPage,
          pageSize: rowsPerPage,
          filter: columnFilters,
        },
        (resp) => {
          setControllers((prev) => ({
            ...prev,
            pageNumber: resp.pageNo || pagination.page,
            pageSize: resp.pageSize || pagination.limit,
          }));
        }
      );
    },
    [columnFilters, dispensingFeesTableData, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = DISPENSING_FEES[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      getDispensingFeesTableData({
        ...controllers,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controllers, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getDispensingFeesFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    getDispensingFeesTableData({
      ...controllers,
      filter: filterPayload,
    });
  };

  const FILTER_BUTTON = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(dispensingFeesTableData),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
  ];

  const ADDITIONAL_OPTIONS = [
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add Dispensing Fees" }),
      tooltip: "Add Dispensing Fees",
      isFreeAction: true,
      onClick: () => {
        setIsEditFee(false);
        setDefaultFormValues(getAddEditDispensingFeeDefaultFormValues());
        setShowAddFee(true);
      },
    },
    (row) => ({
      icon: iconsAndButtons.Edit(),
      tooltip: "Edit",
      isFreeAction: false,
      disabled: moment(moment(row.startDate).format("MM/DD/YYYY")).isBefore(
        moment(),
        "day"
      ),
      onClick: (_event, rowData) => {
        setIsEditFee(true);
        setDefaultFormValues(getAddEditDispensingFeeDefaultFormValues(rowData));
        setShowAddFee(true);
      },
    }),
  ];

  const handleValidate = (values) => {
    let error = {};
    if (!values.dispensingFeeType) {
      error.dispensingFeeType = "Please select the Dispensing Fee Type";
    }
    if (!values.formularyType) {
      error.formularyType = "Please select the Formulary Type";
    }
    if (!values.drugType) {
      error.drugType = "Please select the Drug Type";
    }
    if (!values.ceReimbursementModel) {
      error.ceReimbursementModel =
        "Please select the Reimbursement Model";
    }
    if (!values.dispenseFeeCalc) {
      error.dispenseFeeCalc = "Please select the Dispensing Fee Calculation";
    } else {
      if (Number(values.dispenseFeeCalc) === 1 && !values.percentage) {
        error.percentage = "Please enter the Percentage";
      }
    }
    if (!values.appliedAcType) {
      error.appliedAcType = "Please select the Applied AC Type";
    }
    if (!values.bin) {
      error.bin = "Please enter the BIN";
    }
    if (!values.pcn) {
      error.pcn = "Please enter the PCN";
    }
    if (!values.group) {
      error.group = "Please enter the Group";
    }
    if (!values.dispensingFeePercentage) {
      error.dispensingFeePercentage =
        "Please enter the Dispensing Fee % of EAC";
    }
    if (!values.flatDispensingFee) {
      error.flatDispensingFee = "Please enter the Flat Dispensing Fee";
    }
    if (!values.startDate) {
      error.startDate = "Please select the 340BDirect+ Fee Start Date";
    }
    if (!values.expDate) {
      error.expDate = "Please select the 340BDirect+ Fee End Date";
    }
    if (!values.accessBy) {
      error.accessBy = "Please select the Access By";
    }
    return error;
  };

  const addDispensingFee = async (values = {}) => {
    const payload = createDispensingFeePayload({
      ...values,
      clientId: currentPharmacy.clientId,
      createdBy: userSessionData.userId,
      modifiedBy: userSessionData.userId,
    });
    const resp = await dispatch(saveDispensingFees(payload));
    if (!_isEmpty(resp) && resp.data) {
      handlePolling({
        messageUUid: resp.data,
        currentCount: POLLING_COUNT,
        resetForm: values.resetForm,
        isExit: values.isExit,
      });
    }
  };

  const handleSubmit = async (values, { resetForm }) => {
    const resp = await dispatch(
      validateDispensingFee({
        clientId: currentPharmacy.clientId,
        drugTypeId: values.drugType,
        startDate: values.startDate,
        expirationDate: values.expDate,
        dispensingFeeId: values.dispensingFeeId || 0,
        dispensingFeeTypeId: Number(values.dispensingFeeType),
        formularyTypeId: Number(values.formularyType),
      })
    );
    if (!_isEmpty(resp)) {
      if (resp.showTerminatePopup) {
        dispensingFeePayload.current = {
          ...values,
          previousDispensingFeeId: resp.previousDispensingFeeId,
          resetForm,
        };
        setShowPreviousFeeTerminationPopup(true);
      } else if (resp.showPreventNewFeePopup) {
        setShowPreventNewFeePopup(true);
      } else {
        addDispensingFee({
          ...values,
          resetForm,
        });
      }
    }
  };

  const handlePolling = async ({
    messageUUid,
    currentCount,
    resetForm,
    isExit,
  }) => {
    const count = currentCount;
    const resp = await dispatch(
      dispensingFeeMessageUuidTest(messageUUid, count)
    );
    if (resp && resp.statusCode === 200) {
      showPreviousFeeTerminationPopup &&
        setShowPreviousFeeTerminationPopup(false);
      showPreventNewFeePopup && setShowPreventNewFeePopup(false);
      if (isExit) setShowAddFee(false);
      else resetForm();
      getDispensingFeesTableData({ filter: columnFilters });
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
        resetForm,
        isExit,
      });
    }
  };

  return (
    <>
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h4"
              title={`Dispensing Fees (${getTableHeaderCount(
                dispensingFeesTableData.totalElements
              )})`}
            />
          }
          columns={DISPENSING_FEES}
          data={dispensingFeesTableData.content}
          page={controllers.pageNumber - 1}
          totalCount={dispensingFeesTableData.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={
            isConfigurable
              ? [...FILTER_BUTTON, ...ADDITIONAL_OPTIONS]
              : FILTER_BUTTON
          }
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            minBodyHeight: 100,
            pageSizeOptions: isEmptyGrid(dispensingFeesTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>
      {showAddFee && (
        <BasicPopup
          show={showAddFee}
          title={`${currentPharmacy.phName || "Pharmacy Name"} / ${
            isEditFee ? "Edit" : "Add"
          } Dispensing Fees`}
          disableFooter={true}
          isCustomFooter={true}
          footerActionElement={
            <DispensingFeePopupFooter
              isEditFee={isEditFee}
              setShowAddFee={setShowAddFee}
            />
          }
          handleClose={() => setShowAddFee(false)}
          dialogProps={{
            maxWidth: "md",
            classes: {
              paper: classes.dialogPaper,
            },
          }}
          withFormik={true}
          formikProps={{
            initialValues: defaultFormValues,
            onSubmit: handleSubmit,
            validate: handleValidate,
          }}
        >
          <AddDispensingFees />
        </BasicPopup>
      )}
      {showPreviousFeeTerminationPopup && (
        <BasicPopup
          show={showPreviousFeeTerminationPopup}
          handleClose={() => setShowPreviousFeeTerminationPopup(false)}
          submitProps={{
            buttonTitle: "Yes",
            handleSubmit: () => addDispensingFee(dispensingFeePayload.current),
          }}
          cancelProps={{
            buttonTitle: "No",
            handleCancel: () => {
              dispensingFeePayload.current = {};
              setShowPreviousFeeTerminationPopup(false);
              setShowAddFee(false);
            },
          }}
          dialogProps={{
            maxWidth: "sm",
            classes: {
              paper: classes.confirmationPopup,
            },
          }}
        >
          <BasicTypography variant="h5">
            Dispensing fee is already configured with this Drug Type. Do you
            want to terminate the existing configuration?
          </BasicTypography>
        </BasicPopup>
      )}
      {showPreventNewFeePopup && (
        <BasicPopup
          show={showPreventNewFeePopup}
          handleClose={() => setShowPreventNewFeePopup(false)}
          submitProps={{
            buttonTitle: "Ok",
            handleSubmit: () => setShowPreventNewFeePopup(false),
          }}
          dialogProps={{
            maxWidth: "sm",
            classes: {
              paper: classes.confirmationPopup,
            },
          }}
        >
          <BasicTypography variant="h5">
            Dispensing fee is already configured with the selected Drug Type.
          </BasicTypography>
        </BasicPopup>
      )}
    </>
  );
};

export default DispensingFeesTable;
