import { makeStyles } from "@material-ui/core/styles";

export const useEligibilityStyles = makeStyles((theme) => {
  return {
    switchGridContainer: {
      display: "flex",
      alignItems: "flex-start",
    },
    switchLabel: {
      color: theme.colors.monochrome.input,
      fontSize: "13px",
    },
    switchRoot: {
      display: "flex",
      alignItems: "flex-start",
    },
    actionBtnGridItem: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
    },
    toggleBtnContainer: {
      display: "flex",
    },
    formControlInput: {
      width: "55px",
      color: theme.colors.monochrome.input,
      padding: "0 0 0 7px !important",
      border: `1px solid ${theme.colors.secondary.default} !important`,
      borderRadius: "4px !important",
      boxShadow: "1px 1px 3px rgb(41 84 106 / 7%) !important",
      height: "30px !important",
      fontSize: "small !important",
      backgroundColor: theme.colors.monochrome.offWhite,
      "&::placeholder": {
        color: theme.colors.monochrome.input,
      },
    },
    toggleLabel: {
      fontSize: "13px",
    },
    claimExclusionsContainer: {
      margin: "36px 0px 20px 0px",
    },
  };
});
