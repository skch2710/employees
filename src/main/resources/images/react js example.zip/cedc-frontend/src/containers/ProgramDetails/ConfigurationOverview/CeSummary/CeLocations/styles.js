import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../../utils/helper";

export const useCeLocationStyle = makeStyles((theme) => {
  return {
    verifiedIcon: {
      color: theme.colors.primary.default,
      width: "16px",
      height: "16px",
    },
  };
});
