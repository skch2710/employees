import React from "react";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";

const AddressValidationPopup = ({
  setNotificationPopup,
  onClickUseThisAddress,
  formValues,
  setFormValues,
}) => {
  const globalClasses = useGlobalStyles();

  return (
    <>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <BasicTypography
                variant="h4"
                title={
                  formValues.standardPrescriberAddrHashKey
                    ? "Found the Standard Address"
                    : "This address cannot be standardized. Do you want to use this address anyway?"
                }
              />
            </Grid>
            {/* TO DO IN FUTURE */}
            {/* <Grid item xs={12}>
              <BasicTypography variant="h6" title="Similar Address:" />
              <BasicTypography
                variant="h6"
                title="530 Main Street, Wellington FL, 33414"
              />
            </Grid> */}
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Grid container spacing={2} justifyContent="flex-end">
            <>
              <Grid item>
                <Button
                  size="small"
                  variant="outlined"
                  className={globalClasses.primaryBtn}
                  onClick={() => onClickUseThisAddress()}
                >
                  Yes, Use This Address
                </Button>
              </Grid>

              <Grid item>
                <Button
                  size="small"
                  variant="outlined"
                  className={globalClasses.secondaryBtn}
                  onClick={() => {
                    setNotificationPopup(false);
                    setFormValues({});
                  }}
                >
                  Cancel
                </Button>
              </Grid>
            </>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default AddressValidationPopup;
