import React, { useState } from "react";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import LinearProgress from "@material-ui/core/LinearProgress";
import { Tooltip } from "@material-ui/core";

const BorderLinearProgress = withStyles((theme) => ({
  root: {
    height: 10,
    borderRadius: 10,
  },
  colorPrimary: {
    backgroundColor:
      theme.palette.grey[theme.palette.type === "light" ? 200 : 700],
  },
  bar: {
    borderRadius: 5,
    backgroundColor: "green",
  },
}))(LinearProgress);

const useStyles = makeStyles({
  root: {
    flexGrow: 1,
  },
});

function ProgressBar({ progressBarValue }) {
  const classes = useStyles();

  const [position, setPosition] = useState({
    x: "",
    y: "",
  });

  return (
    <div className={classes.root}>
      <Tooltip
        title="Implementation Progress"
        onMouseMove={(e) => setPosition({ x: e.pageX, y: e.pageY })}
        PopperProps={{
          anchorEl: {
            clientHeight: 0,
            clientWidth: 0,
            getBoundingClientRect: () => ({
              top: position.y,
              left: position.x,
              right: position.x,
              bottom: position.y,
              width: 0,
              height: 0,
            }),
          },
        }}
      >
        <BorderLinearProgress variant="determinate" value={progressBarValue} />
      </Tooltip>
    </div>
  );
}

export default ProgressBar;
