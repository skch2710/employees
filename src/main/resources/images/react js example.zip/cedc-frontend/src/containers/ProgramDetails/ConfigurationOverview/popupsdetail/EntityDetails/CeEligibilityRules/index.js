import React, { useState, useEffect, useContext } from "react";
import { useDispatch } from "react-redux";
import { Grid, FormLabel, Button } from "@material-ui/core";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { Formik, Form, Field } from "formik";
import { eligibilityRulesDefaultValues } from "./helper";
import { useCeEligibilityStyles } from "./styles";
import EligibilityRuleSets from "./EligibilityRuleSets";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import _isArray from "lodash/isArray";
import {
  getEligibilityRuleSets,
  getEligibilityRulesLookup,
  saveEligibilityRulesList,
} from "../../../../../../context/actions/EligibilityRules";
import { getUserSession } from "../../../../../../utils/helper";
import {
  fetchTermsGridTableData,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";

const EligibilityRules = ({ clickOnAdd }) => {
  const defaultValues = eligibilityRulesDefaultValues();
  const classes = useCeEligibilityStyles();
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const userRole = getUserSession();

  const {
    messageUuid,
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext);
  const CEID = messageUuid && messageUuid.ceid !== null && messageUuid.ceid;
  const { ceEligibility } = menusStatuses;

  const [ruleNames, setRuleNames] = useState([]);
  const [createRuleSet, setCreateRuleSet] = useState([]);
  const [showErrorMessage, setShowErrorMessage] = useState(false);
  const [ruleSetData, setRuleSetData] = useState([]);

  const handleSubmit = (values, { resetForm }) => {
    const selectedRulesArray = [];
    if (values.Location)
      selectedRulesArray.push({
        attributeId: 1,
        attributeName: "Location",
      });
    if (values.Encounter)
      selectedRulesArray.push({
        attributeId: 2,
        attributeName: "Encounter",
      });
    if (values.Provider)
      selectedRulesArray.push({
        attributeId: 3,
        attributeName: "Provider",
      });
    if (values.Patient)
      selectedRulesArray.push({
        attributeId: 4,
        attributeName: "Patient",
      });

    const selectedRulesIDs = [];
    selectedRulesArray.map((item) => {
      selectedRulesIDs.push(item.attributeId);
    });

    let addRuleSet = true;
    createRuleSet.length > 0 &&
      createRuleSet.map((item, index) => {
        const ruleSetIDsArray = [];
        item.attributes.map((item) => {
          ruleSetIDsArray.push(item.attributeId);
        });
        if (ruleSetIDsArray.toString() === selectedRulesIDs.toString()) {
          addRuleSet = false;
          setShowErrorMessage(true);
          return;
        }
      });

    if (addRuleSet) {
      setShowErrorMessage(false);
      setCreateRuleSet((prev) => [
        ...prev,
        {
          attributes: selectedRulesArray,
          historyInfo: [],
          isExpanded: false,
          isToggleOn: false,
          isModified: false,
          ruleSetId: createRuleSet.length + 1,
        },
      ]);
      resetForm();
    }
  };

  const getBooleanValue = (values) => {
    const booleanArray = Object.values(values);
    return !booleanArray.includes(true);
  };

  const fetchEligibilityRulesLookup = async () => {
    const ruleNamesArray = await dispatch(getEligibilityRulesLookup());
    setRuleNames(_isArray(ruleNamesArray) ? ruleNamesArray : []);
  };

  const fetchEligibilityRules = async () => {
    const ruleSetArray = await dispatch(getEligibilityRuleSets(CEID));
    const sortedRuleset =
      _isArray(ruleSetArray) &&
      ruleSetArray.sort((p1, p2) =>
        p1.ruleSetId > p2.ruleSetId ? 1 : p1.ruleSetId < p2.ruleSetId ? -1 : 0
      );

    const updatedResult = [];
    _isArray(sortedRuleset) &&
      sortedRuleset.map((item, index) => {
        updatedResult.push({
          attributes: item.attributes,
          isExpanded: false,
          isToggleOn: item.inActiveFlag === "Y" ? true : false,
          historyInfo: item.historyInfo,
          ruleSetId: item.ruleSetId,
        });
      });
    setRuleSetData(updatedResult);
    setCreateRuleSet(updatedResult);
  };

  const handleClickSave = async ({ stopNavigation }) => {
    const payloadArray = [];
    createRuleSet.map((item1, index1) => {
      item1.attributes.map((item2) => {
        const payloadObj = {};
        item2.eligibilityRuleConfigId &&
          (payloadObj.eligibilityRuleConfigId = item2.eligibilityRuleConfigId);
        payloadObj.ceId = CEID;
        payloadObj.attributeId = item2.attributeId;
        payloadObj.ruleSetId = item1.ruleSetId;
        payloadObj.inactiveFlag = item1.isToggleOn === true ? "Y" : "N";
        payloadObj.modifiedById = userRole.userId;
        payloadObj.createdById = item2.createdById
          ? item2.createdById
          : userRole.userId;
        payloadObj.isModified =
          index1 < ruleSetData.length
            ? item1.isToggleOn === ruleSetData[index1].isToggleOn
              ? null
              : true
            : item1.isModified;

        payloadArray.push(payloadObj);
      });
    });

    const res = await dispatch(saveEligibilityRulesList(payloadArray));
    if (res.statusCode === 200) {
      !clickOnAdd && dispatch(getEligibilityRuleSets(messageUuid.ceid));
      if (clickOnAdd || ceEligibility) {
        dispatch(
          updateSectionStatus({
            ceId: messageUuid.ceid,
            sectionId: 4,
            callback: statusCallback,
          })
        );
      }
      if (stopNavigation) setOpenAddCePopup(false);
      else setPopupActiveMenu(MENUS.CE_ORDERING_CONFIGURATION);
    }
  };

  const statusCallback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({
        ...prev,
        ceEligibility: false,
      }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  useEffect(() => {
    fetchEligibilityRulesLookup();
    fetchEligibilityRules();
  }, []);

  return (
    <Formik initialValues={defaultValues} onSubmit={handleSubmit}>
      {({ setFieldValue, values }) => (
        <Form>
          <Grid container spacing={4}>
            <Grid item md={12}>
              <Grid container spacing={1}>
                <Grid item md={12}>
                  <BasicTypography
                    variant="h4"
                    title="Entity Details > Eligibility Rules"
                  />
                </Grid>
                <Grid item md={12}>
                  <BasicTypography variant="subtitle2">
                    Configure eligibility requirements that will be used to
                    determine eligibility for the Covered Entity's 340B Program
                  </BasicTypography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item md={12}>
              <Grid container spacing={3}>
                <Grid item md={12}>
                  <Grid container spacing={1}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Select Eligibility Components and Create Rule Set"
                      />
                    </Grid>
                    <Grid item md={12}>
                      <Grid
                        container
                        spacing={1}
                        className={classes.checkboxAndLabelContainer}
                      >
                        <Grid item md={6}>
                          <Grid container>
                            {ruleNames.map((item, index) => (
                              <Grid
                                item
                                md={3}
                                className={classes.checkboxAndLabelContainer}
                                key={index}
                              >
                                <Field
                                  name={item.attribute}
                                  type="checkbox"
                                  id={item.attributeId}
                                  className={classes.ruleCheckbox}
                                  onChange={(e) => {
                                    setFieldValue(
                                      e.target.name,
                                      e.target.checked
                                    );
                                  }}
                                />
                                <FormLabel
                                  htmlFor={item.attributeId}
                                  classes={{ root: classes.checkboxLabel }}
                                >
                                  {item.attribute}
                                </FormLabel>
                              </Grid>
                            ))}
                          </Grid>
                        </Grid>
                        <Grid item md={6}>
                          <Button
                            type="submit"
                            disabled={getBooleanValue(values)}
                            className={
                              getBooleanValue(values)
                                ? `${globalClasses.outlinedBtn} ${classes.disabledBorder}`
                                : globalClasses.outlinedBtn
                            }
                          >
                            {createRuleSet.length > 0
                              ? "Create Another Eligibility Rule Set"
                              : "Create Eligibility Rule Set"}
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                    {showErrorMessage && (
                      <Grid item md={12}>
                        <div className={classes.messageGrid}>
                          Rule Set is already configured with this combination
                          of eligibility components.
                        </div>
                      </Grid>
                    )}
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid item md={12}>
                    {createRuleSet.length > 0 &&
                      createRuleSet.map((item, index) => (
                        <EligibilityRuleSets
                          ruleSet={item}
                          index={index}
                          setCreateRuleSet={setCreateRuleSet}
                          createRuleSet={createRuleSet}
                          isFromWizard={true}
                          ruleNames={ruleNames}
                        />
                      ))}
                  </Grid>
                </Grid>
              </Grid>
            </Grid>

            <Grid item md={12}>
              <Grid container spacing={2} justifyContent="flex-end">
                <Grid item>
                  <Button
                    size="small"
                    variant="contained"
                    className={globalClasses.primaryBtn}
                    onClick={() => handleClickSave({ stopNavigation: false })}
                  >
                    Next
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={() =>
                      setPopupActiveMenu(MENUS.CE_ORDERING_CONFIGURATION)
                    }
                  >
                    Skip
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={() => handleClickSave({ stopNavigation: true })}
                  >
                    Save and Exit
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    type="reset"
                    size="small"
                    variant="outlined"
                    className={globalClasses.secondaryBtn}
                    onClick={() => setOpenAddCePopup(false)}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );
};

export default EligibilityRules;
