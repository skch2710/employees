import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { getPOItemHistoryExport } from "../../../../context/actions/PurchaseOrders";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { notNull } from "../../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { PO_ITEM_HISTORY_EXPORT_FILE_NAME } from "../constants";
import { usePOStyles } from "../styles";

const POItemHistoryExport = ({ po, controller, count, columnFilters }) => {
  const { poID, poItemID } = po || {};
  const dispatch = useDispatch();
  const classes = usePOStyles();
  const [values, setValues] = useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    FileSaver.saveAs(fileData, PO_ITEM_HISTORY_EXPORT_FILE_NAME + ".xlsx");
  };

  const ExportToPDF = (data) => {
    const headers = data.map((item) => {
      return {
        "PO Item ID": Object.keys(item)[0],
        "PO Item SEQID": Object.keys(item)[1],
        "File PO Item Number": Object.keys(item)[2],
        "Item Invoice Number": Object.keys(item)[3],
        "PO Item Status": Object.keys(item)[4],
        "Package Ordered": Object.keys(item)[5],
        "Package Acknowledged": Object.keys(item)[6],
        "Package Invoiced": Object.keys(item)[7],
        "Package Reconciled": Object.keys(item)[8],
        "File Item Status Code": Object.keys(item)[9],
        "Item Ordered Date": Object.keys(item)[10],
        "Item Acknowledged Date": Object.keys(item)[11],
        "Item Invoiced Date": Object.keys(item)[12],
        "Item Reconciled Date": Object.keys(item)[13],
        "Acknowledged NDC": Object.keys(item)[14],
        "Invoiced NDC": Object.keys(item)[15],
        "Substituted Parent PO Item ID": Object.keys(item)[16],
        "Pgm Package Size": Object.keys(item)[17],
        "Created By": Object.keys(item)[18],
        "Created Date": Object.keys(item)[19],
      };
    });
    const dataRows = data.map((i) => Object.values(i));
    return { headers, dataRows };
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
      getPOItemHistoryExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          poItemID: poItemID,
          filter: columnFilters,
          export: true,
        },
        (result) => {
          var data = result.content.map(
            ({
              poItemID,
              poIdSeqID,
              filePoItemNumber,
              itemInvoiceNumber,
              poItemStatusID,
              packageOrdered,
              packageAcknowledged,
              packageInvoiced,
              packageReconciled,
              fileItemStatus,
              itemOrderedDate,
              itemAcknowledgedDate,
              itemInvoicedDate,
              itemReconciledDate,
              acknowledgedNDC,
              inVoicedNDC,
              substitutedParentpoItemId,
              pgmPackageSize,
              createdByID,
              createdDate,
            }) => ({
              "PO Item ID": notNull(poItemID),
              "PO Item SEQID": notNull(poIdSeqID),
              "File PO Item Number": notNull(filePoItemNumber),
              "Item Invoice Number": notNull(itemInvoiceNumber),
              "PO Item Status": notNull(poItemStatusID),
              "Package Ordered": notNull(packageOrdered),
              "Package Acknowledged": notNull(packageAcknowledged),
              "Package Invoiced": notNull(packageInvoiced),
              "Package Reconciled": notNull(packageReconciled),
              "File Item Status Code": notNull(fileItemStatus),
              "Item Ordered Date": notNull(itemOrderedDate),
              "Item Acknowledged Date": notNull(itemAcknowledgedDate),
              "Item Invoiced Date": notNull(itemInvoicedDate),
              "Item Reconciled Date": notNull(itemReconciledDate),
              "Acknowledged NDC": notNull(acknowledgedNDC),
              "Invoiced NDC": notNull(inVoicedNDC),
              "Substituted Parent PO Item ID": notNull(
                substitutedParentpoItemId
              ),
              "Pgm Package Size": notNull(pgmPackageSize),
              "Created By": notNull(createdByID),
              "Created Date": notNull(createdDate),
            })
          );
          if (e.target.value == "excel") {
            ExportToExcel(data);
            setValues("");
          }
          if (e.target.value == "pdf") {
            const { headers, dataRows } = ExportToPDF(data);
            const doc = new jsPDF();
            doc.autoTable({
              head: [headers[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...dataRows],
            });
            doc.save(`${PO_ITEM_HISTORY_EXPORT_FILE_NAME}.pdf`);
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset
        disabled={count > 0 ? false : true}
        className={classes.exportContainer}
      >
        <select
          className={classes.exportSelect}
          onChange={handleChange}
          value={values}
        >
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default POItemHistoryExport;
