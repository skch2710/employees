import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import _isEqual from "lodash/isEqual";
import LoaderUI from "../../../components/common/Loader/Loader";
import { InventorySearchList } from "../../../context/actions/Inventory";
import InvSearchForm from "./InvSearchForm";
import { userdata } from "../../../utils/common";
import InvMainList from "./InvMainList";
import { INVENTORY_SEARCH } from "../../../context/constants";
import { getDefaultInvListPayload } from "./constants";
import { getAllCoveredEntities } from "../../../context/actions/Common";
import { pagination } from "../../../utils/constants";
import { Grid } from "@material-ui/core";
import BasicTypography from "../../../components/common/Typography/BasicTypography";

const InventoryFilters = () => {
  const dispatch = useDispatch();
  const formRef = useRef(null);
  const clearedRef = useRef(null);
  const userRole = JSON.parse(userdata());
  const [ceList, setCeList] = useState([]);
  const actionRef = useRef(null);
  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const [enableFilters, setEnableFilters] = useState(false);
  const [InvControllers, setInvControllers] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "ndc",
  });
  const {
    loading,
    records: InvmainListdata,
    count,
  } = useSelector((state) => state.inventoryListData);

  const fetchCoveredEntities = async () => {
    const ces = await dispatch(getAllCoveredEntities());
    setCeList(ces);
  };

  const fetchInventoryDetails = (values, callback) => {
    const payloadJson = {
      ...getDefaultInvListPayload(values),
    };
    dispatch(
      InventorySearchList(payloadJson, (resp) => callback && callback(resp))
    );
  };

  const handleSubmit = (values) => {
    fetchInventoryDetails(
      {
        ...values,
        pageSize: pagination.limit,
        pageNumber: pagination.page,
        sortBy: InvControllers.sortBy,
        sortOrder: InvControllers.sortOrder,
      },
      (resp) => {
        actionRef.current && actionRef.current.submitForm(resp);
      }
    );
    setFormSubmittedValues(values);
    setEnableFilters(false);
  };

  useEffect(() => {
    if (userRole.isInternalUser) {
      fetchCoveredEntities();
    } else {
      setCeList(userRole.coveredEntityDTOs);
    }
    return () => {
      dispatch({ type: INVENTORY_SEARCH, data: {} });
    };
  }, []);

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <BasicTypography
          variant="h1"
          title="Inventory Management - Inventory"
        />
      </Grid>
      <Grid item md={12}>
        <InvSearchForm
          handleSubmit={handleSubmit}
          ceList={ceList}
          formRef={formRef}
          handleClear={(values) =>
            actionRef.current && actionRef.current.clearForm(values)
          }
          enableFilters={enableFilters}
          setEnableFilters={setEnableFilters}
        />
      </Grid>
      <Grid item md={12}>
        <InvMainList
          InvmainListdata={InvmainListdata}
          count={count}
          fetchInventoryDetails={fetchInventoryDetails}
          formRef={formRef}
          ref={actionRef}
          loading={loading}
          formSubmittedValues={formSubmittedValues}
          enableFilters={enableFilters}
          setEnableFilters={setEnableFilters}
          InvControllers={InvControllers}
          setInvControllers={setInvControllers}
        />
      </Grid>
    </Grid>
  );
};

export default InventoryFilters;
