import React, { useEffect, useState } from "react";
import {
  Grid,
  Paper,
  IconButton,
  Typography,
  FormLabel,
} from "@material-ui/core";
import HeaderTitle from "../../../components/common/Typography/HeaderTitle";
import { Formik, Form, Field } from "formik";
import { Collapse } from "reactstrap";
import { BsPencilSquare } from "react-icons/bs";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import Toggle from "../../../components/common/Toggle";

const ClientOrderRep = ({ codCollapse, setcodCollapse, phbasicDataValue }) => {
  const globalClasses = useGlobalStyles();
  const phbasicConfigMap =
    phbasicDataValue !== null && phbasicDataValue.pharmacyConfigMap;
  const phElegibilityData = phbasicConfigMap.phEligibilityDetails;
  const phClientOrder = phbasicConfigMap.phClientOrderAndReplenishDetails;
  const phClaimFee = phbasicConfigMap.phClaimExclusionsBasedOnFees;
  const phFroupData = phbasicConfigMap.phGroupOrderAndReplenishDetails;
  //pharmacy Eligibility Details Toggle
  const [fallOuttoggle, setFallOutToggle] = useState(false);
  const [pharmacySupporttoggle, setPharmacySupportToggle] = useState(false);
  const [CashClaimstoggle, setCashClaimsToggle] = useState(false);
  const [c2drugClaimtoggle, setC2DrugClaimsToggle] = useState(false);
  const [c5drugClaimtoggle, setC5DrugClaimsToggle] = useState(false);
  const [c4drugClaimtoggle, setC4DrugClaimsToggle] = useState(false);
  const [c3drugClaimtoggle, setC3DrugClaimsToggle] = useState(false);
  const [encryptedtoggle, setEncryptedToggle] = useState(false);
  const [excludeDrugtoggle, setExcludeDrugToggle] = useState(false);
  const [claimReprocesstoggle, setClaimReprocessToggle] = useState(false);

  //client order and Replenish Toggle
  const [orderpharmacytoggle, setOrderPharmacyToggle] = useState(false);
  const [centralreplenishtoggle, setCentralReplenishToggle] = useState(false);
  const [generatecetoggle, setGenerateC2Toggle] = useState(false);
  const [ceOwnedtoggle, setCEOwnedToggle] = useState(false);
  const [turnOfftoggle, setTurnOffToggle] = useState(false);
  const [centraltoggle, setCentralToggle] = useState(false);
  const [unsolicitedtoggle, setUnsolicitedToggle] = useState(false);
  const [claimtoggle, setClaimToggle] = useState(false);

  //Claim Exclusions Based on Fee Toggle
  const [excludeClaimtoggle, setExcludeClaimToggle] = useState(false);

  //Pharmacy Group Order and Replenish Toggle
  const [ceNetworktoggle, setCENetworkToggle] = useState(false);
  const [orderNotifytoggle, setOrderNotifyToggle] = useState(false);

  useEffect(() => {
    setPharmacySupportToggle(
      phElegibilityData &&
        phElegibilityData !== undefined &&
        phElegibilityData.pharmacySupportCashUCClaims === "Y"
        ? true
        : false
    );
    setEncryptedToggle(
      phElegibilityData &&
        phElegibilityData !== undefined &&
        phElegibilityData.isEncrypted === 1
        ? true
        : false
    );
    setExcludeDrugToggle(
      phElegibilityData &&
        phElegibilityData !== undefined &&
        phElegibilityData.excludeOrphanDrugs === "Y"
        ? true
        : false
    );
    setClaimReprocessToggle(
      phElegibilityData &&
        phElegibilityData !== undefined &&
        phElegibilityData.claimResponses === "Y"
        ? true
        : false
    );
    setOrderPharmacyToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.orderingPharmacy === "Y"
        ? true
        : false
    );
    setGenerateC2Toggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.generateC2OrdersOutOfSwell === "N"
        ? true
        : false
    );
    setCentralReplenishToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.participateInCentralReplenishment === "N"
        ? true
        : false
    );
    setTurnOffToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.turnOffTrueUp === "Y"
        ? true
        : false
    );
    setCEOwnedToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.turnOffCEOwnedInventory === "Y"
        ? true
        : false
    );
    setCentralToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.turnOffCEOwnedInventory === "Y"
        ? true
        : false
    );
    setClaimToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.claimReprocess === "Y"
        ? true
        : false
    );
    setUnsolicitedToggle(
      phClientOrder &&
        phClientOrder !== undefined &&
        phClientOrder.processUnsolicited855and810 === "Y"
        ? true
        : false
    );
    setExcludeClaimToggle(
      phClaimFee &&
        phClaimFee !== undefined &&
        phClaimFee.turnOnMinSpreadOrAdminFeeRule === "Y"
        ? true
        : false
    );
    setCENetworkToggle(
      phFroupData &&
        phFroupData !== undefined &&
        phFroupData.supportMultipleWholesalerForCENetwork === "Y"
        ? true
        : false
    );
    setOrderNotifyToggle(
      phFroupData &&
        phFroupData !== undefined &&
        phFroupData.sendOrderNotifications === "Y"
        ? true
        : false
    );
  }, [phElegibilityData, phClientOrder, phClaimFee, phFroupData]);
  return (
    <div>
      <Paper className="card card-first-level p-20 ">
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <HeaderTitle
            variant="h5"
            component="div"
            title="Ordering and Replenishment"
          />
          <Grid>
            <IconButton size="small" style={{ marginRight: "15px" }}>
              <BsPencilSquare />
            </IconButton>
            <IconButton size="small">
              {codCollapse ? (
                <AiOutlineMinus
                  onClick={() => setcodCollapse(codCollapse ? false : true)}
                />
              ) : (
                <AiOutlinePlus
                  onClick={() => setcodCollapse(codCollapse ? false : true)}
                />
              )}
            </IconButton>
          </Grid>
        </div>
        <hr />
        <Collapse isOpen={codCollapse}>
          <Formik
            enableReinitialize={true}
            initialValues=""
            onSubmit=""
            validate=""
          >
            {(values, handleChange) => {
              return (
                <>
                  <Form>
                    <Typography
                      variant="subtitle1"
                      style={{ color: "#201B51", marginTop: "10px" }}
                    >
                      {" "}
                      Pharmacy Chain Order and Replenish
                    </Typography>
                    <Grid item container spacing={1}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Billing Model</FormLabel>
                        <Typography variant="subtitle2">
                          {phClientOrder !== undefined
                            ? phClientOrder.wholesalerName
                            : "--"}
                        </Typography>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Send Order Notification</FormLabel>
                        <Grid item xs={12} sm={4}>
                          <Field
                            name="centralreplenish"
                            component={Toggle}
                            type="checkbox"
                            checked={centralreplenishtoggle}
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                    <Typography
                      variant="subtitle1"
                      style={{ color: "#201B51", marginTop: "10px" }}
                    >
                      {" "}
                      Client Order Replenish
                    </Typography>
                    <Grid item container spacing={1}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Wholesale Name</FormLabel>
                        <Typography variant="subtitle2">
                          {phClientOrder !== undefined
                            ? phClientOrder.wholesalerName
                            : "--"}
                        </Typography>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Wholesale Account Number</FormLabel>

                        <Typography variant="subtitle2">
                          {phClientOrder !== undefined
                            ? phClientOrder.wholesalerAccountNo
                            : "--"}
                        </Typography>
                      </Grid>
                    </Grid>
                    <Grid item container spacing={1}>
                      <Grid item xs={12} sm={4}>
                        <Field
                          name="centralreplenish"
                          component={Toggle}
                          type="checkbox"
                          checked={centralreplenishtoggle}
                        />
                        <label>Participate in Central Replenishment</label>
                      </Grid>
                    </Grid>
                    <Grid item container spacing={1}>
                      <Grid item xs={12} sm={4}>
                        <Grid style={{ display: "flex" }}>
                          <Typography variant="subtitle2">
                            Replenish Thershold Percent&nbsp;
                          </Typography>
                          <Grid
                            item
                            xs={12}
                            sm={2}
                            style={{ marginTop: "-5px" }}
                          >
                            <Field
                              name="c3drugs"
                              id="c3drugs"
                              type="number"
                              className={globalClasses.formControl}
                              placeholder="0"
                              disabled={true}
                              value={
                                phClientOrder
                                  ? phClientOrder.replenishThresholdPercent
                                  : "----"
                              }
                            />
                          </Grid>
                          <Typography variant="body1">&nbsp;%</Typography>
                        </Grid>
                      </Grid>

                      <Grid item xs={12} sm={4}>
                        <Field
                          name="ceowned"
                          component={Toggle}
                          type="checkbox"
                          checked={ceOwnedtoggle}
                        />
                        <label>Turn Off Covered Entity Owned Inventory</label>
                      </Grid>
                    </Grid>
                    <Grid item container spacing={1}>
                      <Grid item xs={12} sm={4}>
                        <Field
                          name="central"
                          component={Toggle}
                          type="checkbox"
                          checked={centraltoggle}
                        />
                        <label>Central Replenishment</label>
                      </Grid>
                    </Grid>
                  </Form>
                </>
              );
            }}
          </Formik>
        </Collapse>
      </Paper>
    </div>
  );
};

export default ClientOrderRep;
