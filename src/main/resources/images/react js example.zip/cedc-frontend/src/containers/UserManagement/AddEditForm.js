import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  FormControlLabel,
  Grid,
  Button,
  FormLabel,
  Tooltip,
} from "@material-ui/core";
import _isEqual from "lodash/isEqual";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import { Formik, Form, Field } from "formik";
import AddEdituserPermission from "./AddEdituserPermission";
import {
  getUsermanagementAddFieldValue,
  POLLING_COUNT,
  REGEX,
  LABELS
} from "../../utils/constants";
import AutoComplete from "../../components/common/AutoComplete";
import {
  addUser,
  editUser,
  getAddUserMessageUUIDResponse,
  getprivilegesByRole,
  getUserList,
} from "../../context/actions/Usermanagement";
import LoaderUI from "../../components/common/Loader/Loader";
import { yourSplitString } from "../../utils/common";
import {
  validateContactNumber,
  getRolePriority,
  getCeObject,
  getLabelValue,
} from "./helper";

import { PrimaryContactdetails } from "../../context/actions/CoCebasicdetails";
import { ALLOWED_CREATING_USERS_MAP } from "./constant";
import { COContext } from "../ProgramDetails/COContext";
import { useContext } from "react";
import { getCoveredEntity, getUserSession } from "../../utils/helper";
import { useUserManagementStyles } from "./style";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import classNames from "classnames";
import BasicPopup from "../../components/Popup/BasicPopup";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import moment from "moment";
import Toggle from "../../components/common/Toggle";

const EMAIL_RE = /\S+@\S+\.[A-Za-z]{1}\S+/;

const AddEditForm = forwardRef(({
  openPopup,
  actiontitle,
  title,
  rowData = {},
  addUserState = false,
  havingPopup = false,
  permissionObj,
  internalteam,
  submitEmail,
  submitDisplayname,
  setOpenPopup,
  updateActionTitle,
  fetchUserPayload,
  setAddUserPopupOfCo,
  fromCO,
  onUserAdd,
}, ref) => {
  useImperativeHandle(ref, () => ({
    clearForm() {
      setInitialFValues({})
    }
  }))
  const { messageUuid = {} } = useContext(COContext) || {};
  const userSession = getUserSession();
  const { ceList: globalCeList = [] } =
    useSelector((state) => state.coveredEntities) || {};
  const currentCoveredEntity = !_isEmpty(messageUuid)
    ? getCoveredEntity({
      ceId: messageUuid.ceid,
      ceList: globalCeList,
    })[0] || {}
    : {};
  const classes = useUserManagementStyles();
  const globalClasses = useGlobalStyles();

  const dispatch = useDispatch();
  const formRef = useRef();
  const initialPrivileges = rowData ? rowData.userPrivilege : [];
  const rowProps = { ...rowData };
  if (!_isEmpty(currentCoveredEntity))
    rowProps.ceCode = currentCoveredEntity.ceCode;
  const [initialFValues, setInitialFValues] = useState(
    getUsermanagementAddFieldValue({
      rowProps,
      user: userSession,
    })
  );
  const [values, setValues] = useState(initialFValues);
  const [defaultUserPrivileges, setDefaultUserPrivileges] =
    useState(initialPrivileges);
  const [permissions, setPermission] = useState(initialPrivileges);
  const [LockedAccount, setLockedAccount] = useState(
    rowData && rowData.isLockedOut ? rowData.isLockedOut : false
  );
  const [email, setEmail] = useState(rowData ? rowData.emailID : "");
  const [fn, setFn] = useState(rowData ? rowData.firstName : "");
  const [ln, setLn] = useState(rowData ? rowData.lastName : "");
  const [phonenumber, setphonenumber] = useState(
    rowData ? rowData.contactNumber : ""
  );
  const [selectUser, setSelectUser] = useState(
    rowData && rowData.isInternalUser === true
      ? "internal"
      : rowData && rowData.isInternalUser === false
        ? "external"
        : "external"
  );
  const [active, setActive] = useState(
    rowData && rowData.userStatusID === 1
      ? true
      : rowData && rowData.userStatusID === 2
        ? false
        : true
  );
  const loader = useSelector((state) => state.usermanagement.loading);
  const coveredentity =
    useSelector((state) => state.coveredEntities) || [];

  const [cEList, secEList] = useState(coveredentity);
  const [isUnique, setIsUnique] = useState({
    displayname: rowData && rowData.userName ? true : false,
    email: rowData && rowData.emailID ? true : false,
  });
  const [userTitle, setUserTitle] = useState(rowData ? rowData.title : "");
  const customized = useRef(rowData ? rowData.customized || false : false);

  const [view, setView] = useState(title === "View User");

  useEffect(() => {
    setInitialFValues(
      getUsermanagementAddFieldValue({
        rowProps: !_isEmpty(rowData) ? rowData : {},
        user: userSession,
        hrsaId: !_isEmpty(currentCoveredEntity)
          ? currentCoveredEntity.ceCode
          : "",
      })
    );
    setEmail(_isEmpty(rowData) ? "" : rowData.emailID);
    setFn(_isEmpty(rowData) ? "" : rowData.firstName);
    setLn(_isEmpty(rowData) ? "" : rowData.lastName);
    setphonenumber(_isEmpty(rowData) ? "" : rowData.contactNumber);
    setUserTitle(_isEmpty(rowData) ? "" : rowData.title);
    if (!_isEmpty(rowData)) {
      setDefaultUserPrivileges(rowData.userPrivilege);
      setPermission(rowData.userPrivilege);
    } else {
      setDefaultUserPrivileges([]);
      setPermission([]);
    }
  }, [rowData]);

  const userRoles = useSelector((state) => state.getUserrole.records) || [];

  const updatedRoles = (() => {
    const allowedUsersArr =
      ALLOWED_CREATING_USERS_MAP[userSession.userRole.role.roleId];
    const roles = userRoles.filter((role) =>
      allowedUsersArr.includes(role.roleID)
    );
    const getParticularRoles = ({ isExternal }) => {
      return roles.filter((role) => role.externalRole === isExternal);
    };
    if (selectUser === "internal") {
      return getParticularRoles({ isExternal: false });
    } else {
      return getParticularRoles({ isExternal: true });
    }
  })();

  useEffect(() => {
    if (rowData && rowData.roleID) {
      dispatch(
        getprivilegesByRole({ roleid: rowData.roleID }, (res) => {
          setDefaultUserPrivileges([...res.data]);
        })
      );
    }
    secEList(coveredentity.ceList);
  }, []);

  const handleChange = (e, type) => {
    if (type === "email") {
      setValues(e.target.value);
      setEmail(e.target.value);
      // Calling a function for Email Validation
      if (EMAIL_RE.test(e.target.value)) {
        submitEmail({ email: e.target.value }, (result) => {
          if (result === true) {
            var splitted = e.target.value.split("@", 3);
            setValues(splitted[0]);
          }
          setIsUnique((prev) => ({ ...prev, email: result }));
        });
      } else setIsUnique((prev) => ({ ...prev, email: true }));
    }
    if (type === "fn") {
      setValues(e.target.value);
      setFn(e.target.value);
    }
    if (type === "ln") {
      setValues(e.target.value);
      setLn(e.target.value);
    }
    if (type === "displayname") {
      var k = e.target.value.trim();
      setValues(k);
      k &&
        k.length > 0 &&
        submitDisplayname({ userName: k }, (result) => {
          setIsUnique((prev) => ({ ...prev, displayname: result }));
        });
    }
  };

  const formValidate = (values) => {
    let error = {};
    if (!view) {
      if (email === "") {
        error.em = "Please enter the Email ID";
      } else if (email && email.length > 0 && !EMAIL_RE.test(email)) {
        error.em = "Please enter valid Email Id";
      }
      if (
        addUserState !== true &&
        values.ci === "" &&
        selectUser !== "internal"
      ) {
        error.ci = "Please select the Covered Entity";
      }
      if (values.role === "") {
        error.role = "Please select the Role Type";
      }
      if (email !== "" && !isUnique.email) {
        error.em = "Email ID already exists";
      }
      if (values.fn === "" || values.fn.trim() === "") {
        error.fn = "Please enter the First Name";
      }
      if (values.ln === "" || values.ln.trim() === "") {
        error.ln = "Please enter the Last Name";
      }
    }
    return error;
  };
  const resetForm = () => {
    setFn("")
    setLn("")
    setEmail("");
    setphonenumber("");
    setLockedAccount("");
    setUserTitle("");
  };
  const getDependentPermission = ({
    perm,
    value,
    moduleName,
    retainPrevStates = false,
  } = {}) => {
    if (moduleName === "read")
      return {
        ...perm,
        readOnlyFlag: retainPrevStates ? perm.readOnlyFlag : value,
        readWriteFlag: !value ? false : perm.readWriteFlag,
        terminateFlag: !value ? false : perm.readWriteFlag,
      };
    if (moduleName === "write")
      return {
        ...perm,
        readWriteFlag: retainPrevStates ? perm.readOnlyFlag : value,
        readOnlyFlag: value ? true : perm.readOnlyFlag,
      };
    if (moduleName === "terminate") return { ...perm, terminateFlag: value };
  };

  const handleClick = (perRow, value, moduleName) => {
    const newPermissions = permissions.map((perm) => {
      if (
        (perm.resourceID === 8 || perm.resourceID === 6) &&
        perRow.resourceID === 15
      ) {
        return getDependentPermission({
          value,
          moduleName,
          perm,
          retainPrevStates: value,
        });
      } else if (perm.rolePrivilegeID === perRow.rolePrivilegeID) {
        return getDependentPermission({ value, moduleName, perm });
      } else return perm;
    });
    customized.current = !_isEqual(defaultUserPrivileges, newPermissions);
    setPermission(newPermissions);
  };

  const handlePolling = async ({ messageUUid, currentCount }) => {
    const count = currentCount;
    const res = await dispatch(
      getAddUserMessageUUIDResponse(messageUUid, count)
    );
    if (res && res.statusCode === 200) {
      if (fromCO) {
        setAddUserPopupOfCo && setAddUserPopupOfCo(false);
      } else {
        dispatch(getUserList(fetchUserPayload));
      }
      setOpenPopup(false);
      onUserAdd && onUserAdd(res);
    } else if (res && res.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    }
  };

  const handleSubmit = async (values) => {
    if (view) {
      setView(false);
      updateActionTitle();
      return;
    }
    let userCoveredEntities = [
      {
        ceid:
          selectUser === "internal"
            ? "-1"
            : addUserState == true
              ? fromCO
                ? messageUuid !== null && messageUuid.ceid !== null
                  ? messageUuid.ceid
                  : 2
                : []
              : values.ci,
        active: true,
        userCoveredEntityId: 0,
      },
    ];
    const entity = cEList.find((ce) => ce.ceID === values.ci);

    let addUserJson = {
      customized: customized.current,
      createdDate: moment(new Date()).format("MM/DD/YYYY HH:mm:ss"),
      entityName:
        (entity && entity.ceName) || (rowData && rowData.entityName) || "",
      lastLoginDate: "",
      emailID: email,
      firstName: fn.trim(),
      lastName: ln.trim(),
      roleID: Number(values.role),
      sendInvoiceNotifications: values.sn ? "Y" : "N",
      title: userTitle && userTitle.trim(),
      internalUser: selectUser === "internal",
      internalTeamID: selectUser === "internal" ? values.it : 0,
      userName: email,
      userPrivilege: permissions,
      isPrimaryContact: values.primaryContact,
      contactNumber: phonenumber,
      userID: 0,
      userCoveredEntities: userCoveredEntities,
      userRole: {
        active: true,
        deleted: true,
        role: {
          active: true,
          externalRole: true,
          roleID: values.role,
          roleName: "",
          thisCustomRole: true,
        },
        roleEndDate: "",
        roleStartDate: "",
        userRoleId: 0,
      },
      isLockedOut: LockedAccount,
      userType: (rowData && rowData.userType) || "",
      userStatusID: active ? 1 : 2,
      id340b: values.ID340B,
      ...(_isEmpty(rowData) ? { createdById: userSession.userId } : {}),
    };
    if (_isEmpty(rowData)) {
      dispatch(
        addUser(addUserJson, (result) => {
          if (result.statusCode === 200 && result.data !== null) {
            handlePolling({
              messageUUid: result.data,
              currentCount: POLLING_COUNT,
            });
          }
        })
      );
    } else {
      addUserJson.userID = rowData.userID;
      dispatch(
        editUser(addUserJson, (response) => {
          setOpenPopup(false);
          if (response == 200) {
            onUserAdd && onUserAdd(response);
            dispatch(
              PrimaryContactdetails(
                messageUuid !== undefined &&
                  messageUuid !== null &&
                  currentCoveredEntity.ceName
                  ? messageUuid.ceid
                  : currentCoveredEntity.ceName == undefined
                    ? messageUuid.ceid
                    : ""
              )
            );
          }
        })
      );
      setAddUserPopupOfCo && setAddUserPopupOfCo(false);
      setOpenPopup(false);
    }
  };

  const checkInputPhoneNumber = (e) => {
    let value = e.target.value;
    const regEx = /^[0-9]{1,10}$/g;
    if (value && !regEx.test(e.target.value)) return;
    setphonenumber(value);
  };

  const handleChangeSelectUser = (e, formik) => {
    setSelectUser(e.target.value);
    formik.setFieldValue("role", "");
  };

  const handleChangeTitle = (e) => {
    let value = e.target.value;
    const regEx = /^\s+|\s{2,}$/g;
    if (value && regEx.test(e.target.value)) return;
    setUserTitle(value);
  };

  const isHigherInRole = getRolePriority(
    userRoles,
    rowData,
    userSession.userRole.role
  );

  const getCoveredEntityName = (ceId) => {
    const { ceName } = getCeObject(cEList, ceId) || {};
    return (
      <div className={classes.coveredEntityNameWrapper}>
        <Tooltip title={ceName}>
          <div className={classes.coveredEntityName}>{ceName}</div>
        </Tooltip>
      </div>
    );
  };
  const getFormBody = (formik) => (
    <Grid container spacing={2}>
      {loader && <LoaderUI />}
      <Grid item xs={12}>
        {addUserState === false ? (
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <FormLabel>{view ? "User" : "Select User"}</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {rowData && rowData.isInternalUser ? "Internal" : "External"}
                </BasicTypography>
              ) : (
                <div className={classes.radioContainer}>
                  <div className={classes.radioAndLabelContainer}>
                    <Field
                      id="external"
                      value="external"
                      name="selectUser"
                      type="radio"
                      onChange={(e) => {
                        if (rowData) {
                          const covEntity = cEList[0];
                          formik.setFieldValue("ID340B", covEntity.ceCode);
                          formik.setFieldValue("ci", covEntity.ceID);
                        }
                        handleChangeSelectUser(e, formik);
                      }}
                      checked={selectUser === "external" ? true : false}
                    />
                    <FormLabel
                      htmlFor="external"
                      className={globalClasses.radioLabel}
                    >
                      External
                    </FormLabel>
                  </div>
                  <div className={classes.radioAndLabelContainer}>
                    <Field
                      id="internal"
                      value="internal"
                      name="selectUser"
                      type="radio"
                      className={classNames(
                        classes.radioInput,
                        globalClasses.radioLabel
                      )}
                      onChange={(e) => handleChangeSelectUser(e, formik)}
                      checked={selectUser === "internal" ? true : false}
                      disabled={
                        (userSession && !userSession.isInternalUser) ||
                        (rowData && !rowData.isInternalUser)
                      }
                    />
                    <FormLabel
                      htmlFor="internal"
                      className={globalClasses.radioLabel}
                    >
                      Internal
                    </FormLabel>
                  </div>
                </div>
              )}
            </Grid>

            {selectUser === "internal" ? (
              <Grid item xs={12} sm={4}>
                <FormLabel>Internal Team</FormLabel>
                {view ? (
                  internalteam &&
                  internalteam.length > 0 &&
                  internalteam.map((keysItem) => {
                    return (
                      formik.values.it === keysItem.internalTeamId && (
                        <BasicTypography variant="subtitle2">
                          {keysItem.teamName}
                        </BasicTypography>
                      )
                    );
                  })
                ) : (
                  <Field as="select" name="it">
                    {({ field }) => (
                      <AutoComplete
                        {...field}
                        disableCloseOnSelect={false}
                        options={
                          _isArray(internalteam) ? internalteam : []
                        }
                        value={
                          _isArray(internalteam) &&
                          internalteam.find((e) => e.internalTeamId === values.it)
                        }
                        inputPlaceholder="Select Internal Team"
                        getOptionLabel={(option) =>
                          option.teamName || ""
                        }
                        onChange={(e, value) => {
                          formik.setFieldValue("it", value ? value.internalTeamId : "");
                        }}
                        renderOption={(option, _other) => {
                          return (
                            <BasicTypography variant="subtitle2">
                              {option.teamName}
                            </BasicTypography>
                          );
                        }}
                        multiple={false}
                      />
                    )}
                  </Field>

                )}
              </Grid>
            ) : (
              <Grid item xs={12} sm={4}></Grid>
            )}

            <Grid item xs={12} sm={4}>
              <FormControlLabel
                control={
                  <Field
                    label="Active"
                    component={Toggle}
                    type="checkbox"
                    onChange={(e) => setActive(e.target.checked)}
                    checked={active}
                    disabled={view}
                  />
                }
                label="Active"
              />
            </Grid>
            {selectUser !== "internal" && (
              <>
                <Grid item xs={12} sm={4}>
                  <FormLabel required>Covered Entity</FormLabel>
                  {view ? (
                    cEList &&
                    cEList.length > 0 &&
                    cEList.map((keysItem) => {
                      return (
                        formik.values.ci === keysItem.ceID && (
                          <BasicTypography variant="subtitle2">
                            {keysItem.ceName}
                          </BasicTypography>
                        )
                      );
                    })
                  ) : formik.values.ci &&
                    formik.initialValues.ci === formik.values.ci ? (
                    getCoveredEntityName(formik.values.ci)
                  ) : (
                    <Field
                      as="select"
                      name="ci"
                      className={globalClasses.formControl}
                      disabled={
                        title == "Edit User" ||
                        title == "View User" ||
                        cEList.length <= 1
                      }
                      onChange={(e) => {
                        formik.setFieldValue("ci", e.target.value);
                        cEList.map((item) => {
                          if (item.ceID == e.target.value) {
                            formik.setFieldValue("ID340B", item.ceCode);
                          }
                        });
                      }}
                    >
                      <option value={""} disabled>
                        Select Covered Entity
                      </option>
                      {cEList &&
                        cEList.length > 0 &&
                        cEList.map((keysItem, indexVal) => {
                          return (
                            <option key={indexVal} value={keysItem.ceID}>
                              {keysItem.ceName}
                            </option>
                          );
                        })}
                    </Field>
                  )}
                  {selectUser != "internal" &&
                    formik.touched.ci &&
                    formik.errors.ci && (
                      <BasicTypography color="error" variant="caption">
                        {formik.errors.ci}
                      </BasicTypography>
                    )}
                </Grid>

                <Grid item xs={12} sm={4}>
                  <FormLabel>HRSA ID</FormLabel>
                  {view ? (
                    <BasicTypography variant="subtitle2">
                      {formik.values.ID340B ? formik.values.ID340B : "---"}
                    </BasicTypography>
                  ) : (
                    <Field
                      name="ID340B"
                      id="ID340B"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter HRSA ID"
                      disabled
                    />
                  )}
                </Grid>
              </>
            )}

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>First Name</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {yourSplitString(formik.values.fn.length, formik.values.fn)}
                  {getLabelValue(formik.values.fn)}
                </BasicTypography>
              ) : (
                <Field
                  name="fn"
                  id="fn"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter First Name"
                  maxLength={50}
                  value={fn}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                    formik.setFieldValue("fn", value);
                    handleChange(e, "fn");
                  }}
                />
              )}
              {formik.touched.fn && formik.errors.fn && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.fn}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>Last Name</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {getLabelValue(formik.values.ln)}
                </BasicTypography>
              ) : (
                <Field
                  name="ln"
                  id="ln"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter Last Name"
                  maxLength={50}
                  value={ln}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                    formik.setFieldValue("ln", e.target.value);
                    handleChange(e, "ln");
                  }}
                />
              )}
              {formik.touched.ln && formik.errors.ln && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.ln}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>Email ID</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {getLabelValue(email)}
                </BasicTypography>
              ) : (
                <Field
                  name="em"
                  id="em"
                  value={email}
                  type="email"
                  className={globalClasses.formControl}
                  placeholder="Enter Email ID"
                  onChange={(e) => {
                    handleChange(e, "email");
                  }}
                  maxLength={50}
                  disabled={rowData && rowData.emailID}
                />
              )}
              {formik.touched.em && formik.errors.em && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.em}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>User Name</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {getLabelValue(email)}
                </BasicTypography>
              ) : (
                <Field
                  name="dn"
                  id="dn"
                  type="text"
                  value={email}
                  className={globalClasses.formControl}
                  placeholder="Enter User Name"
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                    formik.setFieldValue("dn", value);
                    handleChange(e, "displayname");
                  }}
                  disabled={true}
                  maxlength={50}
                />
              )}
              {formik.touched.dn && formik.errors.dn && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.dn}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel>Primary Phone Number</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {formik.values.contactNumber
                    ? formik.values.contactNumber
                    : "---"}
                </BasicTypography>
              ) : (
                <>
                  <Field
                    name="contactNumber"
                    id="contactNumber"
                    type="text"
                    validate={() => validateContactNumber(phonenumber)}
                    className={globalClasses.formControl}
                    placeholder="Enter Phone Number"
                    onChange={(e) => checkInputPhoneNumber(e)}
                    value={phonenumber}
                  />
                </>
              )}
              {formik.touched.contactNumber && formik.errors.contactNumber && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.contactNumber}
                </BasicTypography>
              )}
            </Grid>
            <Grid item xs={12} sm={4}>
              <FormLabel>Title</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {formik.values.title
                    ? getLabelValue(formik.values.title)
                    : "---"}
                </BasicTypography>
              ) : (
                <Field
                  name="title"
                  id="title"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter Title"
                  maxlength={50}
                  onChange={(e) => handleChangeTitle(e)}
                  value={userTitle}
                />
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>Role Type</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {rowData && rowData.userType}
                </BasicTypography>
              ) : (
                <>
                  {
                    <Field as="select" name="role">
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          disableCloseOnSelect={false}
                          options={
                            _isArray(updatedRoles) ? updatedRoles : []
                          }
                          value={
                            _isArray(updatedRoles) &&
                            updatedRoles.find((e) => e.roleID == formik.values.role)||""
                          }
                          inputPlaceholder=" Select Role Type"
                          onChange={(e, value) => {
                            dispatch(
                              getprivilegesByRole(
                                { roleid: value ? value.roleID : 0 },
                                (res) => {
                                  setPermission([...res.data]);
                                  setDefaultUserPrivileges([...res.data]);
                                }
                              )
                            );
                            formik.setFieldValue("role", value ? value.roleID : "");
                          }}
                          getOptionLabel={(option) =>
                            option.roleName || ""
                          }
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.roleName}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                        />
                      )}
                    </Field>
                  }
                  {formik.touched.role && formik.errors.role && (
                    <BasicTypography color="error" variant="caption">
                      {formik.errors.role}
                    </BasicTypography>
                  )}
                </>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormControlLabel
                control={
                  <Field
                    label="Send Invoice Notifications"
                    name="sn"
                    component={Toggle}
                    onChange={(e) =>
                      formik.setFieldValue("sn", e.target.checked)
                    }
                    checked={formik.values.sn}
                    disabled={view}
                  />
                }
                label="Send Invoice Notifications"
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormControlLabel
                control={
                  <Field
                    label="Primary Contact"
                    name="primaryContact"
                    component={Toggle}
                    type="checkbox"
                    onChange={(e) =>
                      formik.setFieldValue("primaryContact", e.target.checked)
                    }
                    disabled={view}
                    checked={formik.values.primaryContact}
                  />
                }
                label="Primary Contact"
              />
            </Grid>

            {rowData && (
              <Grid item xs={4} sm={4}>
                <FormControlLabel
                  control={
                    <Field
                      label="Lock the Account"
                      name="sn"
                      component={Toggle}
                      onChange={(e) => setLockedAccount(e.target.checked)}
                      checked={LockedAccount}
                      disabled={view}
                    />
                  }
                  label="Lock the Account"
                />
              </Grid>
            )}
          </Grid>
        ) : (
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <FormLabel>{view ? "User" : "Select User"}</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {rowData && rowData.isInternalUser ? "Internal" : "External"}
                </BasicTypography>
              ) : (
                <div className={classes.radioContainer}>
                  <div className={classes.radioAndLabelContainer}>
                    <Field
                      id="external"
                      value="external"
                      name="selectUser"
                      type="radio"
                      onChange={(e) => handleChangeSelectUser(e, formik)}
                      checked={selectUser === "external" ? true : false}
                    />
                    <FormLabel
                      htmlFor="external"
                      className={globalClasses.radioLabel}
                    >
                      External
                    </FormLabel>
                  </div>
                </div>
              )}
            </Grid>

            {selectUser === "internal" ? (
              <Grid item xs={12} sm={4}>
                <FormLabel>Internal Team</FormLabel>
                {view ? (
                  internalteam &&
                  internalteam.length > 0 &&
                  internalteam.map((keysItem) => {
                    return (
                      formik.values.it === keysItem.internalTeamId && (
                        <BasicTypography variant="subtitle2">
                          {keysItem.teamName}
                        </BasicTypography>
                      )
                    );
                  })
                ) : (
                  <Field as="select" name="it">
                    {(props) => {
                      const { field } = props;
                      return (
                        <select
                          {...field}
                          className={globalClasses.formControl}
                        >
                          <option value={""}>Select Internal Team</option>
                          {internalteam &&
                            internalteam.length > 0 &&
                            internalteam.map((keysItem) => {
                              return (
                                <option
                                  key={keysItem.internalTeamId}
                                  value={keysItem.internalTeamId}
                                >
                                  {keysItem.teamName}
                                </option>
                              );
                            })}
                        </select>
                      );
                    }}
                  </Field>
                )}
              </Grid>
            ) : (
              <Grid item xs={12} sm={4}></Grid>
            )}

            <Grid item xs={12} sm={4}>
              <FormControlLabel
                control={
                  <Field
                    label="Active"
                    component={Toggle}
                    type="checkbox"
                    onChange={(e) => setActive(e.target.checked)}
                    checked={active}
                    disabled={view}
                  />
                }
                label="Active"
              />
            </Grid>
            {selectUser !== "internal" && (
              <>
                <Grid item xs={4} sm={4}>
                  <FormLabel required>Covered Entity</FormLabel>
                  <Field
                    as="select"
                    name="ci"
                    multiple={true}
                    className={globalClasses.formControl}
                    disabled={cEList.length <= 1}
                  >
                    {(props) => {
                      const { field } = props;
                      return (
                        <select
                          {...field}
                          className={globalClasses.formControl}
                          disabled={true}
                        >
                          <option
                            value={
                              messageUuid !== undefined &&
                                messageUuid !== null &&
                                currentCoveredEntity.ceName
                                ? messageUuid.ceid
                                : currentCoveredEntity.ceName == undefined
                                  ? messageUuid.ceid
                                  : ""
                            }
                            selected
                          >
                            {" "}
                            {messageUuid !== undefined &&
                              messageUuid !== null &&
                              currentCoveredEntity.ceName
                              ? currentCoveredEntity.ceName
                              : currentCoveredEntity.ceName == undefined
                                ? currentCoveredEntity.coveredEntityName
                                : "----"}
                          </option>
                        </select>
                      );
                    }}
                  </Field>
                  {formik.touched.ci && formik.errors.ci && (
                    <BasicTypography color="error" variant="caption">
                      {formik.errors.ci}
                    </BasicTypography>
                  )}
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormLabel>HRSA ID</FormLabel>
                  {view ? (
                    <BasicTypography variant="subtitle2">
                      {formik.values.ID340B ? formik.values.ID340B : "---"}
                    </BasicTypography>
                  ) : (
                    <Field
                      name="ID340B"
                      id="ID340B"
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter HRSA ID"
                      disabled
                    />
                  )}
                </Grid>
              </>
            )}

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>First Name</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {yourSplitString(formik.values.fn.length, formik.values.fn)}
                </BasicTypography>
              ) : (
                <Field
                  name="fn"
                  id="fn"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter First Name"
                  maxLength={50}
                  value={fn}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                    formik.setFieldValue("fn", value);
                    handleChange(e, "fn");
                  }}
                />
              )}
              {formik.touched.fn && formik.errors.fn && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.fn}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>Last Name</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {getLabelValue(formik.values.ln)}
                </BasicTypography>
              ) : (
                <Field
                  name="ln"
                  id="ln"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter Last Name"
                  maxLength={50}
                  value={ln}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                    formik.setFieldValue("ln", value);
                    handleChange(e, "ln");
                  }}
                />
              )}
              {formik.touched.ln && formik.errors.ln && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.ln}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>Email ID</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">{email}</BasicTypography>
              ) : (
                <Field
                  name="em"
                  id="em"
                  value={email}
                  type="email"
                  className={globalClasses.formControl}
                  placeholder="Enter Email ID"
                  onChange={(e) => {
                    formik.errors.em = "";
                    handleChange(e, "email");
                  }}
                  maxLength={50}
                  disabled={rowData && rowData.emailID}
                />
              )}
              {formik.touched.em && formik.errors.em ? (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.em}
                </BasicTypography>
              ) : (
                formik.touched.em &&
                email &&
                !EMAIL_RE.test(email) && (
                  <BasicTypography color="error" variant="caption">
                    Please enter valid Email Id
                  </BasicTypography>
                )
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>User Name</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">{email}</BasicTypography>
              ) : (
                <Field
                  name="dn"
                  id="dn"
                  type="text"
                  value={email}
                  className={globalClasses.formControl}
                  placeholder="Enter User Name"
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value && !REGEX.alphabetsAndHypen.test(value)) return;
                    formik.setFieldValue("dn", value);
                    handleChange(e, "displayname");
                  }}
                  disabled={true}
                  maxlength={50}
                />
              )}
              {formik.touched.dn && formik.errors.dn && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.dn}
                </BasicTypography>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel>Primary Phone Number</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {formik.values.contactNumber
                    ? formik.values.contactNumber
                    : "---"}
                </BasicTypography>
              ) : (
                <>
                  <Field
                    name="contactNumber"
                    id="contactNumber"
                    type="text"
                    validate={() => validateContactNumber(phonenumber)}
                    className={globalClasses.formControl}
                    placeholder="Enter Phone Number"
                    maxLength="11"
                    onChange={(e) => checkInputPhoneNumber(e)}
                    value={phonenumber}
                  />
                </>
              )}
              {formik.touched.contactNumber && formik.errors.contactNumber && (
                <BasicTypography color="error" variant="caption">
                  {formik.errors.contactNumber}
                </BasicTypography>
              )}
            </Grid>
            <Grid item xs={12} sm={4}>
              <FormLabel>Title</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {formik.values.title ? formik.values.title : "---"}
                </BasicTypography>
              ) : (
                <Field
                  name="title"
                  id="title"
                  type="text"
                  className={globalClasses.formControl}
                  placeholder="Enter Title"
                  maxlength={50}
                  onChange={(e) => handleChangeTitle(e)}
                  value={userTitle}
                />
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormLabel required={!view}>Role Type</FormLabel>
              {view ? (
                <BasicTypography variant="subtitle2">
                  {rowData && rowData.userType}
                </BasicTypography>
              ) : (
                <>
                  <Field
                    as="select"
                    name="role"
                    className={globalClasses.formControl}
                    onChange={(e) => {
                      dispatch(
                        getprivilegesByRole(
                          { roleid: e.target.value },
                          (res) => {
                            setPermission([...res.data]);
                            setDefaultUserPrivileges([...res.data]);
                          }
                        )
                      );
                      formik.setFieldValue("role", e.target.value);
                    }}
                  >
                    <option value={""} disabled>
                      Select Role Type
                    </option>
                    {updatedRoles &&
                      updatedRoles.length > 0 &&
                      updatedRoles.map((keysItem, indexVal) => {
                        return (
                          <option key={indexVal} value={keysItem.roleID}>
                            {keysItem.roleName}
                          </option>
                        );
                      })}
                  </Field>
                  {formik.touched.role && formik.errors.role && (
                    <BasicTypography color="error" variant="caption">
                      {formik.errors.role}
                    </BasicTypography>
                  )}
                </>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormControlLabel
                control={
                  <Field
                    label="Send Invoice Notification"
                    name="sn"
                    component={Toggle}
                    onChange={(e) =>
                      formik.setFieldValue("sn", e.target.checked)
                    }
                    checked={formik.values.sn}
                    disabled={view}
                  />
                }
                label="Send Invoice Notification"
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormControlLabel
                control={
                  <Field
                    label="Primary Contact"
                    name="primaryContact"
                    component={Toggle}
                    type="checkbox"
                    onChange={(e) =>
                      formik.setFieldValue("primaryContact", e.target.checked)
                    }
                    disabled={view}
                    checked={formik.values.primaryContact}
                  />
                }
                label="Primary Contact"
              />
            </Grid>

            {rowData && (
              <Grid item xs={4} sm={4}>
                <FormControlLabel
                  control={
                    <Field
                      label="Lock the Account"
                      name="sn"
                      component={Toggle}
                      onChange={(e) => setLockedAccount(e.target.checked)}
                      checked={LockedAccount}
                      disabled={view}
                    />
                  }
                  label="Lock the Account"
                />
              </Grid>
            )}
          </Grid>
        )}
        {formik.values.role && (
          <Grid container spacing={2}>
            <Grid item md={12}>
              <AddEdituserPermission
                handleClick={handleClick}
                role={formik.values.role}
                permissions={permissions}
                formik={formik}
                values={values}
                sendValue={view}
                defaultUserPrivileges={defaultUserPrivileges}
                user={rowData}
              />
            </Grid>
          </Grid>
        )}
      </Grid>
    </Grid>
  );
  if (havingPopup) {
    return (
      <BasicPopup
        show={openPopup}
        title={actiontitle}
        disableFooter={true}
        handleClose={() => setOpenPopup(false)}
        dialogProps={{
          maxWidth: "lg",
        }}
      >
        <Formik
          enableReinitialize={true}
          initialValues={initialFValues}
          onSubmit={handleSubmit}
          validate={formValidate}
          innerRef={formRef}
        >
          {(formik) => {
            return (
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Form>
                    <Grid container spacing={2}>
                      <Grid item md={12}>
                        {getFormBody(formik)}
                      </Grid>
                      <Grid item md={12}>
                        <Grid
                          container
                          spacing={2}
                          alignItems="center"
                          justifyContent="flex-end"
                        >
                          <Grid item>
                            <Button
                              type="submit"
                              size="small"
                              title={
                                permissionObj !== null &&
                                  !permissionObj.readWriteFlag
                                  ? "You don't have permission."
                                  : !permissionObj.readOnlyFlag
                                    ? "You don't have permission."
                                    : ""
                              }
                              variant="contained"
                              color="primary"
                              className={globalClasses.primaryBtn}
                              disabled={
                                permissionObj !== null &&
                                  !permissionObj.readWriteFlag
                                  ? true
                                  : !permissionObj.readOnlyFlag
                                    ? true
                                    : loader || (view && !isHigherInRole)
                              }
                            >
                              {view ? "Edit" : "Save"}
                            </Button>
                          </Grid>
                          <Grid item>
                            <Button
                              type="reset"
                              size="small"
                              color="default"
                              onClick={() => {
                                setOpenPopup(false);
                              }}
                              className={globalClasses.secondaryBtn}
                            >
                              Cancel
                            </Button>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Form>
                </Grid>
              </Grid>
            );
          }}
        </Formik>
      </BasicPopup>
    );
  }
  return (
    <Formik
      enableReinitialize={true}
      initialValues={initialFValues}
      onSubmit={handleSubmit}
      validate={formValidate}
    >
      {(formik) => {
        return (
          <div
            className={classNames(
              globalClasses.cardPrimary,
              classes.addEditFormInPopUp
            )}
          >
            <Grid container spacing={2}>
              <Grid item md={12}>
                <Form>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      {getFormBody(formik)}
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2} justifyContent="flex-end">
                        <Grid item>
                          <Button
                            type="submit"
                            size="small"
                            title={
                              permissionObj !== null &&
                                !permissionObj.readWriteFlag
                                ? "You don't have permission."
                                : !permissionObj.readOnlyFlag
                                  ? "You don't have permission."
                                  : ""
                            }
                            variant="contained"
                            color="primary"
                            className={globalClasses.primaryBtn}
                            disabled={
                              permissionObj !== null &&
                                !permissionObj.readWriteFlag
                                ? true
                                : !permissionObj.readOnlyFlag
                                  ? true
                                  : loader || (view && !isHigherInRole)
                            }
                          >
                            {view ? "Edit" : "Save"}
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            size="small"
                            color="default"
                            onClick={() => {
                              setOpenPopup(false);
                              setAddUserPopupOfCo && setAddUserPopupOfCo(false);
                            }}
                            className={globalClasses.secondaryBtn}
                          >
                            Cancel
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            type="reset"
                            size="small"
                            variant="outlined"
                            className={globalClasses.secondaryBtn}
                            onClick={() => {
                              resetForm();
                            }}
                          >
                            Clear
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Form>
              </Grid>
            </Grid>
          </div>
        );
      }}
    </Formik>
  );
});
export default AddEditForm;
