import React from "react";
import { useHistory } from "react-router-dom";
import { Typography } from "@material-ui/core";
import { Grid, Button } from "@material-ui/core";
import LoginImages from "./LoginImages";
import { getForgotDefaultValue } from "../../utils/constants";
import { Formik, Field, Form } from "formik";
import "./account.scss";
import { getForgotPassword } from "../../context/actions/Auth";
import { useDispatch, useSelector } from "react-redux";
import LoaderUI from "../../components/common/Loader/Loader";
import Footer from "./footer";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import classNames from "classnames";

const EMAIL_RE = /\S+@\S+\.\S+/;

const Forgotpassword = () => {
  const globalClasses = useGlobalStyles();
  const history = useHistory();
  const dispatch = useDispatch();
  const defaultValues = getForgotDefaultValue();

  const loader = useSelector((state) => state.usermanagement.loading);

  const handleSubmit = (values, { setTouched, setValues }) => {
    dispatch(
      getForgotPassword(values, (result) => {
        if (result.statusCode === 200) {
          setValues(defaultValues);
          setTouched({ em: false });
        }
      })
    );
    // history.push("/forgotpasswordquestions");
  };
  const formValidate = (values) => {
    let error = {};
    if (values.em.trim() === "") {
      error.em = "Please enter the Email ID";
    } else if (!EMAIL_RE.test(values.em)) {
      error.em = "The Email ID you entered is incorrect.";
    } else if (values.em.trim().length > 50)
      error.em = "Email should not be more than 50 characters";
    return error;
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={defaultValues}
        onSubmit={handleSubmit}
        validate={formValidate}
        onReset={() => history.push("/login")}
      >
        {(formik) => (
          <>
            {loader && <LoaderUI />}

            <Grid className="login-bg">
              <Grid className="container-fluid">
                <div className="row login-height">
                  <LoginImages />
                  <Grid className="col-12 col-lg-5 col-md-5 col-sm-12">
                    <Grid className="login-right-wrapper">
                      <Grid className="mb-3">
                        <Typography variant="h1">Forgot Password?</Typography>
                        <Typography
                          variant="h6"
                          component="h4"
                          className="mb-3"
                        >
                          Please enter the Email ID
                        </Typography>
                      </Grid>
                      <Form>
                        <Grid className="mb-3">
                          <Field
                            name="em"
                            type="text"
                            className={classNames(
                              globalClasses.formControl,
                              globalClasses.mailBackgroundIcon,
                              globalClasses.loginScreenInputFields
                            )}
                            id="exampleInputEmail1"
                            aria-describedby="emailHelp"
                            placeholder="Enter Email ID"
                            maxLength={50}
                          />
                          {formik.touched.em && formik.errors.em && (
                            <Typography color="error" variant="caption">
                              {formik.errors.em}
                            </Typography>
                          )}
                        </Grid>
                        <Grid container>
                          <Button
                            type="submit"
                            color="primary"
                            size="large"
                            variant="contained"
                            className="btn btn-primary"
                          >
                            Submit
                          </Button>
                          <Button
                            type="reset"
                            size="large"
                            variant="outlined"
                            color="default"
                            className="btn btn-secondary m-l-20"
                          >
                            cancel
                          </Button>
                        </Grid>
                      </Form>
                    </Grid>
                  </Grid>
                </div>
              </Grid>
            </Grid>
          </>
        )}
      </Formik>
      <Footer />
    </>
  );
};
export default Forgotpassword;
