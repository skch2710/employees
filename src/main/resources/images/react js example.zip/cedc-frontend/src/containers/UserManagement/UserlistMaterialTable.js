import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import AddEdituserPermission from "./AddEdituserPermission";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import TableCustomSortArrow from "../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import DatePicker from "../../components/common/DatePicker";
import AddEditForm from "./AddEditForm";
import ActiveInActiveUser from "./Popupbox/ActiveInActiveUser";
import {
  getEmailExist,
  getUsernameExist,
  getActiveDeactive,
  getUserList,
  getprivilegesByRole,
} from "../../context/actions/Usermanagement";
import { spliceTheString, getUserPreveleges } from "../../utils/common";
import moment from "moment";
import BulkUpload from "./Popupbox/BulkUpload";
import { getRolePriority } from "./helper";
import _isEqual from "lodash/isEqual";
import {
  BACKGROUND_COLOR_FOR_ROLE_NAMES,
  GLOBAL_FILTERS_MAP,
} from "./constant";
import { LABELS, pagination } from "../../utils/constants";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import {
  getTableHeaderCount,
  getUserSession,
  isEmptyGrid,
} from "../../utils/helper";
import BasicPopup from "../../components/Popup/BasicPopup";
import { useUsersListTableStyles } from "./style";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../components/common/ColumnLevelFilterInput";
import TableProgressBar from "../../components/common/TableProgressBar";
import DataNotFound from "../../components/common/DataNotFound";
import useTableIconsAndButtons from "../../components/common/TableIcons";
import Pagination from "../../components/common/Pagination";
import useUsersExport from "./useUsersExport";

const UserlistMaterialTable = ({
  sortBy,
  adduserStateFn,
  Co,
  sortorder,
  clearButton,
  searchClicked,
  searchBy,
  globalFilterValue,
  userExportData,
  coveredentity,
  userlist = {},
  page,
  onChangePagination,
  onChangeSorting,
  onChangeFilter,
  onChangeRowsperpage,
  rowsPerPage,
  getCeIds,
  defaultFilters,
  coCeid,
  fetchUserPayload,
  setrowdatauserlist,
  setaddUserState,
} = {}) => {
  const classes = useUsersListTableStyles({
    totalElements: !_isEmpty(userlist) && userlist.totalElements,
    pageSize: rowsPerPage,
    pageNumber: page,
  });
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel, exportToPdf } = useUsersExport();

  const userRoles = useSelector((state) => state.getUserrole.records) || [];
  const internalTeam =
    useSelector((state) => state.getInternalTeam.records) || [];

  const userSession = getUserSession();
  const { loading } = useSelector((state) => state.usermanagement);
  const iconsAndButtons = useTableIconsAndButtons();

  //States
  const [actiontitle, setActionTitle] = useState("");
  const [actiontitleView, setActionTitleView] = useState("");
  const [submitactiontype, setSubmitActionType] = useState("");
  const [openPopup, setOpenPopup] = useState(false);
  const [permissions, setPermission] = useState([]);
  const [activeuser, setActiveUser] = useState(false);
  const [activeType, setActiveType] = useState("");
  const [BulkUploadPopup, setBulkUploadPopup] = useState(false);
  const [activeUserTitle, setActiveUserTitle] = useState("");
  const [isActive, setIsActive] = useState("");
  const [userid, setUserId] = useState();
  const [rowdata, setRowData] = useState();
  const [enableFilters, setEnableFilters] = useState(false);
  const [openPermissionPopup, setOpenPermissionPopup] = useState(false);
  const columnFiltersRef = useRef({});
  const [editData, setEditData] = useState(null);
  const [permissionObj, setpermissionObj] = useState(null);
  const [defaultRolePermissions, setDefaultRolePermissions] = useState([]);

  useEffect(() => {
    if (editData && !openPopup) setEditData(null);
  }, [openPopup]);

  useEffect(() => {
    if (!_isEqual(defaultFilters, columnFiltersRef.current)) {
      const updatedObj = {};
      defaultFilters.forEach((eachVal) => {
        updatedObj[eachVal.column.field] = eachVal.value;
      });
      columnFiltersRef.current = { ...updatedObj };
    }
  }, [defaultFilters]);

  useEffect(() => {
    setpermissionObj(getUserPreveleges("User Management"));
  }, []);

  const roleStyles = (item) => {
    return {
      background: BACKGROUND_COLOR_FOR_ROLE_NAMES[Number(item.roleID)],
      ...([4, 7].includes(item.roleID)
        ? { color: theme.colors.primary.default }
        : {}),
    };
  };

  const submitEmail = (email, callback) => {
    if (email.email)
      dispatch(
        getEmailExist(email, (result) => {
          callback(result);
        })
      );
  };
  const submitDisplayname = (displayname, callback) => {
    dispatch(
      getUsernameExist(displayname, (result) => {
        callback(result);
      })
    );
  };

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const clickPermissionValue = (row) => {
    setOpenPermissionPopup(true);
    setPermission([...row.userPrivilege]);
    dispatch(
      getprivilegesByRole({ roleid: row.roleID }, (res) => {
        setDefaultRolePermissions([...res.data]);
      })
    );
  };

  const setFilterValues = (filterVal) => {
    const updatedObj = {};
    filterVal.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    columnFiltersRef.current = { ...updatedObj };
    onChangeFilter(filterVal);
  };

  const USERS_COLUMNS = [
    {
      title: "First Name",
      field: "firstName",
      defaultFilter: enableFilters && columnFiltersRef.current.firstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.firstName}>
            <span>{spliceTheString(rowData.firstName)}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.firstName}
          placeholder="First Name"
        />
      ),
    },
    {
      title: "Last Name",
      field: "lastName",
      defaultFilter: enableFilters && columnFiltersRef.current.lastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastName}>
            <span>{spliceTheString(rowData.lastName)}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.lastName}
          placeholder="Last Name"
        />
      ),
    },
    {
      title: "Email ID",
      field: "emailID",
      cellStyle: {
        ...getTableCellStyles(theme),
        cursor: "pointer",
      },
      defaultFilter: enableFilters && columnFiltersRef.current.emailID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return !Co ? (
          <Tooltip title={rowData.emailID}>
            <span>{rowData.emailID}</span>
          </Tooltip>
        ) : (
          <Tooltip title={rowData.emailID}>
            <a
              className={`${globalClasses.clickableLink}, ${globalClasses.textDecoration}`}
              onClick={() => rowdatauserlistfun(rowData)}
            >
              {rowData.emailID}
            </a>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.emailID}
          placeholder="Email ID"
        />
      ),
    },
    {
      title: "Role Type",
      field: "userType",
      cellStyle: {
        ...getTableCellStyles(theme),
        cursor: "pointer",
        maxWidth: 150,
      },
      defaultFilter: enableFilters && columnFiltersRef.current.userType,
      customFilterAndSearch: () => true,
      render: (row) => (
        <div
          className={classes.adminType}
          style={roleStyles(row)}
          onClick={(e) => {
            clickPermissionValue(row);
          }}
        >
          {row.userType}
        </div>
      ),
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.userType}
          placeholder="Role Type"
        />
      ),
    },
    {
      title: "Customized",
      field: "customized",
      defaultFilter: enableFilters && columnFiltersRef.current.customized,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.customized == "true" ? "Yes" : "No"}>
            <span>{rowData.customized == "true" ? "Yes" : "No"}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <select
            {...props}
            className={globalClasses.formControl}
            onChange={(e) => {
              props.onFilterChanged(
                props.columnDef.tableData.id,
                e.target.value
              );
            }}
            defaultValue={columnFiltersRef.current.customized || ""}
          >
            <option value={""}>Select option</option>
            <option value="true">Yes</option>
            <option value="false">No</option>
          </select>
        );
      },
    },
    {
      title: LABELS.CoveredEntity,
      field: "entityName",
      defaultFilter: enableFilters && columnFiltersRef.current.entityName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.entityName}>
            <span>{rowData.entityName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.entityName}
          placeholder="Entity Type"
        />
      ),
    },
    {
      title: "Created Date",
      field: "createdDate",
      defaultFilter: enableFilters && columnFiltersRef.current.createdDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.createdDate}>
            <span>{rowData.createdDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.createdDate
                ? moment(columnFiltersRef.current.createdDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Last Login Date",
      field: "lastLoginDate",
      defaultFilter: enableFilters && columnFiltersRef.current.lastLoginDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastLoginDate || ""}>
            <span>{rowData.lastLoginDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.lastLoginDate
                ? moment(columnFiltersRef.current.lastLoginDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const rowdatauserlistfun = (rowData) => {
    setrowdatauserlist(rowData);
    setaddUserState(true);
  };
  const handleSubmit = () => {
    let payload = {
      ceID: getCeIds(),
      pageNumber: page,
      pageSize: rowsPerPage,
      sortBy: sortBy,
      sortOrder: sortorder,
      enableFilters: columnFiltersRef.length ? columnFiltersRef : undefined,
      ...(searchClicked && {
        [GLOBAL_FILTERS_MAP[searchBy]]: globalFilterValue,
      }),
    };
    dispatch(
      getActiveDeactive({ userId: userid, isActive: isActive }, () => {
        dispatch(getUserList(payload));
      })
    );
    setActiveUser(false);
  };

  const loadUserData = () => {
    let json = {
      ceID: getCeIds(),
      pageNumber: page,
      pageSize: rowsPerPage,
      sortBy: sortBy,
      sortOrder: sortorder,
      enableFilters: columnFiltersRef.length ? columnFiltersRef : undefined,
      [GLOBAL_FILTERS_MAP[searchBy]]: globalFilterValue,
    };
    dispatch(getUserList(json));
  };

  const firstNameLastName = (row) => {
    const arr = [];
    if (row.firstName) {
      arr.push(row.firstName);
    }
    if (row.lastName) {
      arr.push(row.lastName);
    }
    return arr.join(" ");
  };

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: userlist && userlist.totalElements < 1,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportToExcel(),
      isFreeAction: true,
      disabled: isEmptyGrid(userlist),
      onClick: () => {
        exportToExcel({
          getCeIds,
          Co,
          coCeid,
          sortBy,
          sortorder,
          clearButton,
          defaultFilters,
          searchBy,
          globalFilterValue,
        });
      },
    },
    {
      icon: iconsAndButtons.ExportToPdf(),
      isFreeAction: true,
      disabled: isEmptyGrid(userlist),
      onClick: () => {
        exportToPdf({
          getCeIds,
          Co,
          coCeid,
          sortBy,
          sortorder,
          clearButton,
          defaultFilters,
          searchBy,
          globalFilterValue,
        });
      },
    },
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add User" }),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : "",
      isFreeAction: true,
      disabled:
        permissionObj !== null && permissionObj.readWriteFlag ? false : true,
      onClick: () => {
        setOpenPopup(true);
        setActionTitle("Add User");
        setActionTitleView("Add User");
        setSubmitActionType("Add User");
      },
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip:
        permissionObj !== null && !permissionObj.readWriteFlag
          ? "You don't have Permission."
          : "",
      isFreeAction: true,
      disabled: true,
      // permissionObj !== null && permissionObj.readWriteFlag ? false : true,
      onClick: (event, rowData) => {
        setBulkUploadPopup(true);
      },
    },
    {
      icon: iconsAndButtons.View(),
      tooltip: "View",
      isFreeAction: false,
      onClick: (_event, rowData) => {
        setOpenPopup(true);
        setEditData(rowData);
        setActionTitle(`View User - ${firstNameLastName(rowData)}`);
        setActionTitleView("View User");
        setSubmitActionType("Edit");
      },
    },
    (rowData) => {
      const hasLowerRole = getRolePriority(
        userRoles,
        rowData,
        userSession.userRole.role
      );
      return {
        icon: iconsAndButtons.Edit(),
        tooltip:
          !hasLowerRole ||
          (permissionObj !== null && !permissionObj.readWriteFlag)
            ? "You don't have Permission."
            : permissionObj !== null &&
              permissionObj.readOnlyFlag !== null &&
              !permissionObj.readOnlyFlag
            ? "You don't have Permission."
            : "Edit",
        isFreeAction: false,
        disabled:
          permissionObj !== null && !permissionObj.readWriteFlag
            ? true
            : permissionObj !== null &&
              permissionObj.readOnlyFlag !== null &&
              !permissionObj.readOnlyFlag
            ? true
            : !hasLowerRole,
        onClick: (_event, rowData) => {
          setOpenPopup(true);
          setEditData(rowData);
          setActionTitle(`Edit User - ${firstNameLastName(rowData)}`);
          setActionTitleView("Edit User");
          setSubmitActionType("Edit User");
        },
      };
    },
    (rowData) => {
      const hasLowerRole = getRolePriority(
        userRoles,
        rowData,
        userSession.userRole.role
      );
      return {
        icon:
          rowData.userStatusID === 1
            ? iconsAndButtons.Active()
            : permissionObj !== null && !permissionObj.terminateFlag
            ? iconsAndButtons.InActive()
            : iconsAndButtons.InActive(),
        tooltip:
          !hasLowerRole ||
          (permissionObj !== null && !permissionObj.terminateFlag)
            ? "You don't have Permission."
            : "Active/Inactive",
        isFreeAction: false,
        disabled:
          permissionObj !== null && !permissionObj.terminateFlag
            ? true
            : !hasLowerRole,
        onClick: (_event, rowData) => {
          setUserId(rowData.userID);
          setRowData(rowData);

          if (rowData.userStatusID === 1) {
            setActiveUser(true);
            setActiveUserTitle("active");
            setActiveType("deactivate");
            setIsActive("false");
          }

          if (rowData.userStatusID === 2) {
            setActiveUser(true);
            setActiveUserTitle("inactive");
            setActiveType("activate");
            setIsActive("true");
          }
        },
      };
    },
  ];

  const ACTIONS_CO = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(userlist),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add User" }),
      isFreeAction: true,
      onClick: () => {
        adduserStateFn();
        setrowdatauserlist({});
      },
    },
  ];

  const updateActionTitle = () => {
    setActionTitle(`Edit User - ${firstNameLastName(editData)}`);
  };

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={
              Co
                ? `Users List`
                : `Users List (${
                    getTableHeaderCount(userlist.totalElements) || 0
                  })`
            }
          />
        }
        columns={USERS_COLUMNS}
        data={userlist.content || []}
        page={page - 1}
        totalCount={userlist.totalElements || 0}
        onChangePage={onChangePagination}
        onChangeRowsPerPage={onChangeRowsperpage}
        onOrderChange={onChangeSorting}
        onFilterChange={setFilterValues}
        actions={Co ? ACTIONS_CO : ACTIONS}
        localization={{
          header: {
            actions: !Co && "Actions",
          },
          body: {
            emptyDataSourceMessage: loading ? "" : <DataNotFound />,
          },
        }}
        icons={{
          SortArrow: () => TableCustomSortArrow({ sortOrder: sortorder }),
          Filter: ColumnFilterIcon,
        }}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paginationType: "stepped",
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          actionsCellStyle: getTableActionCellStyles(theme),
          tableLayout: "auto",
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: rowsPerPage,
          draggable: false,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          pageSizeOptions: isEmptyGrid(userlist)
            ? []
            : Co
            ? pagination.pageBillingSizeOptions
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />

      {openPopup ? (
        <div>
          <AddEditForm
            updateActionTitle={updateActionTitle}
            permissionObj={permissionObj}
            title={actiontitleView}
            coveredentity={coveredentity}
            internalteam={internalTeam}
            submitEmail={submitEmail}
            submitDisplayname={submitDisplayname}
            submitactiontype={submitactiontype}
            setOpenPopup={setOpenPopup}
            rowData={editData}
            fetchUserPayload={fetchUserPayload}
            havingPopup={true}
            openPopup={openPopup}
            actiontitle={actiontitle}
          />
        </div>
      ) : null}
      <BasicPopup
        title={`This user is ${activeUserTitle}`}
        show={activeuser}
        handleClose={() => setActiveUser(false)}
        disableFooter={true}
      >
        <ActiveInActiveUser
          handleSubmit={handleSubmit}
          setActiveUser={setActiveUser}
          activeType={activeType}
          userid={userid}
          isActive={isActive}
          setRowData={setRowData}
          rowdata={rowdata}
        />
      </BasicPopup>

      {openPermissionPopup && (
        <BasicPopup
          show={openPermissionPopup}
          title={"View User Permissions"}
          disableFooter={true}
          handleClose={() => setOpenPermissionPopup(false)}
          dialogProps={{
            maxWidth: "sm",
            classes: {
              paper: classes.viewPermissionPopupPaper,
            },
          }}
        >
          <AddEdituserPermission
            sendValue={true}
            permissions={permissions}
            defaultUserPrivileges={defaultRolePermissions}
          />
        </BasicPopup>
      )}

      {BulkUploadPopup && (
        <BasicPopup
          title="Bulk Upload Users"
          show={BulkUploadPopup}
          handleClose={() => setBulkUploadPopup(false)}
          disableFooter={true}
        >
          <BulkUpload
            loadUserData={loadUserData}
            setBulkUploadPopup={setBulkUploadPopup}
          />
        </BasicPopup>
      )}
    </div>
  );
};
export default UserlistMaterialTable;
