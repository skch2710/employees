import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, {
  MTablePagination,
  MTableToolbar,
  MTableHeader,
} from "material-table";
import {
  Paper,
  Grid,
  Box,
  TableCell,
  TableHead,
  Tooltip,
} from "@material-ui/core";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { pagination } from "../../../../utils/constants";
import { getPOClaimsList } from "../../../../context/actions/PurchaseOrders";
import { usePOClaimsStyle } from "./styles";
import { getPoClaimsFiltersObject } from "../helper";
import { GET_PO_CLAIM_LIST } from "../../../../context/constants";
import DataNotFound from "../../../../components/common/DataNotFound";
import useFileExport from "./useFileExport";
import {
  getPHIReadAccess,
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../utils/helper";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
} from "../../../../Styles/useGlobalStyles";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const POClaims = ({ po } = {}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const phiReadAccess = getPHIReadAccess();
  const { poID, poItemID, hrsaID, ceName, pharmacy, poDate } = po || {};
  const iconsAndButtons = useTableIconsAndButtons();

  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "ndc",
  });

  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});

  const { records: poClaimsList, loading } = useSelector(
    (state) => state.getPOClaimData
  );

  const classes = usePOClaimsStyle({
    totalElements: poClaimsList.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.page,
  });

  const fetchPOClaims = (payload = {}) => {
    dispatch(
      getPOClaimsList(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: [],
          export: false,
          poID: poID,
          poItemID: poItemID || 0,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (poID) {
      fetchPOClaims();
    }
    return () => {
      dispatch({ type: GET_PO_CLAIM_LIST, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(poClaimsList.totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;

      fetchPOClaims({
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller, poClaimsList]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PO_CLAIMS_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchPOClaims({
        pageNumber: controller.page,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getPoClaimsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchPOClaims({
      ...controller,
      filter: filterPayload,
    });
  };

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(poClaimsList),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(poClaimsList),
      }),
      tooltip: "Export",
      isFreeAction: true,
      disabled: isEmptyGrid(poClaimsList),
      onClick: () =>
        exportToExcel({
          poID,
          poItemID,
          controller,
          columnFilters,
        }),
    },
  ];

  const PO_CLAIMS_COLUMNS = [
    {
      title: "810 Invoice #",
      field: "itemInvoiceNumber",
      defaultFilter:
        enableFilters && columnFiltersRef.current.itemInvoiceNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemInvoiceNumber}>
            <span>{rowData.itemInvoiceNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.itemInvoiceNumber}
          placeholder="810 Invoice #"
        />
      ),
    },
    {
      title: "NDC",
      field: "ndc",
      defaultFilter: enableFilters && columnFiltersRef.current.ndc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc}>
            <span>{rowData.ndc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.ndc}
          placeholder="NDC"
        />
      ),
    },
    {
      title: "Drug Name",
      field: "drugName",
      defaultFilter: enableFilters && columnFiltersRef.current.drugName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.drugName}
          placeholder="Drug Name"
        />
      ),
    },
    {
      title: "Item Pkgs",
      field: "itemPkgs",
      defaultFilter: enableFilters && columnFiltersRef.current.itemPkgs,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.itemPkgs}>
            <span>{rowData.itemPkgs}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.itemPkgs}
          placeholder="Item Pkgs"
        />
      ),
    },
    {
      title: "Pkg Size",
      field: "pkgSize",
      defaultFilter: enableFilters && columnFiltersRef.current.pkgSize,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pkgSize}>
            <span>{rowData.pkgSize}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pkgSize}
          placeholder="Pkg Size"
        />
      ),
    },
    {
      title: "PO Item Status",
      field: "poItemStatus",
      defaultFilter: enableFilters && columnFiltersRef.current.poItemStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poItemStatus}>
            <span>{rowData.poItemStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.poItemStatus}
          placeholder="PO Item Status"
        />
      ),
    },
    {
      title: "Claims Mapped",
      field: "claimsMappingFlag",
      defaultFilter:
        enableFilters && columnFiltersRef.current.claimsMappingFlag,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimsMappingFlag}>
            <span>{rowData.claimsMappingFlag}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimsMappingFlag}
          placeholder="Claims Mapped"
        />
      ),
    },
    {
      title: "Reason No Claims",
      field: "noClaimReason",
      defaultFilter: enableFilters && columnFiltersRef.current.noClaimReason,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.noClaimReason}>
            <span>{rowData.noClaimReason}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.noClaimReason}
          placeholder="Reason No Claims"
        />
      ),
    },
    {
      title: "Wholesaler Account",
      field: "wholesalerAccountDivisionCode",
      defaultFilter:
        enableFilters && columnFiltersRef.current.wholesalerAccountDivisionCode,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.wholesalerAccountDivisionCode}>
            <span>{rowData.wholesalerAccountDivisionCode}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.wholesalerAccountDivisionCode}
          placeholder="Wholesaler Account"
        />
      ),
    },
    {
      title: "Claim ID",
      field: "claimID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.claimID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimID}>
            <span>{rowData.claimID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.claimID}
          placeholder="Claim ID"
        />
      ),
    },
    {
      title: "340B Direct Invoice Date",
      field: "invoiceDate340BDirect",
      defaultFilter:
        enableFilters && columnFiltersRef.current.invoiceDate340BDirect,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.invoiceDate340BDirect}>
            <span>{rowData.invoiceDate340BDirect}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.invoiceDate340BDirect
                ? moment(columnFiltersRef.current.invoiceDate340BDirect)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Date of Service",
      field: "dateOfService",
      defaultFilter: enableFilters && columnFiltersRef.current.dateOfService,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dateOfService}>
            <span>{rowData.dateOfService}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.dateOfService
                ? moment(columnFiltersRef.current.dateOfService)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Rx No",
      field: "rxNumber",
      defaultFilter: enableFilters && columnFiltersRef.current.rxNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.rxNumber}>
            <span>{rowData.rxNumber}</span>
          </Tooltip>
        );
      },
      cellStyle: {
        ...getTableCellStyles(theme),
        ...(phiReadAccess ? { color: theme.colors.yellow.default } : {}),
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.rxNumber}
          placeholder="Rx No"
        />
      ),
    },
    {
      title: "Refill No",
      field: "reFillNo",
      defaultFilter: enableFilters && columnFiltersRef.current.reFillNo,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.reFillNo}>
            <span>{rowData.reFillNo}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.reFillNo}
          placeholder="Refill No"
        />
      ),
    },
    {
      title: "Replenished Units",
      field: "replenishedUnits",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.replenishedUnits,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.replenishedUnits}>
            <span>{rowData.replenishedUnits}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.replenishedUnits}
          placeholder="Replenished Units"
        />
      ),
    },
    {
      title: "Dispensed Units",
      field: "dispensedUnits",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensedUnits,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensedUnits}>
            <span>{rowData.dispensedUnits}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensedUnits}
          placeholder="Dispensed Units"
        />
      ),
    },
    {
      title: "Dispensing Store",
      field: "dispensingStore",
      defaultFilter: enableFilters && columnFiltersRef.current.dispensingStore,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingStore}>
            <span>{rowData.dispensingStore}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.dispensingStore}
          placeholder="Dispensing Store"
        />
      ),
    },
    {
      title: "Receiving Store",
      field: "receivingStore",
      defaultFilter: enableFilters && columnFiltersRef.current.receivingStore,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.receivingStore}>
            <span>{rowData.receivingStore}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.receivingStore}
          placeholder="Receiving Store"
        />
      ),
    },
    {
      title: "Patient First Name",
      field: "memberFirstName",
      defaultFilter: enableFilters && columnFiltersRef.current.memberFirstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.memberFirstName}>
            <span>{rowData.memberFirstName}</span>
          </Tooltip>
        );
      },
      cellStyle: {
        ...getTableCellStyles(theme),
        ...(phiReadAccess ? { color: theme.colors.yellow.default } : {}),
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.memberFirstName}
          placeholder="Patient First Name"
        />
      ),
    },
    {
      title: "Patient Last Name",
      field: "memberLastName",
      defaultFilter: enableFilters && columnFiltersRef.current.memberLastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.memberLastName}>
            <span>{rowData.memberLastName}</span>
          </Tooltip>
        );
      },
      cellStyle: {
        ...getTableCellStyles(theme),
        ...(phiReadAccess ? { color: theme.colors.yellow.default } : {}),
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.memberLastName}
          placeholder="Patient Last Name"
        />
      ),
    },
    {
      title: "Patient ID",
      field: "memberID",
      defaultFilter: enableFilters && columnFiltersRef.current.memberID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.memberID}>
            <span>{rowData.memberID}</span>
          </Tooltip>
        );
      },
      cellStyle: {
        ...getTableCellStyles(theme),
        ...(phiReadAccess ? { color: theme.colors.yellow.default } : {}),
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.memberID}
          placeholder="Patient ID"
        />
      ),
    },
    {
      title: "Physician First Name",
      field: "physicianFirstName",
      defaultFilter:
        enableFilters && columnFiltersRef.current.physicianFirstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.physicianFirstName}>
            <span>{rowData.physicianFirstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.physicianFirstName}
          placeholder="Physician First Name"
        />
      ),
    },
    {
      title: "Physician Last Name",
      field: "physicianLastName",
      defaultFilter:
        enableFilters && columnFiltersRef.current.physicianLastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.physicianLastName}>
            <span>{rowData.physicianLastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.physicianLastName}
          placeholder="Physician Last Name"
        />
      ),
    },
    {
      title: "Physician ID",
      field: "prescriberID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.prescriberID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.prescriberID}>
            <span>{rowData.prescriberID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.prescriberID}
          placeholder="Physician ID"
        />
      ),
    },
    {
      title: "Manufacturer",
      field: "manufacturere",
      defaultFilter: enableFilters && columnFiltersRef.current.manufacturere,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.manufacturere}>
            <span>{rowData.manufacturere}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.manufacturere}
          placeholder="Manufacturer"
        />
      ),
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2} justifyContent="space-between">
          <Grid item xs={12} md>
            <Box display="flex" justifyContent="flex-start">
              <BasicTypography variant="subtitle2">{`HRSA ID #: ${
                hrsaID || ""
              }`}</BasicTypography>
            </Box>
          </Grid>
          <Grid item xs={12} md>
            <Box display="flex" justifyContent="center">
              <BasicTypography variant="subtitle2">
                {`Covered Entity: ${ceName || ""}`}
              </BasicTypography>
            </Box>
          </Grid>
          <Grid item xs={12} md>
            <Box display="flex" justifyContent="center">
              <BasicTypography variant="subtitle2">
                {`Pharmacy Store: ${pharmacy || ""}`}
              </BasicTypography>
            </Box>
          </Grid>
          <Grid item xs={12} md>
            <Box display="flex" justifyContent="center">
              <BasicTypography variant="subtitle2">
                {`PO #: ${poID || ""}`}
              </BasicTypography>
            </Box>
          </Grid>
          <Grid item xs={12} md>
            <Box display="flex" justifyContent="flex-end">
              <BasicTypography variant="subtitle2">
                {`PO Date: ${poDate || ""}`}
              </BasicTypography>
            </Box>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <div className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Purchase Order Claims (${getTableHeaderCount(
                  poClaimsList.totalElements
                )})`}
              />
            }
            columns={PO_CLAIMS_COLUMNS}
            data={poClaimsList.content}
            page={controller.page - 1}
            totalCount={poClaimsList.totalElements}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={ACTIONS}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              Header: (props) => (
                <>
                  <TableHead>
                    <TableCell colSpan={11} className={classes.tableHeader}>
                      <div className={classes.colSpanFirstHeaderStyle}>
                        Purchase Order Item
                      </div>
                    </TableCell>
                    <TableCell colSpan={14} className={classes.tableHeader}>
                      <div>Claims Mapped To Purchase Order Item</div>
                    </TableCell>
                  </TableHead>
                  <MTableHeader {...props} />
                </>
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              showTitle: true,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(poClaimsList)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </div>
      </Grid>
    </Grid>
  );
};

export default memo(POClaims);
