import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../../utils/helper";

export const useInvReplenishmentDetailsStyle = makeStyles((theme) => {
  return {
    tableHeader: {
      background: theme.colors.monochrome.tableHeaderBackground,
      color: theme.colors.monochrome.tableHeaderText,
      fontSize: "11px",
      whiteSpace: "nowrap",
      border: "none",
      textAlign: "center",
      padding: "5px 0",
    },
    exportContainer: {
      textAlign: "right",
      padding: "8px 10px 0 0",
    },
    muiToolbar: (props) => {
      return {
        marginRight: getGridActionButtonsMarginRight(props),
        marginTop: "-38px",
        marginBottom: "6px",
        paddingLeft: "6px",
      };
    },
    buttonStyles: {
      margin: "0 0 0 10px !important",
    },
  };
});
