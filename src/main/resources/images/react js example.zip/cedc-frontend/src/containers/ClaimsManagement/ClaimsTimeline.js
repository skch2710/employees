import React from "react";
import { useTheme } from "@material-ui/core";
import HorizontalTimeline from "react-horizontal-timeline";
import { getOnlyDates, getCurrentObject } from "./helper";
import { useTimelineStyles } from "./style";
import moment from "moment";

const ClaimsTimeline = ({ timelineData = [] } = {}) => {
  const theme = useTheme();
  const classes = useTimelineStyles();
  const dates = getOnlyDates(timelineData || []) || [];

  return (
    <>
      <div className={classes.timelineContainer}>
        {dates.length ? (
          <HorizontalTimeline
            styles={{
              foreground: theme.colors.blue[600],
              outline: theme.colors.blue[600],
            }}
            index={dates && dates.length - 1}
            getLabel={(currItem) => {
              const { fields, date } = getCurrentObject(timelineData, currItem);
              return (
                <div className={classes.labelContainer}>
                  <div>
                    <p>{moment(date).format("MMM DD, YYYY")}</p>
                  </div>
                  <div className={classes.bottomLabelContainer}>
                    <div>
                      <span>
                        {fields && fields.length && fields.join(", ")}
                      </span>
                    </div>
                  </div>
                </div>
              );
            }}
            values={dates}
            isOpenBeginning={true}
            isOpenEnding={true}
            labelWidth={170}
            maxEventPadding={20}
          />
        ) : null}
      </div>
    </>
  );
};

export default ClaimsTimeline;
