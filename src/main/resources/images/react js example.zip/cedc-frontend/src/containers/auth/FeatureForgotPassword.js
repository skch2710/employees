import React, { useEffect, useState } from "react";
import { Paper, Typography, Grid, Button } from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import LockIcon from "../../assets/icon-set-password.png";

import { useStyles } from "../../mui-styles/createpasswordStyle";
import Notfound from "../../components/common/Notfound";
import {
  resetPassword,
  updatePassword,
  validateSecurityAns,
  verifyUUId,
} from "../../context/actions/Auth";
import LoaderUI from "../../components/common/Loader/Loader";

const defaultValues = {
  securityQuestion: {},
  newpw: "",
  cnp: "",
  ans1: "",
  ans2: "",
};

const status = {
  200: "active",
  400: "expired",
  404: "used",
};

const FeatureForgotPassword = () => {
  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();

  const id = location.search.split("=") + location.hash;
  const { pathname } = location;
  const uuid = id.split(",");

  const [data, setData] = useState(null);
  const [validAns, setValidAns] = useState(false);
  const [linkStatus, setLinkStatus] = useState("loading");
  const [errorMessage, setErrorMessage] = useState("");
  let errorMessage1 = "";
  let errorMessage2 = "";

  const loader = useSelector((state) => state.usermanagement.loading);

  const isResetLink = pathname === "/resetpasswordLink";
  const islockLink = pathname === "/accountLockLink";

  if (errorMessage.includes("$")) {
    let splitArray = errorMessage.split("$");
    errorMessage1 = splitArray[0];
    errorMessage2 = splitArray[1];
  } else {
    errorMessage1 = errorMessage;
    errorMessage2 = "";
  }

  useEffect(() => {
    dispatch(
      verifyUUId(uuid[1], (res) => {
        setData(res.data);
        setLinkStatus(status[res.statusCode] || "");
      })
    );
  }, []);

  const handleSubmit = (values, { setTouched }) => {
    if (!validAns) {
      const payload = {
        userID: data.userID,
        securityAnswers: Object.keys(data.securityQuestion).reduce(
          (ac, item, index) => {
            ac[item] = values[`ans${index + 1}`].trim();
            return ac;
          },
          {}
        ),
      };
      setTouched({ ans1: true, ans2: true });
      dispatch(
        validateSecurityAns(payload, (res) => {
          if (res.statusCode === 200) {
            setValidAns(true);
            if (errorMessage !== "") setErrorMessage("");
          } else {
            setErrorMessage(res.errorMessage);
          }
        })
      );
    } else if (isResetLink) {
      dispatch(
        resetPassword(
          {
            userId: data.userID,
            oldPassword: values.currentpw,
            password: values.newpw,
          },
          () => {
            history.replace("/login");
          }
        )
      );
    } else {
      dispatch(
        updatePassword({ userId: data.userID, password: values.newpw }, () => {
          history.replace("/login");
        })
      );
    }
  };

  const formValidate = (values) => {
    let error = {};
    if (validAns && values.newpw.trim() === "") {
      error.newpw = "Please enter the Password";
    } else if (validAns && values.newpw.length < 12) {
      error.newpw =
        "Password must be at least 12 characters in length. Please try again";
    }
    if (validAns && isResetLink && values.currentpw.trim() === "") {
      error.currentpw = "Please enter current password ";
    }
    if (validAns && values.cnp.trim() === "") {
      error.cnp = "Please enter confirm password ";
    }
    if (
      validAns &&
      values.cnp.trim().length > 0 &&
      values.cnp !== values.newpw
    ) {
      error.cnp = "Password mismatch ";
    }
    if (!validAns && !values.ans1.trim()) error.ans1 = "Required field";
    if (!validAns && !values.ans2.trim()) error.ans2 = "Required field";

    return error;
  };

  const firstNameAndLastName = (user) => {
    return user ? user.firstName + " " + user.lastName : "";
  };

  return linkStatus !== "loading" ? (
    <>
      {data && linkStatus === "active" ? (
        <Formik
          initialValues={defaultValues}
          onSubmit={handleSubmit}
          validate={formValidate}
          onReset={() => history.push("/login")}
        >
          {(formik) => (
            <>
              {loader && <LoaderUI />}
              <div>
                <Paper elevation={0} className={classes.paper}>
                  <Typography component="span" className="form-text m-b-30">
                    Welcome :{" "}
                  </Typography>{" "}
                  <strong>{firstNameAndLastName(data)}</strong>
                  <Grid className={classes.subtitle}>
                    <Grid>
                      <img
                        alt="LockIcon"
                        src={LockIcon}
                        className={classes.iconStyle}
                      />
                    </Grid>
                    <Grid>
                      <Typography variant="h6" className={classes.subtitle2}>
                        {isResetLink
                          ? "Reset your password"
                          : "Change Password"}
                      </Typography>
                      <Typography variant="body2" className="form-text m-b-30">
                        Please answer two questions from the list..
                      </Typography>
                    </Grid>
                  </Grid>
                  <Form>
                    <Grid xs={12} sm={12}>
                      <Typography variant="body1" className="mb-3">
                        <strong>Answer the following security questions</strong>
                      </Typography>
                      <Grid
                        container
                        spacing={3}
                        style={{ marginBottom: "16px" }}
                      >
                        {Object.values(data.securityQuestion).map(
                          (qn, index) => {
                            return (
                              <Grid item xs={12} sm={6}>
                                <Typography variant="body2">
                                  {`Question ${index + 1} - ${qn}`}
                                </Typography>
                                <br />
                                <Field
                                  name={`ans${index + 1}`}
                                  id={`ans${index + 1}`}
                                  type="text"
                                  className="form-control pw"
                                  placeholder="Answer of your question"
                                  style={{ marginTop: "-10px" }}
                                  disabled={validAns}
                                />
                                {formik.touched[`ans${index + 1}`] &&
                                  formik.errors[`ans${index + 1}`] && (
                                    <Typography color="error" variant="caption">
                                      {formik.errors[`ans${index + 1}`]}
                                    </Typography>
                                  )}
                              </Grid>
                            );
                          }
                        )}
                      </Grid>
                      {errorMessage && (
                        <Grid className={classes.messageGrid}>
                          {errorMessage1} <br /> {errorMessage2}
                        </Grid>
                      )}
                    </Grid>
                    <Grid className={classes.spacing}>
                      {validAns ? (
                        <>
                          <Typography variant="body1">
                            <strong> Change your Password </strong>
                          </Typography>
                          <Grid
                            container
                            spacing={3}
                            style={{ marginTop: "5px" }}
                          >
                            {isResetLink ? (
                              <Grid item xs={12} sm={4}>
                                <Field
                                  name="currentpw"
                                  id="currentpassword"
                                  type="password"
                                  className="form-control ps"
                                  placeholder="Enter Current Password"
                                  maxLength={50}
                                />
                                {formik.errors.currentpw && (
                                  <Typography color="error" variant="caption">
                                    {formik.errors.currentpw}
                                  </Typography>
                                )}
                              </Grid>
                            ) : null}
                            <Grid item xs={12} sm={isResetLink ? 4 : 6}>
                              <Field
                                name="newpw"
                                id="newpassword"
                                type="password"
                                className="form-control pw"
                                placeholder="Enter New Password"
                                maxLength={50}
                              />
                              {formik.touched.newpw && formik.errors.newpw && (
                                <Typography color="error" variant="caption">
                                  {formik.errors.newpw}
                                </Typography>
                              )}
                            </Grid>

                            <Grid item xs={12} sm={isResetLink ? 4 : 6}>
                              <Field
                                name="cnp"
                                id="confirmnewpassword"
                                type="password"
                                className="form-control ps"
                                placeholder="Confirm New Password"
                                maxLength={50}
                              />
                              {formik.touched.cnp && formik.errors.cnp && (
                                <Typography color="error" variant="caption">
                                  {formik.errors.cnp}
                                </Typography>
                              )}
                            </Grid>

                            <Typography
                              variant="caption"
                              className="form-text m-b-30"
                              style={{ padding: "20px" }}
                            >
                              Must be at least 12 characters in length
                              <br />
                              Special Characters/Caps/Numbers NOT required
                              <br />
                              Unique password history: 20
                            </Typography>
                          </Grid>
                        </>
                      ) : null}
                      <Grid
                        container
                        justifyContent="flex-end"
                        style={{ marginRight: "40px" }}
                      >
                        <Button
                          type="submit"
                          color="primary"
                          size="small"
                          variant="contained"
                          className="btn btn-primary"
                        >
                          Save
                        </Button>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          color="default"
                          className="btn btn-secondary m-l-20"
                        >
                          {" "}
                          cancel
                        </Button>
                      </Grid>
                    </Grid>
                  </Form>
                </Paper>
              </div>
            </>
          )}
        </Formik>
      ) : (
        <div>
          <Notfound
            value={"Oops, there was a problem with your link"}
            linkType={
              islockLink
                ? "Your reset link has expired or has already been used. Please contact admin."
                : "Your reset link has expired or has already been used."
            }
            uuid={uuid[1]}
            nameOfUser={data && firstNameAndLastName(data)}
            usedLink={linkStatus === "used"}
          />
        </div>
      )}
    </>
  ) : (
    <LoaderUI />
  );
};

export default FeatureForgotPassword;
