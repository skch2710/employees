import * as XLSX from "xlsx";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import FileSaver from "file-saver";
import { LABELS, notNull } from "../../../../utils/constants";
import { getRemittanceListExport } from "../../../../context/actions/Invoice";
import { getClaimsListExport } from "../../../../context/actions/Invoice";
import { getTrueupListExport } from "../../../../context/actions/Invoice";

const useFileExportRowData = () => {
  const dispatch = useDispatch();
  const [remittanceSummaryData, setRemittanceSummaryData] = useState();
  const [claimDetailsData, setClaimDetailsData] = useState();
  const [trueUpDetailsData, setTrueUpDetailsData] = useState();
  const [rowdata, setRowdata] = useState();

  const fetchExportData = async (rowdata) => {
    const payload = {
      ceid: rowdata.ceId,
      startDate: rowdata.invoicePeriodStartDate,
      endDate: rowdata.invoicePeriodEndDate,
      export: true,
      sortBy: "",
      sortOrder: "",
    };
    const TrueupClaimsPayload = {
      sortBy: "",
      sortOrder: "",
      export: true,
      ceid: rowdata.ceId,
      startPeriod: rowdata.invoicePeriodStartDate,
      endPeriod: rowdata.invoicePeriodEndDate,
      phGroupId: 0,
      phId: 0,
      filter: [],
    };
    const getRemittanceListdata = await dispatch(
      getRemittanceListExport(payload)
    );
    const getClaimsListdata = await dispatch(
      getClaimsListExport(TrueupClaimsPayload)
    );
    const getTrueupListdata = await dispatch(
      getTrueupListExport(TrueupClaimsPayload)
    );

    if (getRemittanceListdata) {
      setRemittanceSummaryData(getRemittanceListdata.content);
    }
    if (getClaimsListdata) {
      setClaimDetailsData(getClaimsListdata.content);
    }
    if (getTrueupListdata) {
      setTrueUpDetailsData(getTrueupListdata.content);
    }
  };

  const exportData = () => {
    var remittanceSummary = remittanceSummaryData.map(
      ({
        phGroupName,
        phName,
        pharmacyNPI,
        claims340b,
        totalInvoiced,
        dispensingFee,
        pharmacyConnectionFee,
        trueUp,
        tfbDirectplusFlatFee,
        tfbDirectplusTransactionPercentage,
        tfbDirectplusTransactionFee,
        contractPharmacyMinOrMax,
        tfbDirectPlusFee,
        ceTotalReceivedAmount
      }) => ({
        [LABELS.PharmacyChain]: notNull(phGroupName),
        [LABELS.PharmacyStore]: phName,
        "Pharmacy NPI": notNull(pharmacyNPI),
        "#340B Claims": notNull(claims340b),
        "Total Invoiced": notNull(totalInvoiced),
        "Dispensing Fees": notNull(dispensingFee),
        "Connection Fee": notNull(pharmacyConnectionFee),
        "True Up": notNull(trueUp),
        "340BDirect+ Flat Fee": notNull(tfbDirectplusFlatFee),
        "340Direct+ Transaction % Fee": notNull(tfbDirectplusTransactionPercentage),
        "340Direct+ Transaction $ Fee": notNull(tfbDirectplusTransactionFee),
        "Min/Max": notNull(contractPharmacyMinOrMax),
        "Applied 340BDirect+ Fee":  notNull(tfbDirectPlusFee),
        "Total Covered Entity Receivable": notNull(ceTotalReceivedAmount)
      })
    );
    var claimDetails = claimDetailsData.map(
      ({
        adminName,
        ceName,
        adminHRSAID,
        ceReimbursementModel,
        ceReplenishmentModel,
        pharmacyGroup,
        pharmacyStoreName,
        pharmacyNPI,
        physicianFirstName,
        physicianLastName,
        prescriberId,
        replenishmentType,
        claimID,
        refillCode,
        rxNumber,
        pgmDateRxWritten,
        processedDate,
        dateOfService,
        dateReversed,
        claimStatusCode,
        claimType,
        bin,
        pcn,
        groupNumber,
        ndc,
        drugName,
        borGIndicator,
        qtyDisp,
        replenishedQty,
        replenishmentPercentage,
        patientPay,
        thirdPartyPayment,
        cePlanSubsidy,
        totalCollected,
        estimatedAcquisitionCost,
        tfbIngredientCost,
        actualIngredientCost,
        totalInvoiced,
        dispensingFee,
        grossSavings,
        tfbDirectplusFlatFee,
        total340BDirectplusFee,
        totalCEReceivable,
        eightTenDebitInvoice,
        invoiceDate,
        eightTenCreditInvoice,
        creditInvoiceDate,
      }) => ({
        "Admin Name": notNull(adminName),
        "Covered Entity": ceName,
        "HRSA ID": notNull(adminHRSAID),
        "Covered Entity Reimbursement Model": notNull(ceReimbursementModel),
        "Covered Entity Replenishment Model": notNull(ceReplenishmentModel),
         [LABELS.PharmacyChain]: notNull(pharmacyGroup),
         [LABELS.PharmacyStore]: notNull(pharmacyStoreName),
        "Pharmacy NPI": notNull(pharmacyNPI),
        "Physician First Name": notNull(physicianFirstName),
        "Physician Last Name": notNull(physicianLastName),
        "Prescriber ID": notNull(prescriberId),
        "Replenishment Type": notNull(replenishmentType),
        "Claim ID": notNull(claimID),
        "Refill #": notNull(refillCode),
        "Rx Number": notNull(rxNumber),
        "Rx Written Date": notNull(pgmDateRxWritten),
        "Processed Date": notNull(processedDate),
        "Date of Service": notNull(dateOfService),
        "Date Reversed": notNull(dateReversed),
        "Claim Status": notNull(claimStatusCode),
        "Claim Type": notNull(claimType),
        BIN: notNull(bin),
        PCN: notNull(pcn),
        "Group Number": notNull(groupNumber),
        NDC11: notNull(ndc),
        "Drug Name": notNull(drugName),
        "Brand or Generic Indicator": notNull(borGIndicator),
        "Qty Disp": notNull(qtyDisp),
        "Relenished Qty": notNull(replenishedQty),
        "Replenishment Percentage": notNull(replenishmentPercentage),
        "Patient Pay": notNull(patientPay),
        "Third Party Payment": notNull(thirdPartyPayment),
        "Covered Entity Plan Subsidy": notNull(cePlanSubsidy),
        "Total Collected": notNull(totalCollected),
        "Estimated Acquisition Cost": notNull(estimatedAcquisitionCost),
        "340B Ingredient Cost": notNull(tfbIngredientCost),
        "Actual Ingredient Cost": notNull(actualIngredientCost),
        "Total Invoiced": notNull(totalInvoiced),
        "Dispensing Fee": notNull(dispensingFee),
        "Gross Savings": notNull(grossSavings),
        "340BDirect+ Flat Fee": notNull(tfbDirectplusFlatFee),
        "Total 340BDirect+ Fee": notNull(total340BDirectplusFee),
        "Total Covered Entity Receivable": notNull(totalCEReceivable),
        "810 Debit Invoice #": notNull(eightTenDebitInvoice),
        "Debit Invoice Date": notNull(invoiceDate),
        "810 Credit Invoice #": notNull(eightTenCreditInvoice),
        "Credit Invoice Date": notNull(creditInvoiceDate),
      })
    );
    var trueUpDetails = trueUpDetailsData.map(
      ({
        invoicePeriodStartDate,
        invoicePeriodEndDate,
        tfbID,
        claimId,
        processedDate,
        rxNumber,
        rxWrittenDate,
        refillNumber,
        dateOfService,
        bin,
        pcn,
        phGroupName,
        store,
        dispensingStoreNpi,
        ndc,
        drugName,
        brandGenericFlag,
        replenishedPercentage,
        trueUpUnits,
        trueUpAmount,
        trueUpReason,
        trueUpType,
      }) => ({
        "Billing Cycle": `${invoicePeriodStartDate} - ${invoicePeriodEndDate}`,
        "340B ID": notNull(tfbID),
        "Claim ID": notNull(claimId),
        "Processed Date": notNull(processedDate),
        "Rx Number": notNull(rxNumber),
        "Rx Written Date": notNull(rxWrittenDate),
        "Refill #": notNull(refillNumber),
        "Date of Service": notNull(dateOfService),
        BIN: notNull(bin),
        PCN: notNull(pcn),
        [LABELS.PharmacyChain]: notNull(phGroupName),
        [LABELS.PharmacyStore]: notNull(store),
        "Dispensing Store NPI": notNull(dispensingStoreNpi),
        NDC11: notNull(ndc),
        "Drug Name": notNull(drugName),
        "Brand or Generic": notNull(brandGenericFlag),
        "Replenished Percentage": notNull(replenishedPercentage),
        "True-Up Units": notNull(trueUpUnits),
        "True-Up  Amount": notNull(trueUpAmount),
        "True-Up Reason": notNull(trueUpReason),
        "True-Up Type": notNull(trueUpType),
      })
    );
    var Glossary = [];
    var remittanceSummary = XLSX.utils.json_to_sheet(remittanceSummary);
    var claimDetails = XLSX.utils.json_to_sheet(claimDetails);
    var trueUpDetails = XLSX.utils.json_to_sheet(trueUpDetails);
    var Glossary = XLSX.utils.json_to_sheet(Glossary);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, remittanceSummary, "Remittance Summary");
    XLSX.utils.book_append_sheet(wb, claimDetails, "Claim Details");
    XLSX.utils.book_append_sheet(wb, trueUpDetails, "True Up Details");
    XLSX.utils.book_append_sheet(wb, Glossary, "Glossary");

    XLSX.writeFile(wb, "Invoice Package" + " " + rowdata.ceName + ".xlsx");
    setRowdata()
  };
  useEffect(() => {
    if (rowdata !== undefined && rowdata !== null) {
      fetchExportData(rowdata);
    }
  }, [rowdata]);

  useEffect(() => {
    if (remittanceSummaryData && claimDetailsData && trueUpDetailsData) {
      exportData();
    }
  }, [remittanceSummaryData, claimDetailsData, trueUpDetailsData]);

  const rowDataExport = (props) => {
    setRemittanceSummaryData();
    setClaimDetailsData();
    setTrueUpDetailsData();
    const { rowData } = props;
    setRowdata(rowData);
  };

  return { rowDataExport };
};

export default useFileExportRowData;
