import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  Collapse,
  Divider,
  FormLabel,
  Grid,
  IconButton,
  Paper,
} from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import { useDispatch, useSelector } from "react-redux";
import { BsPencilSquare } from "react-icons/bs";
import { COContext } from "../../COContext";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { fetchPhBasicDetails } from "../../../../context/actions/Common";
import { usePhBasicDetailsStyle } from "./styles";
import { MENUS } from "../../ConfigurationOverview/PopupSidebar/constants";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../utils/helper";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import { LABELS } from "../../../../utils/constants";

const PhBasicDetails = memo((props = {}) => {
  const { selectedPharmacy, isAllCollapsed } = props;
  const { clientId, ceid } = selectedPharmacy || {};
  const { clickOnPencil, setCurrentPharmacy, setCoveredEntityName } =
    useContext(COContext) || {};
  const userSession = getUserSession();
  const readWritePermission =
    getUserPermissionOnModuleName("Pharmacies").readWriteFlag;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = usePhBasicDetailsStyle();

  const [isCollapsed, setIsCollapsed] = useState(true);

  const { loading: _basicDetailsLoading, phBasicDetails } =
    useSelector((state) => state.phBasicDetails) || {};

  useEffect(() => {
    clientId && dispatch(fetchPhBasicDetails(clientId));
  }, [clientId]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={classes.basicDetailsWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={classes.basicDetailsTitleWrapper}>
            <BasicTypography variant="h3" title="Basic Details" />
            <div className={classes.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={!userSession.isInternalUser || !readWritePermission}
              >
                <BsPencilSquare
                  onClick={() => {
                    setCurrentPharmacy(selectedPharmacy);
                    setCoveredEntityName(selectedPharmacy.coveredEntity);
                    clickOnPencil(MENUS.PH_BASIC_DETAILS, ceid);
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Pharmacy Basic Details"
                      />
                    </Grid>
                    <Grid item xs={12} md={12}>
                      <Grid container spacing={2}>
                        <Grid item md={12}>
                          <Grid container spacing={2}>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.pharmacyGroup || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {(phBasicDetails.pharmacyName &&
                                  `${phBasicDetails.pharmacyName} #${phBasicDetails.storeNumber}`) ||
                                  "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>NABP</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.nabp || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Region</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.regionDesc || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Division</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.phDivision || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>District</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.phDistrictName || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>I-Code</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.icode || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Address Line 1</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.addressLine1 || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Address Line 2</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.addressLine2 || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>NPI</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.npi || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Store Number</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.storeNumber || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>City</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.city || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>State</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.state || "--"}
                              </BasicTypography>
                            </Grid>

                            <Grid item xs={12} sm={4}>
                              <FormLabel>Zip</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.zip || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Parent Association</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.parentAssociation || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Network</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.network === "Y"
                                  ? "Yes"
                                  : phBasicDetails.network === "N"
                                  ? "No"
                                  : "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Specialty Pharmacy</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.specialityPharmacy === "Y"
                                  ? "Yes"
                                  : phBasicDetails.specialityPharmacy === "N"
                                  ? "No"
                                  : "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Central Fill Location</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.centralFillLocation === "Y"
                                  ? "Yes"
                                  : phBasicDetails.centralFillLocation === "N"
                                  ? "No"
                                  : "--"}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                        <Grid item md={12}>
                          <Grid container spacing={2}>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Covered Entity Contract Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.ceContractDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Effective Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.effectiveDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Go-Live Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.goLiveDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Termination Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.terminatedDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>OPA Effective Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.opaEffectiveDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Fee Start Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {phBasicDetails.feeStartDate || "--"}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Pharmacy Contact Information"
                      />
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Pharmacy Contact First Name</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phBasicDetails.pharmacyContactFirstName || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Pharmacy Contact Last Name</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phBasicDetails.pharmacyContactLastName || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Phone</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phBasicDetails.phone || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Email</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phBasicDetails.email || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Primary Contact Indicator</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {phBasicDetails.primaryContactIndicator === "Y"
                              ? "Yes"
                              : phBasicDetails.primaryContactIndicator === "N"
                              ? "No"
                              : "--"}
                          </BasicTypography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
});

export default PhBasicDetails;
