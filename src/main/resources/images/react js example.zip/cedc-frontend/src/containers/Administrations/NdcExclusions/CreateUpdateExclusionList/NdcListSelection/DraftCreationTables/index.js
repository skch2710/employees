import React, {
  forwardRef,
  memo,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { Button, Grid } from "@material-ui/core";
import _get from "lodash/get";
import { useSelector } from "react-redux";
import { BsChevronLeft, BsChevronRight } from "react-icons/bs";
import NdcSearchTable from "./NdcSearchTable";
import NdcDraftTable from "./NdcDraftTable";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { NdcContext } from "../../../NdcContext";
import { useNdcTablesStyles } from "./styles";
import { pagination } from "../../../../../../utils/constants";
import {
  getDraftExcludedData,
  getSelectedRows,
} from "../../../../../../utils/helper";
import EditNdcDates from "../../EditNdcDates";
import BasicPopup from "../../../../../../components/Popup/BasicPopup";
import EditNdcDatesPopupFooter from "../../EditNdcDatesPopupFooter";

const DraftCreationTables = memo(
  forwardRef((props = {}, ref) => {
    const { searchTableProps } = props;
    const globalClasses = useGlobalStyles();
    const classes = useNdcTablesStyles();
    const {
      ndcData,
      ndcSelectionDraftTableData,
      setNdcSelectionDraftTableData,
    } = useContext(NdcContext) || {};
    const { startDate, endDate } = ndcData || {};
    const searchTableRef = useRef(null);
    const draftTableRef = useRef(null);
    const defaultValues = {
      startDate: startDate || "",
      endDate: endDate || "",
    };

    const [showEditNdcDatesPopup, setShowEditNdcDatesPopup] = useState(false);
    const [searchResults, setSearchResults] = useState({ content: [] });
    const [searchTableControllers, setSearchTableControllers] = useState({
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "",
      sortBy: "",
    });

    const { records: searchResultsInRedux } = useSelector(
      (state) => state.ndcSelectionSearchList
    );

    useEffect(() => {
      setSearchResults(searchResultsInRedux);
    }, [searchResultsInRedux]);

    const handleAddToDraft = (values) => {
      const selectedRows = getSelectedRows(searchTableRef);
      if (selectedRows.length) {
        const afterAddingDates = selectedRows.map((row) => ({
          ...row,
          ndcEffectiveStartDate: values.startDate || "",
          ndcEffectiveEndDate: values.endDate || "",
        }));
        const totalRows = [
          ...ndcSelectionDraftTableData.content,
          ...afterAddingDates,
        ];
        setNdcSelectionDraftTableData({
          content: totalRows,
          totalElements: totalRows.length,
        });
        // To unselect rows of search table. Otherwise if we removed from draft those rows are getting checked.
        const newData = searchResults.content.map((row) => ({
          ...row,
          tableData: {
            checked: false,
          },
        }));
        setSearchResults((prevData) => ({ ...prevData, content: newData }));
        setShowEditNdcDatesPopup(false);
      }
    };

    const handleEditNdcDatesPopup = (state) => {
      if (state) {
        const selectedRows = getSelectedRows(searchTableRef);
        if (selectedRows.length) {
          setShowEditNdcDatesPopup(true);
        }
      } else {
        setShowEditNdcDatesPopup(false);
      }
    };

    const handleRemoveFromDraft = () => {
      const selectedRows = getSelectedRows(draftTableRef);
      if (selectedRows.length) {
        const updatedRowData = getDraftExcludedData({
          originalList: ndcSelectionDraftTableData.content,
          draftList: selectedRows,
        });
        setNdcSelectionDraftTableData({
          content: updatedRowData,
          totalElements: updatedRowData.length,
        });
      }
    };

    useEffect(() => {
      return () =>
        setNdcSelectionDraftTableData({ content: [], totalElements: 0 });
    }, []);

    const handleValidate = (values = {}) => {
      const error = {};
      if (!values.startDate) {
        error.startDate = "Please select the NDC Effective Start Date";
      }
      return error;
    };

    return (
      <>
        <Grid container spacing={2} justifyContent="space-between">
          <Grid item className={classes.gridTableContainer}>
            <div className={globalClasses.tableCardPrimary}>
              <NdcSearchTable
                searchResults={searchResults}
                ref={{ tableRef: searchTableRef, imperativeRef: ref }}
                controllers={searchTableControllers}
                setControllers={setSearchTableControllers}
                {...searchTableProps}
              />
            </div>
          </Grid>
          <Grid item className={classes.gridActionBtnContainer}>
            <Grid
              container
              spacing={2}
              direction="column"
              alignItems="center"
              className={classes.actionButtonContainer}
            >
              <Grid item>
                <Button
                  endIcon={<BsChevronRight size={14} />}
                  variant="contained"
                  size="small"
                  className={globalClasses.primaryBtn}
                  onClick={() => handleEditNdcDatesPopup(true)}
                >
                  Add
                </Button>
              </Grid>
              <Grid item>
                <Button
                  startIcon={<BsChevronLeft size={14} />}
                  variant="contained"
                  size="small"
                  className={globalClasses.redBtn}
                  onClick={handleRemoveFromDraft}
                >
                  Remove
                </Button>
              </Grid>
            </Grid>
          </Grid>
          <Grid item className={classes.gridTableContainer}>
            <div className={globalClasses.tableCardPrimary}>
              <NdcDraftTable ref={draftTableRef} />
            </div>
          </Grid>
        </Grid>
        <BasicPopup
          title="NDC Exclusion Date"
          show={showEditNdcDatesPopup}
          disableFooter={true}
          isCustomFooter={true}
          footerActionElement={
            <EditNdcDatesPopupFooter
              handleEditNdcDatesPopup={(value) =>
                handleEditNdcDatesPopup(value)
              }
            />
          }
          dialogProps={{
            maxWidth: "md",
          }}
          withFormik={true}
          formikProps={{
            initialValues: defaultValues,
            onSubmit: handleAddToDraft,
            validate: handleValidate,
          }}
          handleClose={() => handleEditNdcDatesPopup(false)}
        >
          <EditNdcDates
            startDateProps={{
              minDate: ndcData.startDate,
              maxDate: ndcData.endDate,
              label: "NDC Effective Start Date",
            }}
            endDateProps={{
              minDate: ndcData.startDate,
              maxDate: ndcData.endDate,
              label: "NDC Effective End Date",
            }}
            selectedRows={getSelectedRows(searchTableRef)}
          />
        </BasicPopup>
      </>
    );
  })
);

export default DraftCreationTables;
