import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useContext,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../Styles/useGlobalStyles";
import { getTableHeaderCount, isEmptyGrid } from "../../../../../utils/helper";
import { pagination } from "../../../../../utils/constants";
import DataNotFound from "../../../../../components/common/DataNotFound";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import { NdcContext } from "../../NdcContext";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";
import Pagination from "../../../../../components/common/Pagination";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import DatePicker from "../../../../../components/common/DatePicker";
import moment from "moment";
import {
  exportNdcAppliedClientExclusions,
  getAppliedClientExclusion,
} from "../../../../../context/actions/NdcExclusions";
import { getNdcListsAppliedClientFiltersObject } from "../../helpers";

const AppliedClientExclusionTable = ({ historyObj }) => {
  const columnFiltersRef = useRef({});
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const theme = useTheme();
  const dispatch = useDispatch();
  const { ndcData } = useContext(NdcContext) || {};
  const tableRef = useRef(null);

  const { loading, records: searchResult = {} } =
    useSelector((state) => state.appliedClientExclusionList) || {};

  const [enableColumnFilters, setEnableColumnFilters] = useState(false);
  const [controllers, setControllers] = useState({
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
    listId: [historyObj.listId],
    listHistoryId: historyObj.listHistoryId,
  });
  const [columnFilters, setColumnFilters] = useState([]);

  const setControllersOnResp = (resp = {}, additionalStates = {}) => {
    const { pageNo, pageSize = pagination.limit } = resp;
    setControllers((prev) => {
      if (pageSize !== prev.pageSize)
        tableRef.current.dataManager.changePageSize(pageSize);
      return {
        ...prev,
        pageNumber: pageNo || pagination.page,
        pageSize: pageSize || pagination.limit,
        ...additionalStates,
      };
    });
  };

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      let rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(searchResult.totalElements / rowsPerPage) || 1;
      if (controllers.pageNumber > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
        currentPage = controllers.pageNumber;
      dispatch(
        getAppliedClientExclusion(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            filter: columnFilters,
            sortOrder: controllers.sortOrder,
            sortBy: controllers.sortBy,
            listId: [historyObj.listId],
            listHistoryId: historyObj.listHistoryId,
            isEdit: true,
          },
          (resp) => setControllersOnResp(resp)
        )
      );
    },
    [columnFilters, searchResult, controllers]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = CLIENT_EXCLUSION_COLUMNS[orderedColumnId].field;
      setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
      dispatch(
        getAppliedClientExclusion(
          {
            pageNumber: controllers.pageNumber,
            pageSize: controllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            listId: [historyObj.listId],
            listHistoryId: historyObj.listHistoryId,
            isEdit: true,
          },
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        )
      );
    },
    [controllers, columnFilters, searchResult]
  );

  const handleColumnFilter = (filters = []) => {
    const filterPayload = getNdcListsAppliedClientFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    dispatch(
      getAppliedClientExclusion(
        {
          ...controllers,
          filter: filterPayload,
          pageNumber: pagination.page,
          listId: [historyObj.listId],
          listHistoryId: historyObj.listHistoryId,
          isEdit: true,
        },
        (resp) => setControllersOnResp(resp)
      )
    );
  };

  const CLIENT_EXCLUSION_COLUMNS = [
    {
      title: "Covered Entity",
      field: "coveredEntity",
      defaultFilter: enableColumnFilters && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceName}>
            <span>{rowData.ceName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.coveredEntity}
          placeholder="Covered Entity"
        />
      ),
    },
    {
      title: "HRSA ID",
      field: "hrsaId",
      defaultFilter: enableColumnFilters && columnFiltersRef.current.hrsaId,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.hrsaId}>
            <span>{rowData.hrsaId}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.hrsaId}
          placeholder="HRSA ID"
        />
      ),
    },
    {
      title: "Pharmacy Chain",
      field: "pharmacyChain",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.pharmacyChain,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyChain}>
            <span>{rowData.pharmacyChain}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyChain}
          placeholder="Pharmacy Chain"
        />
      ),
    },
    {
      title: "Pharmacy Store",
      field: "pharmacyStore",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.pharmacyStore,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyStore}>
            <span>{rowData.pharmacyStore}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyStore}
          placeholder="Pharmacy Store"
        />
      ),
    },
    {
      title: "Pharmacy NPI",
      field: "pharmacyNpi",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.pharmacyNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyNpi}>
            <span>{rowData.pharmacyNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.pharmacyNpi}
          placeholder="Pharmacy NPI"
        />
      ),
    },
    {
      title: "Exclusion Applied Start Date",
      field: "startDate",
      defaultFilter:
        enableColumnFilters &&
        columnFiltersRef.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.startDate
                ? moment(columnFiltersRef.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Exclusion Applied End Date",
      field: "endDate",
      defaultFilter:
        enableColumnFilters && columnFiltersRef.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.endDate
                ? moment(columnFiltersRef.current.endDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const TABLE_ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableColumnFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(searchResult),
      onClick: () => {
        setEnableColumnFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportToExcel(),
      disabled: isEmptyGrid(searchResult),
      isFreeAction: true,
      onClick: () => {
        dispatch(
          exportNdcAppliedClientExclusions({
            pageNumber: pagination.page,
            pageSize: pagination.limit,
            sortBy: controllers.sortBy || "",
            sortOrder: controllers.sortOrder || "",
            export: true,
            filter: columnFilters,
            listId: [historyObj.listId],
            listHistoryId: historyObj.listHistoryId,
            downloadFlag: true,
          })
        );
      },
    },
  ];

  useEffect(() => {
    fetchAppliedClientExclusion();
  }, [historyObj]);

  const fetchAppliedClientExclusion = () => {
    dispatch(
      getAppliedClientExclusion(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "asc",
          filter: [],
          export: false,
          filter: columnFilters,
          listId: [historyObj.listId],
          listHistoryId: historyObj.listHistoryId,
          isEdit: true,
        },
        (resp) => setControllersOnResp(resp)
      )
    );
  };

  return (
    <div className={globalClasses.tableCardPrimary}>
      <MaterialTable
        title={
          <BasicTypography
            variant="h5"
            title={`Applied Client Exclusions (${getTableHeaderCount(
              searchResult.totalElements
            )})`}
          />
        }
        tableRef={tableRef}
        columns={CLIENT_EXCLUSION_COLUMNS}
        data={(searchResult && searchResult.content) || []}
        page={controllers.pageNumber - 1}
        totalCount={searchResult.totalElements}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={TABLE_ACTIONS}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Pagination: (props) => <Pagination {...props} />,
          Toolbar: (props) => (
            <MTableToolbar
              classes={{ root: globalClasses.gridMuiToolbar }}
              {...props}
            />
          ),
          OverlayLoading: () => <TableProgressBar />,
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
          },
        }}
        isLoading={loading}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableColumnFilters,
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "bottom",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: getTableHeaderStyles(theme),
          cellStyle: getTableCellStyles(theme),
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controllers.pageSize,
          maxBodyHeight: 400,
          minBodyHeight: 100,
          pageSizeOptions: isEmptyGrid(searchResult)
            ? []
            : pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default AppliedClientExclusionTable;
