import React, {
  memo,
  useState,
  useRef,
  forwardRef,
  useCallback,
  useImperativeHandle,
} from "react";
import { useDispatch } from "react-redux";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip, useTheme, Grid } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { pagination } from "../../../../utils/constants";
import {
  getZeroValueInTotalElements,
  undefinedArrayContent,
} from "../../../../utils/common";
import moment from "moment";
import DatePicker from "../../../../components/common/DatePicker";
import { useInvoiceStyles } from "../styles";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { getInvoiceFiltersObject } from "../helper";
import { isEmptyGrid } from "../../../../utils/helper";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import ActionsView from "./ActionsView";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
  getTableNumericHeaderStyles,
  getTableActionCellStyles,
} from "../../../../Styles/useGlobalStyles";
import { getZipFolder } from "../../../../context/actions/Invoice";
import { formatValue } from "../../../../utils/common";
import DataNotFound from "../../../../components/common/DataNotFound";
import useFileExport from "./useFileExport";
import useFileExportRowData from "./useFileExportRowData";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const InvoiceMainList = forwardRef(
  (
    {
      InvoiceMainListData,
      formRef,
      fetchInvoicedetails,
      loading,
      count,
      formSubmittedValues,
      enableFilters,
      setEnableFilters,
      searchFilterValues,
      InvoiceControllers,
      setInvoiceControllers,
      filtersValues,
    },
    ref
  ) => {
    const globalClasses = useGlobalStyles();
    const dispatch = useDispatch();
    const theme = useTheme();
    const { exportToExcel } = useFileExport();
    const { rowDataExport } = useFileExportRowData();
    const { RangePicker } = DatePicker;
    const iconsAndButtons = useTableIconsAndButtons();
    const [controller, setController] = useState({
      page: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "asc",
      sortBy: "ceName",
    });
    const [openPopup, setOpenPopup] = useState(false);
    const [columnFilters, setColumnFilters] = useState([]);
    const [rowData, setRowData] = useState({});
    const [TrueUpPopup, setTrueUpPopup] = useState(false);
    const [actiontitle, setActionTitle] = useState("");
    const [showInnerGridItemInfo, setShowInnerGridItemInfo] = useState(false);
    const tableRef = useRef(null);
    const columnFiltersRef = useRef({});

    const classes = useInvoiceStyles({
      totalElements: InvoiceMainListData.totalElements,
      pageSize: controller.pageSize,
      pageNumber: controller.page,
    });

    const setControllersOnResp = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setController((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          pageNumber: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    useImperativeHandle(ref, () => ({
      clearForm(initialValues) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        fetchInvoicedetails(initialValues, (resp) =>
          setControllersOnResp(resp)
        );
      },
      submitForm(resp) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        setControllersOnResp(resp);
      },
    }));

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        const rowsPerPage = Number(pageSize);
        const totalPages =
          Math.ceil(InvoiceMainListData.totalElements / rowsPerPage) || 1;
        if (controller.page > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controller.pageSize)
          currentPage = controller.page;
        fetchInvoicedetails(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: controller.sortOrder,
            sortBy: controller.sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp)
        );
      },
      [columnFilters, controller, formSubmittedValues, InvoiceMainListData]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = INVOICE_LIST[orderedColumnId].field;
        setController((prev) => ({ ...prev, sortOrder, sortBy }));
        fetchInvoicedetails(
          {
            pageNumber: controller.page,
            pageSize: controller.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        );
      },
      [controller, formSubmittedValues, columnFilters]
    );

    const handleColumnFilter = (filters) => {
      const { isSubmitting } = (formRef && formRef.current) || {};
      const filterPayload = getInvoiceFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      fetchInvoicedetails(
        {
          ...InvoiceControllers,
          filter: filterPayload,
          ...(isSubmitting ? formSubmittedValues : {}),
        },
        (resp) => setControllersOnResp(resp)
      );
    };

    const ColumnFilterIcon = () => {
      return <TiFilter fontSize="small" />;
    };

    const downloadPdf = (rowData) => {
      const Payload = {
        ceid: rowData.ceId,
        startDate: rowData.invoicePeriodStartDate,
        endDate: rowData.invoicePeriodEndDate,
        phGroupId: filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
        phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
        isMainResult: 0,
      };
      dispatch(getZipFolder(Payload, rowData));
    };

    const INVOICE_LIST = [
      {
        title: "Covered Entity",
        field: "ceName",
        defaultFilter: enableFilters && columnFiltersRef.current.ceName,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.ceName}>
              <span>{rowData.ceName}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.ceName}
            placeholder="Covered Entity"
          />
        ),
      },
      {
        title: "Invoice Number",
        field: "invoiceNumber",
        defaultFilter: enableFilters && columnFiltersRef.current.invoiceNumber,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.invoiceNumber}>
              <span>{rowData.invoiceNumber}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.invoiceNumber}
            placeholder="Invoice Number"
          />
        ),
      },

      {
        title: "Billing Period",
        field: "invoicePeriodStartDate",
        defaultFilter: enableFilters && columnFiltersRef.current.billingPeriod,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip
              title={`${rowData.invoicePeriodStartDate}-${rowData.invoicePeriodEndDate}`}
            >
              <span>
                {rowData.invoicePeriodStartDate}-{rowData.invoicePeriodEndDate}
              </span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.billingPeriod}
            placeholder="Billing Period"
          />
        ),
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.invoicePeriodStartDate
                  ? moment(columnFiltersRef.current.invoicePeriodStartDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "Pharmacy EAC",
        field: "totalInvoiced",
        type: "numeric",
        defaultFilter: enableFilters && columnFiltersRef.current.totalInvoiced,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.totalInvoiced}>
                  <span className={globalClasses.tableNumericPadding}>
                    {formatValue(rowData.totalInvoiced)}
                  </span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.totalInvoiced}
            placeholder="Pharmacy EAC"
          />
        ),
        headerStyle: {
          ...getTableHeaderStyles(theme),
          ...getTableNumericHeaderStyles(),
        },
      },
      {
        title: "Dispensing Fees",
        field: "dispensingFee",
        type: "numeric",
        defaultFilter: enableFilters && columnFiltersRef.current.dispensingFee,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.dispensingFee}>
                  <span className={globalClasses.tableNumericPadding}>
                    {formatValue(rowData.dispensingFee)}
                  </span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.dispensingFee}
            placeholder="Dispensing Fees"
          />
        ),
        headerStyle: {
          ...getTableHeaderStyles(theme),
          ...getTableNumericHeaderStyles(),
        },
      },
      {
        title: "True Up Fees",
        field: "trueUp",
        type: "numeric",
        defaultFilter: enableFilters && columnFiltersRef.current.trueUp,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.trueUp}>
                  <span className={globalClasses.tableNumericPadding}>
                    {formatValue(rowData.trueUp)}
                  </span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.trueUp}
            placeholder="True Up Fees"
          />
        ),
        headerStyle: {
          ...getTableHeaderStyles(theme),
          ...getTableNumericHeaderStyles(),
        },
      },
      {
        title: "Net Remittance",
        field: "ceTotalReceivedAmount",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.ceTotalReceivedAmount,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.ceTotalReceivedAmount}>
                  <span className={globalClasses.tableNumericPadding}>
                    {formatValue(rowData.ceTotalReceivedAmount)}
                  </span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.ceTotalReceivedAmount}
            placeholder="Net Remittance"
          />
        ),
        headerStyle: {
          ...getTableHeaderStyles(theme),
          ...getTableNumericHeaderStyles(),
        },
      },
      {
        title: "340BDirect+ Fees",
        field: "direct340BTrxnFee",
        type: "numeric",
        defaultFilter:
          enableFilters && columnFiltersRef.current.direct340BTrxnFee,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Grid container spacing={1} justifyContent="space-between">
              <Grid item md={2}>
                $
              </Grid>
              <Grid item md={10}>
                <Tooltip title={rowData.direct340BTrxnFee}>
                  <span className={globalClasses.tableNumericPadding}>
                    {formatValue(rowData.direct340BTrxnFee)}
                  </span>
                </Tooltip>
              </Grid>
            </Grid>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.direct340BTrxnFee}
            placeholder="340BDirect+ Fees"
          />
        ),
        headerStyle: {
          ...getTableHeaderStyles(theme),
          ...getTableNumericHeaderStyles(),
        },
      },
    ];

    const actions = [
      {
        icon: iconsAndButtons.View(),
        tooltip: "View",
        isFreeAction: false,
        onClick: (event, rowData) => {
          setOpenPopup(true);
          setRowData(rowData);
          setActionTitle(`Total Covered Entity Receivable Report`);
        },
      },
      {
        icon: iconsAndButtons.ExportRowLevel(),
        tooltip: "Export",
        isFreeAction: false,
        onClick: (event, rowData) => {
          setRowData(rowData);
          downloadPdf(rowData);
        },
      },
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        isFreeAction: true,
        disabled: count < 1,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportButton({
          disabled: isEmptyGrid(InvoiceMainListData),
        }),
        isFreeAction: true,
        disabled: isEmptyGrid(InvoiceMainListData),
        onClick: () =>
          exportToExcel({
            formRef,
            controller,
            columnFilters,
          }),
      },
    ];
    return (
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Invoice List (${getZeroValueInTotalElements(
                InvoiceMainListData
              )})`}
            />
          }
          columns={INVOICE_LIST}
          data={undefinedArrayContent(InvoiceMainListData)}
          page={controller.page - 1}
          totalCount={InvoiceMainListData.totalElements || 0}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          tableRef={tableRef}
          icons={{
            SortArrow: () => TableCustomSortArrow(controller),
            Filter: ColumnFilterIcon,
          }}
          actions={actions}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: InvoiceControllers.pageSize,
            maxBodyHeight: 400,
            minBodyHeight: 100,
            pageSizeOptions: isEmptyGrid(InvoiceMainListData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
        <BasicPopup
          title={rowData.ceName}
          show={openPopup}
          disableFooter={true}
          dialogProps={{
            maxWidth: "lg",
          }}
          handleClose={() => setOpenPopup(false)}
        >
          <ActionsView rowData={rowData} filtersValues={filtersValues} />
        </BasicPopup>
      </div>
    );
  }
);

export default memo(InvoiceMainList);
