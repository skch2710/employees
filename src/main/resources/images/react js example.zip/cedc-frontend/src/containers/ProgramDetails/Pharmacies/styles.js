import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const usePharmacyFiltersStyles = makeStyles((_theme) => {
  return {
    filterHeader: {
      display: "flex",
      justifyContent: "space-between",
    },
    actionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
      gap: "10px",
    },
  };
});

export const usePharmaciesTableStyles = makeStyles((_theme) => {
  return {
  };
});

export const usePhStyles = makeStyles((_theme) => {
  return {
    configurationWrapper: {
      paddingTop: "15px",
    },
    configGlobalActionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
      gap: "10px",
      alignItems: "center",
    },
  };
});
