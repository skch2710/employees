import React, { lazy, Suspense, useContext, memo, useState } from "react";
import { Redirect, Route, Switch, useRouteMatch } from "react-router-dom";
import LoaderUI from "../../components/common/Loader/Loader";
import { COContext } from "./COContext";
import AddCoveredEntity from "./ConfigurationOverview/AddCoveredEntity";
import { useProgramDetailsStyles } from "./styles";

const ConfigOverview = lazy(() => import("./ConfigurationOverview"));
const PreferredLocation = lazy(() => import("./Locations/PreferredLocation"));
const Pharmacies = lazy(() => import("./Pharmacies"));
const ComingSoon = lazy(() => import("../../components/common/comingsoon"));
const BasicPopup = lazy(() => import("../../components/Popup/BasicPopup"));

const ProgramDetails = memo(() => {
  const { path } = useRouteMatch();
  const classes = useProgramDetailsStyles();
  const { openAddCePopup, setOpenAddCePopup, coveredEntityName } =
    useContext(COContext);

  const [clickOnAdd, setclickOnAdd] = useState(false);

  return (
    <Suspense fallback={<LoaderUI />}>
      <Switch>
        <Redirect exact from={`${path}`} to={`${path}/configurationoverview`} />
        <Route
          path={`${path}/configurationoverview`}
          render={() => (
            <>
              <ConfigOverview setclickOnAdd={setclickOnAdd} />
            </>
          )}
        />
        <Route
          exact
          path={`${path}/coveredentitylocations`}
          component={PreferredLocation}
        />
        <Route exact path={`${path}/configurations`} component={ComingSoon} />
        <Route exact path={`${path}/pharmacies`} component={Pharmacies} />
      </Switch>
      <BasicPopup
        title={`${coveredEntityName}`}
        show={openAddCePopup}
        handleClose={() => {
          setOpenAddCePopup(false);
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
      >
        <AddCoveredEntity
          clickOnAdd={clickOnAdd}
          setclickOnAdd={setclickOnAdd}
        />
      </BasicPopup>
    </Suspense>
  );
});

export default ProgramDetails;
