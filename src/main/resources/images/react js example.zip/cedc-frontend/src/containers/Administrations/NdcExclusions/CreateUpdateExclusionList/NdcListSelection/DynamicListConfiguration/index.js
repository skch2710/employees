import React, { forwardRef, memo, useEffect, useState } from "react";
import { Checkbox, FormControlLabel, FormLabel, Grid } from "@material-ui/core";
import { Form, Formik } from "formik";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useNdcSelectionStyles } from "../styles";
import { LABELS } from "../../../../../../utils/constants";
import DynamicListParametersTable from "./DynamicListParametersTable";
import _get from "lodash/get";
import { useSelector } from "react-redux";

const DynamicListConfiguration = memo(() => {
  const classes = useNdcSelectionStyles();

  const { records: ndcDynamicListData } = useSelector(
    (state) => state.ndcDynamicListParams
  );
  const isDefaultChecked = _get(ndcDynamicListData, "content", []).length > 0;

  const [defaultValues, setDefaultValues] = useState({
    applyNdcExclusionsAutomatically: isDefaultChecked,
  });

  useEffect(() => {
    setDefaultValues({
      applyNdcExclusionsAutomatically: isDefaultChecked,
    });
  }, [ndcDynamicListData]);

  return (
    <Formik initialValues={defaultValues} enableReinitialize={true}>
      {({ setFieldValue, values }) => {
        return (
          <Form>
            <div className={classes.greyCard}>
              <Grid item md={12}>
                <BasicTypography
                  variant="h6"
                  className={classes.dlpSectionTitle}
                >
                  Apply System Updates
                </BasicTypography>
              </Grid>
              <Grid item>
                <Grid container spacing={2}>
                  <Grid item sm={12}>
                    <FormControlLabel
                      className={classes.autoApplyExclusionsCheckBox}
                      control={
                        <Checkbox
                          name="applyNdcExclusionsAutomatically"
                          color="primary"
                          size="small"
                          onClick={(e) => {
                            const { checked } = e.target;
                            setFieldValue(
                              "applyNdcExclusionsAutomatically",
                              checked
                            );
                          }}
                          disabled={isDefaultChecked}
                          checked={values.applyNdcExclusionsAutomatically}
                        />
                      }
                      label={
                        <FormLabel>
                          {LABELS.NdcSelectionAutomaticExclusions}
                        </FormLabel>
                      }
                    />
                  </Grid>
                  {values.applyNdcExclusionsAutomatically && (
                    <Grid item sm={12}>
                      <DynamicListParametersTable />
                    </Grid>
                  )}
                </Grid>
              </Grid>
            </div>
          </Form>
        );
      }}
    </Formik>
  );
});
export default DynamicListConfiguration;
