import {
  Button,
  FormLabel,
  Grid,
  Typography,
  useTheme,
} from "@material-ui/core";
import { Tooltip as MuiTooltip } from "@mui/material";
import _get from "lodash/get";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { IoIosHelpCircle } from "react-icons/io";
import { RiFileExcel2Fill } from "react-icons/ri";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  Bar,
  BarChart,
  Brush,
  Legend,
  Pie,
  PieChart,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import ActiveLocations from "../../assets/Icon-active-location.png";
import ActivePatients from "../../assets/Icon-active-patient.png";
import ActivePharmacies from "../../assets/Icon-active-pharmacies.png";
import ActiveProviders from "../../assets/Icon-active-providers.png";
import InvoicedClaims from "../../assets/Icon-invoiced-claims.png";
import InvoicedSavings from "../../assets/Icon-invoiced-savings.png";
import BasicPopup from "../../components/Popup/BasicPopup";
import AutoComplete from "../../components/common/AutoComplete";
import DatePicker from "../../components/common/DatePicker";
import LoaderUI from "../../components/common/Loader/Loader";
import BasicTypography from "../../components/common/Typography/BasicTypography";
import {
  HomeActivCountslocations,
  HomeActivCountspatients,
  HomeActivCountspharmacies,
  HomeActivCountsproviders,
  Homebarchatsavbypharma,
  Homeclaimsavings,
  Homefalloutfirstfiverecords,
  Homefalloutfirstpiechart,
  Homeinventoryreplirecords,
  Homeunreplinvsecoundpiechart,
  invoiceCycle,
  totalUnrealizedSavingsCOGS,
} from "../../context/actions/Home";
import {
  GetCEPharmacyGroup,
  Getpharmacystorevalues,
} from "../../context/actions/Inventory";
import { SAVE_BY_PHARMA_BAR_CHART_DATA } from "../../context/constants";
import { formatValue, formatValueFromString } from "../../utils/common";
import { ERROR, LABELS } from "../../utils/constants";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../utils/helper";
import ViewFullreportdonut1 from "./ViewFullreportdonut1";
import ViewFullreportdonut2 from "./ViewFullreportdonut2";
import { useStyles } from "./styles";
import useFileExportSavingsByPh from "./useFileExportSavingsByPh";

const Home = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const globalClasses = useGlobalStyles();
  const theme = useTheme();
  const [ceName, setceName] = useState("");
  const classes = useStyles();
  const user = getUserSession();
  const [showFullReportOppByPh, setShowFullReportOppByPh] = useState(false);
  const [showFullReportUnrep, setShowFullReportUnrep] = useState(false);
  const { ceList } = useSelector((state) => state.coveredEntities) || [];
  const [ceId, setCeId] = useState(user.coveredEntityDTOs[0].ceID);
  const [getHomeclaimsavings, setgetHomeclaimsavings] = useState({});
  const [getTotalUnrealizedSavingsCOGS, setgetTotalUnrealizedSavingsCOGS] =
    useState({});

  const locationsPermissions = getUserPermissionOnModuleName(
    "Covered Entity Locations"
  );
  const pharmaciesPermissions = getUserPermissionOnModuleName("Pharmacies");
  const providersPermissions = getUserPermissionOnModuleName("Providers");
  const patientsPermissions = getUserPermissionOnModuleName("Patients");

  const [getHomefalloutfirstpiechart, setgetHomefalloutfirstpiechart] =
    useState({});
  const [getHomefalloutfirstfiverecords, setgetHomefalloutfirstfiverecords] =
    useState({});
  const [getHomeunreplinvsecoundpiechart, setgetHomeunreplinvsecoundpiechart] =
    useState({});
  const [getHomeinventoryreplirecords, setgetHomeinventoryreplirecords] =
    useState({});

  const getHomeBarChatSavingByPharma =
    useSelector((state) => state.getHomeBarChatSavingByPharma.records) || [];
  const { exportToExcel } = useFileExportSavingsByPh();
  const [Pgroup, setPgroup] = useState(0);
  const [Pstore, setPstore] = useState(0);
  const [dateError, setDateError] = useState(false);
  const [navigateToLoc, setNavigateToLoc] = useState(true);
  const [navigateToPR, setNavigateToPR] = useState(true);
  const [navigateToPH, setNavigateToPH] = useState(true);
  const [navigateToPA, setNavigateToPA] = useState(true);

  const onClickOppByPh = () => {
    setShowFullReportOppByPh(true);
  };

  const exportSavingsByPharmacy = () => {
    exportToExcel({
      ceId,
      Pstore,
      Pgroup,
      startdate,
      enddate,
    });
  };

  const locationsActiveCount = () => {
    const url = history.push(
      `/program-details/coveredentitylocations?ceId=${ceId}`
    );
  };

  const patientsActiveCount = () => {
    const url = history.push(`/eligibility/patients?ceId=${ceId}`);
  };

  const pharmaciesActiveCount = () => {
    const url = history.push(`/program-details/pharmacies?ceId=${ceId}`);
  };

  const providersActiveCount = () => {
    const url = history.push(`/eligibility/providers?ceId=${ceId}`);
  };

  const onClickUnrepInv = () => {
    setShowFullReportUnrep(true);
  };

  const currentDate = moment().format("MM/DD/YYYY");
  const thirtyDaysBackDate = moment().subtract(1, "month").format("MM/DD/YYYY");
  const [startdate, setstartdate] = useState(thirtyDaysBackDate);
  const [enddate, setenddate] = useState(currentDate);

  const [resetNoticeProps, setResetNoticeProps] = useState({
    show: false,
    remainingDays: 0,
  });

  const popupData = JSON.parse(
    localStorage.getItem("passwordResetNoticeData") || "{}"
  );
  const userSession = localStorage.getItem("sessionslogindata") || "{}";
  const isInternalUser = JSON.parse(userSession).isInternalUser;

  const setRemainingDays = () => {
    const currDate = moment(new Date()).format("YYYY-MM-DD");
    const lastPasswordResetDate = JSON.parse(userSession).lastPasswordResetDate;
    const lastPassResetDate = moment(lastPasswordResetDate).utc().format();
    const expDateFiveDaysBefore = moment(lastPassResetDate)
      .add(85, "d")
      .format();
    const diff = moment(new Date()).diff(expDateFiveDaysBefore, "days");
    if (diff >= 0 && diff < 5) {
      setResetNoticeProps({
        show: true,
        remainingDays: 5 - diff,
      });
      const storeObj = {
        ...popupData,
        [JSON.parse(userSession).emailId]: currDate,
      };
      localStorage.setItem("passwordResetNoticeData", JSON.stringify(storeObj));
    }
  };

  useEffect(() => {
    if (ceList.length === 1) {
      setceName(ceList[0].ceName + " - ");
    }
    const isFromLogin = _get(history, "location.state.from", "") === "login";
    if (isFromLogin && !user.isInternalUser) {
      const popupShownDate = popupData[JSON.parse(userSession).emailId];
      if (popupShownDate) {
        const currDate = moment(new Date()).format("YYYY-MM-DD");
        const isSameDay = moment(popupShownDate).isSame(currDate);
        if (!isSameDay) {
          setRemainingDays();
        }
      } else {
        setRemainingDays();
      }
    }
  }, []);

  const getPharmacygroupvalues =
    useSelector((state) => state.getPharmacygroupvalues.records) || [];

  useEffect(() => {
    dispatch(HomeActivCountslocations({ ceId: ceId }));
    dispatch(HomeActivCountspatients({ ceId: ceId }));
    dispatch(HomeActivCountspharmacies({ ceId: ceId }));
    dispatch(HomeActivCountsproviders({ ceId: ceId }));
    dispatch(GetCEPharmacyGroup({ ceid: [ceId] }));
    getHomeBarChatSavingByPharma.length = 0;
  }, [ceId]);

  const handleChangePstore = (e, value) => {
    setPstore(_get(value, "phid", 0));
    if (Number(value) === 0) {
      dispatch({ type: SAVE_BY_PHARMA_BAR_CHART_DATA, data: {} });
    }
  };

  useEffect(() => {
    if (
      !locationsPermissions.readOnlyFlag &&
      !locationsPermissions.readWriteFlag &&
      !locationsPermissions.terminateFlag
    ) {
      setNavigateToLoc(false);
    }
    if (
      !pharmaciesPermissions.readOnlyFlag &&
      !pharmaciesPermissions.readWriteFlag &&
      !pharmaciesPermissions.terminateFlag
    ) {
      setNavigateToPH(false);
    }
    if (
      !providersPermissions.readOnlyFlag &&
      !providersPermissions.readWriteFlag &&
      !providersPermissions.terminateFlag
    ) {
      setNavigateToPR(false);
    }
    if (
      !patientsPermissions.readOnlyFlag &&
      !patientsPermissions.readWriteFlag &&
      !patientsPermissions.terminateFlag
    ) {
      setNavigateToPA(false);
    }
  });

  useEffect(() => {
    dispatch(
      Homefalloutfirstpiechart(
        {
          ceid: ceId,
          phid: Pstore,
          phGroupId: Pgroup,
          processedStartDate: startdate,
          processedEndDate: enddate,
        },
        setgetHomefalloutfirstpiechart
      )
    );
    dispatch(
      Homeunreplinvsecoundpiechart(
        {
          ceid: ceId,
          phid: Pstore,
          phGroupId: Pgroup,
          processedStartDate: startdate,
          processedEndDate: enddate,
        },
        setgetHomeunreplinvsecoundpiechart
      )
    );
    dispatch(
      Homefalloutfirstfiverecords(
        {
          ceid: ceId,
          phid: Pstore,
          phGroupId: Pgroup,
          processedStartDate: startdate,
          processedEndDate: enddate,
        },
        setgetHomefalloutfirstfiverecords
      )
    );
    dispatch(
      Homeinventoryreplirecords(
        {
          ceid: ceId,
          phid: Pstore,
          phGroupId: Pgroup,
          processedStartDate: startdate,
          processedEndDate: enddate,
        },
        setgetHomeinventoryreplirecords
      )
    );
    dispatch(
      totalUnrealizedSavingsCOGS(
        {
          ceid: ceId,
          phid: Pstore,
          phGroupId: Pgroup,
          processedStartDate: startdate,
          processedEndDate: enddate,
        },
        setgetTotalUnrealizedSavingsCOGS
      )
    );
    const payload = {
      startDate: startdate,
      endDate: enddate,
    };
    dispatch(
      invoiceCycle(payload, (response) => {
        if (
          response &&
          response.length > 0 &&
          response != undefined &&
          response != []
        ) {
          dispatch(
            Homeclaimsavings(
              {
                ceid: ceId,
                phid: Pstore,
                phGroupId: Pgroup,
                processedStartDate: response[0].startDate,
                processedEndDate: response[0].endDate,
              },
              setgetHomeclaimsavings
            )
          );
        } else {
          setgetHomeclaimsavings({});
          setgetTotalUnrealizedSavingsCOGS({});
        }
      })
    );
    dispatch(
      Homebarchatsavbypharma({
        ceid: ceId,
        phid: Pstore,
        phGroupId: Pgroup,
        processedStartDate: startdate,
        processedEndDate: enddate,
      })
    );
  }, [ceId, startdate, enddate, Pstore, Pgroup]);

  let getHomeActivCountslocations = useSelector(
    (state) => state.getHomeActivCountslocations.records
  );

  let getHomeActivCountspatients = useSelector(
    (state) => state.getHomeActivCountspatients.records
  );
  let getHomeActivCountspharmacies = useSelector(
    (state) => state.getHomeActivCountspharmacies.records
  );
  let getHomeActivCountsproviders = useSelector(
    (state) => state.getHomeActivCountsproviders.records
  );
  const loader = useSelector(
    (state) => state.getHomeActivCountslocations.loading
  );
  const getPharmacystorevalues =
    useSelector((state) => state.getPharmacystorevalues.records) || [];

  const handleChangeForCiId = (e) => {
    setCeId(Number(e));
    setstartdate(thirtyDaysBackDate);
    setenddate(currentDate);
    setPstore(0);
    setPgroup(0);
    let json = {
      ceid: [0],
      phGroupId: [0],
    };
    dispatch(Getpharmacystorevalues(json));
  };

  const handleChangePgroup = (e, value) => {
    if (Number(value) === 0) {
      dispatch({ type: SAVE_BY_PHARMA_BAR_CHART_DATA, data: {} });
    }
    setPgroup(_get(value, "phGroupId", 0));
    setPstore(0);
    let json = {
      ceid: [ceId],
      phGroupId: [_get(value, "phGroupId", 0)],
    };
    dispatch(Getpharmacystorevalues(json));
  };
  const donut1 = [];
  const donut2 = [];

  const fillColors = [
    theme.colors.graphColors.green,
    theme.colors.grey.default,
    theme.colors.graphColors.dark,
    theme.colors.yellow.default,
    theme.colors.red[400],
  ];

  if (getHomefalloutfirstpiechart && getHomefalloutfirstpiechart.length > 0) {
    getHomefalloutfirstpiechart.map((obj, index) => {
      let legendName = "";
      if (!obj.falloutReason) {
        legendName = "";
      } else {
        if (obj.falloutReason.length > 15) {
          legendName = obj.falloutReason.slice(0, 15) + "...";
        } else {
          legendName = obj.falloutReason;
        }
      }
      donut1.push({
        name: legendName,
        label: obj.falloutReason ? obj.falloutReason : "",
        value: obj.savings,
        fill: fillColors[index],
      });
    });
  }

  if (
    getHomeunreplinvsecoundpiechart &&
    getHomeunreplinvsecoundpiechart.length > 0
  ) {
    getHomeunreplinvsecoundpiechart.map((obj, index) => {
      donut2.push({
        name: obj.brandGenericFlag,
        label: obj.brandGenericFlag,
        value: obj.unreplenishedInventoryCost,
        fill: fillColors[index],
      });
    });
  }

  const PiechartCustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <Grid container>
          <Grid item>
            <Grid container spacing={1}>
              <Grid className={classes.toolTip} item>
                <Typography>
                  {`${payload[0].payload.label} : `}
                  <span className={classes.chartValues}>
                    ${formatValue(payload[0].value)}
                  </span>
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      );
    }
    return null;
  };
  const BarchartCustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <Grid className={classes.barCharToolTip} container spacing={1}>
          <Grid container spacing={1}>
            <Grid item>
              <span className={classes.dotTIC}></span>
            </Grid>
            <Grid item className={classes.chartValues}>
              ${formatValue(payload[0].value)}
            </Grid>
            <Grid item>
              <Typography>Total Invoiced Claims</Typography>
            </Grid>
          </Grid>
          <Grid container spacing={1}>
            <Grid item>
              <Grid container spacing={1}>
                <Grid item>
                  <span className={classes.dotCgs}></span>
                </Grid>
                <Grid item className={classes.chartValues}>
                  ${formatValue(payload[1].value)}
                </Grid>
                <Grid item>
                  <Typography>Cost of Goods Sold</Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid container spacing={1}>
            <Grid item>
              <Grid container spacing={1}>
                <Grid item>
                  <span className={classes.dotSavings}></span>
                </Grid>
                <Grid item className={classes.chartValues}>
                  ${formatValue(payload[2].value)}
                </Grid>
                <Grid item>
                  <Typography>Total Invoiced Savings</Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      );
    }
    return null;
  };

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={12}>
          <Grid container spacing={2}>
            <Grid
              item
              xs={isInternalUser ? 2 : 12}
              md={isInternalUser ? 2 : 12}
            >
              <BasicTypography variant="h1">
                {`${ceName} Dashboard`}
              </BasicTypography>
            </Grid>
            <Grid item xs={7}>
              {isInternalUser !== false ? (
                <Grid item xs={12} sm={7}>
                  <FormLabel>Select Covered Entity</FormLabel>
                  <AutoComplete
                    disabled={ceList && ceList.length > 1 ? false : true}
                    options={_isArray(ceList) ? ceList : []}
                    inputPlaceholder={"Select Covered Entity"}
                    disableCloseOnSelect={false}
                    disableClearable={true}
                    onChange={(e, value) => {
                      if (!_isEmpty(value)) handleChangeForCiId(value.ceID);
                    }}
                    getOptionLabel={(option) => option.ceName || ""}
                    value={
                      (_isArray(ceList) &&
                        ceList.find((e) => e.ceID == ceId)) ||
                      ""
                    }
                    renderOption={(option, _other) => {
                      return (
                        <BasicTypography variant="subtitle2">
                          {option.ceName}
                        </BasicTypography>
                      );
                    }}
                    multiple={false}
                    textFieldProps={{
                      inputProps: {
                        name: "ceid",
                      },
                    }}
                  />
                </Grid>
              ) : null}
            </Grid>
            <Grid
              item
              xs={isInternalUser ? 3 : 5}
              className={classes.headerRefreshText}
            ></Grid>
          </Grid>
        </Grid>
        <Grid item md={12}>
          <div className={globalClasses.cardPrimary}>
            <Grid>
              <BasicTypography variant="h5" className={classes.programStats}>
                Program Stats
                <MuiTooltip
                  title="Dashboard data gets updated hourly."
                  placement="right-start"
                  componentsProps={{
                    tooltip: {
                      className: classes.programStatsTooltip,
                    },
                  }}
                >
                  <span>
                    <IoIosHelpCircle />
                  </span>
                </MuiTooltip>
              </BasicTypography>
            </Grid>

            <Grid container spacing={2}>
              <Grid item sm={6} xs={12} md={6} lg={3}>
                {navigateToLoc ? (
                  <div
                    onClick={locationsActiveCount}
                    className={classes.cardSecondary}
                  >
                    <Grid>
                      <BasicTypography variant="h5" title="Active Locations" />
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountslocations,
                            "[0].activeLocationCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActiveLocations} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                ) : (
                  <div
                    title={ERROR.PERMISSION_DENIED_MSG}
                    className={globalClasses.cardSecondary}
                  >
                    <Grid>
                      <MuiTooltip title={ERROR.PERMISSION_DENIED_MSG}>
                        <BasicTypography
                          variant="h5"
                          title="Active Locations"
                        />
                      </MuiTooltip>
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountslocations,
                            "[0].activeLocationCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActiveLocations} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                )}
              </Grid>
              <Grid item sm={6} xs={12} md={6} lg={3}>
                {navigateToPA ? (
                  <div
                    onClick={patientsActiveCount}
                    className={classes.cardSecondary}
                  >
                    <Grid>
                      <BasicTypography variant="h5" title="Active Patients" />
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountspatients,
                            "[0].activePatientCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActivePatients} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                ) : (
                  <div
                    title={ERROR.PERMISSION_DENIED_MSG}
                    className={globalClasses.cardSecondary}
                  >
                    <Grid>
                      <MuiTooltip title={ERROR.PERMISSION_DENIED_MSG}>
                        <BasicTypography variant="h5" title="Active Patients" />
                      </MuiTooltip>
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountspatients,
                            "[0].activePatientCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActivePatients} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                )}
              </Grid>
              <Grid item sm={6} xs={12} md={6} lg={3}>
                {navigateToPH ? (
                  <div
                    onClick={pharmaciesActiveCount}
                    className={classes.cardSecondary}
                  >
                    <Grid>
                      <BasicTypography variant="h5" title="Active Pharmacies" />
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountspharmacies,
                            "[0].activePharmacyCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActivePharmacies} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                ) : (
                  <div
                    title={ERROR.PERMISSION_DENIED_MSG}
                    className={globalClasses.cardSecondary}
                  >
                    <Grid>
                      <MuiTooltip title={ERROR.PERMISSION_DENIED_MSG}>
                        <BasicTypography
                          variant="h5"
                          title="Active Pharmacies"
                        />
                      </MuiTooltip>
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountspharmacies,
                            "[0].activePharmacyCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActivePharmacies} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                )}
              </Grid>
              <Grid item sm={6} xs={12} md={6} lg={3}>
                {navigateToPR ? (
                  <div
                    onClick={providersActiveCount}
                    className={classes.cardSecondary}
                  >
                    <Grid>
                      <BasicTypography variant="h5" title="Active Providers" />
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountsproviders,
                            "[0].activeProviderCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActiveProviders} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                ) : (
                  <div
                    title={ERROR.PERMISSION_DENIED_MSG}
                    className={globalClasses.cardSecondary}
                  >
                    <Grid>
                      <MuiTooltip title={ERROR.PERMISSION_DENIED_MSG}>
                        <BasicTypography
                          variant="h5"
                          title="Active Pharmacies"
                        />
                      </MuiTooltip>
                      <Grid className={classes.count}>
                        <p className={classes.cardText}>
                          {_get(
                            getHomeActivCountsproviders,
                            "[0].activeProviderCount",
                            0
                          )}
                        </p>
                      </Grid>
                      <Grid className={classes.cardIcon}>
                        <img src={ActiveProviders} alt="Active" />
                      </Grid>
                      <Grid className={classes.cardDateHalf}>
                        <BasicTypography variant="h6" title={currentDate} />
                      </Grid>
                    </Grid>
                  </div>
                )}
              </Grid>
            </Grid>
          </div>
        </Grid>
        <Grid item md={12}>
          <div className={globalClasses.cardPrimary}>
            <Grid container spacing={3}>
              <Grid item xs="auto">
                <Grid className="label_text">
                  <span>Display Data Range</span>
                </Grid>
              </Grid>
              <Grid item xs={2}>
                <Grid>
                  <FormLabel>Start Date </FormLabel>
                  <DatePicker
                    disabledDate={(date) =>
                      !date || (enddate && !date.isSameOrBefore(enddate, "day"))
                    }
                    onChange={(e, date) => {
                      if (!date) {
                        setenddate(currentDate);
                        setstartdate(thirtyDaysBackDate);
                      } else {
                        setDateError(false);
                        setstartdate(date);
                      }
                    }}
                    value={startdate !== "" ? moment(startdate) : ""}
                  />
                </Grid>
              </Grid>
              <Grid item xs={2}>
                <Grid>
                  <FormLabel>End Date</FormLabel>
                  <DatePicker
                    onChange={(_e, date) => {
                      if (!date) {
                        setenddate(currentDate);
                      } else {
                        setDateError(false);
                        setenddate(date);
                      }
                    }}
                    disabledDate={(d) =>
                      !d || !d.isSameOrAfter(startdate, "day")
                    }
                    value={enddate !== "" ? moment(enddate) : ""}
                  />
                </Grid>
              </Grid>
              <Grid item xs={3}>
                <FormLabel>{LABELS.PharmacyChain}</FormLabel>
                <AutoComplete
                  value={
                    (_isArray(getPharmacygroupvalues) &&
                      getPharmacygroupvalues.find(
                        (e) => e.phGroupId == Pgroup
                      )) ||
                    ""
                  }
                  disableCloseOnSelect={false}
                  options={
                    _isArray(getPharmacygroupvalues)
                      ? getPharmacygroupvalues
                      : []
                  }
                  inputPlaceholder={`Select ${LABELS.PharmacyChain}`}
                  onChange={(e, value) => {
                    handleChangePgroup(e, value);
                  }}
                  getOptionLabel={(option) => option.phGroupName || ""}
                  renderOption={(option, _other) => {
                    return (
                      <BasicTypography variant="subtitle2">
                        {option.phGroupName}
                      </BasicTypography>
                    );
                  }}
                  multiple={false}
                />
              </Grid>
              <Grid item xs={3}>
                <FormLabel>{LABELS.PharmacyStore}</FormLabel>
                <AutoComplete
                  value={
                    (_isArray(getPharmacystorevalues) &&
                      getPharmacystorevalues.find((e) => e.phid == Pstore)) ||
                    ""
                  }
                  disableCloseOnSelect={false}
                  options={
                    _isArray(getPharmacystorevalues)
                      ? getPharmacystorevalues
                      : []
                  }
                  inputPlaceholder={`Select ${LABELS.PharmacyStore}`}
                  onChange={(e, value) => handleChangePstore(e, value)}
                  getOptionLabel={(option) => option.phName || ""}
                  renderOption={(option, _other) => {
                    return (
                      <BasicTypography variant="subtitle2">
                        {option.phName}
                      </BasicTypography>
                    );
                  }}
                  multiple={false}
                />
              </Grid>
            </Grid>
            <Grid container spacing={4}>
              <Grid item sm={3} xs={12} md={6} lg={3}>
                <div className={globalClasses.cardSecondary}>
                  <Grid
                    className={classes.cardBgImg}
                    style={{ backgroundImage: `url(${InvoicedClaims})` }}
                  >
                    <BasicTypography
                      variant="h5"
                      title="Total Invoiced Claims"
                    />
                    <Grid className={classes.countFull}>
                      <p className={classes.cardText}>
                        {formatValueFromString(
                          _get(getHomeclaimsavings, "[0].invoicedClaims", 0) ||
                            "$0.00"
                        )}
                      </p>
                    </Grid>

                    {getHomeclaimsavings && getHomeclaimsavings.length > 0 ? (
                      <Grid className={classes.cardDate}>
                        {_get(getHomeclaimsavings, "[0].startDate", 0)} -
                        {_get(getHomeclaimsavings, "[0].endDate", 0)}
                      </Grid>
                    ) : (
                      <BasicTypography
                        className={classes.cardDate}
                        variant="h6"
                        title="No Billing Cycle found"
                      />
                    )}
                  </Grid>
                </div>
              </Grid>
              <Grid item sm={3} xs={12} md={6} lg={3}>
                <div className={globalClasses.cardSecondary}>
                  <Grid
                    className={classes.cardBgImg}
                    style={{ backgroundImage: `url(${InvoicedClaims})` }}
                  >
                    <BasicTypography variant="h5" title="COGS" />
                    <Grid className={classes.cogsValues}>
                      <Grid>
                        Admin Fee :
                        {formatValueFromString(
                          _get(getHomeclaimsavings, "[0].adminFee", "$0.00")
                        )}
                      </Grid>
                      <Grid>
                        Dispensing Fee :
                        {formatValueFromString(
                          _get(
                            getHomeclaimsavings,
                            "[0].dispensingFee",
                            "$0.00"
                          )
                        )}
                      </Grid>
                      <Grid>
                        340B Drug Cost :
                        {formatValueFromString(
                          _get(getHomeclaimsavings, "[0].tfbDrugCost", "$0.00")
                        )}
                      </Grid>
                    </Grid>
                    {getHomeclaimsavings && getHomeclaimsavings.length > 0 ? (
                      <Grid className={classes.cardDate}>
                        {_get(getHomeclaimsavings, "[0].startDate", 0)} -
                        {_get(getHomeclaimsavings, "[0].endDate", 0)}
                      </Grid>
                    ) : (
                      <BasicTypography
                        className={classes.cardDate}
                        variant="h6"
                        title="No Billing Cycle found"
                      />
                    )}
                  </Grid>
                </div>
              </Grid>
              <Grid item sm={3} xs={12} md={6} lg={3}>
                <div className={globalClasses.cardSecondary}>
                  <Grid
                    className={classes.cardBgImg}
                    style={{ backgroundImage: `url(${InvoicedSavings})` }}
                  >
                    <BasicTypography
                      variant="h5"
                      title="Total Invoiced Savings"
                    />
                    <Grid className={classes.countFull}>
                      <p className={classes.cardText}>
                        {formatValueFromString(
                          _get(getHomeclaimsavings, "[0].invoicedSavings", 0) ||
                            "$0.00"
                        )}
                      </p>
                    </Grid>
                    {getHomeclaimsavings && getHomeclaimsavings.length > 0 ? (
                      <Grid className={classes.cardDate}>
                        {_get(getHomeclaimsavings, "[0].startDate", 0)} -
                        {_get(getHomeclaimsavings, "[0].endDate", 0)}
                      </Grid>
                    ) : (
                      <BasicTypography
                        className={classes.cardDate}
                        variant="h6"
                        title="No Billing Cycle found"
                      />
                    )}
                  </Grid>
                </div>
              </Grid>
              <Grid item sm={3} xs={12} md={6} lg={3}>
                <div className={globalClasses.cardSecondary}>
                  <Grid
                    className={classes.cardBgImg}
                    style={{ backgroundImage: `url(${InvoicedClaims})` }}
                  >
                    <BasicTypography
                      variant="h5"
                      title="Total Unrealized Savings/COGS"
                    />
                    <Grid className={classes.cogsValues}>
                      <Grid>
                        Unrealized Savings :
                        {formatValueFromString(
                          _get(
                            getTotalUnrealizedSavingsCOGS,
                            "[0].unrealizedSavings",
                            "$0.00"
                          )
                        )}
                      </Grid>
                      <Grid>
                        COGS :
                        {formatValueFromString(
                          _get(
                            getTotalUnrealizedSavingsCOGS,
                            "[0].unrealizedCogs",
                            "$0.00"
                          )
                        )}
                      </Grid>
                    </Grid>
                    {getHomeclaimsavings && getHomeclaimsavings.length > 0 ? (
                      <Grid className={classes.cardDate}>--</Grid>
                    ) : (
                      <Grid className={classes.cardDate}>--</Grid>
                    )}
                  </Grid>
                </div>
              </Grid>
            </Grid>
            <Grid container spacing={4}>
              <Grid item sm={4} xs={12} md={6} lg={4}>
                <Grid className={globalClasses.cardSecondary}>
                  <BasicTypography
                    variant="h5"
                    title="Opportunity by Pharmacy Store (Fallout)"
                  />
                  <PieChart
                    className={classes.recharts}
                    width={300}
                    height={200}
                  >
                    <Pie
                      data={donut1}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={60}
                      label
                    />
                    <Tooltip
                      className={classes.toolTip}
                      content={<PiechartCustomTooltip />}
                    />
                    <text
                      x={80}
                      y={100}
                      dy={3}
                      fontSize={11}
                      textAnchor="middle"
                    >
                      Fallout Reasons
                    </text>
                    <Legend
                      iconType="circle"
                      layout="vertical"
                      align="right"
                      verticalAlign="middle"
                      iconSize={10}
                    />
                  </PieChart>
                  <Grid className={classes.cardContent}>
                    <table className={classes.phStoreTable}>
                      <tr>
                        <th>{LABELS.PharmacyStore}</th>
                        <th>Est.Savings</th>
                      </tr>
                      {getHomefalloutfirstfiverecords &&
                        getHomefalloutfirstfiverecords.length > 0 &&
                        getHomefalloutfirstfiverecords.map((ele, index) => {
                          return (
                            <tr key={ele.phName + index}>
                              <td class="CellWithvalue">{`${ele.phName}`}</td>
                              <td>{ele.savings} </td>
                            </tr>
                          );
                        })}
                    </table>
                  </Grid>
                  <Grid className={classes.cardViewFullReport}>
                    <Button
                      className={classes.viewFullReportBtn}
                      onClick={onClickOppByPh}
                    >
                      View Full Report
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item sm={4} xs={12} md={6} lg={4}>
                <Grid className={globalClasses.cardSecondary}>
                  <BasicTypography
                    variant="h5"
                    title="Unreplenished Inventory Cost by Pharmacy Store"
                  />
                  <PieChart
                    className={classes.recharts}
                    width={300}
                    height={200}
                  >
                    <Pie
                      data={donut2}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={60}
                      label
                    />
                    <Tooltip
                      className={classes.toolTip}
                      content={<PiechartCustomTooltip />}
                    />
                    <text
                      x={110}
                      y={100}
                      dy={3}
                      fontSize={11}
                      textAnchor="middle"
                    >
                      Brand/Generic
                    </text>
                    <Legend
                      iconType="circle"
                      layout="vertical"
                      align="right"
                      verticalAlign="middle"
                      iconSize={10}
                    />
                  </PieChart>
                  <Grid className={classes.cardContent}>
                    <table className={classes.phStoreTable}>
                      <tr>
                        <th>{LABELS.PharmacyStore}</th>
                        <th>Inventory Cost</th>
                      </tr>

                      {getHomeinventoryreplirecords &&
                        getHomeinventoryreplirecords.length > 0 &&
                        getHomeinventoryreplirecords.map((ele, index) => {
                          return (
                            <tr key={ele.phName + index}>
                              <td class="CellWithvalue">{`${ele.phName}`}</td>
                              <td>{ele.unreplenishedInventoryCost}</td>
                            </tr>
                          );
                        })}
                    </table>
                  </Grid>
                  <Grid className={classes.cardViewFullReport}>
                    <Button
                      className={classes.viewFullReportBtn}
                      onClick={onClickUnrepInv}
                    >
                      View Full Report
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item sm={4} xs={12} md={6} lg={4}>
                <Grid className={globalClasses.cardSecondary}>
                  <BasicTypography
                    className={globalClasses.cardTitle}
                    variant="h6"
                  >
                    Manufacturer Exclusion Impact
                  </BasicTypography>
                  <PieChart width={300} height={200}></PieChart>
                  <Grid className={classes.cardContent}>
                    <p>Coming Soon...</p>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid
              item
              sm={12}
              xs={12}
              md={12}
              lg={12}
              spacing={4}
              className={classes.cardSecondaryContainer}
            >
              <Grid className={globalClasses.cardSecondary}>
                <Grid container spacing={2}>
                  <Grid item xs={10}>
                    <BasicTypography
                      variant="h4"
                      title=" Savings by Pharmacy"
                    />
                  </Grid>
                  <Grid item xs={2}>
                    <Button
                      startIcon={
                        <RiFileExcel2Fill
                          color={
                            getHomeBarChatSavingByPharma &&
                            getHomeBarChatSavingByPharma.length > 0
                              ? theme.colors.green.dark
                              : ""
                          }
                        />
                      }
                      variant="outlined"
                      size="small"
                      component="button"
                      disabled={
                        getHomeBarChatSavingByPharma &&
                        getHomeBarChatSavingByPharma.length > 0
                          ? false
                          : true
                      }
                      onClick={exportSavingsByPharmacy}
                      className={globalClasses.exportButton}
                    >
                      Export
                    </Button>
                  </Grid>
                </Grid>
                <Grid container spacing={1}>
                  <Grid container item spacing={3}>
                    <Grid item xs={4}>
                      <p>
                        <span className={classes.dotTIC}></span>
                        Total Invoiced Claims -
                        <span className="totalbarchart_value">
                          {getHomeBarChatSavingByPharma &&
                          getHomeBarChatSavingByPharma.length > 0
                            ? formatValueFromString(
                                getHomeBarChatSavingByPharma[0].totalSales
                              )
                            : "$0.00"}
                        </span>
                      </p>
                    </Grid>
                    <Grid item xs={4}>
                      <p class="CGS">
                        <span className={classes.dotCgs}></span>
                        <span class="dot_CGS"></span>
                        Cost of Goods Sold -
                        <span className="totalbarchart_value">
                          {getHomeBarChatSavingByPharma &&
                          getHomeBarChatSavingByPharma.length > 0
                            ? formatValueFromString(
                                getHomeBarChatSavingByPharma[0].totalCOGS
                              )
                            : "$0.00"}
                        </span>
                      </p>
                    </Grid>
                    <Grid item xs={4}>
                      <p class="Savings">
                        <span className={classes.dotSavings}></span>
                        Total Invoiced Savings -
                        <span className="totalbarchart_value">
                          {getHomeBarChatSavingByPharma &&
                          getHomeBarChatSavingByPharma.length > 0
                            ? formatValueFromString(
                                getHomeBarChatSavingByPharma[0].totalSavings
                              )
                            : "$0.00"}
                        </span>
                      </p>
                    </Grid>
                  </Grid>
                </Grid>
                <BarChart
                  className={classes.recharts}
                  width={700}
                  height={400}
                  barSize={8}
                  data={
                    getHomeBarChatSavingByPharma && getHomeBarChatSavingByPharma
                  }
                  margin={{ left: 50 }}
                  layout="vertical"
                >
                  <XAxis
                    type="number"
                    className={classes.toolTip}
                    margin={{ width: 50 }}
                    padding={{ left: 20, right: 20 }}
                    tickFormatter={(label) => `$${formatValue(label)}`}
                  />
                  <YAxis type="category" dataKey="phName" />
                  <Tooltip
                    className={classes.toolTip}
                    content={<BarchartCustomTooltip />}
                  />
                  {getHomeBarChatSavingByPharma &&
                  getHomeBarChatSavingByPharma.length > 7 ? (
                    <Brush
                      dataKey="phName"
                      height={20}
                      startIndex={0}
                      endIndex={7}
                      stroke={theme.colors.grey[400]}
                    />
                  ) : (
                    ""
                  )}
                  <Bar
                    dataKey="totalInvoicedClaims"
                    radius={[0, 10, 10, 0]}
                    fill={theme.colors.graphColors.green}
                    formatter={(dataKey) =>
                      "$" + new Intl.NumberFormat("en").format(dataKey)
                    }
                  />
                  <Bar
                    dataKey="cogs"
                    radius={[0, 10, 10, 0]}
                    fill={theme.colors.graphColors.blue}
                    formatter={(dataKey) =>
                      "$" + new Intl.NumberFormat("en").format(dataKey)
                    }
                  />
                  <Bar
                    dataKey="savings"
                    radius={[0, 10, 10, 0]}
                    fill={theme.colors.graphColors.dark}
                    formatter={(dataKey) =>
                      "$" + new Intl.NumberFormat("en").format(dataKey)
                    }
                  />
                </BarChart>
                {loader ? <LoaderUI /> : ""}
                <BasicPopup
                  title={"Opportunity by Pharmacy (Fallout)  - Full Report"}
                  show={showFullReportOppByPh}
                  disableFooter={true}
                  dialogProps={{
                    maxWidth: "md",
                  }}
                  handleClose={() => setShowFullReportOppByPh(false)}
                >
                  <ViewFullreportdonut1
                    ceid={ceId}
                    phid={Pstore}
                    phGroupId={Pgroup}
                    processedStartDate={startdate}
                    processedEndDate={enddate}
                  />
                </BasicPopup>
                <BasicPopup
                  title={
                    "Unreplenished Inventory Cost by Pharmacy - Full Report"
                  }
                  show={showFullReportUnrep}
                  disableFooter={true}
                  dialogProps={{
                    maxWidth: "md",
                  }}
                  handleClose={() => setShowFullReportUnrep(false)}
                >
                  <ViewFullreportdonut2
                    ceid={ceId}
                    phid={Pstore}
                    phGroupId={Pgroup}
                    processedStartDate={startdate}
                    processedEndDate={enddate}
                  />
                </BasicPopup>
              </Grid>
            </Grid>
          </div>
        </Grid>
      </Grid>
      <BasicPopup
        show={resetNoticeProps.show}
        handleClose={() =>
          setResetNoticeProps((prev) => ({ ...prev, show: false }))
        }
        title="Password Reset Notice"
        submitProps={{
          buttonTitle: "Ok",
          handleSubmit: () => {
            setResetNoticeProps((prev) => ({ ...prev, show: false }));
          },
        }}
      >
        {`Your password will expire in ${resetNoticeProps.remainingDays} days. Please reset your password to avoid your account from being blocked.`}
      </BasicPopup>
    </>
  );
};
export default Home;
