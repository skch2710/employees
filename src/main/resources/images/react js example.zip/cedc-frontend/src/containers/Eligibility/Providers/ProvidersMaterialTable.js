import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import DatePicker from "../../../components/common/DatePicker";
import { TiFilter } from "react-icons/ti";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import {
  ProvidersSearch,
  deleteProvider,
  deleteProviderMessageUuid,
} from "../../../context/actions/providers";
import {
  SET_PROVIDERS_LOCATION_TABLE_DATA,
  SET_PROVIDERS_DEA_TABLE_DATA,
} from "../../../context/actions/providers/constants";
import ProvidersLocations from "./ProvidersLocations";
import ProviderDeaView from "./ProviderDeaView";
import ExportProvider from "./ExportProvider";
import BasicPopup from "../../../components/Popup/BasicPopup";
import { POLLING_COUNT, pagination } from "../../../utils/constants";
import AddProvider from "../../ProgramDetails/ConfigurationOverview/popupsdetail/CEConfiguration/CEProviders/AddProvider";
import _isEqual from "lodash/isEqual";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import _get from "lodash/get";
import { useProviderStyle } from "./styles";
import { getProviderDefaultPayload } from "./constants";
import {
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  getUserSession,
  isEmptyGrid,
} from "../../../utils/helper";
import {
  getTableActionCellStyles,
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../Styles/useGlobalStyles";
import TableProgressBar from "../../../components/common/TableProgressBar";
import DataNotFound from "../../../components/common/DataNotFound";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../components/common/Pagination";

const ProvidersMaterialTable = ({
  ciId,
  controller,
  onChangePagination,
  onChangeSorting,
  onChangeFilter,
  ceProvider,
  messageUuid,
  ceSelected,
  CEidarray,
  searchData,
  defaultFilters,
  clickOnAdd,
  setMenusStatuses,
  provider,
  openPopup,
  actionTitle,
  setOpenPopup,
  setActionTitle,
  providerPermissionObj,
}) => {
  const dispatch = useDispatch();
  const theme = useTheme();
  const userRole = getUserSession();
  const globalClasses = useGlobalStyles();
  const iconsAndButtons = useTableIconsAndButtons();
  const providersPermissionObj =
    getUserPermissionOnModuleName("Providers") || {};

  const { records: providersAllData, loading } = useSelector(
    (state) => state.providersalldata
  );

  const classes = useProviderStyle({
    totalElements:
      !_isEmpty(providersAllData) && providersAllData.totalElements,
    pageSize: controller.pageSize,
    pageNumber: controller.page,
  });

  const [filter, setFilter] = useState(false);
  const [providerInnerGridPopup, setProviderInnerGridPopup] = useState(false);
  const [recordForEdit, setRecordForEdit] = useState(null);
  const filterValues = useRef({});
  const [openDeaPopup, setOpenDeaPopup] = useState(false);
  const { exportToExcel } = ExportProvider();

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  const closePopup = () => {
    setOpenPopup(false);
  };

  useEffect(() => {
    if (!_isEqual(defaultFilters, filterValues.current)) {
      const updatedObj = {};
      defaultFilters &&
        defaultFilters.forEach((eachVal) => {
          updatedObj[eachVal.column.field] = eachVal.value;
        });
      filterValues.current = { ...updatedObj };
    }
  }, [defaultFilters]);

  const setFilterValues = (filterVal) => {
    const updatedObj = {};
    filterVal.forEach((eachVal) => {
      updatedObj[eachVal.column.field] = eachVal.value;
    });
    filterValues.current = { ...updatedObj };
    onChangeFilter(filterVal);
  };

  useEffect(() => {
    if (recordForEdit && !openPopup) setRecordForEdit(null);
  }, [openPopup]);

  const PROVIDER_COLUMNS = [
    {
      title: "Provider First Name",
      field: "firstName",
      defaultFilter: filter && filterValues.current.firstName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.firstName}>
            <span>{rowData.firstName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.firstName}
          placeholder="Provider First Name"
        />
      ),
    },
    {
      title: "Provider Last Name",
      field: "lastName",
      defaultFilter: filter && filterValues.current.lastName,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastName}>
            <span>{rowData.lastName}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.lastName}
          placeholder="Provider Last Name"
        />
      ),
    },
    {
      title: "Provider NPI",
      field: "providerNpi",
      defaultFilter: filter && filterValues.current.providerNpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerNpi}>
            <span>{rowData.providerNpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerNpi}
          placeholder="Provider NPI"
        />
      ),
    },
    {
      title: "Provider DEA",
      field: "providerDea",
      defaultFilter: filter && filterValues.current.providerDea,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.providerDea}>
            <span>
              <a
                className={`${globalClasses.clickableLink}, ${globalClasses.textDecoration}`}
                onClick={() => {
                  setActionTitle("Prescriber Name/DEA Details");
                  setRecordForEdit(rowData);
                  setOpenDeaPopup(true);
                }}
              >
                {rowData.providerDea}
              </a>
            </span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.providerDea}
          placeholder="Provider DEA"
        />
      ),
    },
    {
      title: "Provider SPI",
      field: "prescriberSpi",
      defaultFilter: filter && filterValues.current.prescriberSpi,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.prescriberSpi}>
            <span>{rowData.prescriberSpi}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.prescriberSpi}
          placeholder="Provider SPI"
        />
      ),
    },
    {
      title: "Program Type",
      field: "exclusive",
      defaultFilter: filter && filterValues.current.exclusive,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.exclusive}>
            <span>{rowData.exclusive}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={filterValues.current.exclusive}
          placeholder="Program Type"
        />
      ),
    },
    {
      title: "Provider Start Date",
      field: "startDate",
      defaultFilter: filter && filterValues.current.startDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.startDate
                ? moment(filterValues.current.startDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Provider End Date",
      field: "endDate",
      defaultFilter: filter && filterValues.current.endDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.endDate
                ? moment(filterValues.current.endDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Last Modified Date",
      field: "lastModifiedDate",
      defaultFilter: filter && filterValues.current.lastModifiedDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.lastModifiedDate}>
            <span>{rowData.lastModifiedDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            {...props}
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              filterValues.current.lastModifiedDate
                ? moment(filterValues.current.lastModifiedDate)
                : ""
            }
          />
        );
      },
    },
  ];

  const Actions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(providersAllData),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(providersAllData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(providersAllData),
      onClick: () =>
        exportToExcel({
          ciId: ciId,
          searchData: searchData,
          ceSelected: ceSelected,
          ceProvider: ceProvider,
          CEidarray: CEidarray,
          defaultFilters,
          controller,
        }),
    },
    {
      icon: iconsAndButtons.Plus(),
      tooltip: "Provider Locations",
      isFreeAction: false,
      onClick: (_event, rowData) => {
        setRecordForEdit(rowData);
        setProviderInnerGridPopup(true);
      },
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip: !providersPermissionObj.readWriteFlag
        ? "You don't have Permission."
        : "",
      disabled: true,
      isFreeAction: true,
    },
    {
      icon: iconsAndButtons.View(),
      tooltip: !providersPermissionObj.readOnlyFlag
        ? "You don't have Permission."
        : "View",
      isFreeAction: false,
      disabled: providersPermissionObj.readOnlyFlag ? false : true,
      onClick: (_e, rowData) => {
        setOpenPopup(true);
        setRecordForEdit(rowData);
        setActionTitle("View Provider");
      },
    },
    (rowData) => {
      const isTerminated = rowData.isTerminated === "Y" ? true : false;
      return {
        icon: iconsAndButtons.Edit(),
        tooltip: !providersPermissionObj.readWriteFlag
          ? "You don't have Permission."
          : "Edit",
        isFreeAction: false,
        disabled: providersPermissionObj.readWriteFlag
          ? isTerminated
            ? true
            : false
          : true,
        onClick: (_e, rowData) => {
          setOpenPopup(true);
          setRecordForEdit(rowData);
          setActionTitle(`Edit Provider`);
        },
      };
    },
    (rowData) => {
      const isTerminated = rowData.isTerminated === "Y" ? true : false;
      const payload = {
        ...rowData,
        modifiedBy: userRole.userId,
      };
      return {
        icon: iconsAndButtons.Block({ isBlocked: isTerminated }),
        tooltip:
          providersPermissionObj !== null &&
          !providersPermissionObj.terminateFlag
            ? "You don't have Permission."
            : isTerminated
            ? "Terminated"
            : "Terminate",
        isFreeAction: false,
        disabled:
          !isTerminated &&
          providersPermissionObj !== null &&
          providersPermissionObj.terminateFlag
            ? false
            : true,
        onClick: async (_e, rowData) => {
          const resp = await dispatch(deleteProvider(payload));
          if (!_isEmpty(resp) && resp.data) {
            handlePolling({
              messageUUid: resp.data,
              currentCount: POLLING_COUNT,
              rowData,
            });
          }
        },
      };
    },
  ];

  const handlePolling = async ({ messageUUid, currentCount, rowData }) => {
    const count = currentCount;
    const resp = await dispatch(deleteProviderMessageUuid(messageUUid, count));
    if (resp && resp.statusCode === 200) {
      fetchProviderList(rowData);
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    }
  };

  const fetchProviderList = () => {
    const ceid = ciId ? [ciId] : ceSelected ? [ceSelected.ceID] : CEidarray;
    dispatch(
      ProvidersSearch({
        ...getProviderDefaultPayload(searchData),
        ceid: ceid,
        filter: defaultFilters,
        ...controller,
      })
    );
  };

  const CeActions = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${filter ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(providersAllData),
      onClick: () => {
        setFilter((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(providersAllData),
      }),
      isFreeAction: true,
      disabled: isEmptyGrid(providersAllData),
      onClick: () =>
        exportToExcel({
          ciId: _get(messageUuid, "ceid", ciId),
          searchData: searchData,
          ceSelected: ceSelected,
          ceProvider: ceProvider,
          CEidarray: CEidarray,
          defaultFilters,
          controller,
        }),
    },
    {
      icon: iconsAndButtons.Plus(),
      tooltip: "Provider Locations",
      isFreeAction: false,
      onClick: (_event, rowData) => {
        setRecordForEdit(rowData);
        setProviderInnerGridPopup(true);
      },
    },
    {
      icon: iconsAndButtons.AddCustomButton({ title: "Add Provider" }),
      tooltip:
        providerPermissionObj &&
        providerPermissionObj !== null &&
        !providerPermissionObj.readWriteFlag
          ? "You don't have Permission."
          : "",
      isFreeAction: true,
      disabled:
        providerPermissionObj &&
        providerPermissionObj !== null &&
        providerPermissionObj.readWriteFlag
          ? false
          : true,
      onClick: () => {
        setOpenPopup(true);
        setActionTitle("Add Provider");
      },
    },
    {
      icon: iconsAndButtons.BulkUploadButton(),
      tooltip:
        providerPermissionObj &&
        providerPermissionObj !== null &&
        !providerPermissionObj.readWriteFlag
          ? "You don't have Permission."
          : "",
      isFreeAction: true,
      disabled: true,
    },
  ];

  return (
    <>
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Provider List (${getTableHeaderCount(
                providersAllData.totalElements
              )})`}
            />
          }
          columns={PROVIDER_COLUMNS}
          data={providersAllData.content || []}
          page={controller.page - 1}
          totalCount={providersAllData.totalElements}
          onChangePage={onChangePagination}
          onOrderChange={onChangeSorting}
          onFilterChange={(val) => {
            setFilterValues(val);
          }}
          isLoading={loading}
          actions={!ceProvider ? Actions : CeActions}
          localization={{
            header: {
              actions: !ceProvider && "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          icons={{
            SortArrow: () => TableCustomSortArrow(controller),
            Filter: ColumnFilterIcon,
          }}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{
                  root: globalClasses.gridMuiToolbar,
                }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          options={{
            debounceInterval: 500,
            doubleHorizontalScroll: false,
            search: false,
            actionsColumnIndex: 0,
            filtering: filter,
            paginationType: "stepped",
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            actionsCellStyle: getTableActionCellStyles(theme),
            tableLayout: "auto",
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controller && controller.pageSize,
            draggable: false,
            pageSizeOptions: isEmptyGrid(providersAllData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
            maxBodyHeight: 400,
            minBodyHeight: 100,
          }}
        />
      </div>
      <BasicPopup
        title={"Provider Location Details"}
        show={providerInnerGridPopup}
        disableFooter={true}
        dialogProps={{
          maxWidth: "md",
        }}
        handleClose={() => {
          setRecordForEdit({});
          setProviderInnerGridPopup(false);
          dispatch({
            type: SET_PROVIDERS_LOCATION_TABLE_DATA,
            data: [],
            isSelectedLocation: false,
          });
        }}
      >
        <ProvidersLocations provideRowData={recordForEdit} />
      </BasicPopup>
      <BasicPopup
        title={`${actionTitle}`}
        show={openPopup}
        handleClose={() => {
          closePopup();
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
      >
        <AddProvider
          setOpenPopup={setOpenPopup}
          messageUuid={messageUuid}
          ceSelected={ceSelected}
          rowData={recordForEdit}
          title={actionTitle}
          searchData={searchData}
          clickOnAdd={clickOnAdd}
          setMenusStatuses={setMenusStatuses}
          provider={provider}
          defaultFilters={defaultFilters}
        />
      </BasicPopup>

      <BasicPopup
        title={`${actionTitle}`}
        show={openDeaPopup}
        handleClose={() => {
          setOpenDeaPopup(false);
          fetchProviderList();
          dispatch({
            type: SET_PROVIDERS_DEA_TABLE_DATA,
            data: [],
          });
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "xs",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
      >
        <ProviderDeaView provideRowData={recordForEdit} />
      </BasicPopup>
    </>
  );
};
export default ProvidersMaterialTable;
