import { makeStyles } from "@material-ui/core/styles";
import { getGridActionButtonsMarginRight } from "../../../../../../utils/helper";

export const usePhBillingAndFeesStyles = makeStyles((theme) => {
  return {
    adminFeesApplyBtnContainer: {
      display: "flex",
      alignItems: "flex-end",
    },
    percentageWrapper: {
      display: "flex",
      alignItems: "center",
      gap: "5px",
    },
    adminFeeTypeNotice: {
      height: "30px",
      display: "flex",
      alignItems: "center",
      marginTop: "18px",
      "& p": {
        color: theme.colors.monochrome.disabledText,
        margin: 0,
        fontStyle: "italic",
        fontSize: "13px",
      },
    },
    actionBtnContainer: {
      display: "flex",
      justifyContent: "flex-end",
      gap: "10px",
    },
  };
});

export const useAdminFeeStyles = makeStyles((theme) => {
  return {
    radioContainer: {
      display: "flex",
      alignItems: "center",
      height: "30px",
      gap: "16px",
    },
    radioAndLabelContainer: {
      display: "flex",
      gap: "5px",
      alignItems: "center",
      "& label": {
        color: `${theme.colors.monochrome.input} !important`,
        fontFamily: theme.fontFamily,
        cursor: "pointer",
      },
    },
    radioInput: {
      margin: "0 !important",
    },
  };
});

export const useAdminFeesTableStyles = makeStyles((theme) => {
  return {
    checkbox: {
      color: theme.colors.green[500],
      "&$checked": {
        color: theme.colors.green[500],
      },
    },
    btnLabelContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    dialogPaper: {
      height: "75vh",
    },
  };
});

export const useDispensingFeesTableStyles = makeStyles((theme) => {
  return {
    checkbox: {
      color: theme.colors.green[500],
      "&$checked": {
        color: theme.colors.green[500],
      },
    },
    btnLabelContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
    },
    dialogPaper: {
      height: "75vh",
    },
    confirmationPopup: {
      height: "auto",
    },
  };
});

export const useDispensingFeesStyles = makeStyles((theme) => {
  return {
    switchGridContainer: {
      display: "flex",
    },
    switchContainer: {
      display: "flex",
      justifyContent: "space-between",
      width: "100%",
      height: "30px",
      marginTop: "22px",
      "& .MuiFormControlLabel-root": {
        margin: "0px !important",
      },
    },
    switchLabel: {
      color: theme.colors.monochrome.input,
      fontSize: "13px",
    },
    radioContainer: {
      display: "flex",
      alignItems: "center",
      height: "30px",
      gap: "16px",
    },
    radioAndLabelContainer: {
      display: "flex",
      gap: "5px",
      alignItems: "center",
      "& label": {
        color: `${theme.colors.monochrome.input} !important`,
        fontFamily: theme.fontFamily,
        cursor: "pointer",
      },
    },
    radioInput: {
      margin: "0 !important",
    },
    applyBtnGrid: {
      display: "flex",
      alignItems: "flex-end",
      gap: "10px",
      justifyContent: "flex-end",
    },
    btnRoot: {
      minWidth: "40%",
      fontSize: "14px",
      border: `1px solid ${theme.colors.blue.dark}`,
      color: theme.colors.blue.dark,
      "&:hover": {
        border: `1px solid ${theme.colors.blue.dark}`,
      },
    },
    btnLabelContainer: {
      display: "flex",
      gap: "14px",
    },
    percentageWrapper: {
      display: "flex",
      alignItems: "center",
      gap: "5px",
    },
  };
});
