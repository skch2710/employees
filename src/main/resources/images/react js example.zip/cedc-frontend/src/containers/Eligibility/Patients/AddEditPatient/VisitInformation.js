import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Grid, Button, FormLabel, Typography } from "@material-ui/core";
import DatePicker from "../../../../components/common/DatePicker";
import moment from "moment";
import { Formik, Form, Field } from "formik";
import _uniqBy from "lodash/uniqBy";
import { getProviderNpi } from "../../../../context/actions/providers";
import {
  addVisitInfo,
  addVisitMessageUUID,
  getPatientSearchData,
  getVisitDateExist,
} from "../../../../context/actions/Patients";
import _isEmpty from "lodash/isEmpty";
import { usePatientStyles } from "../style";
import Eligibilityconfigpopup from "../../../ProgramDetails/ConfigurationOverview/popupsdetail/CEConfiguration/ServiceArea/Eligibilityconfigpopup";
import {
  getServiceArea,
  getServiceConfigLookup,
  saveServiceArea,
} from "../../../../context/actions/ConfigOverview";
import BasicPopup from "../../../../components/Popup/BasicPopup";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import { addVisitPayload, fetchPatientDefaultValues } from "../constant";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { POLLING_COUNT } from "../../../../utils/constants";
import { GLOBAL_LOADING } from "../../../../context/constants";
import AutoComplete from "../../../../components/common/AutoComplete";
import _isArray from "lodash/isArray";
const VisitInformation = (patientProps) => {
  const {
    setOpenPopup,
    setValue,
    formData,
    setFormData,
    title,
    formRef,
    isVisitDateExist,
    setIsVisitDateExist,
    memberConfigFile,
    addPatient,
    defaultFilters,
    patientSearchData,
  } = patientProps || {};
  const globalClasses = useGlobalStyles();
  const classes = usePatientStyles();
  const dispatch = useDispatch();
  const [providerNpiList, setProviderNpiList] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const isAddVisit = title === "Add Visit";

  const serviceAreaData =
    useSelector((state) => state.getServiceLookUp.data) || [];
  const { loading } = useSelector((state) => state.globalLoader);
  const visitInfoDropValues =
    Array.isArray(serviceAreaData) &&
    serviceAreaData.length > 0 &&
    serviceAreaData[0];
  const admitType = _uniqBy(visitInfoDropValues["Admit Type"], "configItemId");
  const hospialService = _uniqBy(
    visitInfoDropValues["Hospital Service"],
    "configItemId"
  );
  const patientLocation = _uniqBy(
    visitInfoDropValues["Patient Location"],
    "configItemId"
  );
  const serviceFacility = _uniqBy(
    visitInfoDropValues["Servicing Facility"],
    "configItemId"
  );

  const handleChange = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    let { name, value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue(name, value);
  };

  const formValidate = (values) => {
    let errors = {};
    if (values.visitDate === "") {
      setIsVisitDateExist("");
      errors.visitDate = "Please select the Admit/Visit Date";
    }
    if (!(isVisitDateExist === "")) {
      errors.visitDate = isVisitDateExist;
    }
    return errors;
  };

  useEffect(() => {
    dispatch(getServiceConfigLookup({ ceid: formData.ceid }));
  }, []);

  useEffect(async () => {
    if (formData.ceid) {
      const payload = {
        ceid: Number(formData && formData.ceid),
        npi: "",
      };
      const resp = await getProviderNpi(payload);
      if (resp.statusCode === 200) {
        setProviderNpiList(resp.data);
      }
    }
  }, [formData.ceid]);

  const handleFormData = async (values) => {
    if (isAddVisit) {
      const payload = {
        ...addVisitPayload(values),
      };
      const resp = await dispatch(addVisitInfo(payload));
      if (!_isEmpty(resp) && resp.data) {
        handlePolling({ messageUUid: resp.data, currentCount: POLLING_COUNT });
      }
    } else {
      setFormData(values);
      setValue(2);
    }
  };

  const handlePolling = async ({
    messageUUid,
    currentCount,
    stopNavigation,
  }) => {
    const count = currentCount;
    const res = await dispatch(addVisitMessageUUID(messageUUid, count));
    if (res && res.statusCode === 200) {
      if (stopNavigation) setOpenPopup(false);
      else setOpenPopup(false);
      if (!addPatient) {
        fetchPatientsList();
      }
    } else if (res && res.statusCode === 102 && count > 1) {
      handlePolling({
        messageUUid,
        currentCount: count - 1,
      });
    }
  };
  const fetchPatientsList = (payload = {}) => {
    dispatch(
      getPatientSearchData(
        {
          ...fetchPatientDefaultValues(patientSearchData),
          ...payload,
          filter: defaultFilters || [],
        },
        false
      )
    );
  };
  const handleVisitDate = (date, setFieldValue) => {
    const payload = {
      personId: formData && formData.patientId,
      visitDate: date,
    };
    if (date) {
      dispatch(
        getVisitDateExist(payload, (res) => {
          if (res.statusCode === 404) setIsVisitDateExist(res.errorMessage);
          else if (res.statusCode === 200) {
            setIsVisitDateExist("");
            if (addPatient) {
              setFieldValue("effectiveDate", date);
              setFieldValue("recentVisitDate", date);
            }
            setFieldValue(
              "terminationDate",
              moment(date)
                .add(memberConfigFile.eligibilityPeriod, "d")
                .format("MM/DD/YYYY")
            );
          }
        })
      );
    }
  };

  const configureServiceArea = (
    <Button
      type="button"
      size="small"
      variant="outlined"
      className={globalClasses.secondaryBtn}
      onClick={() => {
        dispatch(getServiceConfigLookup({ ceid: formData.ceid }));
        setOpenModal(true);
      }}
      disabled={loading}
    >
      Configure
    </Button>
  );

  const submitData = (type, data) => {
    const payload =
      data.map((obj) => ({
        ...obj,
        ceid: Number(formData && formData.ceid),
      })) || [];
    dispatch(
      saveServiceArea({ configItemIds: payload }, (res) => {
        if (res.statusCode === 200) {
          handleServiceAreaPolling({
            messageUUID: res.data,
            currentCount: 75,
            type: type,
          });
        }
      })
    );
  };

  const handleServiceAreaPolling = async ({
    messageUUID,
    currentCount,
    type,
  }) => {
    const count = currentCount;
    dispatch(
      getServiceArea({ messageuuid: messageUUID }, (response) => {
        if (response.statusCode === 200) {
          setOpenModal(false);
          dispatch(getServiceConfigLookup({ ceid: formData.ceid }));
        } else if (response && response.statusCode === 102 && count > 1) {
          handleServiceAreaPolling({
            messageUUID,
            currentCount: count - 1,
            type,
          });
          setOpenModal(false);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      })
    );
  };

  const closePopup = () => {
    setOpenModal(false);
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={formData}
        validate={formValidate}
        onSubmit={handleFormData}
        innerRef={formRef}
      >
        {({ values, errors, touched, setFieldValue }) => (
          <Grid container spacing={2}>
            <Grid item md={12}>
              <BasicTypography variant="h4" title="Visit Info" />
            </Grid>
            <Grid item md={12}>
              <Form>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <FormLabel required>Admit/Visit Date</FormLabel>
                    <Field
                      as="select"
                      name="visitDate"
                      className={globalClasses.formControl}
                    >
                      {({ field }) => (
                        <DatePicker
                          {...field}
                          onChange={(_e, date) => {
                            setFieldValue("visitDate", date);
                            handleVisitDate(date, setFieldValue);
                          }}
                          value={
                            values.visitDate
                              ? moment(values.visitDate, "MM/DD/YYYY")
                              : ""
                          }
                        />
                      )}
                    </Field>
                    {((touched.visitDate && errors.visitDate) ||
                      isVisitDateExist) && (
                      <Typography color="error" variant="caption">
                        {isVisitDateExist ? isVisitDateExist : errors.visitDate}
                      </Typography>
                    )}
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <Grid
                      container
                      spacing={1}
                      justifyContent="space-between"
                      alignItems="flex-end"
                    >
                      <Grid item xs={12} md={7}>
                        <FormLabel>Hospital Service</FormLabel>
                        <Field
                          as="select"
                          name="hospitalServiceId"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={
                                _isArray(hospialService) ? hospialService : []
                              }
                              inputPlaceholder={"Select Hospital Service"}
                              disableCloseOnSelect={false}
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "hospitalServiceId",
                                  value && value.inactiveFlag === "N"
                                    ? value.configItemId
                                    : ""
                                );
                              }}
                              value={
                                _isArray(hospialService) &&
                                hospialService.find(
                                  (e) =>
                                    e.configItemId === values.hospitalServiceId
                                )
                              }
                              getOptionLabel={(option) =>
                                (option.inactiveFlag === "N" &&
                                  option.configurationType) ||
                                ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  option.inactiveFlag === "N" && (
                                    <BasicTypography variant="subtitle2">
                                      {option.configurationType}
                                    </BasicTypography>
                                  )
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        md={5}
                        container
                        justifyContent="flex-end"
                      >
                        {configureServiceArea}
                      </Grid>
                    </Grid>
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <Grid
                      container
                      spacing={1}
                      justifyContent="space-between"
                      alignItems="flex-end"
                    >
                      <Grid item xs={12} md={7}>
                        <FormLabel>Admit Type</FormLabel>
                        <Field
                          as="select"
                          name="admitTypeId"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={
                                _isArray(admitType) && admitType
                                  ? admitType
                                  : []
                              }
                              inputPlaceholder={"Select Admit Type"}
                              disableCloseOnSelect={false}
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "admitTypeId",
                                  value && value.inactiveFlag === "N"
                                    ? value.configItemId
                                    : ""
                                );
                              }}
                              value={
                                _isArray(admitType) &&
                                admitType.find(
                                  (e) => e.configItemId === values.admitTypeId
                                )
                              }
                              getOptionLabel={(option) =>
                                (option.inactiveFlag === "N" &&
                                  option.configurationType) ||
                                ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  option.inactiveFlag === "N" && (
                                    <BasicTypography variant="subtitle2">
                                      {option.configurationType}
                                    </BasicTypography>
                                  )
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        md={5}
                        container
                        justifyContent="flex-end"
                      >
                        {configureServiceArea}
                      </Grid>
                    </Grid>
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <Grid
                      container
                      spacing={1}
                      justifyContent="space-between"
                      alignItems="flex-end"
                    >
                      <Grid item xs={12} sm={7}>
                        <FormLabel>Servicing Facility</FormLabel>
                        <Field
                          as="select"
                          name="servicingFacilityId"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={
                                _isArray(serviceFacility) && serviceFacility
                                  ? serviceFacility
                                  : []
                              }
                              inputPlaceholder={"Select Servicing Facility"}
                              disableCloseOnSelect={false}
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "servicingFacilityId",
                                  value && value.inactiveFlag === "N"
                                    ? value.configItemId
                                    : ""
                                );
                              }}
                              value={
                                _isArray(serviceFacility) &&
                                serviceFacility.find(
                                  (e) =>
                                    e.configItemId ===
                                    values.servicingFacilityId
                                )
                              }
                              getOptionLabel={(option) =>
                                (option.inactiveFlag === "N" &&
                                  option.configurationType) ||
                                ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  option.inactiveFlag === "N" && (
                                    <BasicTypography variant="subtitle2">
                                      {option.configurationType}
                                    </BasicTypography>
                                  )
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={5}
                        container
                        justifyContent="flex-end"
                      >
                        {configureServiceArea}
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <Grid
                      container
                      spacing={1}
                      justifyContent="space-between"
                      alignItems="flex-end"
                    >
                      <Grid item xs={12} sm={7}>
                        <FormLabel>Assigned Patient Location</FormLabel>
                        <Field
                          as="select"
                          name="patientLocationId"
                          className={globalClasses.formControl}
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              options={
                                _isArray(patientLocation) && patientLocation
                                  ? patientLocation
                                  : []
                              }
                              inputPlaceholder={
                                "Select Assigned Patient Location"
                              }
                              disableCloseOnSelect={false}
                              onChange={(_e, value) => {
                                setFieldValue(
                                  "patientLocationId",
                                  value && value.inactiveFlag === "N"
                                    ? value.configItemId
                                    : ""
                                );
                              }}
                              value={
                                _isArray(patientLocation) &&
                                patientLocation.find(
                                  (e) =>
                                    e.configItemId === values.patientLocationId
                                )
                              }
                              getOptionLabel={(option) =>
                                (option.inactiveFlag === "N" &&
                                  option.configurationType) ||
                                ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  option.inactiveFlag === "N" && (
                                    <BasicTypography variant="subtitle2">
                                      {option.configurationType}
                                    </BasicTypography>
                                  )
                                );
                              }}
                              multiple={false}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={5}
                        container
                        justifyContent="flex-end"
                      >
                        {configureServiceArea}
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <FormLabel>Provider NPI</FormLabel>
                    <Field as="select" name="prescriberId">
                      {({ field }) => (
                        <AutoComplete
                          {...field}
                          options={
                            _isArray(providerNpiList) ? providerNpiList : []
                          }
                          inputPlaceholder={" Select Sliding Scale Category"}
                          disableCloseOnSelect={false}
                          onChange={(e, value) => {
                            if (value === null) {
                              setFieldValue("prescriberId", null);
                              setFieldValue("providerFirstName", "");
                              setFieldValue("providerLastName", "");
                              setFieldValue("providerSpi", "");
                              setFieldValue("providerDea", "");
                            } else {
                              setFieldValue(
                                "prescriberId",
                                value && value.prescriberId
                              );
                              setFieldValue(
                                "providerFirstName",
                                value && value.firstName
                              );
                              setFieldValue(
                                "providerLastName",
                                value && value.lastName
                              );
                              setFieldValue("providerSpi", value && value.spi);
                              setFieldValue("providerDea", value && value.dea);
                            }
                          }}
                          value={
                            _isArray(providerNpiList) &&
                            providerNpiList.find(
                              (e) => e.prescriberId === values.prescriberId
                            )
                          }
                          getOptionLabel={(option) => option.npi || ""}
                          renderOption={(option, _other) => {
                            return (
                              <BasicTypography variant="subtitle2">
                                {option.npi}
                              </BasicTypography>
                            );
                          }}
                          multiple={false}
                        />
                      )}
                    </Field>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <FormLabel>Provider First Name</FormLabel>
                    <Field
                      name="providerFirstName"
                      value={values.providerFirstName}
                      type="text"
                      disabled
                      className={globalClasses.formControl}
                      placeholder="Enter Provider First Name"
                    />
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <FormLabel>Provider Last Name</FormLabel>
                    <Field
                      name="providerLastName"
                      value={values.providerLastName}
                      disabled
                      type="text"
                      maxLength={50}
                      className={globalClasses.formControl}
                      placeholder="Enter Provider Last Name"
                      onChange={(e) => handleChange(e, setFieldValue)}
                    />
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <FormLabel>Provider DEA</FormLabel>
                    <Field
                      name="providerDea"
                      value={values.providerDea}
                      disabled
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider DEA"
                      onChange={(e) => handleChange(e, setFieldValue)}
                    />
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <FormLabel>Provider SPI</FormLabel>
                    <Field
                      name="providerSpi"
                      value={values.providerSpi}
                      disabled
                      type="text"
                      className={globalClasses.formControl}
                      placeholder="Enter Provider SPI"
                      onChange={(e) => handleChange(e, setFieldValue)}
                    />
                  </Grid>
                  <Grid item md={12}>
                    <Grid container justifyContent="flex-end" spacing={2}>
                      <Grid item>
                        <Button
                          type="submit"
                          color="primary"
                          size="small"
                          variant="contained"
                          className={globalClasses.primaryBtn}
                        >
                          {isAddVisit ? "Add Visit" : "Next"}
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="button"
                          size="small"
                          variant="outlined"
                          color="default"
                          className={globalClasses.secondaryBtn}
                          onClick={() => {
                            setOpenPopup(false);
                          }}
                        >
                          Cancel
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Form>
            </Grid>
          </Grid>
        )}
      </Formik>
      <BasicPopup
        title="Configure Service Areas"
        show={openModal}
        handleClose={() => {
          closePopup();
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper:
              serviceAreaData.length > 0
                ? classes.dialogPaper
                : classes.noContentDialog,
          },
        }}
      >
        <Eligibilityconfigpopup
          submitData={submitData}
          setOpenPopup={setOpenModal}
          formRef={formRef}
          serviceAreaData={serviceAreaData}
          isVisitInfo={true}
        />
      </BasicPopup>
    </>
  );
};

export default VisitInformation;
