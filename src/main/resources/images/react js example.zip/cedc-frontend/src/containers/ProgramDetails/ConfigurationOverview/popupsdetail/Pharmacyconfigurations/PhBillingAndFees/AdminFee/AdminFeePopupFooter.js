import React from "react";
import { useFormikContext } from "formik";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../../../../../Styles/useGlobalStyles";

const AdminFeePopupFooter = (props = {}) => {
  const { setShowAddFee } = props;
  const { submitForm, setFieldValue, initialValues } = useFormikContext();
  const globalClasses = useGlobalStyles();

  return (
    <Grid container justifyContent="flex-end" spacing={2}>
      <Grid item>
        <Button
          onClick={() => {
            setFieldValue("isExit", true);
            submitForm();
          }}
          className={globalClasses.primaryBtn}
        >
          {`${
            initialValues.clientAdminFeeNewId ? "Save & Exit" : "Add & Exit"
          }`}
        </Button>
      </Grid>
      {initialValues.clientAdminFeeNewId ? (
        ""
      ) : (
        <Grid item>
          <Button
            className={globalClasses.secondaryBtn}
            onClick={() => {
              setFieldValue("isExit", false);
              submitForm();
            }}
          >
            Add Another
          </Button>
        </Grid>
      )}
      <Grid item>
        <Button
          className={globalClasses.grayButton}
          onClick={() => setShowAddFee(false)}
        >
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};

export default AdminFeePopupFooter;
