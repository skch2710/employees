import { pagination } from "../../../utils/constants";
import { userdata, filterFunctionality } from "../../../utils/common";
import _get from "lodash/get";
const userrole = JSON.parse(userdata());
const CELIST = userrole.coveredEntityDTOs;


export const ALL_ADDITIONAL_DATE_FILTER_OPTION = [
  { id: 1, category: "Quarter", value: "quarter" },
  { id: 2, category: "Month", value: "month" },
  { id: 3, category: "Date Range", value: "dateRange" },
  { id: 4, category: "Current Week", value: "currentWeek" },
  { id: 5, category: "Today", value: "today" },
];

export const LIMITED_ADDITIONAL_DATE_FILTER_OPTION = [
  { id: 1, category: "Month", value: "month" },
  { id: 2, category: "Quarter", value: "quarter" },
  { id: 3, category: "Date Range", value: "dateRange" },
];

export const QUARTER_OPTIONS = [
  { id: 1, label: "Q1", value: 1 },
  { id: 2, label: "Q2", value: 2 },
  { id: 3, label: "Q3", value: 3 },
  { id: 4, label: "Q4", value: 4 },
];

export const TABLE_CELL_STYLE = {
  fontSize: "11px",
  whiteSpace: "nowrap",
  padding: "12px",
};


export const getFilteredInvoiceDefaultValue = () => {
  return {
    ceId: [CELIST[0].ceID],
    invoicePeriodStartDate: "",
    invoicePeriodEndDate: "",
    phID: 0,
    phGroupId: 0,
  };
};
export const getDefaultInvoiceListPayload = () => {
  return {
    ceId: [CELIST[0].ceID],
    invoicePeriodStartDate: "",
    invoicePeriodEndDate: "",
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "ceName",
    sortOrder: "asc",
    phID: 0,
    phGroupId: 0,
  };
};

export const getDefaultInvoiceListExport = (values) => {
  return {
    ceId: values.ceId,
    invoicePeriodStartDate: values.invoicePeriodStartDate,
    invoicePeriodEndDate: values.invoicePeriodEndDate,
    pageNumber: pagination.page,
    pageSize: pagination.limit,
    sortBy: "ceName",
    sortOrder: "asc",
    phID: _get(values, "phID.phid", 0),
    phGroupId:  _get(values, "phGroupId.phGroupId", 0)
  };
};

export const INVENTORY_LIST_EXPORT_FILE_NAME = "Inventory List";
export const INVENTORY_INNER_LIST_EXPORT_FILE_NAME = "Inventory Details";
