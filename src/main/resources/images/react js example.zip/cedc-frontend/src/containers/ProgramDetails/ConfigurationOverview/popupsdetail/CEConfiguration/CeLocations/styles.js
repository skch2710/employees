import { makeStyles } from "@material-ui/core/styles";

export const useCeLocationsStyles = makeStyles((_theme) => {
  return {
    downloadLinkContainer: {
      display: "flex",
      justifyContent: "flex-end",
      alignItems: "center",
    },
  };
});
