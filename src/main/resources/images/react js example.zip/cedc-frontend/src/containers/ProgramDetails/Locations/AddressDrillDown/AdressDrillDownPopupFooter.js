import React from "react";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";

const AddressDrillDownPopupFooter = (props = {}) => {
  const { onNextButtonClick, closePopup, hideNext } = props;
  const globalClasses = useGlobalStyles();

  return (
    <Grid container spacing={2} justifyContent="flex-end">
      {!hideNext && (
        <Grid item>
          <Button
            onClick={onNextButtonClick}
            className={globalClasses.primaryBtn}
          >
            Next
          </Button>
        </Grid>
      )}

      <Grid item>
        <Button
          variant="outlined"
          className={globalClasses.secondaryBtn}
          onClick={closePopup}
        >
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
};

export default AddressDrillDownPopupFooter;
