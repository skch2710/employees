import React, { useState, useEffect } from "react";
import { Paper, Tooltip } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import "antd/dist/antd.css";

//Common
import HeaderTitle from "../../../../../../components/common/Typography/HeaderTitle";
import MaterialTable, { MTableToolbar } from "material-table";
import { useStyles } from "../../../../../../mui-styles/commonTableMuiStyle";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
//css
import { TiFilter } from "react-icons/ti";
import { LABELS, pagination } from "../../../../../../utils/constants";
import Mainbinpcnexport from "./Export/Mainbinpcnexport";
import { getZeroValueInTotalElements } from "../../../../../../utils/common";
import { undefinedArrayContent } from "../../../../../../utils/common";
import { Cobinpcndatatoggleoff } from "../../../../../../context/actions/CoPopupBinpcn";

const ColumnFilterIcon = () => {
  return <TiFilter fontSize="small" />;
};

const Mainbinpcn = ({ locationCollapse, setlocationCollapse, ciId }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [rowsPerPage, setRowsPerPage] = useState(pagination.limit);
  const [page, setPage] = useState(pagination.page);
  const [sortBy, setsortBy] = useState("bin");
  const [sortorder, setOrder] = useState("asc");
  const [data, setData] = useState(columns);

  const onChangeRowsperpage = (pagesize) => {
    const { totalElements = 0 } = cobinpcndatatoggleoff;
    const totalPages = Math.ceil(totalElements / pagesize);
    if (page > totalPages) setPage(pagination.page);
    setRowsPerPage(pagesize);
  };

  const onChangePagination = (data, pagesize) => {
    let currentpage = data + 1;
    if (pagesize === rowsPerPage) setPage(currentpage);
  };

  const onChangeSorting = async (orderedColumnId) => {
    setOrder(sortorder === "asc" ? "desc" : "asc");
    setsortBy(columns[orderedColumnId].field);
  };

  useEffect(() => {
    dispatch(
      Cobinpcndatatoggleoff({
        ceid: ciId,
        pageNumber: page,
        pageSize: rowsPerPage,
        sortBy: sortBy,
        sortOrder: sortorder,
        export: false,
      })
    );
  }, [rowsPerPage, page, sortBy, sortorder]);

  let cobinpcndatatoggleoff = useSelector(
    (state) => state.cobinpcntoggleoffdata.records
  );
  // let Maingetbinpcndata = useSelector((state) => state.Cobinpcndata_toggleoff.records);
  // let Mainbinpcnexportdata = useSelector((state) => state.Cobinpcndata_toggleoff.records);
  const columns = [
    {
      title: "BIN Block Group",
      field: "binBlockGroup",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.binBlockGroup}>
            <span>{rowData.binBlockGroup}</span>
          </Tooltip>
        );
      },
      // editComponent: (rowData) => {
      //   return (
      //     <input className="formControl"></input>

      //   );
      // },
    },
    {
      title: "Bin Block Type",
      field: "binBlockType",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.binBlockType}>
            <span>{rowData.binBlockType}</span>
          </Tooltip>
        );
      },
    },
    {
      title: LABELS.PharmacyChain,
      field: "pharmacyGroup",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacyGroup}>
            <span>{rowData.pharmacyGroup}</span>
          </Tooltip>
        );
      },
    },
    {
      title: LABELS.PharmacyStore,
      field: "pharmacy",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pharmacy}>
            <span>{rowData.pharmacy}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "BIN",
      field: "bin",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bin}>
            <span>{rowData.bin}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "PCN",
      field: "pcn",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pcn}>
            <span>{rowData.pcn}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Group No",
      field: "groupNumber",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.groupNumber}>
            <span>{rowData.groupNumber}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Payor",
      field: "payor",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.payor}>
            <span>{rowData.payor}</span>
          </Tooltip>
        );
      },
    },
    // Payor
    {
      title: "Start Date",
      field: "startDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "End Date",
      field: "endDate",
      cellStyle: {
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        overflow: "hidden",
        maxWidth: 100,
        fontSize: "11px",
      },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.endDate}>
            <span>{rowData.endDate}</span>
          </Tooltip>
        );
      },
    },
  ];

  return (
    <div>
      {/* <Paper className="card card-first-level p-20 "> */}

      <div className={classes.root}>
        <div className="card card-first-level">
          <Mainbinpcnexport
            // Mainbinpcnexportdata={cobinpcndatatoggleoff.content}
            // ciId={ciId}
            // providerNPI={providerNPI}
            count={getZeroValueInTotalElements(cobinpcndatatoggleoff)}
          />
          <MaterialTable
            title={
              <HeaderTitle
                variant="h6"
                title={`BinPcn List -Total Count (${getZeroValueInTotalElements(
                  cobinpcndatatoggleoff
                )})`}
              />
            }
            // title={<HeaderTitle variant="h6" title="Data Preview" />}
            columns={columns}
            data={undefinedArrayContent(cobinpcndatatoggleoff)}
            page={page - 1}
            totalCount={cobinpcndatatoggleoff.totalElements}
            onChangePage={onChangePagination}
            onOrderChange={onChangeSorting}
            onChangeRowsPerPage={onChangeRowsperpage}
            // actions={Actions}
            icons={{
              SortArrow: () => TableCustomSortArrow({ sortOrder: sortorder }),
              Filter: ColumnFilterIcon,
            }}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Toolbar: (props) => (
                <div
                  style={{
                    marginRight: "259px",
                    marginTop: "-48px",
                    marginBottom: "18px",
                  }}
                >
                  <MTableToolbar {...props} />
                </div>
              ),
            }}
            options={{
              search: false,
              searchFieldAlignment: "right",
              searchAutoFocus: true,
              searchFieldVariant: "standard",
              actionsColumnIndex: 0,
              filtering: false,
              paginationType: "stepped",
              paging: "true",
              showFirstLastPageButtons: false,
              paginationPosition: "top",
              exportButton: false,
              exportAllData: false,
              exportFileName: "Locations List",
              headerStyle: {
                background: "#EFF4FA",
                color: "#8F9BB3",
                fontSize: "11px",
                whiteSpace: "nowrap",
              },
              tableLayout: "auto",
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: rowsPerPage,
              draggable: false,
            }}
          />
        </div>
      </div>
      {/* </Paper> */}
    </div>
  );
};

export default Mainbinpcn;
