import React, { memo, useEffect, useState } from "react";
import { Grid, Button } from "@material-ui/core";
import moment from "moment";
import _get from "lodash/get";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useDispatch } from "react-redux";
import IcoPdf from "../../../../../../assets/ico-pdf.png";
import classNames from "classnames";
import _isEmpty from "lodash/isEmpty";
import {
  getInvoiceDetailsList,
  getInvoiceDetailsSummary,
} from "../../../../../../context/actions/Invoice";
import { formatValue } from "../../../../../../utils/common";
import { getInvoiceDetailsExportPdf } from "../../../../../../context/actions/Invoice";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useInvoiceDetailsStyle } from "./styles";
import InvoiceDetailsAccordion from "./InvoiceDetailsAccordion";

const InvoiceDetails = ({
  setOpenPopup,
  setValue,
  actionsRowDataDetails,
  filtersValues,
}) => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = useInvoiceDetailsStyle();
  const { ceId, invoicePeriodEndDate, invoicePeriodStartDate } =
    actionsRowDataDetails || {};
  const [invoiceDetailsSummary, setInvoiceDetailsSummary] = useState({});
  const [invoiceDetails, setInvoiceDetails] = useState([]);
  const startDate = moment(actionsRowDataDetails.invoicePeriodStartDate);
  const endDate = moment(actionsRowDataDetails.invoicePeriodEndDate);
  const formattedStartDate = startDate.format("MMMM D , Y");
  const formattedEndDate = endDate.format("MMMM D , Y");

  const fetchInvoiceDetailsSummary = async () => {
    const payload = {
      ceId: ceId,
      phGroupId: filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
      phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
      invoicePeriodStartDate: invoicePeriodStartDate,
      invoicePeriodEndDate: invoicePeriodEndDate,
      isMainResult: 1,
    };
    const res = await dispatch(getInvoiceDetailsSummary(payload));
    setInvoiceDetailsSummary(!_isEmpty(res) ? res : {});
  };

  const fetchInvoiceDetails = (payload = {}) => {
    dispatch(
      getInvoiceDetailsList(
        {
          ceId: ceId,
          invoicePeriodStartDate: invoicePeriodStartDate,
          invoicePeriodEndDate: invoicePeriodEndDate,
          phGroupId: filtersValues == "" ? 0 : filtersValues.phGroupId,
          phId: filtersValues == "" ? 0 : filtersValues.phId,
          isMainResult: 1,
        },
        (data) => {
          setInvoiceDetails(data);
        }
      )
    );
  };

  const dynamicGrids = () => {
    const grids = invoiceDetails.map(function (ele, index) {
      return <InvoiceDetailsAccordion key={index} res={ele} />;
    });
    return grids;
  };

  const downloadPdf = () => {
    const Payload = {
      ceid: ceId,
      phGroupId: filtersValues.phGroupId == "" ? 0 : filtersValues.phGroupId,
      phId: filtersValues.phId == "" ? 0 : filtersValues.phId,
      startDate: invoicePeriodStartDate,
      endDate: invoicePeriodEndDate,
    };
    dispatch(getInvoiceDetailsExportPdf(Payload));
  };

  useEffect(() => {
    fetchInvoiceDetails();
    fetchInvoiceDetailsSummary();
  }, []);

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={5}>
            <BasicTypography
              variant="h5"
              title={`Invoice Number : ${actionsRowDataDetails.invoiceNumber}`}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography
              variant="h5"
              title={` Billing Cycle : ${formattedStartDate} -
                    ${formattedEndDate}`}
            />
          </Grid>
          <Grid item className={classes.pdfAlignment} xs={12} sm={3}>
            <Button
              startIcon={<img src={IcoPdf} width={20} height={20} />}
              type="submit"
              color="default"
              size="small"
              onClick={downloadPdf}
              component="button"
              classes={{
                root: classNames(classes.btn, globalClasses.exportButton),
              }}
            >
              Export
            </Button>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12} md={8}>
        {dynamicGrids()}
      </Grid>
      <Grid item xs={12} md={4}>
        <div className={globalClasses.cardPrimary}>
          <Grid
            container
            wrap="nowrap"
            spacing={2}
            className={classes.detailsSummary}
          >
            <Grid item>
              <BasicTypography
                variant="h4"
                title="340B Direct+ Fee Invoice Summary"
              />
            </Grid>
          </Grid>
          <Grid className={classes.remittanceTotals}>
            <table className={classes.summaryTable}>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.labelstextColor}>Pharmacy EAC</td>
                <td>$</td>
                <td className={classes.totalValuesInBold}>
                  {formatValue(invoiceDetailsSummary.totalInvoiced)}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>Dispensing Fees</td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(invoiceDetailsSummary.dispensingFee)}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>340B Drug Cost</td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(invoiceDetailsSummary.drugCost)}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.labelstextColor}>
                  Covered Entity Gross Savings
                </td>
                <td>$</td>
                <td className={classes.totalValuesInBold}>
                  {formatValue(invoiceDetailsSummary.grossSavings)}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>340BDirect+ Fee %</td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(
                    invoiceDetailsSummary.tbfDirectPlusFlatFeePercentage
                  )}
                </td>
              </tr>
              <tr className={classes.ceRemittanceTotals}>
                <td className={classes.boldText}>340BDirect+ Flat Fee</td>
                <td>$</td>
                <td className={classes.valueTextColor}>
                  {formatValue(invoiceDetailsSummary.tfbDirectPlusFlatFee)}
                </td>
              </tr>
              <tr className={classes.netDueCe}>
                <td className={classes.ceNetDueLabel}>
                  Total 340BDirect+ Fees
                </td>
                <td className={classes.ceNetDueLabel}>$</td>
                <td className={classes.ceNetDueValue}>
                  {formatValue(invoiceDetailsSummary.totalTFBDirectPLusFees)}
                </td>
              </tr>
              <tr className={classes.insuredClaimsText}>
                *Insured Claims Only
              </tr>
            </table>
          </Grid>
        </div>
      </Grid>
    </Grid>
  );
};
export default memo(InvoiceDetails);
