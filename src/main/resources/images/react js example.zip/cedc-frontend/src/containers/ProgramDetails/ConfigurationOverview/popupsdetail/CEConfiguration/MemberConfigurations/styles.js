import { makeStyles } from "@material-ui/core/styles";

export const useCeMembersStyles = makeStyles((_theme) => ({
  downloadLink: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    gap: "5px",
  },
}));
