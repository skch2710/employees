import _isEmpty from "lodash/isEmpty";
import { getFeeIds } from "../../../../../../utils/helper";

export const getBillingContactDetailsFiltersObject = (filters) => {
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: "startWith",
      value: filter.value,
    };
  });
};

export const getAdminFeeDefaultFormValues = (values = {}) => {
  return {
    feesType: values.adminFeeTypeNewId || 0,
    adminFee: values.flatFee || "",
    startDate: values.feeStartDate || "",
    endDate: values.feeEndDate || "",
    claimType: values.adminFeeClaimTypeId || 0,
    addClaimType: values.adminFeeAddlClaimTypeId || 0,
    adminFeePercentage: values.percentage || "",
    switch: values.adminFeeSwitchTypeId || 0,
    basisOf:
      values.adminFeeTypeNewId === 4 || values.adminFeeTypeNewId === 5 ? 1 : 0,
    ...(values.isEdit ? { isEdit: values.isEdit } : {}),
    ...(values.ceAdminFeeNewId
      ? { ceAdminFeeNewId: values.ceAdminFeeNewId }
      : {}),
    applicableFor: "",
    customizedOrNot: [],
    selectedClients: [],
    feeTypeLabel: values.feeType || "",
  };
};

export const getAdminFeeSavePayload = (values = {}) => ({
  ceid: values.ceId,
  adminFeeTypeNewId: Number(values.feesType),
  adminFeeClaimTypeId: Number(values.claimType),
  adminFeeAddlClaimTypeId: Number(values.addClaimType),
  adminFeeSwitchTypeId: Number(values.switch),
  adminFee: values.adminFee || "",
  adminFeePercentage: values.adminFeePercentage || "",
  adminFeeStartDate: values.startDate,
  adminFeeEndDate: values.endDate,
  adminFeePercentageBasisId:
    values.feesType === "4" || values.feesType === "5" ? 1 : values.basisOf,
  ...(values.ceAdminFeeNewId
    ? { ceAdminFeeNewId: values.ceAdminFeeNewId }
    : {}),
  ...(!_isEmpty(values.selectedClients)
    ? { clientFeeIds: getFeeIds(values.selectedClients) }
    : {}),
  ...(values.applicableFor
    ? { applyClients: Number(values.applicableFor) }
    : {}),
  createdById: values.createdById || 0,
  modifiedById: values.modifiedById || 0,
});

export const getAdminFeesFiltersObject = (filters) => {
  const dateFields = ["feeStartDate", "feeEndDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};
