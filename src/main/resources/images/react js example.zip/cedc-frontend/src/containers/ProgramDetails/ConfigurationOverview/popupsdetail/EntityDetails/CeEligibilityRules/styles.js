import { makeStyles } from "@material-ui/core/styles";

export const useCeEligibilityStyles = makeStyles((theme) => {
  return {
    checkboxAndLabelContainer: {
      display: "flex",
      alignItems: "center",
    },
    ruleCheckbox: {
      marginRight: "6px",
    },
    checkboxLabel: {
      paddingBottom: "0px",
    },
    ruleSetGridContainer: {
      border: `1px solid ${theme.colors.grey.boxOneBorder}`,
      backgroundColor: theme.colors.grey.boxOneBackground,
      padding: "10px 10px 10px 16px",
      margin: "0px !important",
    },
    ruleSetCollapseContainer: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "20px",
    },
    ruleSetContainer: {
      display: "flex",
    },
    ruleSetDivContainer: {
      display: "flex",
    },
    conditionalOperator: {
      margin: "6px 12px",
    },
    ruleSetInfoContainer: {
      backgroundColor: theme.colors.monochrome.offWhite,
      padding: "20px 0",
    },
    startEndStatusContainer: {
      display: "flex",
      justifyContent: "space-between",
      marginLeft: "16px",
      width: "60%",
    },
    dividerContainer: {
      display: "flex",
      alignItems: "center",
    },
    dividerBorder: {
      borderBottom: `1px solid ${theme.colors.grey.boxOneBorder}`,
      width: "100%",
    },
    dividerContent: {
      padding: "0 10px 0 10px",
      margin: "24px 0",
    },
    ruleNameBox: {
      width: "120px",
      padding: "6px 12px",
      backgroundColor: theme.colors.green[100],
      border: `1px solid ${theme.colors.grey[200]}`,
      color: theme.typography.subtitle2.color,
      borderRadius: "4px",
    },
    collpaseBtn: {
      border: `1px solid ${theme.colors.grey[200]}`,
      backgroundColor: theme.colors.secondary.default,
      borderRadius: "4px",
      width: "24px",
      height: "22px",
    },
    disabledBorder: {
      border: `1px solid ${theme.colors.grey[100]}`,
    },
    messageGrid: {
      border: `1px solid ${theme.colors.pink.default}`,
      backgroundColor: theme.colors.pink.default,
      padding: "10px",
      fontSize: "12px",
    },
  };
});
