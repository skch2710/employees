import React, { useState, useContext } from "react";
import { Grid, Switch, Button } from "@material-ui/core";
import { Formik, Field } from "formik";
import HeaderTitle from "../../../../../../components/common/Typography/HeaderTitle";
import Globalbin from "./Globalbin";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";

const Binandpcn = ({ messageUiid, ciId }) => {
  const { setPopupActiveMenu, setOpenAddCePopup } = useContext(COContext);
  const [globalbinsToggle, setglobalbinsToggle] = useState(true);

  return (
    <Formik enableReinitialize={true} initialValues="" onSubmit="">
      {({ values, handleChange }) => (
        <>
          <Grid>
            <HeaderTitle
              variant="h1"
              title="Covered Entity Configuration > BIN/PCN Configuration"
            />
          </Grid>
          <Grid className="applyglobalbins">
            <Field
              label="Entity Details/BIN/PCN Configuration"
              name="la"
              component={Switch}
              type="checkbox"
              onChange={(e) => setglobalbinsToggle(e.target.checked)}
              checked={globalbinsToggle}
              size="small"
              color="primary"
            />
            <label>Apply Global Bin Blocks</label>
          </Grid>

          <Grid>
            <Globalbin
              toggleglobalbin={globalbinsToggle}
              ciId={ciId}
              messageUiid={messageUiid}
            />
          </Grid>

          <Grid
            xs={12}
            container
            justifyContent="flex-end"
            style={{ padding: "12px" }}
          >
            <Button
              type="submit"
              color="primary"
              size="small"
              variant="contained"
              className="btn btn-primary text-capitalize"
              onClick={() => {
                setPopupActiveMenu(MENUS.CE_LOCATIONS);
              }}
            >
              Next
            </Button>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className="btn btn-secondary m-l-20 text-capitalize"
              onClick={() => {
                setPopupActiveMenu(MENUS.CE_LOCATIONS);
              }}
            >
              Skip
            </Button>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className="btn btn-secondary m-l-20 text-capitalize"
              onClick={() => {
                setOpenAddCePopup(false);
              }}
            >
              Save
            </Button>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className="btn btn-secondary m-l-20 text-capitalize"
              onClick={() => {
                setOpenAddCePopup(false);
              }}
            >
              Cancel
            </Button>
          </Grid>
        </>
      )}
    </Formik>
  );
};

export default Binandpcn;
