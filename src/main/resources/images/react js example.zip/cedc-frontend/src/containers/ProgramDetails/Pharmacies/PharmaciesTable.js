import { Paper, Tooltip, useTheme } from "@material-ui/core";
import MaterialTable, { MTableToolbar } from "material-table";
import moment from "moment";
import React, {
  forwardRef,
  memo,
  useCallback,
  useContext,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import TableCustomSortArrow from "../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import { useDispatch, useSelector } from "react-redux";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../Styles/useGlobalStyles";
import ColumnLevelFilterInput from "../../../components/common/ColumnLevelFilterInput";
import DataNotFound from "../../../components/common/DataNotFound";
import DatePicker from "../../../components/common/DatePicker";
import Pagination from "../../../components/common/Pagination";
import useTableIconsAndButtons from "../../../components/common/TableIcons";
import TableProgressBar from "../../../components/common/TableProgressBar";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { LABELS, pagination } from "../../../utils/constants";
import {
  getCoveredEntity,
  getTableHeaderCount,
  getUserPermissionOnModuleName,
  getUserSession,
  isEmptyGrid,
} from "../../../utils/helper";
import { COContext } from "../COContext";
import { MENUS } from "../ConfigurationOverview/PopupSidebar/constants";
import { getPharmaciesFiltersObject } from "./helper";
import usePharmacyExport from "./usePharmacyExport";

const PharmaciesTable = memo(
  forwardRef((props = {}, ref) => {
    const {
      getPharmaciesTableData,
      formSubmittedValues,
      ceList,
      handleCompletedPharmacyClick,
    } = props;
    const {
      setPopupActiveMenu,
      setOpenAddCePopup,
      setCurrentPharmacy,
      setMessageUuid,
      setCeId,
      setCoveredEntityName,
      setClickedOnPartial,
      setPhConfigSectionStatus,
      phConfigStatusPercent,
      setPhConfigStatusPercent,
    } = useContext(COContext) || {};
    const { exportToExcel } = usePharmacyExport();
    const userSession = getUserSession();
    const readWritePermission =
      getUserPermissionOnModuleName("Pharmacies").readWriteFlag;
    const theme = useTheme();
    const tableRef = useRef(null);
    const globalClasses = useGlobalStyles();
    const dispatch = useDispatch();
    const iconsAndButtons = useTableIconsAndButtons();

    const [controllers, setControllers] = useState({
      pageNumber: pagination.page,
      pageSize: pagination.limit,
      sortOrder: "",
      sortBy: "",
    });
    const [enableFilters, setEnableFilters] = useState(false);
    const [columnFilters, setColumnFilters] = useState([]);
    const columnFiltersRef = useRef({});
    const { loading, records: pharmaciesTableData } =
      useSelector((state) => state.pharmaciesList) || {};

    useImperativeHandle(ref, () => ({
      // This function will be called when submit button clicked from search component
      submitForm(resp) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        setControllersOnResp(resp);
      },
      // This function will be called when clear button clicked from search component
      clearForm(payload) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        getPharmaciesTableData(payload, (resp) => setControllersOnResp(resp));
      },
    }));

    const handlePartialPharmacyClick = useCallback((pharmacy) => {
      const currentCoveredEntity =
        getCoveredEntity({
          ceId: pharmacy.ceid,
          ceList,
        })[0] || {};
      setCoveredEntityName(pharmacy.coveredEntity);
      setMessageUuid({ ...currentCoveredEntity, ceid: pharmacy.ceid });
      setCeId(pharmacy.ceid);
      setCurrentPharmacy(pharmacy);
      setClickedOnPartial(true);
      setPopupActiveMenu(MENUS.PH_BASIC_DETAILS);
      setOpenAddCePopup(true);
    }, []);

    const PHARMACIES_COLUMNS = [
      {
        title: LABELS.CoveredEntity,
        field: "coveredEntity",
        defaultFilter: enableFilters && columnFiltersRef.current.coveredEntity,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.coveredEntity || ""}>
              <span>{rowData.coveredEntity || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.coveredEntity}
            placeholder="Covered Entity"
          />
        ),
      },
      {
        title: "Pharmacy Store",
        field: "pharmacyName",
        customFilterAndSearch: () => true,
        defaultFilter: enableFilters && columnFiltersRef.current.pharmacyName,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyName || ""}>
              <span>{rowData.pharmacyName || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pharmacyName}
            placeholder="Pharmacy Store"
          />
        ),
      },
      {
        title: "Configuration Status",
        field: "configStatus",
        customFilterAndSearch: () => true,
        defaultFilter: enableFilters && columnFiltersRef.current.configStatus,
        render: (rowData) => {
          return (
            <Tooltip
              title={
                rowData.configStatusId === 2
                  ? "Click to view the configured sections"
                  : "Click to complete the configuration"
              }
            >
              {rowData.configStatusId === 2 ? (
                <a
                  className={`${globalClasses.clickableLink}, ${globalClasses.textDecoration}`}
                  onClick={() => {
                    handleCompletedPharmacyClick(rowData);
                  }}
                >
                  {rowData.configStatus || ""}
                </a>
              ) : userSession.isInternalUser &&
                readWritePermission &&
                rowData.configStatusId === 1 ? (
                <a
                  className={`${globalClasses.clickableLink}, ${globalClasses.textDecoration}`}
                  onClick={() => handlePartialPharmacyClick(rowData)}
                >
                  {rowData.configStatus || ""}
                </a>
              ) : (
                <span>{rowData.configStatus || ""}</span>
              )}
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.configStatus}
            placeholder="Configuration Status"
          />
        ),
      },
      {
        title: `${LABELS.PharmacyChain}`,
        defaultFilter:
          enableFilters && columnFiltersRef.current.pharmacyNetwork,
        field: "pharmacyNetwork",
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.pharmacyNetwork || ""}>
              <span>{rowData.pharmacyNetwork || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.pharmacyNetwork}
            placeholder={`${LABELS.PharmacyChain}`}
          />
        ),
      },
      {
        title: "Go-Live Date",
        field: "goLiveDate",
        defaultFilter: enableFilters && columnFiltersRef.current.goLiveDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.goLiveDate || ""}>
              <span>{rowData.goLiveDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.goLiveDate
                  ? moment(columnFiltersRef.current.goLiveDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "Start Date",
        field: "startDate",
        defaultFilter: enableFilters && columnFiltersRef.current.startDate,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.startDate || ""}>
              <span>{rowData.startDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.startDate
                  ? moment(columnFiltersRef.current.startDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "End Date",
        field: "endDate",
        customFilterAndSearch: () => true,
        defaultFilter: enableFilters && columnFiltersRef.current.endDate,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.endDate || ""}>
              <span>{rowData.endDate || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => {
          return (
            <DatePicker
              {...props}
              onChange={(date) => {
                if (date) {
                  props.onFilterChanged(
                    props.columnDef.tableData.id,
                    moment(date).format("MM/DD/YYYY")
                  );
                } else {
                  props.onFilterChanged(props.columnDef.tableData.id, "");
                }
              }}
              value={
                columnFiltersRef.current.endDate
                  ? moment(columnFiltersRef.current.endDate)
                  : ""
              }
            />
          );
        },
      },
      {
        title: "Third Party Brand $+%",
        field: "brandDispensingFeeThirdParty",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters &&
          columnFiltersRef.current.brandDispensingFeeThirdParty,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.brandDispensingFeeThirdParty || ""}>
              <span>{rowData.brandDispensingFeeThirdParty || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.brandDispensingFeeThirdParty}
            placeholder="Third Party Brand $+%"
          />
        ),
      },
      {
        title: "Third Party Generic $+%",
        field: "genericDispensingFeeThirdParty",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters &&
          columnFiltersRef.current.genericDispensingFeeThirdParty,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.genericDispensingFeeThirdParty || ""}>
              <span>{rowData.genericDispensingFeeThirdParty || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.genericDispensingFeeThirdParty}
            placeholder="Third Party Generic $+%"
          />
        ),
      },
      {
        title: "Third Party Specialty Brand $+%",
        field: "specialtyBrandDispensingFeeThirdParty",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters &&
          columnFiltersRef.current.specialtyBrandDispensingFeeThirdParty,
        render: (rowData) => {
          return (
            <Tooltip
              title={rowData.specialtyBrandDispensingFeeThirdParty || ""}
            >
              <span>{rowData.specialtyBrandDispensingFeeThirdParty || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={
              columnFiltersRef.current.specialtyBrandDispensingFeeThirdParty
            }
            placeholder="Third Party Specialty Brand $+%"
          />
        ),
      },
      {
        title: "Third Party Specialty Generic $+%",
        field: "specialtyGenericDispensingFeeThirdParty",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters &&
          columnFiltersRef.current.specialtyGenericDispensingFeeThirdParty,
        render: (rowData) => {
          return (
            <Tooltip
              title={rowData.specialtyGenericDispensingFeeThirdParty || ""}
            >
              <span>
                {rowData.specialtyGenericDispensingFeeThirdParty || ""}
              </span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={
              columnFiltersRef.current.specialtyGenericDispensingFeeThirdParty
            }
            placeholder="Third Party Specialty Generic $+%"
          />
        ),
      },
      {
        title: "Cash Flat Fee $+%",
        field: "cashFlatFeeBoth",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters && columnFiltersRef.current.cashFlatFeeBoth,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.cashFlatFeeBoth || ""}>
              <span>{rowData.cashFlatFeeBoth || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.cashFlatFeeBoth}
            placeholder="Cash Flat Fee $+%"
          />
        ),
      },
      {
        title: "Cash Specialty Brand $+%",
        field: "specialtyBrandDispensingFeeCash",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters &&
          columnFiltersRef.current.specialtyBrandDispensingFeeCash,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.specialtyBrandDispensingFeeCash || ""}>
              <span>{rowData.specialtyBrandDispensingFeeCash || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.specialtyBrandDispensingFeeCash}
            placeholder="Cash Specialty Brand $+%"
          />
        ),
      },
      {
        title: "Cash Specialty Generic $+%",
        field: "specialtyGenericDispensingFeeCash",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters &&
          columnFiltersRef.current.specialtyGenericDispensingFeeCash,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.specialtyGenericDispensingFeeCash || ""}>
              <span>{rowData.specialtyGenericDispensingFeeCash || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.specialtyGenericDispensingFeeCash}
            placeholder="Cash Specialty Generic $+%"
          />
        ),
      },
      {
        title: "Cash Brand $+%",
        field: "brandDispensingFeeCash",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters && columnFiltersRef.current.brandDispensingFeeCash,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.brandDispensingFeeCash || ""}>
              <span>{rowData.brandDispensingFeeCash || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.brandDispensingFeeCash}
            placeholder="Cash Brand $+%"
          />
        ),
      },
      {
        title: "Cash Generic $+%",
        field: "genericDispensingFeeCash",
        type: "numeric",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters && columnFiltersRef.current.genericDispensingFeeCash,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.genericDispensingFeeCash || ""}>
              <span>{rowData.genericDispensingFeeCash || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.genericDispensingFeeCash}
            placeholder="Cash Generic $+%"
          />
        ),
      },
      {
        title: "Program Type",
        field: "programType",
        customFilterAndSearch: () => true,
        defaultFilter: enableFilters && columnFiltersRef.current.programType,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.programType || ""}>
              <span>{rowData.programType || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.programType}
            placeholder="Program Type"
          />
        ),
      },
      {
        title: "Billing Model",
        field: "billingModel",
        customFilterAndSearch: () => true,
        defaultFilter: enableFilters && columnFiltersRef.current.billingModel,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.billingModel || ""}>
              <span>{rowData.billingModel || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.billingModel}
            placeholder="Billing Model"
          />
        ),
      },
      {
        title: "Wholesaler",
        field: "wholesaler",
        customFilterAndSearch: () => true,
        defaultFilter: enableFilters && columnFiltersRef.current.wholesaler,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.wholesaler || ""}>
              <span>{rowData.wholesaler || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.wholesaler}
            placeholder="Wholesaler"
          />
        ),
      },
      {
        title: "Participating in Cash Program",
        field: "participatingInCashProgram",
        customFilterAndSearch: () => true,
        defaultFilter:
          enableFilters && columnFiltersRef.current.participatingInCashProgram,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.participatingInCashProgram || ""}>
              <span>{rowData.participatingInCashProgram || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.participatingInCashProgram}
            placeholder="Participating in Cash Program"
          />
        ),
      },
    ];

    const setControllersOnResp = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          pageNumber: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        const rowsPerPage = Number(pageSize);
        const totalPages = Math.ceil(
          pharmaciesTableData.totalElements / rowsPerPage
        );
        if (controllers.pageNumber > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
          currentPage = controllers.pageNumber;
        getPharmaciesTableData(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: controllers.sortOrder,
            sortBy: controllers.sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp)
        );
      },
      [columnFilters, pharmaciesTableData, controllers, formSubmittedValues]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = PHARMACIES_COLUMNS[orderedColumnId].field;
        setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        getPharmaciesTableData(
          {
            pageNumber: controllers.pageNumber,
            pageSize: controllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        );
      },
      [controllers, formSubmittedValues, columnFilters, pharmaciesTableData]
    );

    const handleColumnFilter = (filters) => {
      const filterPayload = getPharmaciesFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      getPharmaciesTableData(
        {
          ...formSubmittedValues,
          ...controllers,
          filter: filterPayload,
          pageNumber: pagination.page,
        },
        (resp) => setControllersOnResp(resp)
      );
    };

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        isFreeAction: true,
        disabled: isEmptyGrid(pharmaciesTableData),
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportButton({
          disabled: isEmptyGrid(pharmaciesTableData),
        }),
        isFreeAction: true,
        disabled: isEmptyGrid(pharmaciesTableData),
        onClick: () =>
          exportToExcel({
            controllers,
            columnFilters,
            formSubmittedValues,
            ceList,
          }),
      },
    ];

    return (
      <div className={globalClasses.tableCardPrimary}>
        <MaterialTable
          title={
            <BasicTypography
              variant="h5"
              title={`Pharmacy List (${getTableHeaderCount(
                pharmaciesTableData.totalElements
              )})`}
            />
          }
          columns={PHARMACIES_COLUMNS}
          data={pharmaciesTableData.content || []}
          page={controllers.pageNumber - 1}
          totalCount={pharmaciesTableData.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          tableRef={tableRef}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            showFirstLastPageButtons: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(pharmaciesTableData)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </div>
    );
  })
);

export default PharmaciesTable;
