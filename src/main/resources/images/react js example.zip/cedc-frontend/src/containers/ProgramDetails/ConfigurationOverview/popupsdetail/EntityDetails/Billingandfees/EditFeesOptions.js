import React, { memo } from "react";
import { FormLabel, Grid } from "@material-ui/core";
import { Field, useFormikContext } from "formik";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import ExistingClientData from "./ExistingClientData";

const EditFeesOptions = () => {
  const { values, errors, handleChange, setFieldValue } = useFormikContext();
  const globalClasses = useGlobalStyles();

  const handleRadioChange = (e) => {
    setFieldValue("selectedClients", []);
    setFieldValue("customizedOrNot", []);
    handleChange(e);
  };

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2} alignItems="center">
          <Grid item>
            <Grid container spacing={1} alignItems="center">
              <Grid item className={globalClasses.verticalCenter}>
                <Field
                  id="newClient"
                  type="radio"
                  name="applicableFor"
                  className={globalClasses.formControl}
                  value="1"
                  onChange={handleRadioChange}
                />
              </Grid>
              <Grid item>
                <FormLabel
                  htmlFor="newClient"
                  className={globalClasses.switchRadioLabels}
                >
                  Apply only for the new clients
                </FormLabel>
              </Grid>
            </Grid>
          </Grid>
          <Grid item>
            <Grid container spacing={1} alignItems="center">
              <Grid item className={globalClasses.verticalCenter}>
                <Field
                  id="existingClient"
                  type="radio"
                  name="applicableFor"
                  className={globalClasses.formControl}
                  value="2"
                  onChange={handleRadioChange}
                />
              </Grid>
              <Grid item>
                <FormLabel
                  htmlFor="existingClient"
                  className={globalClasses.switchRadioLabels}
                >
                  Apply only to the existing clients
                </FormLabel>
              </Grid>
            </Grid>
          </Grid>
          <Grid item>
            <Grid container spacing={1} alignItems="center">
              <Grid item className={globalClasses.verticalCenter}>
                <Field
                  id="allClient"
                  type="radio"
                  name="applicableFor"
                  className={globalClasses.formControl}
                  value="3"
                  onChange={handleRadioChange}
                />
              </Grid>
              <Grid item>
                <FormLabel
                  htmlFor="allClient"
                  className={globalClasses.switchRadioLabels}
                >
                  Apply to all clients
                </FormLabel>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        {errors.applicableFor && (
          <BasicTypography color="error" variant="caption">
            {errors.applicableFor}
          </BasicTypography>
        )}
      </Grid>
      {Number(values.applicableFor) === 2 && (
        <Grid item md={12}>
          <ExistingClientData />
        </Grid>
      )}
    </Grid>
  );
};

export default memo(EditFeesOptions);
