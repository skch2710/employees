import { userdata } from "../../../../../../utils/common";

const userRole = JSON.parse(userdata());

export const getPayload = (values) => {
  return {
    ...(values.clientConfigId ? { clientConfigId: values.clientConfigId } : {}),
    programTypeId: values.programType,
    claimProcessTypeId: values.claimType,
    claimsReprocess: values.claimReprocess === true ? "Y" : "N",
    cashCliamsLesserOfLogic: values.cashClaimLesserLogic === true ? "Y" : "N",
    reversalConstraint:
      values.reversalConstraintInput == ""
        ? "0.00"
        : values.reversalConstraintInput,
    brandMinSpread:
      values.brandMinSpread == "" || values.brandMinSpread == "0"
        ? "0.00"
        : Number(values.brandMinSpread),
    brandMinAdminFee:
      values.brandMinAdminFee == "" || values.brandMinAdminFee == "0"
        ? "0.00"
        : values.brandMinAdminFee,
    genericMinSpread:
      values.genericMinSpread == "" || values.genericMinSpread == "0"
        ? "0.00"
        : values.genericMinSpread,
    genericMinAdminFee:
      values.genericMinAdminFee == "" || values.genericMinAdminFee == "0"
        ? "0.00"
        : values.genericMinAdminFee,
    minSpreadOrAdminFeeFlag: values.turnOnMinSpread === true ? "Y" : "N",
    modifiedById: userRole.userId,
  };
};
