import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../../utils/helper";

export const useProviderStyle = makeStyles((theme) => {
  return {
    tableHeader: {
      background: theme.colors.monochrome.tableHeaderBackground,
      color: theme.colors.monochrome.tableHeaderText,
      fontSize: "11px",
      whiteSpace: "nowrap",
      border: "none",
      textAlign: "unset !important",
      padding: "5px 0",
    },
    exportContainer: {
      textAlign: "right",
      padding: "8px 10px 0 0",
    },
    adminType: {
      fontWeight: "bold",
      fontSize: "0.75rem",
      borderRadius: 8,
      padding: "4px 10px",
      display: "inline-block",
      marginTop: "2px",
      color: "#FFFFFF",
      width: "120px",
    },
    deaTableInput: {
      borderWidth: 1,
      borderStyle:"solid",
      borderColor:theme.colors.monochrome.inputIconsColor,
      borderRadius: "4px",
      padding: "4px",
      boxShadow: "none"
    },
    providerDeaTableContainer:{
      "& .MuiToolbar-root": {
        paddingBottom: "10px",
      },
      "& .MuiSvgIcon-fontSizeSmall":{
        fontSize:"1rem",
        color:theme.colors.green.active
      }
    },
    enableFilterButton: (props = {}) => {
      return {
        marginRight: getGridActionButtonsMarginRight(props),
        marginTop: "-38px",
        marginBottom: "6px",
        paddingLeft: "6px",
        minHeight: "30px",
      };
    },
    dialogPaper: {
      minHeight: "44vh",
    },
  };
});
