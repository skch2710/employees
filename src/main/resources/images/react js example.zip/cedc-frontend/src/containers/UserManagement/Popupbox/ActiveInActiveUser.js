import React from "react";
import { Button, Grid } from "@material-ui/core";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";

const ActiveInActiveUser = ({ setActiveUser, activeType, handleSubmit }) => {
  const globalClasses = useGlobalStyles();

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <p style={{ width: "405px" }}>Do you want to {activeType} this user?</p>
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={2} justifyContent="flex-end">
          <Grid item>
            <Button
              type="submit"
              color="primary"
              size="small"
              variant="contained"
              className={globalClasses.primaryBtn}
              onClick={handleSubmit}
            >
              Yes
            </Button>
          </Grid>
          <Grid item>
            <Button
              type="reset"
              size="small"
              variant="outlined"
              color="default"
              className={globalClasses.secondaryBtn}
              onClick={() => setActiveUser(false)}
            >
              No
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default ActiveInActiveUser;
