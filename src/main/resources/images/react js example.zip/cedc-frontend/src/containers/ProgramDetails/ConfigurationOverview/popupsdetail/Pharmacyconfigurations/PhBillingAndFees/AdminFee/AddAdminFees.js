import { Box, FormLabel, Grid, Typography } from "@material-ui/core";
import { Field, useFormikContext } from "formik";
import _isArray from "lodash/isArray";
import moment from "moment";
import React, {
  forwardRef,
  useContext,
  useEffect,
  useImperativeHandle,
  useState,
} from "react";
import { useDispatch } from "react-redux";
import { useGlobalStyles } from "../../../../../../../Styles/useGlobalStyles";
import DatePicker from "../../../../../../../components/common/DatePicker";
import BasicTypography from "../../../../../../../components/common/Typography/BasicTypography";
import {
  fetchAddClaimTypesOption,
  fetchBasisOfOptions,
  fetchClaimTypesOption,
  fetchFeesTypes,
} from "../../../../../../../context/actions/ConfigOverview";
import {
  endDateValidation,
  startDateValidation,
} from "../../../../../../../utils/common";
import { COContext } from "../../../../../COContext";
import { usePhBillingAndFeesStyles } from "../styles";
import AutoComplete from "../../../../../../../components/common/AutoComplete";

const AddAdminFees = forwardRef((_props, ref) => {
  const { values, setFieldValue, resetForm, errors, touched } =
    useFormikContext();
  const dispatch = useDispatch();
  const { currentPharmacy = {} } = useContext(COContext);
  const globalClasses = useGlobalStyles();
  const classes = usePhBillingAndFeesStyles();
  const [feesTypeOptions, setFeesTypesOptions] = useState([]);
  const [claimTypesOptions, setClaimTypesOptions] = useState([]);
  const [addClaimTypesOptions, setAddClaimTypesOptions] = useState([]);
  const [basisOfOptions, setBasisOfOptions] = useState([]);

  // After clicking on add another we need to fetch new fee types.
  useImperativeHandle(ref, () => ({
    fetchFeeTypes() {
      getFeesTypes();
    },
  }));

  const getFeesTypes = async () => {
    if (values.isEdit) {
      setFeesTypesOptions([
        {
          adminFeeTypeNewId: Number(values.feesType),
          adminFeeType: values.feeTypeLabel,
        },
      ]);
    } else {
      const resp = await dispatch(
        fetchFeesTypes({ ceId: 0, clientId: currentPharmacy.clientId })
      );
      if (_isArray(resp)) {
        // *To exclude Pharmacy Chain Gross Savings option in client level only
        const afterExcludedOptions = resp.filter((type = {}) => {
          return type.adminFeeTypeNewId !== 9;
        });
        setFeesTypesOptions(afterExcludedOptions);
      }
    }
  };

  const getClaimTypesOptions = async () => {
    const resp = await fetchClaimTypesOption();
    resp && setClaimTypesOptions(resp);
  };

  const getAddClaimTypesOptions = async () => {
    const resp = await fetchAddClaimTypesOption();
    resp && setAddClaimTypesOptions(resp);
  };

  const getBasisOfOptions = async () => {
    const resp = await fetchBasisOfOptions();
    resp && setBasisOfOptions(resp);
  };

  useEffect(() => {
    getFeesTypes();
    getClaimTypesOptions();
    getAddClaimTypesOptions();
    getBasisOfOptions();
  }, []);

  const getFeesTypeName = (value) => {
    const fee =
      feesTypeOptions.find((fee) => {
        return fee.adminFeeTypeNewId === Number(value);
      }) || {};
    return fee.adminFeeType;
  };

  const getStartDate = ({ setFieldValue, values }) => {
    return (
      <>
        <FormLabel required>340BDirect+ Fee Start Date</FormLabel>
        <Field as="select" name="startDate">
          {({ field }) => (
            <DatePicker
              {...field}
              onChange={(_e, date) => {
                if (!date) setFieldValue("endDate", "");
                setFieldValue("startDate", date);
              }}
              value={
                values.startDate ? moment(values.startDate, "MM/DD/YYYY") : ""
              }
              disabledDate={(d) => startDateValidation(d, values.endDate)}
            />
          )}
        </Field>
        {errors.startDate && touched.startDate && (
          <Typography color="error" variant="caption">
            {errors.startDate}
          </Typography>
        )}
      </>
    );
  };

  const getPercentage = ({ setFieldValue }) => {
    return (
      <>
        <FormLabel required>Percentage</FormLabel>
        <div className={classes.percentageWrapper}>
          <span>%</span>
          <Field
            name="adminFeePercentage"
            type="text"
            className={globalClasses.formControl}
            placeholder="Enter Percentage"
            onChange={(e) => {
              const { value } = e.target;
              const regEx = /^(\d{0,2}(\.\d{0,2})?|100(\.00?)?)$/g;
              if (value && !regEx.test(value)) return;
              setFieldValue("adminFeePercentage", value.toString());
            }}
          />
        </div>
        {errors.adminFeePercentage && touched.adminFeePercentage && (
          <Typography color="error" variant="caption">
            {errors.adminFeePercentage}
          </Typography>
        )}
      </>
    );
  };

  const getEndDate = ({ setFieldValue, values }) => {
    return (
      <>
        <FormLabel>340BDirect+ Fee End Date</FormLabel>
        <Field as="select" name="endDate">
          {({ field }) => (
            <DatePicker
              {...field}
              onChange={(_e, date) => {
                setFieldValue("endDate", date);
              }}
              value={values.endDate ? moment(values.endDate, "MM/DD/YYYY") : ""}
              disabledDate={(d) => endDateValidation(d, values.startDate)}
            />
          )}
        </Field>
      </>
    );
  };

  const getClaimType = () => {
    return (
      <>
        <FormLabel required>Claim Type</FormLabel>
        <Field
          as="select"
          name="claimType"
          className={globalClasses.formControl}
        
        >
          {({ field }) => (
            <AutoComplete
              {...field}
              options={_isArray(claimTypesOptions) ? claimTypesOptions : []}
              inputPlaceholder={"Select Claim Type"}
              disableCloseOnSelect={false}
              disabled={values.isEdit}
              onChange={(e, value) => {
                setFieldValue(
                  "claimType",
                  value ? value.adminFeeClaimTypeId : 0
                );
              }}
              getOptionLabel={(option) => option.adminFeeClaimType || ""}
              value={
                (_isArray(claimTypesOptions) &&
                  claimTypesOptions.find(
                    (e) => e.adminFeeClaimTypeId == values.claimType
                  )) ||
                ""
              }
              renderOption={(option, _other) => {
                return (
                  <BasicTypography variant="subtitle2">
                    {option.adminFeeClaimType}
                  </BasicTypography>
                );
              }}
              multiple={false}
              textFieldProps={{
                inputProps: {
                  name: "claimType",
                },
              }}
            />
          )}
        </Field>
        {errors.claimType && touched.claimType && (
          <Typography color="error" variant="caption">
            {errors.claimType}
          </Typography>
        )}
      </>
    );
  };

  const getAddClaimType = () => {
    return (
      <>
        <FormLabel required>Additional Claim Type Detail </FormLabel>
        <Field
          as="select"
          name="addClaimType"
          className={globalClasses.formControl}
         
        >
          {({ field }) => (
            <AutoComplete
              {...field}
              options={
                _isArray(addClaimTypesOptions) ? addClaimTypesOptions : []
              }
              inputPlaceholder={"Select Additional Claim Type"}
              disableCloseOnSelect={false}
              disabled={values.isEdit}
              onChange={(e, value) => {
                setFieldValue(
                  "addClaimType",
                  value ? value.adminFeeAddlClaimTypeId : 0
                );
              }}
              getOptionLabel={(option) => option.adminFeeAddlClaimType || ""}
              value={
                (_isArray(addClaimTypesOptions) &&
                  addClaimTypesOptions.find(
                    (e) => e.adminFeeAddlClaimTypeId == values.addClaimType
                  )) ||
                ""
              }
              renderOption={(option, _other) => {
                return (
                  <BasicTypography variant="subtitle2">
                    {option.adminFeeAddlClaimType}
                  </BasicTypography>
                );
              }}
              multiple={false}
              textFieldProps={{
                inputProps: {
                  name: "addClaimType",
                },
              }}
            />
          )}
        </Field>
        {errors.addClaimType && touched.addClaimType && (
          <Typography color="error" variant="caption">
            {errors.addClaimType}
          </Typography>
        )}
      </>
    );
  };

  const getFlatFee = () => {
    return (
      <>
        <FormLabel required>340BDirect+ Flat Fee</FormLabel>
        <div className={classes.percentageWrapper}>
          <span>$</span>
          <Field
            name="adminFee"
            type="text"
            className={globalClasses.formControl}
            placeholder="Enter 340BDirect+ Flat Fee"
            onChange={(e) => {
              const { value } = e.target;
              const regEx = /^\d*\.{0,1}\d{0,2}$/g;
              if (value && !regEx.test(value)) return;
              setFieldValue("adminFee", value.toString());
            }}
          />
        </div>
        {errors.adminFee && touched.adminFee && (
          <Typography color="error" variant="caption">
            Please enter the 340BDirect+ Flat Fee
          </Typography>
        )}
      </>
    );
  };

  const getBasisOf = () => {
    return (
      <>
        <FormLabel>Basis of</FormLabel>
        <Field as="select" name="basisOf" className={globalClasses.formControl}>
          {({ field }) => (
            <AutoComplete
              {...field}
              disableCloseOnSelect={false}
              options={_isArray(basisOfOptions) ? basisOfOptions : []}
              onChange={(_e, value) => {
                setFieldValue("basisOf", value ? value.percentageBasisId : "");
              }}
              getOptionLabel={(option) => option.percentageBasisType || ""}
              renderOption={(option, _other) => {
                return (
                  <BasicTypography variant="subtitle2">
                    {option.percentageBasisType}
                  </BasicTypography>
                );
              }}
              value={
                (_isArray(basisOfOptions) &&
                  basisOfOptions.find(
                    (e) =>
                      e.percentageBasisId ==
                      (values.basisOf == 0 ? 1 : values.basisOf)
                  )) ||
                ""
              }
              multiple={false}
            />
          )}
        </Field>
      </>
    );
  };

  return (
    <Grid container direction="column" spacing={4}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <FormLabel required>Add Fee Type</FormLabel>
            <Field
              as="select"
              name="feesType"
              className={globalClasses.formControl}
            >
              {({ field }) => (
                <AutoComplete
                  {...field}
                  disabled={values.clientAdminFeeNewId}
                  options={_isArray(feesTypeOptions) ? feesTypeOptions : []}
                  disableCloseOnSelect={false}
                  inputPlaceholder={"Select Fee Type"}
                  onChange={(e, value) => {
                    resetForm();
                    setFieldValue(
                      "feesType",
                      value ? value.adminFeeTypeNewId : 0
                    );
                  }}
                  getOptionLabel={(option) => option.adminFeeType || ""}
                  value={
                    (_isArray(feesTypeOptions) &&
                      feesTypeOptions.find(
                        (e) => e.adminFeeTypeNewId == values.feesType
                      )) ||
                    ""
                  }
                  renderOption={(option, _other) => {
                    return (
                      <BasicTypography variant="subtitle2">
                        {option.adminFeeType}
                      </BasicTypography>
                    );
                  }}
                  multiple={false}
                  textFieldProps={{
                    inputProps: {
                      name: "feesType",
                    },
                  }}
                />
              )}
            </Field>
            {errors.feesType && touched.feesType && (
              <Typography color="error" variant="caption">
                {errors.feesType}
              </Typography>
            )}
          </Grid>
          {Number(values.feesType) === 0 && (
            <Grid item xs={12} sm={4}>
              <Box className={classes.adminFeeTypeNotice}>
                <p>Select Fee Type to configure</p>
              </Box>
            </Grid>
          )}
        </Grid>
      </Grid>
      <Grid item md={12}>
        <Grid container spacing={1} direction="column">
          <Grid item md={12}>
            <BasicTypography variant="h4">
              {getFeesTypeName(values.feesType)}
            </BasicTypography>
          </Grid>
          <Grid item md={12}>
            <Grid container spacing={2}>
              {Number(values.feesType) === 3 && (
                <>
                  <Grid item xs={12} sm={4}>
                    <FormLabel required>Flat Fee Per Transaction</FormLabel>
                    <div className={classes.percentageWrapper}>
                      <span>$</span>
                      <Field
                        name="adminFee"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Flat Fee Per Transaction"
                        onChange={(e) => {
                          const { value } = e.target;
                          const regEx = /^\d*\.{0,1}\d{0,2}$/g;
                          if (value && !regEx.test(value)) return;
                          setFieldValue("adminFee", value.toString());
                        }}
                      />
                    </div>
                    {errors.adminFee && touched.adminFee && (
                      <Typography color="error" variant="caption">
                        Please enter the Flat Fee Per Transaction
                      </Typography>
                    )}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getClaimType()}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getAddClaimType()}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getStartDate({ setFieldValue, values })}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getEndDate({ setFieldValue, values })}
                  </Grid>
                </>
              )}
              {Number(values.feesType) === 4 && (
                <>
                  <Grid item xs={12} sm={4}>
                    {getPercentage({ setFieldValue })}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getBasisOf()}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getStartDate({ setFieldValue, values })}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getEndDate({ setFieldValue, values })}
                  </Grid>
                </>
              )}
              {Number(values.feesType) === 5 && (
                <>
                  <Grid item xs={12} sm={4}>
                    {getFlatFee()}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getPercentage({ setFieldValue })}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getBasisOf()}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getClaimType()}
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    {getAddClaimType()}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getStartDate({ setFieldValue, values })}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getEndDate({ setFieldValue, values })}
                  </Grid>
                </>
              )}
              {Number(values.feesType) === 6 && (
                <>
                  <Grid item xs={12} sm={4}>
                    {getFlatFee()}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getStartDate({ setFieldValue, values })}
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    {getEndDate({ setFieldValue, values })}
                  </Grid>
                </>
              )}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
});

export default AddAdminFees;
