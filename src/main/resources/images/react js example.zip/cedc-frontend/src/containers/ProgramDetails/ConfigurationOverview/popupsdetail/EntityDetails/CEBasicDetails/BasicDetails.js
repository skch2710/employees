import React, { useState, useEffect, useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Grid, Button, FormLabel } from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import DatePicker from "../../../../../../components/common/DatePicker";
import moment from "moment";
import _isEmpty from "lodash/isEmpty";
import { toast } from "react-toastify";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import {
  getCeBasicDetailsDefaultValues,
  CeBaicDetailsDefaultValuesFromRes,
  getbasicDetailsGetData,
} from "./constants";
import LoaderUI from "../../../../../../components/common/Loader/Loader";
import {
  CoCebasicdetails,
  Cobasicdetailsmsguuid,
  getstates,
  CETypedropdownlist,
  getCecodeExist,
  PrimaryContactdetails,
} from "../../../../../../context/actions/CoCebasicdetails";
import {
  fetchTermsGridTableData,
  getCOBasicDetails,
  getPrimaryContactDetails,
  updateSectionStatus,
} from "../../../../../../context/actions/ConfigOverview";
import {
  endDateValidation,
  startDateValidation,
  userdata,
} from "../../../../../../utils/common";
import { COContext } from "../../../../COContext";
import { MENUS } from "../../../PopupSidebar/constants";
import { getAllCoveredEntities } from "../../../../../../context/actions/Common";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useCeBasicDetailsStyles } from "./BasicDetailsStyle";
import {
  LABELS,
  POLLING_COUNT,
  REGEX,
} from "../../../../../../utils/constants";
import AutoComplete from "../../../../../../components/common/AutoComplete";
import _isArray from "lodash/isArray";

const BasicDetails = ({
  clickOnAdd,
  setclickOnAdd,
  basicDetailsGetData,
  primaryState,
  setPrimarystate,
}) => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = useCeBasicDetailsStyles();
  const {
    menusStatuses,
    setMenusStatuses,
    setPopupActiveMenu,
    setOpenAddCePopup,
    setMessageUuid,
    messageUuid,
    setOpenAddUserPopup,
    ceId,
    setCeId,
    setCoveredEntityName,
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
  } = useContext(COContext) || {};
  const { basicDetails } = menusStatuses;
  const [defaultValues, setDefaultValues] = useState(
    getCeBasicDetailsDefaultValues()
  );

  const userrole = JSON.parse(userdata());
  const fetchBasicDetails = async () => {
    const payload = {
      ceID: ceId,
    };
    const basicDetails = await dispatch(getCOBasicDetails(payload));
    const primaryContact = await dispatch(PrimaryContactdetails(ceId));
    if (primaryContact) {
      setPrimarystate(true);
    } else {
      setPrimarystate(false);
    }
    const res = { ...basicDetails, ...primaryContact };
    if (res) setMessageUuid(res);
    if (res) setDefaultValues(CeBaicDetailsDefaultValuesFromRes(res));
  };

  useEffect(() => {
    if (ceId && ceId !== "") {
      fetchBasicDetails();
      // setPrimarystate(true);
    }
  }, []);

  useEffect(() => {
    if (basicDetailsGetData && basicDetailsGetData !== null) {
      setDefaultValues(getbasicDetailsGetData(basicDetailsGetData));
    }
  }, [basicDetailsGetData]);

  const [ceCodeExist, setCeCodeExist] = useState("");

  const handleChangeHRSAID = (e, setFieldValue) => {
    const regEx = /^\s+|\s{2,}$/g;
    const { value } = e.target;
    if (value && regEx.test(value)) return;
    setFieldValue("hrsaID", e.target.value);
    dispatch(
      getCecodeExist(e.target.value, (res) => {
        if (res.statusCode == 404) setCeCodeExist(res.errorMessage);
        if (res.statusCode == 200) setCeCodeExist("");
      })
    );
  };

  const handleChangeContractTerm = (e, setFieldValue, values) => {
    const value = e.target.value;
    const regEx = /^[0-9]*(\.[0-9]{0,1})?$/;
    if (value && !regEx.test(e.target.value)) return;
    setFieldValue("contractTerm", e.target.value);
    const newDate = moment(values.startDate).add(
      Number(e.target.value),
      "years"
    );
    const updatedEndDate = moment(newDate).format("MM/DD/YYYY");
    setFieldValue("endDate", e.target.value == "" ? "" : updatedEndDate);
  };

  const handleValidate = (values) => {
    let error = {};
    if (!values.ceName) {
      error.ceName = "Please enter the Covered Entity";
    }
    if (!values.addressLine1) {
      error.addressLine1 = "Please enter the Address Line 1";
    }
    if (!values.cityName) {
      error.cityName = "Please enter the City ";
    }
    if (!values.stateId) {
      error.stateId = "Please select the State";
    }
    if (values.zipCode.length < 5) {
      error.zipCode = "Please enter the 5 digit Zip Code only";
    }
    if (!values.hrsaID) {
      setCeCodeExist("");
      error.hrsaID = "Please enter  the HRSA ID";
    }
    if (!(ceCodeExist === "")) {
      error.hrsaID = ceCodeExist;
    }

    if (!values.ceTypeId) {
      error.ceTypeId = "Please select the Covered Entity Type";
    }
    if (messageUuid == false) {
      if (!values.startDate) {
        error.startDate = "Please select the MSA Start Date";
      }
    }

    return error;
  };

  const handleSubmit = async (values) => {
    const payload = {
      ceid: ceId ? ceId : null,
      ceCode: values.hrsaID.trim(),
      ceName: values.ceName.trim(),
      ceTypeId: values.ceTypeId,
      createdBy: userrole.userId,
      modifiedBy: userrole.userId,
      contractTerm: values.contractTerm,
      contractStartDate: values.startDate,
      contractEndDate: values.endDate,
      effectiveDate: values.effectiveDate,
      entityAddress: {
        address1: values.addressLine1.trim(),
        address2: values.addressLine2.trim(),
        city: values.cityName.trim(),
        stateId: values.stateId,
        zipCode: values.zipCode,
        createdBy: userrole.userId,
        modifiedBy: userrole.userId,
      },
    };
    const res = await dispatch(CoCebasicdetails(payload));
    if (!_isEmpty(res)) {
      if (res.data) {
        handlePolling({
          messageUuid: res.data,
          currentCount: POLLING_COUNT,
        });
      }
    }
  };

  const handlePolling = async ({ messageUuid, currentCount }) => {
    const count = currentCount;
    const resp = await dispatch(Cobasicdetailsmsguuid(messageUuid, count));
    if (resp && resp.statusCode === 200) {
      setMessageUuid(resp.data);
      setCeId(resp.data.ceid);
      setCoveredEntityName(resp.data.ceName);
      dispatch(getAllCoveredEntities({ disableLoader: true }));

      // Fetch updated Basic details and primary contact data and
      // set to defaultValues to bind to form fields
      const coBasicDetails = await dispatch(
        getCOBasicDetails({ ceID: resp.data.ceid }, { disableLoader: true })
      );
      const coPrimaryContact = await dispatch(
        getPrimaryContactDetails(resp.data.ceid, { disableLoader: true })
      );
      const res = { ...coBasicDetails, ...coPrimaryContact };
      if (res) setDefaultValues(CeBaicDetailsDefaultValuesFromRes(res));

      if (clickOnAdd || basicDetails) {
        dispatch(
          updateSectionStatus({
            ceId: resp.data.ceid,
            sectionId: 1,
            callback,
          })
        );
      }
    } else if (resp && resp.statusCode === 102 && count > 1) {
      handlePolling({ messageUuid, currentCount: count - 1 });
    } else if (resp && resp.statusCode === 500) {
      toast.error(resp.errorMessage);
    }
  };

  const callback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({ ...prev, basicDetails: false }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  useEffect(() => {
    dispatch(getstates());
    dispatch(CETypedropdownlist());
  }, []);

  const statelist = useSelector((state) => state.ce_states_list.records) || [];
  const CEtypelist =
    useSelector((state) => state.CETypedropdownvalues.records) || [];

  const loader = useSelector(
    (state) => state.Cebasic_detailsmessageuuid.loading
  );

  return (
    <>
      {loader ? <LoaderUI /> : ""}
      <Formik
        enableReinitialize={true}
        initialValues={defaultValues}
        onSubmit={handleSubmit}
        validate={handleValidate}
      >
        {({ values, setFieldValue, errors, touched }) => (
          <Grid container spacing={2}>
            <Grid item md={12}>
              <BasicTypography
                variant="h4"
                title="Entity Details > Basic Details"
              />
            </Grid>
            <Grid item md={12}>
              <BasicTypography variant="h5" title="Covered Entity Details" />
            </Grid>
            <Grid item md={12}>
              <Form>
                <Grid container spacing={2}>
                  <Grid item md={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>{LABELS.CoveredEntity}</FormLabel>
                        <Field
                          name="ceName"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Covered Entity"
                          maxLength={150}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (value && !REGEX.alphabetsAndHypen.test(value))
                              return;
                            setFieldValue("ceName", value);
                          }}
                        />
                        {errors.ceName && touched.ceName && (
                          <BasicTypography color="error" variant="caption">
                            {errors.ceName}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Address Line 1</FormLabel>
                        <Field
                          name="addressLine1"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Address Line 1"
                          maxLength={100}
                          onChange={(e) => {
                            const regEx = /^\s+|\s{2,}$/g;
                            const { value } = e.target;
                            if (value && regEx.test(value)) return;
                            setFieldValue("addressLine1", value);
                          }}
                        />
                        {errors.addressLine1 && touched.addressLine1 && (
                          <BasicTypography color="error" variant="caption">
                            {errors.addressLine1}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Address Line 2</FormLabel>
                        <Field
                          name="addressLine2"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Address Line 2"
                          maxLength={100}
                          onChange={(e) => {
                            const regEx = /^\s+|\s{2,}$/g;
                            const { value } = e.target;
                            if (value && regEx.test(value)) return;
                            setFieldValue("addressLine2", value);
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>City</FormLabel>
                        <Field
                          name="cityName"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter City"
                          maxLength={100}
                          onChange={(e) => {
                            const regEx = /^\s+|\s{2,}$/g;
                            const { value } = e.target;
                            if (value && regEx.test(value)) return;
                            setFieldValue("cityName", value);
                          }}
                        />
                        {errors.cityName && touched.cityName && (
                          <BasicTypography color="error" variant="caption">
                            {errors.cityName}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>State</FormLabel>
                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="stateId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={_isArray(statelist) ? statelist : []}
                              inputPlaceholder={"Select State"}
                              value={
                                (_isArray(statelist) &&
                                  statelist.find(
                                    (e) => e.stateId == values.stateId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue ? newValue.stateId : "";
                                setFieldValue("stateId", value);
                              }}
                              getOptionLabel={(option) =>
                                option.stateName || ""
                              }
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.stateName}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                              textFieldProps={{
                                inputProps: {
                                  name: "stateId",
                                },
                              }}
                            />
                          )}
                        </Field>

                        {errors.stateId && touched.stateId && (
                          <BasicTypography color="error" variant="caption">
                            {errors.stateId}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Zip</FormLabel>
                        <Field
                          name="zipCode"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Zip Code"
                          maxLength={100}
                          onChange={(e) => {
                            const value = e.target.value;
                            const regEx = /^[0-9]{1,5}$/g;
                            if (value && !regEx.test(e.target.value)) return;
                            setFieldValue("zipCode", e.target.value);
                          }}
                        />
                        {errors.zipCode && touched.zipCode && (
                          <BasicTypography color="error" variant="caption">
                            {errors.zipCode}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>HRSA ID</FormLabel>
                        <Field
                          name="hrsaID"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter HRSA ID"
                          maxLength={15}
                          onChange={(e) => handleChangeHRSAID(e, setFieldValue)}
                        />
                        {errors.hrsaID && touched.hrsaID && (
                          <BasicTypography color="error" variant="caption">
                            {errors.hrsaID}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel required>Covered Entity Type</FormLabel>

                        <Field
                          as="select"
                          className={globalClasses.formControl}
                          name="ceTypeId"
                        >
                          {({ field }) => (
                            <AutoComplete
                              {...field}
                              disableCloseOnSelect={false}
                              options={_isArray(CEtypelist) ? CEtypelist : []}
                              inputPlaceholder={"Select Covered Entity Type"}
                              value={
                                (_isArray(CEtypelist) &&
                                  CEtypelist.find(
                                    (e) => e.ceTypeId == values.ceTypeId
                                  )) ||
                                ""
                              }
                              onChange={(e, newValue) => {
                                const value = newValue ? newValue.ceTypeId : "";
                                setFieldValue("ceTypeId", value);
                              }}
                              getOptionLabel={(option) => option.ceType || ""}
                              renderOption={(option, _other) => {
                                return (
                                  <BasicTypography variant="subtitle2">
                                    {option.ceType}
                                  </BasicTypography>
                                );
                              }}
                              multiple={false}
                              textFieldProps={{
                                inputProps: {
                                  name: "ceTypeId",
                                },
                              }}
                            />
                          )}
                        </Field>
                        {errors.ceTypeId && touched.ceTypeId && (
                          <BasicTypography color="error" variant="caption">
                            {errors.ceTypeId}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={6} sm={2}>
                        <FormLabel required={!messageUuid}>
                          MSA Start Date
                        </FormLabel>
                        <Field as="select" name="startDate">
                          {({ field }) => (
                            <DatePicker
                              placeholder="MSA Start Date"
                              disabledDate={(date) =>
                                startDateValidation(date, values.endDate)
                              }
                              {...field}
                              disabled={
                                defaultValues && defaultValues.startDate
                              }
                              onChange={(_e, date) => {
                                setFieldValue("startDate", date);
                                setFieldValue("endDate", "");
                                setFieldValue("contractTerm", "");
                              }}
                              value={
                                values.startDate
                                  ? moment(values.startDate, "MM/DD/YYYY")
                                  : ""
                              }
                              getPopupContainer={(triggerNode) => {
                                return triggerNode.parentNode;
                              }}
                            />
                          )}
                        </Field>
                        {errors.startDate && touched.startDate && (
                          <BasicTypography color="error" variant="caption">
                            {errors.startDate}
                          </BasicTypography>
                        )}
                      </Grid>
                      <Grid item xs={6} sm={2}>
                        <FormLabel>MSA End Date</FormLabel>
                        <Field as="select" name="endDate">
                          {({ field }) => (
                            <DatePicker
                              placeholder="MSA End Date"
                              disabledDate={(d) =>
                                endDateValidation(d, values.startDate)
                              }
                              {...field}
                              onChange={(e, date) => {
                                setFieldValue("effectiveDate", "");
                                setFieldValue("endDate", date);
                                setFieldValue("contractTerm", "");
                                if (values.startDate != "" && date != "") {
                                  var result = moment(new Date(date)).diff(
                                    new Date(values.startDate),
                                    "months",
                                    true
                                  );
                                  var contractdec = result / 12;
                                  setFieldValue(
                                    "contractTerm",
                                    contractdec.toFixed(1)
                                  );
                                }
                              }}
                              value={
                                values.endDate
                                  ? moment(values.endDate, "MM/DD/YYYY")
                                  : ""
                              }
                              getPopupContainer={(triggerNode) => {
                                return triggerNode.parentNode;
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Effective Date</FormLabel>
                        <Field as="select" name="effectiveDate">
                          {({ field }) => (
                            <DatePicker
                              disabledDate={(date) =>
                                !date ||
                                (values.endDate &&
                                  !date.isSameOrBefore(values.endDate, "day"))
                              }
                              {...field}
                              disabled={true}
                              onChange={(_e, date) => {
                                setFieldValue("effectiveDate", date);
                              }}
                              value={
                                values.effectiveDate
                                  ? moment(values.effectiveDate, "MM/DD/YYYY")
                                  : ""
                              }
                              getPopupContainer={(triggerNode) => {
                                return triggerNode.parentNode;
                              }}
                            />
                          )}
                        </Field>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <FormLabel>Contract Term (In Years)</FormLabel>
                        <Field
                          name="contractTerm"
                          type="text"
                          className={globalClasses.formControl}
                          placeholder="Enter Contract Term (In Years)"
                          onChange={(e) =>
                            handleChangeContractTerm(e, setFieldValue, values)
                          }
                          disabled={values.startDate !== "" ? false : true}
                        />
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sm={4}
                        className={classes.addBtnContainer}
                      >
                        <Button
                          type="submit"
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                        >
                          {!messageUuid ? "Save" : "Update"}
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                  {ceId !== "" ? (
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Covered Entity Main Contact"
                      />
                    </Grid>
                  ) : null}
                  {primaryState ? (
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Full Name</FormLabel>
                          <Field
                            name="fullName"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter Full Name"
                            disabled
                          />
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Email Address</FormLabel>
                          <Field
                            name="emailAddress"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter Email Address"
                            disabled
                          />
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Contact Number</FormLabel>
                          <Field
                            name="contactNumber"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter Contact Number"
                            disabled
                          />
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Title</FormLabel>
                          <Field
                            name="title"
                            type="text"
                            className={globalClasses.formControl}
                            placeholder="Enter title"
                            disabled
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                  ) : null}
                  {ceId !== "" && (
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}></Grid>
                        <Grid item xs={12} sm={4}></Grid>
                        <Grid item xs={6} sm={2}></Grid>
                        <Grid
                          item
                          xs={6}
                          sm={2}
                          className={classes.addUserBtnContainer}
                        >
                          <Button
                            startIcon={<AddCircleOutlineIcon />}
                            size="small"
                            variant="outlined"
                            className={globalClasses.secondaryBtn}
                            onClick={() => {
                              setOpenAddUserPopup(true);
                              setclickOnAdd(true);
                            }}
                          >
                            Add User
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  )}
                  <Grid item md={12}>
                    <Grid container justifyContent="flex-end" spacing={2}>
                      {messageUuid !== false && (
                        <Grid item>
                          <Button
                            color="primary"
                            size="small"
                            variant="contained"
                            className={globalClasses.primaryBtn}
                            onClick={() => {
                              setPopupActiveMenu(MENUS.CE_BILLING_AND_FEES);
                            }}
                          >
                            Next
                          </Button>
                        </Grid>
                      )}
                      <Grid item>
                        <Button
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          onClick={() => setOpenAddCePopup(false)}
                        >
                          Save and Exit
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          type="reset"
                          size="small"
                          variant="outlined"
                          className={globalClasses.secondaryBtn}
                          onClick={() => setOpenAddCePopup(false)}
                        >
                          Cancel
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Form>
            </Grid>
          </Grid>
        )}
      </Formik>
    </>
  );
};

export default BasicDetails;
