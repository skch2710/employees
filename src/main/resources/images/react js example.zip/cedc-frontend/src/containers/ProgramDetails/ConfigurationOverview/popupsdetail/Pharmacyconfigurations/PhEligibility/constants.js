export const eligibilityDefaultValues = () => {
  return {
    programType: "",
    claimType: "",
    falloutClaims: false,
    pharmacySupports: false,
    cashClaimsC2DrugsBtn: false,
    cashClaimsC2DrugsInput: "",
    thirdPartyClaimsC4DrugsBtn: false,
    thirdPartyClaimsC4DrugsInput: "",
    thirdPartyClaimsC2DrugsBtn: false,
    thirdPartyClaimsC2DrugsInput: "",
    thirdPartyClaimsC5DrugsBtn: false,
    thirdPartyClaimsC5DrugsInput: "",
    thirdPartyClaimsC3DrugsBtn: false,
    thirdPartyClaimsC3DrugsInput: "",
    nonPreferredGenericsBtn: false,
    nonPreferredGenericsInput: "",
    isEncrypted: false,
    excludeOrphanDrugs: false,
    claimReprocess: false,
    reversalConstraintBtn: false,
    reversalConstraintInput: "",
    reversalConstraint: false,
    cashClaimLesserLogic: false,
    turnOnMinSpread: false,
    brandMinSpread: "",
    brandMinAdminFee: "",
    genericMinSpread: "",
    genericMinAdminFee: "",
  };
};

const getBooleanValue = (value) => {
  if (value === "Y") return true;
  else return false;
};

export const eligibilityDefaultValuesFromResponse = (res = {}) => {
  return {
    programType: res.programTypeId,
    claimType: res.claimProcessTypeId,
    falloutClaims: getBooleanValue(
      res.falloutClaimsForAppliedAcquisitionCost40IfWacNadacOr
    ),
    pharmacySupports: getBooleanValue(res.pharmacySupportCashUcClaims),
    cashClaimsC2DrugsBtn: getBooleanValue(
      res.excludeC2drugsOutsideOfDaysForCashClaimsRadioButton
    ),
    cashClaimsC2DrugsInput: res.excludeC2drugsOutsideOfDaysForCashClaims,
    thirdPartyClaimsC4DrugsBtn: getBooleanValue(
      res.excludeC4drugsOutsideOfDaysForThirdPartyClaimsRadio
    ),
    thirdPartyClaimsC4DrugsInput:
      res.excludeC4drugsOutsideOfDaysForThirdPartyClaims,
    thirdPartyClaimsC2DrugsBtn: getBooleanValue(
      res.excludeC2drugsOutsideOfDaysForThirdPartyClaimsRadio
    ),
    thirdPartyClaimsC2DrugsInput:
      res.excludeC2drugsOutsideOfDaysForThirdPartyClaims,
    thirdPartyClaimsC5DrugsBtn: getBooleanValue(
      res.excludeC5drugsOutsideOfDaysForThirdPartyClaimsRadio
    ),
    thirdPartyClaimsC5DrugsInput:
      res.excludeC5drugsOutsideOfDaysForThirdPartyClaims,
    thirdPartyClaimsC3DrugsBtn: getBooleanValue(
      res.excludeC3drugsOutsideOfDaysForThirdPartyClaimsRadio
    ),
    thirdPartyClaimsC3DrugsInput:
      res.excludeC3drugsOutsideOfDaysForThirdPartyClaims,
    nonPreferredGenericsBtn: getBooleanValue(
      res.excludeNonPreferredGenericsOutsideOfDaysRadio
    ),
    nonPreferredGenericsInput: res.excludeNonPreferredGenericsOutsideOfDays,
    isEncrypted: res.isEncrypted || false,
    excludeOrphanDrugs: getBooleanValue(res.excludeOrphanDrugs),
    claimReprocess: getBooleanValue(res.claimReprocess),
    reversalConstraintBtn: res.reversalConstraint == 0 ? false : true,
    reversalConstraintInput: res.reversalConstraint,
    cashClaimLesserLogic: getBooleanValue(res.cashClaimLesserOfLogic),
    turnOnMinSpread: getBooleanValue(res.turnOnMinSpreadAdminFeeRule),
    brandMinSpread: res.brandMinSpread,
    brandMinAdminFee: res.brandMinAdminFee,
    genericMinSpread: res.genericMinSpread,
    genericMinAdminFee: res.genericMinAdminFee,
    clientId: res.clientId || "",
  };
};
