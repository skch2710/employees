import React from "react";
import { useDispatch } from "react-redux";
import { getPOClaimExport } from "../../../../context/actions/PurchaseOrders";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { notNull } from "../../../../utils/constants";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { usePOStyles } from "../styles";
import { CLAIMS_EXPORT_FILE_NAME } from "../constants";

const POClaimsExport = ({ poID, controller, count, columnFilters }) => {
  const dispatch = useDispatch();
  const classes = usePOStyles();
  const [values, setValues] = React.useState("");

  const ExportToExcel = (data) => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    FileSaver.saveAs(fileData, CLAIMS_EXPORT_FILE_NAME + ".xlsx");
  };

  let heads = [];
  let rows = [];

  const ExportToPdf = (data) => {
    data.forEach((items) => {
      let keys_heads = {};
      keys_heads["810 Invoice #"] = Object.keys(items)[0];
      keys_heads["NDC"] = Object.keys(items)[1];
      keys_heads["Drug Name"] = Object.keys(items)[2];
      keys_heads["Item Pkgs"] = Object.keys(items)[3];
      keys_heads["Pkg size"] = Object.keys(items)[4];
      keys_heads["PO Item status"] = Object.keys(items)[5];
      keys_heads["Claims Mapped"] = Object.keys(items)[6];
      keys_heads["Reason No Claims"] = Object.keys(items)[7];
      keys_heads["Wholesaler Account"] = Object.keys(items)[8];
      keys_heads["Claim ID"] = Object.keys(items)[9];
      keys_heads["340B Direct Invoice Date"] = Object.keys(items)[10];
      keys_heads["Date of Service"] = Object.keys(items)[11];
      keys_heads["Rx No"] = Object.keys(items)[12];
      keys_heads["Refill No"] = Object.keys(items)[13];
      keys_heads["Units"] = Object.keys(items)[14];
      keys_heads["Source Type"] = Object.keys(items)[15];
      keys_heads["Dispensing Store"] = Object.keys(items)[16];
      keys_heads["Receiving Store"] = Object.keys(items)[17];
      keys_heads["Patient First Name"] = Object.keys(items)[18];
      keys_heads["Patient Last Name"] = Object.keys(items)[19];
      keys_heads["Patient ID"] = Object.keys(items)[20];
      keys_heads["Physician First Name"] = Object.keys(items)[21];
      keys_heads["Physician Last Name"] = Object.keys(items)[22];
      keys_heads["Physician ID"] = Object.keys(items)[23];
      heads.push(keys_heads);
    });

    data.forEach((i) => {
      let keys_rows = Object.values(i);
      rows.push(keys_rows);
    });
  };

  const handleChange = (e) => {
    setValues(e.target.value);
    dispatch(
      getPOClaimExport(
        {
          poID: poID,
          sortBy: controller.sortBy,
          sortOrder: controller.sortOrder,
          filter: columnFilters,
          export: true,
        },
        function (result) {
          var data = result.content.map(
            ({
              itemInvoiceNumber,
              ndc,
              drugName,
              itemPkgs,
              pkgSize,
              poItemStatus,
              claimsMappingFlag,
              noClaimReason,
              wholesalerAccountDivisionCode,
              claimID,
              invoiceDate340BDirect,
              dateOfService,
              rxNumber,
              reFillNo,
              units,
              sourceType,
              dispensingStore,
              receivingStore,
              memberFirstName,
              memberLastName,
              memberID,
              physicianFirstName,
              physicianLastName,
              prescriberID,
            }) => ({
              "810 Invoice #": notNull(itemInvoiceNumber),
              NDC: notNull(ndc),
              "Drug Name": notNull(drugName),
              "Item Pkgs": notNull(itemPkgs),
              "Pkg size": notNull(pkgSize),
              "PO Item status": notNull(poItemStatus),
              "Claims Mapped": notNull(claimsMappingFlag),
              "Reason No Claims": notNull(noClaimReason),
              "Wholesaler Account": notNull(wholesalerAccountDivisionCode),
              "Claim ID": notNull(claimID),
              "340B Direct Invoice Date": notNull(invoiceDate340BDirect),
              "Date of Service": notNull(dateOfService),
              "Rx No": notNull(rxNumber),
              "Refill No": notNull(reFillNo),
              Units: notNull(units),
              "Source Type": notNull(sourceType),
              "Dispensing Store": notNull(dispensingStore),
              "Receiving Store": notNull(receivingStore),
              "Patient First Name": notNull(memberFirstName),
              "Patient Last Name": notNull(memberLastName),
              "Patient ID": notNull(memberID),
              "Physician First Name": notNull(physicianFirstName),
              "Physician Last Name": notNull(physicianLastName),
              "Physician ID": notNull(prescriberID),
            })
          );
          if (e.target.value == "excel") {
            setTimeout(ExportToExcel(data), 5000);
            setValues("");
          }
          if (e.target.value == "pdf") {
            setTimeout(ExportToPdf(data), 5000);
            const doc = new jsPDF();
            doc.autoTable({
              head: [heads[0]],
              theme: "grid",
              tableWidth: "auto",
              fontStyle: "normal",
              body: [...rows],
            });
            doc.save(`${CLAIMS_EXPORT_FILE_NAME}.pdf`);
            setValues("");
          }
        }
      )
    );
  };

  return (
    <form>
      <fieldset
        disabled={count > 0 ? false : true}
        className={classes.exportContainer}
      >
        <select
          className={classes.exportSelect}
          onChange={handleChange}
          value={values}
          disabled={count > 0 ? false : true}
        >
          <option value="" disabled selected>
            Export
          </option>
          <option value="excel">MS Excel</option>
          <option value="pdf">PDF</option>
        </select>
      </fieldset>
    </form>
  );
};

export default POClaimsExport;
