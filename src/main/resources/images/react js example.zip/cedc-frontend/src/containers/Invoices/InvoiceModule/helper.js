export const getInvoiceInnergridFiltersObject = (filters) => {
  const containsToFields = ["billingPeriod"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getInvoiceInnerSubgridFiltersObject = (filters) => {
  const containsToFields = ["billingPeriod"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getInvoiceFiltersObject = (filters) => {
  const containsToFields = ["billingPeriod" , "invoicePeriodStartDate", "invoicePeriodEndDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};


export const getRemittanceFiltersObject = (filters) => {
  const containsToFields = ["billingCycle"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getClaimsFiltersObject = (filters) => {
  const containsToFields = ["invoiceDate" , "creditInvoiceDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};

export const getTrueupFiltersObject = (filters) => {
  const containsToFields = ["billingCycle" , "processedDate" , "rxWrittenDate" , "dateOfService"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: containsToFields.includes(filter.column.field)
        ? "="
        : "startWith",
      value: filter.value,
    };
  });
};


