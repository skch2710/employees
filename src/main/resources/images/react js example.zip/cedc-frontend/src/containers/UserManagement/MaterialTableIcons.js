import React, { forwardRef } from "react";
import Button from "@material-ui/core/Button";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
//react-icons
import { RiDeleteBin5Line } from "react-icons/ri";
import { BiEditAlt } from "react-icons/bi";
import { FaSort } from "react-icons/fa";
import { MdOutlineFilterList } from "react-icons/md";
import { BiUpload } from "react-icons/bi";
import {AiOutlineEye} from "react-icons/ai";
import {BsCheckCircle} from "react-icons/bs";


const tableIcons = {
  AddButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Add User
    </Button>
   
  )),
  UploadButton: forwardRef((props, ref) => (
    <Button
      startIcon={<BiUpload />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      
      Bulk Upload
    </Button>
  )),
  Active: forwardRef((props,ref)=>(
    <BsCheckCircle fontSize="small" color="green" {...props} ref={ref} />
  )),
  InActive: forwardRef((props,ref)=>(
    <BsCheckCircle fontSize="small" color="action" {...props} ref={ref} />
  )),
  Delete: forwardRef((props, ref) => (
    <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => (
    <BiEditAlt fontSize="small" color="action" {...props} ref={ref} />
  )),
  Eye:  forwardRef((props, ref) => (
    <AiOutlineEye fontSize="small" color="action" {...props} ref={ref} />
  )),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => (
    <MdOutlineFilterList {...props} ref={ref} />
  )),
  };

export default tableIcons;
