import { makeStyles } from "@material-ui/core/styles";

export const useCeProviderStyles = makeStyles((theme) => ({
  coveredEntityNameWrapper: {
    width: "100%",
    height: "30px",
    display: "flex",
    alignItems: "center",
  },
  coveredEntityName: {
    width: "100%",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    color: theme.colors.monochrome.disabledText,
  },
  downloadLink: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    gap: "5px",
  },
  verticalTabs: {
    display: "flex",
  },
  tabs: {
    width: "30%",
  },
  tabLabel: {
    fontSize: "14px",
    textTransform: "capitalize",
    alignItems: "flex-start",
  },
  dialogPaper: {
    minHeight: "44vh",
  }
}));
