import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Grid } from "@material-ui/core";
import _isEmpty from "lodash/isEmpty";
import AddEditForm from "./AddEditForm";
import {
  getUserrole,
  getEmailExist,
  getUsernameExist,
  getInternalTeam,
} from "../../context/actions/Usermanagement";
import UserlistMaterialTable from "./UserlistMaterialTable";
import { getUserPreveleges } from "../../utils/common";
import BasicPopup from "../../components/Popup/BasicPopup";

const Userlist = ({
  sortBy,
  Co,
  sortorder,
  clearButton,
  searchBy,
  globalFilterValue,
  userExportData,
  messageUiid,
  coveredentity,
  userlist,
  page,
  onChangePagination,
  onChangeSorting,
  onChangeFilter,
  onChangeRowsperpage,
  rowsPerPage,
  getCeIds,
  coCeid,
  defaultFilters,
  setAddUserPopupOfCo,
  setshowfieldsvalues,
  showfieldsvalues,
  rowdatauserlist,
  setrowdatauserlist,
  primarystate,
  setprimarystate,
  ...rest
}) => {
  const dispatch = useDispatch();

  const userRoles = useSelector((state) => state.getUserrole.records) || [];
  const internalteam =
    useSelector((state) => state.getInternalTeam.records) || [];

  const [addUserState, setaddUserState] = useState(false);
  const [submitactiontype, setSubmitActionType] = useState("");
  const [openPopup, setOpenPopup] = useState(false);
  const [filter, setFilter] = useState(false);
  const [permissionObj, setpermissionObj] = useState(null);
  const scrollToRef = useRef();
  const formRef = useRef();

  useEffect(() => {
    dispatch(getUserrole());
    dispatch(getInternalTeam());
    setpermissionObj(getUserPreveleges("User Management"));
  }, []);

  const adduserStateFn = () => {
    setaddUserState(true);
    !_isEmpty(formRef.current) && formRef.current.clearForm();
    setTimeout(function () {
      if (!_isEmpty(scrollToRef.current)) {
        scrollToRef.current.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    }, 100);
  };

  const closePopup = () => {
    setaddUserState(false);
    setOpenPopup(false);
  };

  const submitEmail = (email, callback) => {
    dispatch(
      getEmailExist(email, (result) => {
        callback(result);
      })
    );
  };
  const submitDisplayname = (displayname, callback) => {
    dispatch(
      getUsernameExist(displayname, (result) => {
        callback(result);
      })
    );
  };

  const fetchUserPayload = {
    ceID: Co ? coCeid : getCeIds(),
    pageNumber: 1,
    pageSize: rowsPerPage,
    sortBy: sortBy,
    sortOrder: sortorder,
    filter: defaultFilters || undefined,
  };

  return (
    <Grid item xs={12}>
      <UserlistMaterialTable
        userExportData={userExportData}
        Co={Co}
        coCeid={coCeid}
        adduserStateFn={adduserStateFn}
        userlist={userlist}
        page={page}
        sortBy={sortBy}
        sortorder={sortorder}
        clearButton={clearButton}
        searchBy={searchBy}
        globalFilterValue={globalFilterValue}
        rowsPerPage={rowsPerPage}
        onChangePagination={onChangePagination}
        onChangeRowsperpage={onChangeRowsperpage}
        onChangeSorting={onChangeSorting}
        onChangeFilter={onChangeFilter}
        filter={filter}
        setFilter={setFilter}
        getCeIds={getCeIds}
        defaultFilters={defaultFilters}
        fetchUserPayload={fetchUserPayload}
        rowdatauserlist={rowdatauserlist}
        setrowdatauserlist={setrowdatauserlist}
        setaddUserState={setaddUserState}
        addUserState={setaddUserState}
        {...rest}
      />

      <Grid ref={scrollToRef} item xs={12}>
        {Co && addUserState && (
          <AddEditForm
            messageUiid={messageUiid}
            addUserState={addUserState}
            roles={userRoles}
            closePopup={closePopup}
            permissionObj={permissionObj}
            coveredentitydata={coveredentity}
            internalteam={internalteam}
            submitEmail={submitEmail}
            submitDisplayname={submitDisplayname}
            submitactiontype={"Submit"}
            setOpenPopup={setOpenPopup}
            setAddUserPopupOfCo={setAddUserPopupOfCo}
            fromCO={Co}
            setshowfieldsvalues={setshowfieldsvalues}
            showfieldsvalues={showfieldsvalues}
            rowData={rowdatauserlist}
            primarystate={primarystate}
            setprimarystate={setprimarystate}
            ref={formRef}
            {...rest}
          />
        )}
      </Grid>
      <BasicPopup
        title={""}
        show={openPopup}
        handleClose={() => setOpenPopup(false)}
        dialogProps={{
          maxWidth: "md",
        }}
      >
        <Grid item xs={12}>
          <AddEditForm
            roles={userRoles}
            messageUiid={messageUiid}
            closePopup={closePopup}
            coveredentitydata={coveredentity}
            internalteam={internalteam}
            permissionObj={permissionObj}
            submitEmail={submitEmail}
            submitDisplayname={submitDisplayname}
            submitactiontype={submitactiontype}
            setOpenPopup={setOpenPopup}
            fetchUserPayload={fetchUserPayload}
            {...rest}
          />
        </Grid>
      </BasicPopup>
    </Grid>
  );
};

export default Userlist;
