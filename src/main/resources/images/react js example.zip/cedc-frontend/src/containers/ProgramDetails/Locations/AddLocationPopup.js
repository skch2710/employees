import React, { useState, useContext } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Grid, Button, FormLabel, Typography } from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import { ALL, getAddLocationPopupDefaultValues } from "./constants";
import DatePicker from "../../../components/common/DatePicker";
import moment from "moment";
import {
  addLocation,
  getlocationHrsaIdExist,
  getLocationList,
  validateStandardAddress,
  getAllCesAssociatedToAddresses,
} from "../../../context/actions/Locations";
import {
  fetchTermsGridTableData,
  getCeLocations,
  updateSectionStatus,
} from "../../../context/actions/ConfigOverview";
import _isEqual from "lodash/isEqual";
import _isArray from "lodash/isArray";
import { COContext } from "../COContext";
import { getCeLocationPayloadJson } from "../ConfigurationOverview/CeSummary/CeLocations/helper";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { REGEX, pagination } from "../../../utils/constants";
import BasicPopup from "../../../components/Popup/BasicPopup";
import AddressValidationPopup from "./AddressValidationPopup.js";
import { useLocationStyles } from "./styles";
import AccuracyConfirmationPopupFooter from "./OPALocationPopup/RegisteredParticipatedTables/AccuracyConfirmationPopupFooter";
import AccuracyConfirmationPopup from "./OPALocationPopup/RegisteredParticipatedTables/AccuracyConfirmationPopup";
import { getUserSession } from "../../../utils/helper";
import { endDateValidation, startDateValidation } from "../../../utils/common";
import _debounce from "lodash/debounce";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import AutoComplete from "../../../components/common/AutoComplete";

const AddLocationPopup = ({
  setOpenPopup,
  messageUuid = {},
  ciId,
  rowData,
  ceSelected,
  title,
  Co,
  clickOnAdd,
  setTabSelected,
  fetchLocations,
  updateFieldsAfterSaveLocation,
}) => {
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const classes = useLocationStyles();
  const accuracyPopupDefaultValues = {
    confirmedData: [],
  };

  const {
    setCeConfigStatusPercent,
    ceConfigStatusPercent,
    termsGridPayload,
    setMenusStatuses,
    menusStatuses,
  } = useContext(COContext) || {};
  const { coLocation } = menusStatuses;

  const defaultValues = getAddLocationPopupDefaultValues(
    (rowData && rowData) || {},
    ceSelected
  );
  const stateList = useSelector((state) => state.ce_states_list.records) || [];
  const stateName =
    stateList &&
    stateList.find((itm) => itm.stateName === defaultValues.stateName);
  const initialValues = stateList && {
    ...defaultValues,
    stateId: stateName && stateName.stateId,
  };
  const [ceHrsaIdExist, setHrsaIdExist] = useState("");
  const [notificationPopup, setNotificationPopup] = useState(false);

  const [cesWithSameAddress, setCesWithSameAddress] = useState([]);
  const [showAccuracyPopup, setShowAccuracyPopup] = useState(false);
  const [formValues, setFormValues] = useState({});

  const userSession = getUserSession();
  const isEdit = title === "Edit Covered Entity Location";

  const checkInputZipCode = (e, formik) => {
    let { name, value } = e.target;
    const regEx = /([^0-9])/g;
    if (value && regEx.test(value)) return;
    formik.setFieldValue(name, value);
  };

  const onDateChange = (name, value, formik) => {
    if (name === "startDate" && value === "")
      formik.setTouched({ startDate: true });
    formik.setFieldValue(name, value);
  };

  const handleLoacationName = (e, formik) => {
    const regEx = /^\s+|\s{2,}$/g;
    let { name, value } = e.target;
    if (value && regEx.test(value)) return;
    formik.setFieldValue(name, value);
  };

  const handleLoacationHRSAID = _debounce(async (value) => {
    const res = await dispatch(
      getlocationHrsaIdExist({ ceId: ceSelected.ceID, hrsaId: value })
    );
    if (res) {
      if (res.statusCode == 404) setHrsaIdExist(res.errorMessage);
      if (res.statusCode == 200) setHrsaIdExist("");
    }
  }, 300);

  const handleValidate = () => {};

  const handleSubmit = (values) => {
    setFormValues(values);
    const stateObj =
      stateList.find((item) => item.stateId == values.stateId) || {};
    const addressValidationPayload = {
      address1: values.addressLine1,
      address2: values.addressLine2,
      city: values.city,
      state: stateObj.stateCode,
      zip: values.zipCode,
    };

    if (rowData) {
      const stateObj =
        stateList.find((item) => item.stateId == rowData.stateId) || {};
      const rowDataPayload = {
        address1: rowData.addressLine1,
        address2: rowData.addressLine2,
        city: rowData.city,
        state: stateObj.stateCode,
        zip: rowData.zip,
      };
      if (_isEqual(addressValidationPayload, rowDataPayload)) {
        saveLocation(values);
      } else {
        dispatch(
          validateStandardAddress(addressValidationPayload, (res) => {
            setNotificationPopup(true);
            if (res.statusCode === 200) {
              setFormValues((prev) => ({ ...prev, ...res.data }));
            } else if (res.statusCode === 404) {
              setFormValues((prev) => ({
                ...prev,
                nonStandardHashKey: res.data.nonStandardPrescriberAddrHashKey,
              }));
            }
          })
        );
      }
    } else {
      dispatch(
        validateStandardAddress(addressValidationPayload, (res) => {
          setNotificationPopup(true);
          if (res.statusCode === 200) {
            setFormValues((prev) => ({ ...prev, ...res.data }));
          } else if (res.statusCode === 404) {
            setFormValues((prev) => ({
              ...prev,
              nonStandardHashKey: res.data.nonStandardPrescriberAddrHashKey,
            }));
          }
        })
      );
    }
  };

  const onClickUseThisAddress = () => {
    const payload = {
      hashKeyList: [
        {
          hashKey:
            formValues.standardPrescriberAddrHashKey ||
            formValues.nonStandardHashKey,
          isStandaredKey: formValues.standardPrescriberAddrHashKey
            ? true
            : false,
        },
      ],
      ceId: ceSelected.ceID,
    };
    dispatch(
      getAllCesAssociatedToAddresses(payload, (res) => {
        if (res.statusCode === 200) {
          setNotificationPopup(false);
          setShowAccuracyPopup(true);
          setCesWithSameAddress(res.data || []);
        } else if (res.statusCode === 404) {
          saveLocation(formValues);
        }
      })
    );
  };

  const saveLocation = (inputValues) => {
    let payload = {
      ceid:
        !Co && inputValues.ceid
          ? inputValues.ceid
          : messageUuid && messageUuid.ceid !== null
          ? messageUuid.ceid
          : ciId || (ceSelected && ceSelected.ceID),
      entityLocationId: inputValues.entityLocationId,
      locationName: inputValues.locationName,
      locationHrsaId: inputValues.locationHrsaId,
      addressLine1: inputValues.addressLine1,
      addressLine2: inputValues.addressLine2,
      city: inputValues.city,
      endDate: inputValues.endDate,
      startDate: inputValues.startDate,
      zipCode: inputValues.zipCode,
      stateId: parseInt(inputValues.stateId),
      is340bSite: true,
      locSourceId: inputValues.sourceId,
      modifiedById: userSession.userId,
      modifiedDate: moment(new Date()).format("MM/DD/YYYY"),
      standardAddress1: inputValues.standardPrescriberAddress1 || "",
      standardAddress2: inputValues.standardPrescriberAddress2 || "",
      standardCity: inputValues.standardPrescriberCity || "",
      standardState: inputValues.standardPrescriberState || "",
      standardZip: inputValues.standardPrescriberZip || "",
      addrHashKey: inputValues.nonStandardHashKey || "",
      standardAddrHashKey: inputValues.standardPrescriberAddrHashKey || "",
      createdById: userSession.userId,
      parent: 0,
    };
    dispatch(
      addLocation(payload, async (res) => {
        if (res.statusCode === 200) {
          let locPayload = {
            ceid: !Co
              ? ceSelected.ceID
              : messageUuid && messageUuid.ceid !== null && [messageUuid.ceid],
          };
          const locationList =
            ceSelected &&
            !Co &&
            (await dispatch(
              getLocationList({ ceIDs: [ceSelected.ceID], locationName: "" })
            ));
          if (!isEdit) {
            locPayload = {
              ...locPayload,
              pageNo: pagination.page,
              locations: locationList || [],
              locationStatus: "",
            };
          }
          fetchLocations(locPayload, (resp) =>
            updateFieldsAfterSaveLocation({
              ...resp,
              locations: locPayload.locations,
            })
          );
          Co &&
            !clickOnAdd &&
            dispatch(
              getCeLocations(
                getCeLocationPayloadJson({
                  ceId: messageUuid.ceid,
                })
              )
            );
          if ((clickOnAdd && messageUuid === false) || coLocation) {
            dispatch(
              updateSectionStatus({
                ceId: payload.ceid,
                sectionId: 6,
                callback,
              })
            );
          } else {
            dispatch(
              updateSectionStatus({
                ceId: payload.ceid,
                sectionId: 6,
              })
            );
          }
          setOpenPopup(false);
          setTabSelected(ALL);
        }
      })
    );
  };

  const callback = (res) => {
    if (res.statusCode == 200) {
      const ceConfigPercent =
        (res.data && res.data.configPercentage) || ceConfigStatusPercent;
      if (ceConfigPercent) {
        setCeConfigStatusPercent(ceConfigPercent);
      }
      setMenusStatuses((prev) => ({ ...prev, coLocation: false }));
      dispatch(fetchTermsGridTableData(termsGridPayload));
    }
  };

  const formValidate = (values) => {
    let errors = {};

    if (values.ceName === "") {
      errors.ceName = "Please select the Covered Entity";
    }
    if (values.locationName === "") {
      errors.locationName = "Please enter the Provider Location";
    }
    if (!values.locationHrsaId) {
      setHrsaIdExist("");
      errors.locationHrsaId = "Please enter the Provider Location HRSA ID";
    }
    if (ceHrsaIdExist) {
      errors.locationHrsaId = ceHrsaIdExist;
    }
    if (values.addressLine1 === "") {
      errors.addressLine1 = "Please enter the Address Line 1";
    }
    if (values.city === "") {
      errors.city = "Please enter the City";
    }
    if (!values.stateId) {
      errors.stateId = "Please select the State";
    }
    if (values.zipCode.length < 5) {
      errors.zipCode = "Please enter the 5 digit Zip Code only";
    }
    if (values.startDate === "") {
      errors.startDate = "Please select the Provider Start Date";
    }
    return errors;
  };

  const handleChange = (e, formik) => {
    const regEx = /^\s+|\s{2,}$/g;
    let { name, value } = e.target;
    if (value && regEx.test(value)) return;
    formik.setFieldValue(name, value);
  };

  return (
    <>
      <Formik
        enableReinitialize={true}
        initialValues={initialValues}
        validate={formValidate}
        onSubmit={handleSubmit}
      >
        {(formik) => {
          return (
            <Form>
              <Grid container spacing={2}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Covered Entity</FormLabel>
                      <Field
                        name="coveredEntityName"
                        id="coveredEntityName"
                        type="text"
                        className={globalClasses.formControl}
                        disabled
                        value={
                          formik.values.coveredEntityName ||
                          (!Co
                            ? ceSelected && ceSelected.ceName
                            : (messageUuid && messageUuid.ceName) ||
                              formik.values.coveredEntityName)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <FormLabel>HRSA ID</FormLabel>
                      <Field
                        name="ceCode"
                        id="ceCode"
                        type="text"
                        className={globalClasses.formControl}
                        disabled
                        value={
                          formik.values.ceCode ||
                          (!Co
                            ? ceSelected && ceSelected.ceCode
                            : messageUuid &&
                              (messageUuid.hrsaId || messageUuid.ceCode))
                        }
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Provider Location</FormLabel>
                      <Field
                        name="locationName"
                        type="text"
                        maxLength={150}
                        className={globalClasses.formControl}
                        placeholder="Enter Provider Location"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (
                            value &&
                            !REGEX.alphabetsAndHypen.test(e.target.value)
                          )
                            return;
                          formik.setFieldValue("locationName", e.target.value);
                          handleLoacationName(e, formik);
                        }}
                      />
                      {formik.touched.locationName &&
                        formik.errors.locationName && (
                          <Typography color="error" variant="caption">
                            {formik.errors.locationName}
                          </Typography>
                        )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Provider Location HRSA ID</FormLabel>
                      <Field
                        name="locationHrsaId"
                        type="text"
                        maxLength={15}
                        disabled={isEdit}
                        className={globalClasses.formControl}
                        placeholder="Enter Provider Location HRSA ID"
                        onChange={(e) => {
                          const regEx = /^\s+|\s{2,}$/g;
                          const { value } = e.target;
                          if (value && regEx.test(value)) return;
                          formik.setFieldValue("locationHrsaId", value);
                          if (formik.values.locationHrsaId !== value && value)
                            handleLoacationHRSAID(value);
                        }}
                      />
                      {((formik.touched.locationHrsaId &&
                        formik.errors.locationHrsaId) ||
                        ceHrsaIdExist) && (
                        <Typography color="error" variant="caption">
                          {formik.errors.locationHrsaId || ceHrsaIdExist}
                        </Typography>
                      )}
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Address Line 1</FormLabel>
                      <Field
                        name="addressLine1"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Address Line 1"
                        maxLength={100}
                        onChange={(e) => handleChange(e, formik)}
                      />
                      {formik.touched.addressLine1 &&
                        formik.errors.addressLine1 && (
                          <Typography color="error" variant="caption">
                            {formik.errors.addressLine1}
                          </Typography>
                        )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel>Address Line 2</FormLabel>
                      <Field
                        name="addressLine2"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Address Line 2"
                        maxLength={100}
                        onChange={(e) => handleChange(e, formik)}
                      />
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>City</FormLabel>
                      <Field
                        name="city"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter City"
                        maxLength={100}
                        onChange={(e) => handleChange(e, formik)}
                      />
                      {formik.touched.city && formik.errors.city && (
                        <Typography color="error" variant="caption">
                          {formik.errors.city}
                        </Typography>
                      )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>State</FormLabel>
                      <Field as="select" name="stateId">
                        {({ field }) => (
                          <AutoComplete
                            {...field}
                            options={_isArray(stateList) ? stateList : []}
                            inputPlaceholder={"Select State"}
                            disableCloseOnSelect={false}
                            onChange={(e, value) => {
                              formik.setFieldValue(
                                "stateId",
                                value ? value.stateId : ""
                              );
                            }}
                            getOptionLabel={(option) => option.stateName || ""}
                            value={
                              stateList.find(
                                (e) => e.stateId == formik.values.stateId
                              ) || ""
                            }
                            renderOption={(option, _other) => {
                              return (
                                <BasicTypography variant="subtitle2">
                                  {option.stateName}
                                </BasicTypography>
                              );
                            }}
                            multiple={false}
                            textFieldProps={{
                              inputProps: {
                                name: "stateId",
                              },
                            }}
                          />
                        )}
                      </Field>
                      {formik.touched.stateId && formik.errors.stateId && (
                        <Typography color="error" variant="caption">
                          {formik.errors.stateId}
                        </Typography>
                      )}
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <FormLabel required>Zip</FormLabel>
                      <Field
                        name="zipCode"
                        type="text"
                        className={globalClasses.formControl}
                        placeholder="Enter Zip"
                        maxLength={5}
                        onChange={(e) => checkInputZipCode(e, formik)}
                      />
                      {formik.touched.zipCode && formik.errors.zipCode && (
                        <Typography color="error" variant="caption">
                          {formik.errors.zipCode}
                        </Typography>
                      )}
                    </Grid>

                    <Grid item xs={12} sm={5}>
                      <Grid container spacing={1}>
                        <Grid item xs={12} sm={6}>
                          <FormLabel required>
                            Provider Start Date
                          </FormLabel>
                          <DatePicker
                            disabledDate={(date) =>
                              startDateValidation(
                                date,
                                formik.values.endDate
                              ) || date.isBefore(new Date(), "day")
                            }
                            onChange={(e, date) => {
                              if (!date) onDateChange("endDate", "", formik);
                              onDateChange("startDate", date, formik);
                            }}
                            value={
                              formik.values.startDate !== ""
                                ? moment(formik.values.startDate)
                                : ""
                            }
                            disabled={
                              isEdit && rowData.locationStatus === "Terminated"
                                ? false
                                : isEdit &&
                                  moment(rowData.startDate).isSameOrBefore(
                                    moment(),
                                    "day"
                                  )
                                ? true
                                : false
                            }
                          />
                          {formik.touched.startDate &&
                            formik.errors.startDate && (
                              <Typography color="error" variant="caption">
                                {formik.errors.startDate}
                              </Typography>
                            )}
                        </Grid>

                        <Grid item xs={12} sm={6}>
                          <FormLabel>Provider End Date</FormLabel>
                          <DatePicker
                            onChange={(e, date) =>
                              onDateChange("endDate", date, formik)
                            }
                            disabledDate={(d) =>
                              isEdit && rowData.locationStatus !== "Terminated"
                                ? d.isSameOrBefore(new Date(), "day") ||
                                  endDateValidation(d, formik.values.startDate)
                                : endDateValidation(d, formik.values.startDate)
                            }
                            value={
                              formik.values.endDate !== ""
                                ? moment(formik.values.endDate)
                                : ""
                            }
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid container justifyContent="flex-end" spacing={2}>
                    <Grid item>
                      <Button
                        type="submit"
                        size="small"
                        variant="contained"
                        className={globalClasses.primaryBtn}
                        disabled={ceHrsaIdExist}
                      >
                        {rowData ? "Save" : "Add Covered Entity Location"}
                      </Button>
                    </Grid>
                    <Grid item>
                      <Button
                        type="reset"
                        size="small"
                        variant="outlined"
                        className={globalClasses.secondaryBtn}
                        onClick={() => {
                          setOpenPopup(false);
                        }}
                      >
                        Cancel
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Form>
          );
        }}
      </Formik>

      {notificationPopup && (
        <BasicPopup
          show={notificationPopup}
          disableFooter={true}
          disableHeader={true}
          dialogProps={{
            maxWidth: "sm",
          }}
        >
          <AddressValidationPopup
            setNotificationPopup={setNotificationPopup}
            onClickUseThisAddress={onClickUseThisAddress}
            formValues={formValues}
            setFormValues={setFormValues}
          />
        </BasicPopup>
      )}

      <BasicPopup
        disableCloseButton
        title="Confirmation of Accuracy Needed"
        show={showAccuracyPopup}
        disableFooter={true}
        isCustomFooter={true}
        footerActionElement={
          <AccuracyConfirmationPopupFooter
            setShowAccuracyPopup={setShowAccuracyPopup}
            formValues={formValues}
          />
        }
        dialogProps={{
          maxWidth: "md",
        }}
        withFormik={true}
        formikProps={{
          onSubmit: (values) => {
            if (userSession.isInternalUser) {
              saveLocation(formValues);
            } else {
              setShowAccuracyPopup(false);
              setCesWithSameAddress([]);
            }
          },
          validate: handleValidate,
          initialValues: accuracyPopupDefaultValues,
        }}
        dialogTitleProps={{ className: classes.dialogTitle }}
      >
        <AccuracyConfirmationPopup
          selectedRows={[formValues]}
          ceSelected={ceSelected}
          cesWithSameAddress={cesWithSameAddress}
          isAddLocationFlow={true}
        />
      </BasicPopup>
    </>
  );
};

export default AddLocationPopup;
