import React, { memo, useEffect, useState, useRef, useCallback } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { Paper, Grid, Tooltip } from "@material-ui/core";
import DatePicker from "../../../../components/common/DatePicker";
import _isEmpty from "lodash/isEmpty";
import moment from "moment";
import { useTheme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { TiFilter } from "react-icons/ti";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import DataNotFound from "../../../../components/common/DataNotFound";
import { pagination } from "../../../../utils/constants";
import { getPOHistoryList } from "../../../../context/actions/PurchaseOrders";
import useFileExport from "./useFileExport";
import { getPoHistoryFiltersObject } from "../helper";
import { GET_PO_HISTORY_LIST } from "../../../../context/constants";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import { isEmptyGrid } from "../../../../utils/helper";
import {
  getTableCellStyles,
  useGlobalStyles,
  getTableHeaderStyles,
} from "../../../../Styles/useGlobalStyles";
import TableProgressBar from "../../../../components/common/TableProgressBar";
import useTableIconsAndButtons from "../../../../components/common/TableIcons";
import ColumnLevelFilterInput from "../../../../components/common/ColumnLevelFilterInput";
import Pagination from "../../../../components/common/Pagination";

const POHistory = ({ po } = {}) => {
  const { poID, poItemID, poDate } = po || {};
  const globalClasses = useGlobalStyles();
  const dispatch = useDispatch();
  const theme = useTheme();
  const { exportToExcel } = useFileExport();
  const iconsAndButtons = useTableIconsAndButtons();

  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});
  const tableRef = useRef(null);

  const { records: poHistoryList = {}, loading } =
    useSelector((state) => state.getPOHistoryData) || {};

  const fetchPoHistory = (payload = {}) => {
    dispatch(
      getPOHistoryList(
        {
          pageNumber: pagination.page,
          pageSize: pagination.limit,
          sortBy: "",
          sortOrder: "",
          filter: [],
          export: false,
          poID: poID,
          poItemId: 0,
          ...payload,
        },
        (data) => {
          setController((prev) => ({
            ...prev,
            page: data.pageNo,
            pageSize: data.pageSize,
          }));
        }
      )
    );
  };

  useEffect(() => {
    if (poID) {
      fetchPoHistory();
    }
    return () => {
      dispatch({ type: GET_PO_HISTORY_LIST, data: {} });
    };
  }, []);

  const onPageChange = useCallback(
    (newPage, pageSize) => {
      let currentPage = newPage + 1;
      const rowsPerPage = Number(pageSize);
      const totalPages =
        Math.ceil(poHistoryList.totalElements / rowsPerPage) || 1;
      if (controller.page > totalPages) currentPage = totalPages;
      else if (newPage === 0 && rowsPerPage !== controller.pageSize)
        currentPage = controller.page;
      fetchPoHistory({
        ...controller,
        pageNumber: currentPage,
        pageSize: rowsPerPage,
        filter: columnFilters,
      });
    },
    [columnFilters, controller, poHistoryList]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = PO_HISTORY_COLUMNS[orderedColumnId].field;
      setController((prev) => ({
        ...prev,
        sortOrder,
        sortBy,
      }));
      fetchPoHistory({
        pageNumber: controller.page,
        pageSize: controller.pageSize,
        sortOrder,
        sortBy,
        filter: columnFilters,
      });
    },
    [controller, columnFilters]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getPoHistoryFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchPoHistory({
      ...controller,
      filter: filterPayload,
    });
  };

  const ACTIONS = [
    {
      icon: iconsAndButtons.Filter(),
      tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
      isFreeAction: true,
      disabled: isEmptyGrid(poHistoryList),
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: iconsAndButtons.ExportButton({
        disabled: isEmptyGrid(poHistoryList),
      }),
      tooltip: "Export",
      isFreeAction: true,
      disabled: isEmptyGrid(poHistoryList),
      onClick: () =>
        exportToExcel({
          poID,
          poItemID,
          controller,
          columnFilters,
        }),
    },
  ];

  const PO_HISTORY_COLUMNS = [
    {
      title: "PO Date",
      field: "poDate",
      defaultFilter: enableFilters && columnFiltersRef.current.poDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poDate}>
            <span>{rowData.poDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.poDate
                ? moment(columnFiltersRef.current.poDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "PO Status",
      field: "poStatus",
      defaultFilter: enableFilters && columnFiltersRef.current.poStatus,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poStatus}>
            <span>{rowData.poStatus}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.poStatus}
          placeholder="PO Status"
        />
      ),
    },
    {
      title: "Reason",
      field: "reasonDesc",
      defaultFilter: enableFilters && columnFiltersRef.current.reasonDesc,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.reasonDesc}>
            <span>{rowData.reasonDesc}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.reasonDesc}
          placeholder="Reason"
        />
      ),
    },
    {
      title: "PO Status Date",
      field: "poStatusDate",
      defaultFilter: enableFilters && columnFiltersRef.current.poStatusDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poStatusDate}>
            <span>{rowData.poStatusDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.poStatusDate
                ? moment(columnFiltersRef.current.poStatusDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "810 Invoice Number",
      field: "invoiceNumber",
      defaultFilter: enableFilters && columnFiltersRef.current.invoiceNumber,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.invoiceNumber}>
            <span>{rowData.invoiceNumber}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.invoiceNumber}
          placeholder="810 Invoice Number"
        />
      ),
    },
    {
      title: "EDI 855 File Count",
      field: "edi855FileCount",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.edi855FileCount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.edi855FileCount}>
            <span>{rowData.edi855FileCount}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.edi855FileCount}
          placeholder="EDI 855 File Count"
        />
      ),
    },
    {
      title: "EDI 810 File Count",
      field: "edi810FileCount",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.edi810FileCount,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.edi810FileCount}>
            <span>{rowData.edi810FileCount}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.edi810FileCount}
          placeholder="EDI 810 File Count"
        />
      ),
    },
    {
      title: "Created Date",
      field: "createdDate",
      defaultFilter: enableFilters && columnFiltersRef.current.createdDate,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.createdDate}>
            <span>{rowData.createdDate}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => {
        return (
          <DatePicker
            onChange={(date) => {
              if (date) {
                props.onFilterChanged(
                  props.columnDef.tableData.id,
                  moment(date).format("MM/DD/YYYY")
                );
              } else {
                props.onFilterChanged(props.columnDef.tableData.id, "");
              }
            }}
            value={
              columnFiltersRef.current.createdDate
                ? moment(columnFiltersRef.current.createdDate)
                : ""
            }
          />
        );
      },
    },
    {
      title: "Created By",
      field: "createdByID",
      type: "numeric",
      defaultFilter: enableFilters && columnFiltersRef.current.createdByID,
      customFilterAndSearch: () => true,
      render: (rowData) => {
        return (
          <Tooltip title={rowData.createdByID}>
            <span>{rowData.createdByID}</span>
          </Tooltip>
        );
      },
      filterComponent: (props) => (
        <ColumnLevelFilterInput
          {...props}
          value={columnFiltersRef.current.createdByID}
          placeholder="Created By"
        />
      ),
    },
  ];

  return (
    <Grid container spacing={2}>
      <Grid item md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <BasicTypography variant="subtitle2">{`Order #: ${
              poID || ""
            }`}</BasicTypography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <BasicTypography variant="subtitle2">{`Order Date : ${
              poDate || ""
            }`}</BasicTypography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item md={12}>
        <div className={globalClasses.tableCardPrimary}>
          <MaterialTable
            title={
              <BasicTypography
                variant="h5"
                title={`Purchase Order History (${
                  poHistoryList.totalElements || 0
                })`}
              />
            }
            columns={PO_HISTORY_COLUMNS}
            data={poHistoryList.content}
            page={controller.page - 1}
            totalCount={poHistoryList.totalElements}
            onChangePage={onPageChange}
            onOrderChange={handleSort}
            onFilterChange={handleColumnFilter}
            tableRef={tableRef}
            icons={{
              SortArrow: () => TableCustomSortArrow(controller),
              Filter: () => <TiFilter fontSize="small" />,
            }}
            actions={ACTIONS}
            components={{
              Container: (props) => <Paper {...props} elevation={0} />,
              Pagination: (props) => <Pagination {...props} />,
              Toolbar: (props) => (
                <MTableToolbar
                  classes={{ root: globalClasses.gridMuiToolbar }}
                  {...props}
                />
              ),
              OverlayLoading: () => <TableProgressBar />,
            }}
            localization={{
              header: {
                actions: "Actions",
              },
              body: {
                emptyDataSourceMessage: loading ? "" : <DataNotFound />,
              },
            }}
            isLoading={loading}
            options={{
              debounceInterval: 500,
              showTitle: true,
              search: false,
              actionsColumnIndex: 0,
              filtering: enableFilters,
              paging: true,
              showFirstLastPageButtons: false,
              paginationPosition: "bottom",
              exportButton: false,
              paginationType: "stepped",
              headerStyle: getTableHeaderStyles(theme),
              cellStyle: getTableCellStyles(theme),
              tableLayout: "auto",
              draggable: false,
              columnResizable: true,
              emptyRowsWhenPaging: false,
              pageSize: controller.pageSize,
              maxBodyHeight: 400,
              minBodyHeight: 100,
              pageSizeOptions: isEmptyGrid(poHistoryList)
                ? []
                : pagination.pageSizeOptions,
              showEmptyDataSourceMessage: true,
            }}
          />
        </div>
      </Grid>
    </Grid>
  );
};

export default memo(POHistory);
