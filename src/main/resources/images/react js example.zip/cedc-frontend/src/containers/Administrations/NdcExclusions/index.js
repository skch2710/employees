import { Grid } from "@material-ui/core";
import _get from "lodash/get";
import React, { useContext, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import BasicPopup from "../../../components/Popup/BasicPopup";
import BasicTypography from "../../../components/common/Typography/BasicTypography";
import { ndcSearchList } from "../../../context/actions/NdcExclusions";
import { getUserSession } from "../../../utils/helper";
import CeNdcList from "./CeNdcList";
import CreateUpdateExclusionList from "./CreateUpdateExclusionList";
import { NdcContext } from "./NdcContext";
import NdcList from "./NdcList";
import NdcSearchForm from "./NdcSearchForm";
import PharmaciesNdcList from "./PharmaciesNdcList";
import SelectViewTabs from "./SelectViewTabs";
import { COVERED_ENTITY, NDC, PHARMACY_STORE } from "./constants";
import { getDefaultNdcListPayload, getNdcListPayload } from "./helpers";
import { useNdcStyles } from "./styles";

const NdcExclusions = () => {
  const {
    showAddEditNdcListPopup,
    handleConfigPopup,
    ndcConfigPopupTitle,
    setNdcSearchPayload,
  } = useContext(NdcContext);
  const dispatch = useDispatch();
  const classes = useNdcStyles();
  const formRef = useRef(null);
  const actionRef = useRef(null);
  const [CurrentTab, setCurrentTab] = useState(NDC);
  const [formSubmittedValues, setFormSubmittedValues] = useState({});
  const { ndcLists = [] } = useSelector((state) => state.ndcLists);
  const userSession = getUserSession();
  const { ceList } = useSelector((state) => state.coveredEntities);

  const currentTabs = (tab) => {
    return {
      isList: tab === NDC,
      isCoveredEntity: tab === COVERED_ENTITY,
      isPhGroup: tab === PHARMACY_STORE,
    };
  };

  const handleSelectedTab = (tab) => {
    const tabsPayload = currentTabs(tab);
    setCurrentTab(tab);
    if (
      !formSubmittedValues.hasOwnProperty("ceId") &&
      !userSession.isInternalUser
    ) {
      formSubmittedValues.ceId = ceList;
    }
    const payloadJson = {
      ...getDefaultNdcListPayload(formSubmittedValues),
      ...tabsPayload,
    };
    dispatch(ndcSearchList(payloadJson, (resp) => resp));
  };

  const fetchNdcDetails = (values, payload = {}, callback) => {
    const tabsPayload = currentTabs(CurrentTab);
    if (!values.hasOwnProperty("ceId") && !userSession.isInternalUser) {
      values.ceId = ceList;
    }
    const payloadJson = {
      ...getNdcListPayload(values),
      ...payload,
      ...tabsPayload,
    };
    setNdcSearchPayload(payloadJson);
    dispatch(ndcSearchList(payloadJson, (resp) => callback && callback(resp)));
  };

  const handleSubmit = (values) => {
    fetchNdcDetails(values, {}, (resp) => {
      actionRef.current && actionRef.current.submitForm(resp);
    });
    setFormSubmittedValues(values);
  };

  const handleNdcSearchClear = (values) => {
    actionRef.current && actionRef.current.clearForm(values);
    setFormSubmittedValues({});
  };

  useEffect(() => {
    if (ndcLists.length) {
      setFormSubmittedValues((prev = {}) => {
        const prevListIds = _get(prev, "listId", []);
        return {
          ...prev,
          listId: prevListIds.length
            ? prevListIds.length + 1 === ndcLists.length
              ? ndcLists
              : prevListIds
            : ndcLists,
        };
      });
      if (!showAddEditNdcListPopup) {
        fetchNdcDetails({
          listId: [],
          sortBy: "listName",
          sortOrder: "asc",
        });
      }
    }
  }, [ndcLists]);

  return (
    <>
      <Grid container spacing={2}>
        <Grid item md={12}>
          <BasicTypography
            variant="h1"
            title="Administration - NDC Exclusions"
          />
        </Grid>
        <Grid item md={12}>
          <NdcSearchForm
            handleSubmit={handleSubmit}
            ndcLists={ndcLists}
            formRef={formRef}
            handleClear={(values) => handleNdcSearchClear(values)}
          />
        </Grid>
        <Grid item md={12}>
          <Grid container spacing={2} alignItems="center">
            <Grid item>
              <BasicTypography variant="h5">Selected View</BasicTypography>
            </Grid>
            <Grid item md>
              <SelectViewTabs handleSelectedTab={handleSelectedTab} />
            </Grid>
          </Grid>
        </Grid>
        {CurrentTab === NDC ? (
          <Grid item md={12}>
            <NdcList
              formSubmittedValues={formSubmittedValues}
              formRef={formRef}
              ref={actionRef}
              fetchNdcDetails={fetchNdcDetails}
            />
          </Grid>
        ) : null}
        {CurrentTab === COVERED_ENTITY ? (
          <Grid item md={12}>
            <CeNdcList
              formSubmittedValues={formSubmittedValues}
              formRef={formRef}
              ref={actionRef}
              fetchNdcDetails={fetchNdcDetails}
            />
          </Grid>
        ) : null}
        {CurrentTab === PHARMACY_STORE ? (
          <Grid item md={12}>
            <PharmaciesNdcList
              formSubmittedValues={formSubmittedValues}
              formRef={formRef}
              ref={actionRef}
              fetchNdcDetails={fetchNdcDetails}
            />
          </Grid>
        ) : null}
      </Grid>
      <BasicPopup
        title={ndcConfigPopupTitle}
        show={showAddEditNdcListPopup}
        handleClose={() => {
          handleConfigPopup({ state: false });
        }}
        disableFooter={true}
        dialogProps={{
          maxWidth: "lg",
          classes: {
            paper: classes.dialogPaper,
          },
        }}
      >
        <CreateUpdateExclusionList />
      </BasicPopup>
    </>
  );
};

export default NdcExclusions;
