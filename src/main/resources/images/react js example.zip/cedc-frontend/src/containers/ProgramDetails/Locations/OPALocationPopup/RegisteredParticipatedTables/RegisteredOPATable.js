import React, {
  forwardRef,
  memo,
  useContext,
  useImperativeHandle,
  useRef,
  useState,
  useCallback,
} from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import _isEmpty from "lodash/isEmpty";
import {
  getTableCellStyles,
  getTableHeaderStyles,
  useGlobalStyles,
} from "../../../../../Styles/useGlobalStyles";
import { pagination } from "../../../../../utils/constants";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import DataNotFound from "../../../../../components/common/DataNotFound";
import { Paper, Tooltip, useTheme } from "@material-ui/core";
import { TiFilter } from "react-icons/ti";
import { useOPALocationsTablesStyles } from "./styles";
import {
  getExcludedData,
  getTableHeaderCount,
  isEmptyGrid,
} from "../../../../../utils/helper";
import TableProgressBar from "../../../../../components/common/TableProgressBar";
import ColumnLevelFilterInput from "../../../../../components/common/ColumnLevelFilterInput";
import { useDispatch, useSelector } from "react-redux";
import useTableIconsAndButtons from "../../../../../components/common/TableIcons";
import TableCustomSortArrow from "../../../../../components/common/TableCustomSortArrow";
import Pagination from "../../../../../components/common/Pagination";
import { COContext } from "../../../COContext";
import pass from "../../../../../assets/pass.png";
import { exportOPASearchResultTableData } from "../../../../../context/actions/Locations";
import { getRegisteredOPATablePayload } from "../../constants";

const RegisteredOPATable = memo(
  forwardRef((props = {}, ref) => {
    const { tableRef, imperativeRef } = ref;
    const {
      searchResults = {},
      formSubmittedValues,
      getSearchTableData,
      controllers,
      setControllers,
      setSelectedSearchResults,
      selectedSearchResults,
      ceSelected,
    } = props || {};
    const dispatch = useDispatch();
    const theme = useTheme();
    const globalClasses = useGlobalStyles();
    const iconsAndButtons = useTableIconsAndButtons();
    const { participatingLocationsData } = useContext(COContext);

    const { loading } = useSelector(
      (state) => state.getRegisteredLocationListData
    );

    const [columnFilters, setColumnFilters] = useState([]);
    const [enableFilters, setEnableFilters] = useState(false);

    const columnFiltersRef = useRef({});

    const classes = useOPALocationsTablesStyles({
      totalElements: !_isEmpty(searchResults) && searchResults.totalElements,
      pageSize: controllers.pageSize,
      pageNumber: controllers.pageNumber,
    });

    useImperativeHandle(imperativeRef, () => ({
      // This function will be called when submit button clicked from search component
      submitForm(resp) {
        columnFiltersRef.current = {};
        setControllersOnResp(resp);
        setSelectedSearchResults({
          ...selectedSearchResults,
          registered: [],
        });
      },
      // This function will be called when clear button clicked from search component
      clearForm(payload) {
        columnFiltersRef.current = {};
        setColumnFilters([]);
        setSelectedSearchResults({
          ...selectedSearchResults,
          registered: [],
        });
        getSearchTableData(payload, (resp) => setControllersOnResp(resp));
      },
    }));

    const setControllersOnResp = (resp = {}, additionalStates = {}) => {
      const { pageNo, pageSize = pagination.limit } = resp;
      setControllers((prev) => {
        if (pageSize !== prev.pageSize)
          tableRef.current.dataManager.changePageSize(pageSize);
        return {
          ...prev,
          pageNumber: pageNo || pagination.page,
          pageSize: pageSize || pagination.limit,
          ...additionalStates,
        };
      });
    };

    const onPageChange = useCallback(
      (newPage, pageSize) => {
        let currentPage = newPage + 1;
        const rowsPerPage = Number(pageSize);
        const totalPages =
          Math.ceil(searchResults.totalElements / rowsPerPage) || 1;
        if (controllers.pageNumber > totalPages) currentPage = totalPages;
        else if (newPage === 0 && rowsPerPage !== controllers.pageSize)
          currentPage = controllers.pageNumber;

        getSearchTableData(
          {
            pageNumber: currentPage,
            pageSize: rowsPerPage,
            sortOrder: controllers.sortOrder,
            sortBy: controllers.sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp)
        );
      },
      [columnFilters, searchResults, controllers, formSubmittedValues]
    );

    const handleSort = useCallback(
      (orderedColumnId) => {
        const sortOrder = controllers.sortOrder === "asc" ? "desc" : "asc";
        const sortBy = REGISTERED_LOCATIONS_COLUMNS[orderedColumnId].field;
        setControllers((prev) => ({ ...prev, sortOrder, sortBy }));
        getSearchTableData(
          {
            pageNumber: controllers.pageNumber,
            pageSize: controllers.pageSize,
            sortOrder,
            sortBy,
            filter: columnFilters,
            ...formSubmittedValues,
          },
          (resp) => setControllersOnResp(resp, { sortOrder, sortBy })
        );
      },
      [controllers, formSubmittedValues, columnFilters, searchResults]
    );
    const getFiltersObject = (filters = []) => {
      return filters.map((filter) => {
        return {
          column: {
            field: filter.column.field,
          },
          operator: "startWith",
          value: filter.value,
        };
      });
    };
    const handleColumnFilter = (filters = []) => {
      const filterPayload = getFiltersObject(filters);
      setColumnFilters(filterPayload);
      const updatedFiltersObj = {};
      filters.forEach((filter) => {
        updatedFiltersObj[filter.column.field] = filter.value;
      });
      columnFiltersRef.current = { ...updatedFiltersObj };
      getSearchTableData(
        {
          ...formSubmittedValues,
          ...controllers,
          filter: filterPayload,
          pageNumber: pagination.page,
        },
        (resp) => setControllersOnResp(resp)
      );
    };

    const REGISTERED_LOCATIONS_COLUMNS = [
      {
        title: "Provider Location HRSA ID",
        field: "locHrsaid",
        defaultFilter: enableFilters && columnFiltersRef.current.locHrsaid,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.locHrsaid}>
              <span>{rowData.locHrsaid || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.locHrsaid}
            placeholder="Provider Location HRSA ID"
          />
        ),
      },
      {
        title: "Address Line 1",
        field: "address1",
        defaultFilter: enableFilters && columnFiltersRef.current.address1,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.address1}>
              <span>{rowData.address1 || ""}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.address1}
            placeholder="Address Line 1"
          />
        ),
      },
      {
        title: "Address Line 2",
        field: "address2",
        defaultFilter: enableFilters && columnFiltersRef.current.address2,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.address2}>
              <span>{rowData.address2}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.address2}
            placeholder="Address Line 2"
          />
        ),
      },
      {
        title: "City",
        field: "city",
        defaultFilter: enableFilters && columnFiltersRef.current.city,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.city}>
              <span>{rowData.city}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.city}
            placeholder="City"
          />
        ),
      },
      {
        title: "State",
        field: "state",
        defaultFilter: enableFilters && columnFiltersRef.current.state,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.state}>
              <span>{rowData.state}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.state}
            placeholder="State"
          />
        ),
      },
      {
        title: "Zip",
        field: "zip",
        defaultFilter: enableFilters && columnFiltersRef.current.zip,
        customFilterAndSearch: () => true,
        render: (rowData) => {
          return (
            <Tooltip title={rowData.zip}>
              <span>{rowData.zip}</span>
            </Tooltip>
          );
        },
        filterComponent: (props) => (
          <ColumnLevelFilterInput
            {...props}
            value={columnFiltersRef.current.zip}
            placeholder="Zip"
          />
        ),
      },
    ];

    const tableData = getExcludedData({
      originalList: searchResults.content || [],
      draftList: participatingLocationsData.content,
      identifierKey: "id",
    });

    const ACTIONS = [
      {
        icon: iconsAndButtons.Filter(),
        tooltip: `${enableFilters ? "Close" : "Open"} Filters`,
        disabled: isEmptyGrid(searchResults) && _isEmpty(columnFilters),
        isFreeAction: true,
        onClick: () => {
          setEnableFilters((prev) => !prev);
        },
      },
      {
        icon: iconsAndButtons.ExportToExcel(),
        disabled: isEmptyGrid(searchResults),
        isFreeAction: true,
        onClick: async () => {
          const payload = getRegisteredOPATablePayload(
            {
              ...formSubmittedValues,
              ...controllers,
              export: true,
            },
            ceSelected
          );
          await dispatch(
            exportOPASearchResultTableData({
              ...payload,
              filter: columnFilters,
            })
          );
        },
      },
    ];
    return (
      <>
        <MaterialTable
          title={
            <div className={classes.successContainer}>
              <BasicTypography
                variant="h5"
                title={`Registered OPA Locations (${getTableHeaderCount(
                  searchResults.totalElements || 0
                )})`}
              />
              {selectedSearchResults.registered.length > 0 && (
                <span className={classes.uploadSuccess}>
                  <img src={pass} alt="passed" />
                  <p>{`${selectedSearchResults.registered.length} ${
                    selectedSearchResults.registered.length === 1
                      ? "Location"
                      : "Locations"
                  } selected`}</p>
                </span>
              )}
            </div>
          }
          tableRef={tableRef}
          columns={REGISTERED_LOCATIONS_COLUMNS}
          data={tableData}
          page={controllers.pageNumber - 1}
          totalCount={searchResults.totalElements}
          onChangePage={onPageChange}
          onOrderChange={handleSort}
          onFilterChange={handleColumnFilter}
          onSelectionChange={(rows) => {
            setSelectedSearchResults({
              ...selectedSearchResults,
              registered: rows,
            });
          }}
          icons={{
            SortArrow: () => TableCustomSortArrow(controllers),
            Filter: () => <TiFilter fontSize="small" />,
          }}
          actions={ACTIONS}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Pagination: (props) => <Pagination {...props} />,
            Toolbar: (props) => (
              <MTableToolbar
                classes={{ root: globalClasses.gridMuiToolbar }}
                {...props}
              />
            ),
            OverlayLoading: () => <TableProgressBar />,
          }}
          localization={{
            header: {
              actions: "Actions",
            },
            body: {
              emptyDataSourceMessage: loading ? "" : <DataNotFound />,
            },
          }}
          isLoading={loading}
          options={{
            debounceInterval: 500,
            search: false,
            actionsColumnIndex: 0,
            filtering: enableFilters,
            paging: true,
            selection: true,
            showFirstLastPageButtons: false,
            showTextRowsSelected: false,
            paginationPosition: "bottom",
            exportButton: false,
            paginationType: "stepped",
            exportAllData: false,
            headerStyle: getTableHeaderStyles(theme),
            cellStyle: getTableCellStyles(theme),
            tableLayout: "auto",
            draggable: false,
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: controllers.pageSize,
            maxBodyHeight: 400,
            minBodyHeight: 400,
            pageSizeOptions: isEmptyGrid(searchResults)
              ? []
              : pagination.pageSizeOptions,
            showEmptyDataSourceMessage: true,
          }}
        />
      </>
    );
  })
);

export default RegisteredOPATable;
