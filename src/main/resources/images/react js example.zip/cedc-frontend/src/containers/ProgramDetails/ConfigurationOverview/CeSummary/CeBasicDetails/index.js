import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  Collapse,
  Divider,
  FormLabel,
  Grid,
  IconButton,
  Paper,
} from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import BasicTypography from "../../../../../components/common/Typography/BasicTypography";
import {
  getCOBasicDetails,
  getPrimaryContactDetails,
} from "../../../../../context/actions/ConfigOverview";
import {
  getUserPermissionOnModuleName,
  getUserSession,
} from "../../../../../utils/helper";
import { COContext } from "../../../COContext";
import { MENUS } from "../../PopupSidebar/constants";
import { BsPencilSquare } from "react-icons/bs";
import { useCeSummaryStyle } from "../styles";
import { useGlobalStyles } from "../../../../../Styles/useGlobalStyles";
import { LABELS} from "../../../../../utils/constants";

const CeBasicDetails = memo((props = {}) => {
  const { ceId, isAllCollapsed } = props;
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const commonSummaryClasses = useCeSummaryStyle();
  const userSession = getUserSession();
  const readWritePermission = getUserPermissionOnModuleName(
    "Configuration Overview"
  ).readWriteFlag;

  const { clickOnPencil, setCoveredEntityName } = useContext(COContext) || {};

  const { loading: _basicDetailsLoading, basicDetails } =
    useSelector((state) => state.ceBasicDetails) || {};
  const { loading: _contactDetailsLoading, contactDetails } =
    useSelector((state) => state.ceContactDetails) || {};

  const [isCollapsed, setIsCollapsed] = useState(true);

  const fetchBasicDetails = async (ceId) => {
    dispatch(getCOBasicDetails({ ceID: ceId }));
    dispatch(getPrimaryContactDetails(ceId));
  };

  useEffect(() => {
    ceId && fetchBasicDetails(ceId);
  }, [ceId]);

  useEffect(() => {
    setIsCollapsed(isAllCollapsed);
  }, [isAllCollapsed]);

  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={commonSummaryClasses.summaryWrapper}>
      <Grid container>
        <Grid item md={12}>
          <div className={commonSummaryClasses.summaryTitleWrapper}>
            <BasicTypography variant="h3" title="Basic Details" />
            <div className={commonSummaryClasses.actionBtnContainer}>
              <IconButton
                size="small"
                disabled={!userSession.isInternalUser || !readWritePermission}
              >
                <BsPencilSquare
                  onClick={() => {
                    setCoveredEntityName(basicDetails.ceName);
                    clickOnPencil(MENUS.CE_BASIC_DETAILS, ceId);
                  }}
                />
              </IconButton>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item md={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={commonSummaryClasses.collapseContainer}>
              <Grid container spacing={4}>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Covered Entity Details"
                      />
                    </Grid>
                    <Grid item xs={12} md={12}>
                      <Grid container spacing={2}>
                        <Grid item md={12}>
                          <Grid container spacing={2}>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>{LABELS.CoveredEntity}</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.ceName || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Address Line 1</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.addressLine1 || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Address Line 2</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.addressLine2 || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>City</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.city || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>State</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.state || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Zip</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.zip || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>HRSA ID</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.hrsaId || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Covered Entity Type</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.coveredEntityType || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>Start Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.startDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={2}>
                              <FormLabel>End Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.endDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Effective Date</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.effectiveDate || "--"}
                              </BasicTypography>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                              <FormLabel>Contract Term</FormLabel>
                              <BasicTypography variant="subtitle2">
                                {basicDetails.contractTerm || "--"}
                              </BasicTypography>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={2}>
                    <Grid item md={12}>
                      <BasicTypography
                        variant="h5"
                        title="Covered Entity Main Contact"
                      />
                    </Grid>
                    <Grid item md={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Full Name</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {contactDetails.fullname || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Email Address</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {contactDetails.emailAddress || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Contact Number</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {contactDetails.contactNumber || "--"}
                          </BasicTypography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <FormLabel>Title</FormLabel>
                          <BasicTypography variant="subtitle2">
                            {contactDetails.title || "--"}
                          </BasicTypography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </div>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
});

export default CeBasicDetails;
