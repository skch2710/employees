import { Grid } from "@material-ui/core";
import _isArray from "lodash/isArray";
import _isEmpty from "lodash/isEmpty";
import React, {
  memo,
  useContext,
  useEffect,
  useState
} from "react";
import { useDispatch } from "react-redux";
import { useGlobalStyles } from "../../../../Styles/useGlobalStyles";
import BasicTypography from "../../../../components/common/Typography/BasicTypography";
import {
  fetchNdcSectionStatus,
  getNdcListHistory,
} from "../../../../context/actions/NdcExclusions";
import { NdcContext } from "../NdcContext";
import { NDC_TABS } from "../constants";
import { useNdcSearchFormStyles } from "../styles";

const ViewListHistory = ({ rowData }) => {
  const dispatch = useDispatch();
  const globalClasses = useGlobalStyles();
  const classes = useNdcSearchFormStyles();
  const [listHistory, setListHistory] = useState([]);
  const {
    handleConfigPopup,
    setProgress,
    setActiveNdcConfigTab,
    setActiveInactiveTabs,
    setNdcData,
    setIsNewList,
    setNdcConfigPopupTitle,
  } = useContext(NdcContext);

  const fetchListHistory = () => {
    dispatch(
      getNdcListHistory(
        {
          listId: rowData.listId,
        },
        (response) => {
          _isArray(response) && setListHistory(response);
        }
      )
    );
  };

  const getNdcSectionStatus = async (listId) => {
    const res = await dispatch(fetchNdcSectionStatus(listId));
    !_isEmpty(res) && setProgress(res);
  };

  useEffect(() => {
    fetchListHistory();
  }, []);

  const handleViewLinkClick = (elm) => {
    setNdcConfigPopupTitle(rowData.listName);
    setIsNewList(false);
    setNdcData({
      ...rowData,
      listHistoryId: elm.listHistoryId,
    });
    setActiveInactiveTabs({
      [NDC_TABS.NDC_BASIC_DETAILS]: true,
      [NDC_TABS.NDC_SELECTION]: true,
      [NDC_TABS.NDC_LIST_APPLICATION]: true,
      [NDC_TABS.NDC_LIST_REVIEW]: true,
    });
    setActiveNdcConfigTab(NDC_TABS.NDC_LIST_REVIEW);
    getNdcSectionStatus(rowData.listId);
    handleConfigPopup({ state: true });
  };

  return (
    <div className={globalClasses.cardPrimary}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <BasicTypography variant="h4" title={rowData.listName} />
        </Grid>
        <Grid item xs={12}>
          <Grid container spacing={2} direction="column">
            {listHistory.map((elm) => {
              return (
                <Grid item key={elm.listHistoryId}>
                  <Grid
                    container
                    className={classes.listHistoryCards}
                    spacing={2}
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Grid item>
                      <BasicTypography variant="h5">
                        <span>{elm.user} - </span>
                        {elm && elm.status && (
                          <span
                            className={
                              elm.status === "Active"
                                ? classes.listHistoryActive
                                : classes.listHistoryInActive
                            }
                          >
                            {elm.status}
                          </span>
                        )}
                      </BasicTypography>
                      <BasicTypography
                        variant="h6"
                        title={`Timestamp : ${elm.lastModifiedDate}`}
                      />
                    </Grid>
                    <Grid item>
                      <a
                        className={classes.viewLink}
                        href="#"
                        onClick={() => handleViewLinkClick(elm)}
                      >
                        {"View >"}
                      </a>
                    </Grid>
                  </Grid>
                </Grid>
              );
            })}
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};

export default memo(ViewListHistory);
