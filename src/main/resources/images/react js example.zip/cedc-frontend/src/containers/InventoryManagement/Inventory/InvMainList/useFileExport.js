import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { InventorymainExport } from "../../../../context/actions/Inventory";
import { notNull } from "../../../../utils/constants";
import {
  getDefaultInvListPayload
} from "../constants";


const useFileExport = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { InvControllers, columnFilters, formRef } = props;
    const { isSubmitting, values } = (formRef && formRef.current) || {};
    dispatch(
      InventorymainExport(
        {
          ...getDefaultInvListPayload(values),
          sortBy: InvControllers.sortBy,
          sortOrder: InvControllers.sortOrder,
          filter: columnFilters,
          export: true,
          ...(isSubmitting
            ? { ...[values.ceID] }
            : {}),
        },
        (result) => {
          var data = result.content.map(
            ({
              ndc,
              drugName,
              wholesalerName,
              packageSize,
              openingUnits,
              unitsDispensed,
              unitsReplenished,
              returnedUnits,
              pxOwedInventory,
              ceOwnedInventory,
              three40BInventoryCost,
              scheduleType,
              drugManufacturerName,
            }) => ({
              "NDC" : notNull(ndc),
              "Drug Name": drugName,
              "Wholesaler Name": wholesalerName,
              "Package Size": notNull(packageSize),
              "Opening Units": notNull(openingUnits),
              "Units Dispensed": notNull(unitsDispensed),
              "Units Replenished": notNull(unitsReplenished),
              "Returned Units": notNull(returnedUnits),
              "Px Owed Inventory": notNull(pxOwedInventory),
              "Covered Entity Owned Inventory": notNull(ceOwnedInventory),
              "340B Inventory Cost": notNull(three40BInventoryCost),
              "Schedule Type": notNull(scheduleType),
              "Drug Manufacturer": notNull(drugManufacturerName),
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Inventory List" + ".xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExport;
