import React from "react";
import { Field, FieldArray } from "formik";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Tooltip,
  useTheme,
} from "@material-ui/core";
import { BiBlock } from "react-icons/bi";
import { modulePermissionHeader } from "../../components/common/Table/TableHeadCells";
import { CiCircleCheck } from "react-icons/ci";
import { ImCross } from "react-icons/im";
import { CiCircleRemove } from "react-icons/ci";
import { getPermissionDisableState, getPermissionMapping } from "./helper";
import { useSelector } from "react-redux";
import LoaderUI from "../../components/common/Loader/Loader";
import { SUPER_USER_ROLE_IDS } from "./constant";
import { useUserManagementStyles } from "./style";

const AddEdituserPermission = ({
  sendValue: viewOnly,
  permissions = [],
  handleClick,
  defaultUserPrivileges = [],
  user,
  role,
}) => {
  const theme = useTheme();
  let isSuperUser = false;
  if (role) {
    isSuperUser = SUPER_USER_ROLE_IDS.includes(Number(role));
  } else if (user) {
    isSuperUser = SUPER_USER_ROLE_IDS.includes(user.roleID);
  }
  const classes = useUserManagementStyles();
  const loader = useSelector((state) => state.usermanagement.loading);
  const disabledNode = (
    <Field name={`disabled`} type={`checkbox`} checked={false} disabled />
  );
  const blockedNode = <CiCircleRemove size={22} color="red" />;
  const greenCheckNode = <CiCircleCheck size={22} color="green" />;
  const redCrossNode = <ImCross size={15} color="red" />;
  const NaNode = <BiBlock size={20} color={theme.colors.grey[900]} />;

  return (
    <TableContainer component={Paper} className={classes.userPermissionsCard}>
      {loader && <LoaderUI />}
      <Table
        className={classes.userPermissionsTable}
        size="small"
        aria-label="a dense table"
      >
        <TableHead>
          <TableRow>
            {modulePermissionHeader.map((header, index) => (
              <Tooltip
                key={index}
                title={header.tooltipContent}
                PopperProps={{ style: { marginTop: -12 } }}
              >
                <TableCell key={index}>{header.label}</TableCell>
              </Tooltip>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {viewOnly ? (
            permissions.length > 0 && defaultUserPrivileges.length > 0 ? (
              permissions.map((row, index) => {
                return (
                  <TableRow key={index}>
                    <TableCell
                      component="th"
                      scope="row"
                      size="small"
                      fontSize="12px"
                    >
                      {(row.resource && row.resource.resourceName) ||
                        row.moduleName}
                    </TableCell>
                    <TableCell size="small">
                      {getPermissionMapping({
                        row,
                        defaultUserPrivileges,
                        permission: "read",
                        disabledNode: blockedNode,
                        view: true,
                        greenCheckNode,
                        redCrossNode,
                        NaNode,
                      })}
                    </TableCell>
                    <TableCell size="small">
                      {getPermissionMapping({
                        row,
                        defaultUserPrivileges,
                        permission: "readWrite",
                        disabledNode: blockedNode,
                        view: true,
                        greenCheckNode,
                        redCrossNode,
                        NaNode,
                      })}
                    </TableCell>
                    <TableCell size="small">
                      {getPermissionMapping({
                        row,
                        defaultUserPrivileges,
                        permission: "terminate",
                        disabledNode: blockedNode,
                        view: true,
                        greenCheckNode,
                        redCrossNode,
                        NaNode,
                      })}
                    </TableCell>
                  </TableRow>
                );
              })
            ) : null
          ) : (
            <FieldArray
              name="pm"
              render={() => (
                <>
                  {permissions.length > 0 && defaultUserPrivileges.length > 0
                    ? permissions.map((row, index) => (
                      <TableRow key={index}>
                        <TableCell
                          component="th"
                          scope="row"
                          size="small"
                          fontSize="12px"
                        >
                          {(row.resource && row.resource.resourceName) ||
                            row.moduleName}
                        </TableCell>
                        <TableCell size="small" className={classes.icons}>
                          {getPermissionMapping({
                            row,
                            defaultUserPrivileges,
                            permission: "read",
                            disabledNode,
                            NaNode,
                            enabledNode: (
                              <Field
                                onClick={(e) =>
                                  handleClick(row, e.target.checked, "read")
                                }
                                name={`pm[${index}].readOnlyFlag`}
                                type={`checkbox`}
                                checked={row.readOnlyFlag}
                                disabled={
                                  isSuperUser ||
                                  getPermissionDisableState({
                                    row,
                                    permissions,
                                  })
                                }
                              />
                            ),
                          })}
                        </TableCell>
                        <TableCell size="small" className={classes.icons}>
                          {getPermissionMapping({
                            row,
                            defaultUserPrivileges,
                            permission: "readWrite",
                            disabledNode,
                            NaNode,
                            enabledNode: (
                              <Field
                                onClick={(e) =>
                                  handleClick(row, e.target.checked, "write")
                                }
                                name={`pm[${index}].readWriteFlag`}
                                type={`checkbox`}
                                checked={row.readWriteFlag}
                                disabled={
                                  isSuperUser ||
                                  getPermissionDisableState({
                                    row,
                                    permissions,
                                  })
                                }
                              />
                            ),
                          })}
                        </TableCell>
                        <TableCell size="small" className={classes.icons}>
                          {getPermissionMapping({
                            row,
                            defaultUserPrivileges,
                            permission: "terminate",
                            disabledNode,
                            NaNode,
                            enabledNode: (
                              <Field
                                name={`pm[${index}].terminateFlag`}
                                type={`checkbox`}
                                onClick={(e) =>
                                  handleClick(
                                    row,
                                    e.target.checked,
                                    "terminate"
                                  )
                                }
                                checked={row.terminateFlag}
                                disabled={
                                  isSuperUser ||
                                  getPermissionDisableState({
                                    row,
                                    permissions,
                                  })
                                }
                              />
                            ),
                          })}
                        </TableCell>
                      </TableRow>
                    ))
                    : null}
                </>
              )}
            />
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
};
export default AddEdituserPermission;
