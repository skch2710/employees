export const getDeliveryMethodDropdownOptions = ({ options = [], id } = {}) => {
  const FILE_TYPE_TO_DELIVERY_MAPPING = {
    1: [5],
    2: [6],
    3: [7, 8],
    4: [9],
  };
  if (id) {
    return (
      options.filter((option) =>
        FILE_TYPE_TO_DELIVERY_MAPPING[id].includes(option.id)
      ) || options
    );
  } else return options || [];
};

export const getFrequencyDropdownOptions = ({ options = [], id } = {}) => {
  const FILE_TYPE_TO_FREQUENCY_MAPPING = {
    1: [10],
    2: [10],
    3: [11, 12, 13, 14],
    4: [10],
  };
  if (id) {
    return (
      options.filter((option) =>
        FILE_TYPE_TO_FREQUENCY_MAPPING[id].includes(option.id)
      ) || options
    );
  } else return options || [];
};
