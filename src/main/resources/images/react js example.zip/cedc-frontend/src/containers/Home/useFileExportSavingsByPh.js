import { useDispatch } from "react-redux";
import * as XLSX from "xlsx";
import FileSaver from "file-saver";
import { Homebarchatsavbypharma } from "../../context/actions/Home";
import { notNull } from "../../utils/constants";
import { formatValue } from "../../utils/common";

const useFileExportSavingsByPh = () => {
  const dispatch = useDispatch();

  const exportToExcel = (props) => {
    const { ceId, Pstore, Pgroup, startdate, enddate } = props;

    dispatch(
      Homebarchatsavbypharma(
        {
          export: "true",
          ceid: ceId,
          phid: Pstore,
          phGroupId: Pgroup,
          processedStartDate: startdate,
          processedEndDate: enddate,
        },
        (result) => {
          var data = result.map(
            ({ phName, totalInvoicedClaims, cogs, savings }) => ({
              "Pharmacy Store": notNull(phName),
              "Total Invoiced Claims": totalInvoicedClaims
                ? "$" + formatValue(totalInvoicedClaims)
                : "",
              "Cost of Goods Sold": cogs ? "$" + formatValue(cogs) : "",
              "Total Invoiced Savings": savings
                ? "$" + formatValue(savings)
                : "",
            })
          );
          const ws = XLSX.utils.json_to_sheet(data);
          const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const fileData = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
          });
          FileSaver.saveAs(fileData, "Savings by Pharmacy.xlsx");
        }
      )
    );
  };

  return { exportToExcel };
};

export default useFileExportSavingsByPh;
