import { makeStyles } from "@material-ui/core";

export const useCeOrderingConfigStyles = makeStyles((theme) => {
  return {
    collapseWrapper: {
      border: `1px solid ${theme.colors.monochrome.cardBorder}`,
      borderRadius: "10px",
      boxShadow: `0 0 18px 0 ${theme.colors.monochrome.cardBoxShadow}`,
      lineHeight: "1.42857143",
      margin: "0 0 10px 0",
    },
    collapseTitleWrapper: {
      display: "flex",
      justifyContent: "space-between",
      padding: "10px 15px",
    },
    collapseTitleText: {
      fontSize: 15,
    },
    actionBtnContainer: {
      display: "flex",
      gap: "10px",
    },
    tableCardPadding: {
      padding: "10px 20px",
    },
    wizardButtonsContainer: {
      marginTop: 20,
    },
  };
});
