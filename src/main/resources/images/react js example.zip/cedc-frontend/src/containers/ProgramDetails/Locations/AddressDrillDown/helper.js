export const getLocationHistoryFiltersObject = (filters = []) => {
  const dateFields = ["startDate", "endDate", "lastModifiedDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};

export const getProviderAssociationFiltersObject = (filters = []) => {
  const dateFields = ["startDate", "endDate"];
  return filters.map((filter) => {
    return {
      column: {
        field: filter.column.field,
      },
      operator: dateFields.includes(filter.column.field) ? "=" : "startWith",
      value: filter.value,
    };
  });
};
