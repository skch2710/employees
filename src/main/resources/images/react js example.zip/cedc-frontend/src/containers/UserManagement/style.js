import { makeStyles } from "@material-ui/core";
import { getGridActionButtonsMarginRight } from "../../utils/helper";

export const useUserManagementStyles = makeStyles((theme) => ({
  filterHeader: {
    display: "flex",
    justifyContent: "space-between",
  },
  addEditFormInPopUp: {
    margin: "30px 0px 0px 0px",
  },
  uploadSuccess: {
    margin: "0 8px",
    color: theme.colors.green[400],
    display: "flex",
    alignItems: "center",
    columnGap: "5px",
    "& > p": {
      margin: 0,
    },
  },
  uploadError: {
    margin: 0,
    color: theme.colors.red[400],
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    columnGap: "5px",
    "& > p": {
      margin: 0,
    },
  },
  headerErrorsContainer: {
    display: "flex",
    flexDirection: "column",
    rowGap: "5px",
    "& > p": {
      margin: 0,
    },
  },
  headerErrors: {
    margin: "8px 0 0",
    color: "red",
  },
  successErrorContainer: {
    display: "flex",
    alignItems: "center",
    columnGap: "10px",
  },

  radioContainer: {
    display: "flex",
    alignItems: "center",
    height: "30px",
    gap: "16px",
  },
  radioAndLabelContainer: {
    display: "flex",
    gap: "5px",
    alignItems: "center",
    "& label": {
      color: `${theme.colors.monochrome.input} !important`,
      fontFamily: theme.fontFamily,
      cursor: "pointer",
    },
  },
  downloadLinkContainer: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  coveredEntityNameWrapper: {
    width: "100%",
    height: "30px",
    display: "flex",
    alignItems: "center",
  },
  coveredEntityName: {
    width: "100%",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    color: theme.colors.monochrome.disabledText,
  },
  userPermissionsTable: {
    "& thead th": {
      fontWeight: "400",
      color: theme.colors.monochrome.tableHeaderText,
      backgroundColor: theme.colors.monochrome.tableHeaderBackground,
    },
    "& tbody th": {
      color: theme.colors.monochrome.tableCellColor,
    },
    "& tbody td": {
      fontWeight: "100",
    },

    "& tbody tr:hover": {
      backgroundColor: theme.colors.monochrome.tableRowHover,
    },
  },
  userPermissionsCard: {
    boxShadow:
      "0px 2px 1px -1px rgba(0,0,0,0.2), 0px 1px 1px 0px rgba(0,0,0,0.14), 0px 1px 3px 0px rgba(0,0,0,0.12)",
  },
  bulkUploadIcon: {
    height: 18,
    width: 18,
    marginRight: 4,
  },
  icons: {
    "& svg": {
      width: 14,
    },
  },
}));

export const useUsersListTableStyles = makeStyles((theme) => ({
  adminType: {
    fontWeight: "bold",
    fontSize: "0.75rem",
    borderRadius: 8,
    padding: "4px 10px",
    display: "inline-block",
    marginTop: "2px",
    color: theme.colors.monochrome.offWhite,
    width: "120px",
    textAlign: "center",
  },
}));
