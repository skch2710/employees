import React, { useState, useCallback, useRef, forwardRef } from "react";
import { Button, Paper, useTheme } from "@material-ui/core";
import MaterialTable, { MTableToolbar } from "material-table";
import TableCustomSortArrow from "../../../../../../components/common/TableCustomSortArrow";
import { TiFilter } from "react-icons/ti";
import DataNotFound from "../../../../../../components/common/DataNotFound";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import { pagination } from "../../../../../../utils/constants";
import tableIcons from "../../../../../../utils/MaterialTableIcons";
import { getDocumentsFiltersObject } from "../helper";
import { useBasicDetailsStyles } from "./styles";
import { TABLE_CELL_STYLE } from "./constants";

const UploadedDocumentsTable = (props = {}) => {
  const { docList, fetchDocumentsList } = props;
  const theme = useTheme();
  const classes = useBasicDetailsStyles();
  const [controller, setController] = useState({
    page: pagination.page,
    pageSize: pagination.limit,
    sortOrder: "asc",
    sortBy: "",
  });
  const [enableFilters, setEnableFilters] = useState(false);
  const [columnFilters, setColumnFilters] = useState([]);
  const columnFiltersRef = useRef({});

  const onPageChange = useCallback(
    (data, pageSize) => {
      let currentPage = data + 1;
      fetchDocumentsList({
        pageNumber: currentPage,
        pageSize: pageSize,
        filter: columnFilters,
      });
    },
    [columnFilters]
  );

  const handleSort = useCallback(
    (orderedColumnId) => {
      const sortOrder = controller.sortOrder === "asc" ? "desc" : "asc";
      const sortBy = DOCUMENTS_LIST_COLUMNS[orderedColumnId].field;
      setController((prev) => ({ ...prev, sortOrder, sortBy }));
      fetchDocumentsList({ sortOrder, sortBy });
    },
    [controller]
  );

  const handleColumnFilter = (filters) => {
    const filterPayload = getDocumentsFiltersObject(filters);
    setColumnFilters(filterPayload);
    const updatedFiltersObj = {};
    filters.forEach((filter) => {
      updatedFiltersObj[filter.column.field] = filter.value;
    });
    columnFiltersRef.current = { ...updatedFiltersObj };
    fetchDocumentsList({
      ...controller,
      filter: filterPayload,
    });
  };

  const DOCUMENTS_LIST_COLUMNS = [
    {
      title: "File Name",
      field: "fName",
      defaultFilter: enableFilters && columnFiltersRef.current.fName,
      customFilterAndSearch: () => true,
      cellStyle: TABLE_CELL_STYLE,
    },
    {
      title: "Covered Entity",
      field: "ceName",
      defaultFilter: enableFilters && columnFiltersRef.current.ceName,
      customFilterAndSearch: () => true,
      cellStyle: TABLE_CELL_STYLE,
    },
    {
      title: "Pharmacy",
      field: "phName",
      defaultFilter: enableFilters && columnFiltersRef.current.phName,
      customFilterAndSearch: () => true,
      cellStyle: TABLE_CELL_STYLE,
    },
    {
      title: "Upload Date",
      field: "uploadDate",
      defaultFilter: enableFilters && columnFiltersRef.current.uploadDate,
      customFilterAndSearch: () => true,
      cellStyle: TABLE_CELL_STYLE,
    },
    {
      title: "Is Addendum",
      field: "isAddendum",
      defaultFilter: enableFilters && columnFiltersRef.current.isAddendum,
      customFilterAndSearch: () => true,
      cellStyle: TABLE_CELL_STYLE,
    },
    {
      title: "Reviewed By",
      field: "reviewedBy",
      defaultFilter: enableFilters && columnFiltersRef.current.reviewedBy,
      customFilterAndSearch: () => true,
      cellStyle: TABLE_CELL_STYLE,
    },
  ];

  const documentList = [
    {
      fName: "PSA",
      ceName: "Community Health",
      phName: "Pharmacy A",
      uploadDate: "03/24/1992",
      isAddendum: "Yes",
      reviewedBy: "johnsmith@gmail.com",
    },
    {
      fName: "PSA",
      ceName: "Community Health",
      phName: "Pharmacy A",
      uploadDate: "03/24/1992",
      isAddendum: "Yes",
      reviewedBy: "johnsmith@gmail.com",
    },
  ];

  const actions = [
    {
      icon: tableIcons.Filter,
      tooltip: `${enableFilters ? "Disable" : "Enable"} Filter`,
      isFreeAction: true,
      disabled: documentList && documentList.totalElements < 1,
      onClick: () => {
        setEnableFilters((prev) => !prev);
      },
    },
    {
      icon: forwardRef((props, ref) => (
        <Button
          variant="outlined"
          size="small"
          component="button"
          className="export-button"
          {...props}
          ref={ref}
          classes={{ root: classes.buttonStyles }}
        >
          Export
        </Button>
      )),
      tooltip: "Export",
      disabled: documentList && documentList.totalElements < 1,
      isFreeAction: true,
      onClick: () => {},
    },
    {
      icon: tableIcons.Edit,
      tooltip: "Item History",
      isFreeAction: false,
    },
  ];

  const loading = false;

  return (
    <div className="card card-first-level">
      <MaterialTable
        title={<BasicTypography variant="h4" title="Data Preview" />}
        columns={DOCUMENTS_LIST_COLUMNS}
        data={documentList}
        page={controller.page - 1}
        totalCount={documentList.length || 0}
        onChangePage={onPageChange}
        onOrderChange={handleSort}
        onFilterChange={handleColumnFilter}
        icons={{
          SortArrow: () => TableCustomSortArrow(controller),
          Filter: () => <TiFilter fontSize="small" />,
        }}
        actions={actions}
        components={{
          Container: (props) => <Paper {...props} elevation={0} />,
          Toolbar: (props) => (
            <div className={classes.enableFilterButton}>
              <MTableToolbar {...props} />
            </div>
          ),
        }}
        localization={{
          header: {
            actions: "Actions",
          },
          body: {
            emptyDataSourceMessage: !loading ? <DataNotFound /> : "",
          },
        }}
        options={{
          debounceInterval: 500,
          search: false,
          actionsColumnIndex: 0,
          filtering: enableFilters,
          paging: true,
          showFirstLastPageButtons: false,
          paginationPosition: "top",
          exportButton: false,
          paginationType: "stepped",
          exportAllData: false,
          headerStyle: {
            background: theme.colors.monochrome.tableHeaderBackground,
            color: theme.colors.monochrome.tableHeaderText,
            fontSize: "11px",
            whiteSpace: "nowrap",
            textAlign: "left",
          },
          tableLayout: "auto",
          draggable: false,
          columnResizable: true,
          emptyRowsWhenPaging: false,
          pageSize: controller.pageSize,
          maxBodyHeight: 400,
          minBodyHeight: 80,
          pageSizeOptions: pagination.pageSizeOptions,
          showEmptyDataSourceMessage: true,
        }}
      />
    </div>
  );
};

export default UploadedDocumentsTable;
