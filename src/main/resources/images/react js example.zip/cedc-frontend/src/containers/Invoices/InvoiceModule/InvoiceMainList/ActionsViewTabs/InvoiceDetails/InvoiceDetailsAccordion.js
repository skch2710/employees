import React, { memo, useCallback, useState } from "react";
import { Collapse, Divider, Grid, IconButton, Paper } from "@material-ui/core";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
import BasicTypography from "../../../../../../components/common/Typography/BasicTypography";
import InvoiceDetailstables from "./InvoiceDetailstables";
import {
  formatValueInAccordion,
  formatValue,
} from "../../../../../../utils/common";
import { useGlobalStyles } from "../../../../../../Styles/useGlobalStyles";
import { useInvoiceDetailsStyle } from "./styles";
import classNames from "classnames";

const InvoiceDetailsAccordion = ({ res }) => {
  const classes = useInvoiceDetailsStyle();
  const globalClasses = useGlobalStyles();
  const [isCollapsed, setIsCollapsed] = useState(true);
  const toggleCollapse = useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);

  return (
    <Paper className={classes.summaryWrapper}>
      <Grid container>
        <Grid item xs={12} className={classes.commonHeaderStyle}>
          <div className={classes.summaryTitleWrapper}>
            <BasicTypography
              className={classes.commonHeaderStyle}
              variant="h3"
              title={res.phGroupName}
            />
            <div className={classes.actionBtnContainer}>
              <IconButton size="small">
                {isCollapsed ? (
                  <AiOutlineMinus onClick={toggleCollapse} />
                ) : (
                  <AiOutlinePlus onClick={toggleCollapse} />
                )}
              </IconButton>
            </div>
          </div>
        </Grid>
        <Grid item xs={12}>
          <Collapse in={isCollapsed} timeout="auto" unmountOnExit>
            <Divider classes={{ root: globalClasses.divider }} />
            <div className={classes.collapseContainer}>
              <InvoiceDetailstables data={res.invoiceDetailsList} />
            </div>
            <Grid
              xs={12}
              container
              spacing={1}
              className={classes.directPlusFeesGrid}
            >
              <Grid item xs={12} md={3}>
                <BasicTypography
                  className={classes.insuredClaimsText}
                  variant="h6"
                  title="*Insured Claims Only"
                />
              </Grid>
              <Grid item xs={12} md={9}>
                <Grid xs={12} container direction="column">
                  <Grid item>
                    <Grid xs={12} container>
                      <Grid xs={8} item>
                        <BasicTypography
                          variant="h6"
                          className={classes.directPlusFeesTitle}
                          title="340BDirect+ Fee %"
                        />
                      </Grid>
                      <Grid xs={1} item>
                        <BasicTypography
                          variant="h6"
                          className={classNames(
                            classes.directPlusFeesTitle,
                            classes.dollarPadding
                          )}
                          title="$"
                        />
                      </Grid>
                      <Grid xs={3}>
                        <BasicTypography
                          variant="h6"
                          className={classes.directPlusFeesTitle}
                          title={formatValue(res.tfbDirectPlusFeePercentage)}
                        />
                      </Grid>
                    </Grid>
                    <Grid xs={12} container>
                      <Grid xs={8} item>
                        <BasicTypography
                          variant="h6"
                          className={classes.directPlusFeesTitle}
                          title="340BDirect+ Flat Fee"
                        />
                      </Grid>
                      <Grid xs={1} item>
                        <BasicTypography
                          variant="h6"
                          className={classNames(
                            classes.directPlusFeesTitle,
                            classes.dollarPadding
                          )}
                          title="$"
                        />
                      </Grid>
                      <Grid xs={3}>
                        <BasicTypography
                          variant="h6"
                          className={classes.directPlusFeesTitle}
                          title={formatValue(res.tfbDirectPlusFlatFee)}
                        />
                      </Grid>
                    </Grid>
                    <Grid xs={12} container>
                      <Grid xs={8} item>
                        <BasicTypography
                          variant="h6"
                          className={classes.totals}
                          title={res.phGroupName + " Total 340BDirect+ Fees "}
                        />
                      </Grid>
                      <Grid xs={1} item>
                        <BasicTypography
                          variant="h6"
                          className={classNames(
                            classes.totals,
                            classes.dollarPadding
                          )}
                          title="$"
                        />
                      </Grid>
                      <Grid xs={3}>
                        <BasicTypography
                          variant="h6"
                          className={classes.totals}
                          title={formatValue(res.total340BDirectplusFees)}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Collapse>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default memo(InvoiceDetailsAccordion);
