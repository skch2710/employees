import React, { useState, useEffect } from "react";
import MaterialTable, { MTableToolbar } from "material-table";
import { useDispatch, useSelector } from "react-redux";

import { Paper, Tooltip } from "@material-ui/core";
import HeaderTitle from "../../../../components/common/Typography/HeaderTitle";
//react-icons
import { TiFilter } from "react-icons/ti";
import { pagination } from "../../../../utils/constants";
import LoaderUI from "../../../../components/common/Loader/Loader";
import TableCustomSortArrow from "../../../../components/common/TableCustomSortArrow";
import { useStyles } from "../../../../mui-styles/commonTableMuiStyle";
import { TrueUPreports } from "../../../../context/actions/Invoice";

const TrueUp = ({ totalCount, rowdata, phID, phGroupId }) => {
  const [sortBy, setsortBy] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(pagination.limit);
  const [sortorder, setOrder] = useState("asc");
  const [page, setPage] = useState(pagination.page);
  const [billingperiod, setbillingperiod] = useState(
    rowdata && rowdata.billingPeriod
  );

  const [tableinnergridData, settableinnergridData] = useState({
    content: [],
    totalElements: 0,
  });

  const TrueUp_Columns = [
    {
      title: "Claim ID",
      field: "claimId",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimId}>
            <span>{rowData.claimId}</span>
          </Tooltip>
        );
      },
    },

    {
      title: "Processed Date",
      field: "processedDate",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.processedDate}>
            <span>{rowData.processedDate}</span>
          </Tooltip>
        );
      },
    },

    {
      title: "Rx Number",
      field: "rxNumber",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.rxNumber}>
            <span>{rowData.rxNumber}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Rx Written Date",
      field: "rxWrittenDate",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.rxWrittenDate}>
            <span>{rowData.rxWrittenDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Refill #",
      field: "refillHash",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.refillHash}>
            <span>{rowData.refillHash}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Date of Service",
      field: "dateOfService",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dateOfService}>
            <span>{rowData.dateOfService}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "340B ID",
      field: "tfbID",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.tfbID}>
            <span>{rowData.tfbID}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Covered Entity",
      field: "coveredEntity",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.coveredEntity}>
            <span>{rowData.coveredEntity}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient First Name",
      field: "memberFirstName",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.memberFirstName}>
            <span>{rowData.memberFirstName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient Last Name",
      field: "memberLastName",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.memberLastName}>
            <span>{rowData.memberLastName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient ID",
      field: "memberId",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.memberId}>
            <span>{rowData.memberId}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient Visit Date",
      field: "patientVisitDate",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientVisitDate}>
            <span>{rowData.patientVisitDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient Sliding Scale",
      field: "patientSlidingScale",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientSlidingScale}>
            <span>{rowData.patientSlidingScale}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Physician First Name",
      field: "physicianFirstName",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.physicianFirstName}>
            <span>{rowData.physicianFirstName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Physician Last Name",
      field: "physicianLastName",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.physicianLastName}>
            <span>{rowData.physicianLastName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Prescriber ID",
      field: "prescriberID",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.prescriberID}>
            <span>{rowData.prescriberID}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Store",
      field: "store",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.store}>
            <span>{rowData.store}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "NCPDP",
      field: "ncpdp",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ncpdp}>
            <span>{rowData.ncpdp}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "NPI",
      field: "npi",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.npi}>
            <span>{rowData.npi}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "NDC11",
      field: "ndc11",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ndc11}>
            <span>{rowData.ndc11}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Drug Name",
      field: "drugName",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.drugName}>
            <span>{rowData.drugName}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Indicator",
      field: "indicator",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.indicator}>
            <span>{rowData.indicator}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Qty Disp",
      field: "qtyDisp",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.qtyDisp}>
            <span>{rowData.qtyDisp}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Days Supply",
      field: "daysSupply",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.daysSupply}>
            <span>{rowData.daysSupply}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "BIN",
      field: "bin",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.bin}>
            <span>{rowData.bin}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "PCN",
      field: "pcn",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.pcn}>
            <span>{rowData.pcn}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Group Number",
      field: "groupNumber",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.groupNumber}>
            <span>{rowData.groupNumber}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient Type",
      field: "personType",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.personType}>
            <span>{rowData.personType}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Patient Pay",
      field: "patientPay",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.patientPay}>
            <span>{rowData.patientPay}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Third Party Payment",
      field: "thirdPartPayment",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.thirdPartPayment}>
            <span>{rowData.thirdPartPayment}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Covered Entity Plan Subsidy",
      field: "cePlanSubsidy",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.cePlanSubsidy}>
            <span>{rowData.cePlanSubsidy}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Total Payment",
      field: "totalPayment",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.totalPayment}>
            <span>{rowData.totalPayment}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Insured Patient Cost",
      field: "insuredPatientCost",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.insuredPatientCost}>
            <span>{rowData.insuredPatientCost}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Uninsured Patient Cost",
      field: "unInsuredPatientCost",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.unInsuredPatientCost}>
            <span>{rowData.unInsuredPatientCost}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Gross Dispensing Fee",
      field: "grossDispensingFee",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.grossDispensingFee}>
            <span>{rowData.grossDispensingFee}</span>
          </Tooltip>
        );
      },
    },

    {
      title: "Program Admin Fee",
      field: "programAdminFee",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.programAdminFee}>
            <span>{rowData.programAdminFee}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "340B Ingredient Cost",
      field: "tfBIngredientCost",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.tfBIngredientCost}>
            <span>{rowData.tfBIngredientCost}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Total Claim Cost",
      field: "totalClaimCost",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.totalClaimCost}>
            <span>{rowData.totalClaimCost}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Total Covered Entity Receivable",
      field: "totalCEReceivable",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.totalCEReceivable}>
            <span>{rowData.totalCEReceivable}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Claim Profit/Loss",
      field: "claimProfitorLoss",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.claimProfitorLoss}>
            <span>{rowData.claimProfitorLoss}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Invoice Date",
      field: "startDate",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.startDate}>
            <span>{rowData.startDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "PO Number",
      field: "poNumber",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.poNumber}>
            <span>{rowData.poNumber}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Date",
      field: "trueUpDate",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpDate}>
            <span>{rowData.trueUpDate}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Source Type",
      field: "invoiceSourcetypeId",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.invoiceSourcetypeId}>
            <span>{rowData.invoiceSourcetypeId}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Units",
      field: "trueUpUnits",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpUnits}>
            <span>{rowData.trueUpUnits}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Brand Or Generic",
      field: "brandGenericFlag",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.brandGenericFlag}>
            <span>{rowData.brandGenericFlag}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Unit Price",
      field: "unitprice",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.unitprice}>
            <span>{rowData.unitprice}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Adj%",
      field: "trueUpAdjpercent",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpAdjpercent}>
            <span>{rowData.trueUpAdjpercent}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Dispensing Fee",
      field: "trueUpDispensingFee",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpDispensingFee}>
            <span>{rowData.trueUpDispensingFee}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Amount",
      field: "trueUpAmount",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpAmount}>
            <span>{rowData.trueUpAmount}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Reason",
      field: "trueUpReason",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpReason}>
            <span>{rowData.trueUpReason}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Dispensing Store",
      field: "dispensingStore",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingStore}>
            <span>{rowData.dispensingStore}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Dispensing Store NPI",
      field: "dispensingStoreNPI",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.dispensingStoreNPI}>
            <span>{rowData.dispensingStoreNPI}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Carve In Claim ID",
      field: "carveInClaimId",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.carveInClaimId}>
            <span>{rowData.carveInClaimId}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "CEReimbursementModel",
      field: "ceReimbursementModel",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.ceReimbursementModel}>
            <span>{rowData.ceReimbursementModel}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "EAC",
      field: "eac",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.eac}>
            <span>{rowData.eac}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Model",
      field: "trueUpModel",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpModel}>
            <span>{rowData.trueUpModel}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "Metric Quantity",
      field: "metricQuantity",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.metricQuantity}>
            <span>{rowData.metricQuantity}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "EAC Type",
      field: "eacType",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.eacType}>
            <span>{rowData.eacType}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up EAC",
      field: "trueUpEAC",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpEAC}>
            <span>{rowData.trueUpEAC}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "TMCO True-Up Cost",
      field: "mcotrueUpCost",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.mcotrueUpCost}>
            <span>{rowData.mcotrueUpCost}</span>
          </Tooltip>
        );
      },
    },
    {
      title: "True-Up Units Metric Qty",
      field: "trueUpUnitsMetricQty",
      cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
      render: (rowData) => {
        return (
          <Tooltip title={rowData.trueUpUnitsMetricQty}>
            <span>{rowData.trueUpUnitsMetricQty}</span>
          </Tooltip>
        );
      },
    },
  ];

  const dispatch = useDispatch();
  const classes = useStyles();
  const onChangeRowsperpage = (pagesize) => {
    const { totalElements = 0 } = tableinnergridData;
    const totalPages = Math.ceil(totalElements / pagesize);
    if (page > totalPages) setPage(pagination.page);
    setRowsPerPage(pagesize);
  };

  const onChangePagination = (data, pagesize) => {
    let currentpage = data + 1;
    if (pagesize === rowsPerPage) setPage(currentpage);
  };

  const onChangeSorting = async (orderedColumnId) => {
    setOrder(sortorder === "asc" ? "desc" : "asc");
    setsortBy(TrueUp_Columns[orderedColumnId].field);
  };

  useEffect(() => {
    dispatch(
      TrueUPreports({
        ceid: 20,
        pageNumber: page,
        pageSize: rowsPerPage,
        sortBy: sortBy,
        sortOrder: sortorder,
        export: false,
        phid: phID,
        phGroupId: phGroupId,
        billingPeriod: billingperiod,
      })
    );
  }, [rowsPerPage, page, sortBy, sortorder]);

  const loader = useSelector((state) => state.getTrueUpreports.loading);
  const getTrueUpreports =
    useSelector((state) => state.getTrueUpreports.records) || [];

  const Actions = [];

  const ColumnFilterIcon = () => {
    return <TiFilter fontSize="small" />;
  };

  let getinventorySubInnerGrid =
    useSelector((state) => state.getinventorySubInnerGrid.records) || [];
  let Inventoryinnergridexportdata = useSelector(
    (state) => state.Inventoryinnergridexportdata.records
  );
  return (
    <div className="">
      <div className="innergrid">
        <MaterialTable
          title={<HeaderTitle variant="h6" title="" />}
          Inventoryinnergridexportdata={getTrueUpreports.content}
          columns={TrueUp_Columns}
          data={getTrueUpreports.content}
          page={page - 1}
          totalCount={totalCount}
          // actions={Actions}
          onOrderChange={onChangeSorting}
          onChangePage={onChangePagination}
          onChangeRowsPerPage={onChangeRowsperpage}
          setPage={setPage}
          rowsPerPage={rowsPerPage}
          icons={{
            SortArrow: () => TableCustomSortArrow({ sortOrder: sortorder }),
            Filter: ColumnFilterIcon,
          }}
          components={{
            Container: (props) => <Paper {...props} elevation={0} />,
            Toolbar: (props) => (
              <div
                style={{
                  marginRight: "259px",
                  marginTop: "",
                  marginBottom: "18px",
                }}
              >
                <MTableToolbar {...props} />
              </div>
            ),
          }}
          localization={{
            header: {
              actions: "Actions",
            },
          }}
          options={{
            search: false,
            searchFieldAlignment: "right",
            searchAutoFocus: true,
            searchFieldVariant: "standard",
            actionsColumnIndex: 0,
            // filtering: filter,
            paginationType: "stepped",
            paging: "true",
            showFirstLastPageButtons: false,
            paginationPosition: "top",
            exportButton: false,
            exportAllData: false,
            exportFileName: "Inventory List",
            headerStyle: {
              background: "#EFF4FA",
              color: "#8F9BB3",
              fontSize: "11px",
              whiteSpace: "nowrap",
            },
            tableLayout: "auto",
            columnResizable: true,
            emptyRowsWhenPaging: false,
            pageSize: rowsPerPage,
            draggable: false,
            pageSizeOptions: [25, 50, 75, 100],
          }}
        />
        {loader && <LoaderUI />}
      </div>
    </div>
  );
};

export default TrueUp;
