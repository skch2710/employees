import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "antd/dist/antd.css";
import "./App.css";
import "./main-style.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
import { useSelector } from "react-redux";
import { BrowserRouter, Redirect, Route, Switch } from "react-router-dom";
import Login from "./containers/auth/login";
import Createpassword from "./containers/auth/CreatePassword";
import Loginverification from "./containers/auth/login-verification";
import Forgotpassword from "./containers/auth/Forgotpassword";
import FeatureForgotPassword from "./containers/auth/FeatureForgotPassword";
import ResetPassword from "./containers/auth/ResetPassword";
import MainPage from "./router/index";
import Notfound from "./components/common/Notfound";
import LoaderUI from "./components/common/Loader/Loader";
import PrivateRoute from "./router/PrivateRoute";
import { useGlobalStyles } from "./Styles/useGlobalStyles";

const App = () => {
  const { loading } = useSelector((state) => state.globalLoader);
  const classes = useGlobalStyles();

  return (
    <div className={classes.root}>
      {loading && <LoaderUI />}
      <BrowserRouter>
        <Switch>
          <Route exact path="/login" component={Login} />
          <Route exact path="/createpassword" component={Createpassword} />
          <Route
            exact
            path="/login-verification"
            component={Loginverification}
          />
          <Route exact path="/forgot-password" component={Forgotpassword} />
          <Route
            exact
            path="/forgotPasswordLink"
            component={FeatureForgotPassword}
          />
          <Route
            exact
            path="/resetpasswordLink"
            component={FeatureForgotPassword}
          />
          <Route
            exact
            path="/resetpasswordquestions"
            component={ResetPassword}
          />
          <Route
            exact
            path="/accountLockLink"
            component={FeatureForgotPassword}
          />
          <Route exact path="/404" component={Notfound} />
          <Redirect exact from="/" to="/login" />
          <PrivateRoute component={MainPage} />
        </Switch>
      </BrowserRouter>
      <ToastContainer autoClose={5000} pauseOnFocusLoss={false} />
    </div>
  );
};

export default App;
