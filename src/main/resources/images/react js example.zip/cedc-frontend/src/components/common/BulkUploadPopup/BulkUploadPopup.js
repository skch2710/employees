import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Typography,
  IconButton,
  TextField,
  Grid,
  Button
} from "@material-ui/core";
import { IoIosCloseCircleOutline } from "react-icons/io";
import DownloadTemplate from "../DownloadTemplate";

const BulkUpload = (props) => {
  const {
    excelColumns,
    filename,
    title,
    children,
    openPopup,
    maxWidth,
    setOpenPopup,
    typeWidhth = false,
  } = props;

  return (
    <Dialog open={openPopup} maxWidth={maxWidth} style={{ height: "600px" }}>
      <DialogTitle>
        <Typography variant="body2" component="div" style={{ flexGrow: 1 }}>
          {title}
        </Typography>
      </DialogTitle>

      <DialogContent dividers style={typeWidhth || {}}>
        {children}
      </DialogContent>
      <div style={{ padding: "20px" }}>
        <div style={{ display: "flex", marginBottom: "14px" }}>
          <Typography>Don't have the template?</Typography>
          <div
            style={{
              border: "2px solid #1890ff",
              borderRadius: "4px",
              marginLeft: "4px",
            }}
          >
            <DownloadTemplate columns={excelColumns} filename={filename} />
          </div>
        </div>
        <TextField
          // variant="outlined"
          multiline
          minRows={6}
          placeholder="Drag and drop a file here"
          fullWidth
          style={{
            borderBottom: "none",
            marginBottom: "16px",
            border: "2px dotted #dedee2",
          }}
        />
        <Typography style={{ display: "flex", justifyContent: "center", marginBottom: '10px' }}>
          (OR)
        </Typography>
        <Grid container xs={12} justifyContent="center">
          <Button
            type="submit"
            color="primary"
            size="small"
            variant="contained"
            className="btn btn-primary text-capitalize"
          >
            Choose File
          </Button>
          <Button
            type="reset"
            size="small"
            variant="outlined"
            color="default"
            className="btn btn-secondary m-l-20 text-capitalize"
            onClick={()=>setOpenPopup(false)}
          >
            Close
          </Button>
        </Grid>
      </div>
    </Dialog>
  );
};
export default BulkUpload;
