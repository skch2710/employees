import React, { forwardRef } from "react";
import { Button, useTheme } from "@material-ui/core";
import classNames from "classnames";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import BackupOutlinedIcon from "@material-ui/icons/BackupOutlined";
import SendOutlinedIcon from "@material-ui/icons/SendOutlined";
import CheckCircleOutlineIcon from "@material-ui/icons/CheckCircleOutline";
import {
  MdOutlineFilterList,
  MdOutlineHistory,
  MdOutlineMedicalServices,
} from "react-icons/md";
import { TiExportOutline } from "react-icons/ti";
import { FaPrescription, FaSort, FaRegHandshake } from "react-icons/fa";
import { BiBlock, BiEditAlt, BiLocationPlus, BiUpload } from "react-icons/bi";
import {
  RiDeleteBin5Line,
  RiFileExcel2Fill,
  RiFileCopyLine,
} from "react-icons/ri";
import { AiOutlineEye, AiOutlinePlus } from "react-icons/ai";
import { BsCheckCircle } from "react-icons/bs";
import { useIconAndButtonsStyle } from "./styles";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { BsXCircle } from "react-icons/bs";
import ArrowExport from "../../../assets/Icons/export_with_arrow.png";
import ExportToExcelIcon from "../../../assets/Icons/excel-export.png";
import ExportToPdfIcon from "../../../assets/Icons/pdf-export.png";

const useTableIconsAndButtons = () => {
  const globalClasses = useGlobalStyles();
  const classes = useIconAndButtonsStyle();
  const theme = useTheme();

  const ExportButton = (customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        startIcon={
          <RiFileExcel2Fill
            color={customProps.disabled ? "" : theme.colors.green.dark}
          />
        }
        variant="outlined"
        size="small"
        component="button"
        {...props}
        ref={ref}
        classes={{
          root: classNames(classes.btn, globalClasses.exportButton),
        }}
        {...customProps}
      >
        Export
      </Button>
    ));
  };

  const ExportToExcel = (customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        variant="outlined"
        size="small"
        component="button"
        {...props}
        ref={ref}
        classes={{
          root: classNames(classes.btn, globalClasses.exportSmallButtons),
        }}
        {...customProps}
      >
        <img
          src={ExportToExcelIcon}
          alt="export-to-excel"
          height={22}
          width={22}
        />
      </Button>
    ));
  };

  const ExportToPdf = (customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        variant="outlined"
        size="small"
        component="button"
        {...props}
        ref={ref}
        classes={{
          root: classNames(classes.btn, globalClasses.exportSmallButtons),
        }}
        {...customProps}
      >
        <img src={ExportToPdfIcon} alt="export-to-pdf" height={22} width={22} />
      </Button>
    ));
  };

  const ExportWithArrow = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <span ref={ref} {...props}>
        <img src={ArrowExport} alt="export" height={20} width={20} />
      </span>
    ));
  };

  const AddCeButton = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        startIcon={<AddCircleOutlineIcon />}
        variant="outlined"
        size="small"
        component="button"
        className="button2 text-capitalize"
        {...props}
        ref={ref}
      >
        Add Covered Entity
      </Button>
    ));
  };

  const AddUserButton = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        startIcon={<AddCircleOutlineIcon />}
        variant="outlined"
        size="small"
        component="button"
        className="button2 text-capitalize"
        {...props}
        ref={ref}
      >
        Add User
      </Button>
    ));
  };

  const UploadLocationButton = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        startIcon={<BackupOutlinedIcon />}
        variant="outlined"
        size="small"
        component="button"
        className="button2 text-capitalize"
        {...props}
        ref={ref}
      >
        Upload Locations
      </Button>
    ));
  };

  const Delete = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
    ));
  };

  const Clear = (customProps = {}) => {
    const { ...others } = customProps;
    return forwardRef((props, ref) => (
      <BsXCircle
        fontSize="small"
        color="red"
        {...props}
        {...others}
        ref={ref}
      />
    ));
  };

  const Copy = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <RiFileCopyLine fontSize="small" color="action" {...props} ref={ref} />
    ));
  };

  const ExportRowLevel = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <TiExportOutline fontSize="small" color="disabled" {...props} ref={ref} />
    ));
  };

  const Edit = (customProps = {}) => {
    const { ...others } = customProps;
    return forwardRef((props, ref) => (
      <BiEditAlt
        fontSize="small"
        color="action"
        {...props}
        {...others}
        ref={ref}
      />
    ));
  };

  const Sort = (_customProps = {}) => {
    return forwardRef((props, ref) => <FaSort {...props} ref={ref} />);
  };

  const Filter = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <MdOutlineFilterList {...props} ref={ref} className={classes.btn} />
    ));
  };

  const AddPharmacy = (customProps = {}) => {
    const { pharmacyPermissionObj, statusId } = customProps;
    return forwardRef((props, ref) => (
      <MdOutlineMedicalServices
        fontSize="small"
        {...props}
        ref={ref}
      />
    ));
  };

  const Send = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <SendOutlinedIcon fontSize="small" {...props} ref={ref} />
    ));
  };

  const Plus = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <AiOutlinePlus fontSize="small" color="action" {...props} ref={ref} />
    ));
  };

  const History = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <MdOutlineHistory
        fontSize="small"
        color="disabled"
        {...props}
        ref={ref}
      />
    ));
  };

  const Claim = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <FaPrescription fontSize="small" color="disabled" {...props} ref={ref} />
    ));
  };

  const AddCustomButton = (customProps = {}) => {
    const { title, ...others } = customProps;
    return forwardRef((props, ref) => (
      <Button
        startIcon={<AddCircleOutlineIcon />}
        variant="outlined"
        size="small"
        component="button"
        className={globalClasses.grayButton}
        {...props}
        {...others}
        ref={ref}
      >
        {title}
      </Button>
    ));
  };

  const OutLinedButton = (customProps = {}) => {
    const { title, ...others } = customProps;
    return forwardRef((props, ref) => (
      <Button
        startIcon={<AddCircleOutlineIcon />}
        variant="outlined"
        size="small"
        component="button"
        className={globalClasses.outlinedBtn}
        {...props}
        {...others}
        ref={ref}
      >
        {title}
      </Button>
    ));
  };

  const BulkUploadButton = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <Button
        startIcon={<BiUpload />}
        variant="outlined"
        size="small"
        component="button"
        className={globalClasses.grayButton}
        {...props}
        ref={ref}
      >
        Bulk Upload
      </Button>
    ));
  };

  const View = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <AiOutlineEye fontSize="small" color="action" {...props} ref={ref} />
    ));
  };

  const Block = (customProps = {}) => {
    const { isBlocked } = customProps;
    return forwardRef((props, ref) => (
      <BiBlock
        fontSize="small"
        color={isBlocked ? theme.colors.red[900] : ""}
        {...props}
        ref={ref}
      />
    ));
  };

  const Active = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <BsCheckCircle
        fontSize="small"
        color={theme.colors.green.active}
        {...props}
        ref={ref}
      />
    ));
  };

  const InActive = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <BsCheckCircle
        fontSize="small"
        color={theme.colors.grey.inactive}
        {...props}
        ref={ref}
      />
    ));
  };

  const HandShakeIcon = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <FaRegHandshake fontSize="small" color="action" {...props} ref={ref} />
    ));
  };

  const Check = (customProps = {}) => {
    const { isBlocked, ...others } = customProps;
    return forwardRef((props, ref) => (
      <CheckCircleOutlineIcon
        fontSize="small"
        color={isBlocked ? theme.colors.grey[900] : theme.colors.green.default}
        {...props}
        {...others}
        ref={ref}
      />
    ));
  };

  const Location = (_customProps = {}) => {
    return forwardRef((props, ref) => (
      <BiLocationPlus fontSize="small" color="action" {...props} ref={ref} />
    ));
  };

  return {
    ExportButton,
    ExportWithArrow,
    ExportToExcel,
    ExportToPdf,
    AddCeButton,
    AddUserButton,
    UploadLocationButton,
    Delete,
    Edit,
    Sort,
    Filter,
    AddPharmacy,
    AddCustomButton,
    OutLinedButton,
    Send,
    Plus,
    History,
    Claim,
    BulkUploadButton,
    View,
    Block,
    ExportRowLevel,
    Active,
    InActive,
    HandShakeIcon,
    Check,
    Copy,
    Clear,
    Location,
  };
};

export default useTableIconsAndButtons;
