import { makeStyles } from "@material-ui/core/styles";

export const useAutocompleteStyles = makeStyles((theme) => {
  return {
    autocompleteRoot: ({ rootStyles }) => ({
      background: theme.colors.monochrome.offWhite,
      border: `1px solid ${theme.colors.secondary.default}`,
      borderRadius: "4px",
      boxShadow: "1px 1px 3px rgb(41 84 106 / 7%)",
      "& .MuiInput-root": {
        padding: "1px 0 1px 7px",
      },
      "& .MuiInput-underline": {
        "&:before": {
          display: "none",
        },
        "&:after": {
          display: "none",
        },
      },
      "& .MuiAutocomplete-inputRoot": {
        "& :first-child": {
          marginLeft: 0,
        },
        "&.Mui-disabled": {
          background: theme.colors.grey.inputDisableBg,
          cursor: "not-allowed",
        },
      },
      ...rootStyles,
    }),
    multiselectTag: ({ tagStyles }) => ({
      margin: "0 4px",
      ...tagStyles,
    }),
    autocompleteInput: ({ inputStyles }) => ({
      padding: "0 !important",
      height: "26px",
      ...inputStyles,
    }),
    customTextField: () => ({
      "& input": {
        color: theme.colors.monochrome.input,
        fontSize: "13px",
      },
      "& input::placeholder": {
        fontSize: "small",
        color: theme.colors.monochrome.input,
        opacity: 1,
      },
    }),
    endAdornment: {
      top: "50%",
      transform: "translateY(-50%)",
      right: "6px",
    },
    popupIndicator: {
      width: "20px",
      height: "20px",
      color: theme.colors.monochrome.inputIconsColor,
    },
    clearIndicator: {
      width: "20px",
      height: "20px",
      color: theme.colors.monochrome.inputIconsColor,
    },
    option: {
      gap: "5px",
    },
  };
});
