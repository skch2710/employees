import { makeStyles } from "@material-ui/core";

export const useIconAndButtonsStyle = makeStyles((_theme) => ({
  btn: {
    minHeight: "30px",
  },
  excelIcon: {
    width: "18px",
    height: "18px",
  },
}));
