import React from "react";
import { Tooltip } from "@material-ui/core";
import BasicTypography from "./Typography/BasicTypography";

export const CustomTextRenderer = ({ value, variant = "subtitle2", maxLength } = {}) => {
  const labelValue = value.slice(0, maxLength) + "..."
  if (value && value.length <= maxLength) {
    return <BasicTypography title={value} variant={variant} />
  }
  else
    return (
      <BasicTypography variant={variant}>
        <Tooltip title={value} placement="bottom">
          <span>{labelValue}</span>
        </Tooltip>
      </BasicTypography>
    );
};
