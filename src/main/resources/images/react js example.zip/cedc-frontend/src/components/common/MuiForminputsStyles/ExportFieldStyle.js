import { makeStyles } from '@material-ui/core/styles';

export const exportFieldStyle=makeStyles(()=>({
    exportField:{
        width:"100px",
        height:"27px",
        marginRight:"12px",
        border: "2px solid #EFF4FA !important",
        color: "#4D4F5C !important",
        fontSize:"small",
       
        
    },
   

  }));