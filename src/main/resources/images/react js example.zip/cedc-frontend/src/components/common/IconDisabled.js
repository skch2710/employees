import React  from "react";
import {
  IconButton,
  Tooltip,
} from "@material-ui/core";
import { BsPencilSquare } from "react-icons/bs";

const IconDisabled = () =>{
return <IconButton size="small" style={{ marginRight: "15px" }} disabled={true}><Tooltip title="You don't have permission." ><BsPencilSquare  disabled={true}/></Tooltip></IconButton> 

}

export default IconDisabled;