import { makeStyles } from "@material-ui/core";

export const useDataNotFoundStyle = makeStyles((theme) => {
  return {
    bodyContainer: {
      display: "flex",
      justifyContent: "center",
      padding: "10px 0",
      gap: "10px",
      opacity: 0.5,
      color: theme.colors.monochrome.tableCellColor,
      alignItems: "center",
      "& p": {
        margin: 0,
      },
    },
  };
});
