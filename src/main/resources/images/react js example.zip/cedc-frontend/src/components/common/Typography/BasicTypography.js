import React from "react";
import { Typography } from "@material-ui/core";

const BasicTypography = ({ children, title, ...rest }) => {
  return <Typography {...rest}>{title || children}</Typography>;
};

export default BasicTypography;
