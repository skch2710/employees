import { makeStyles } from "@material-ui/core/styles";

export const usePaginationStyles = makeStyles((theme) => {
  return {
    paginationWrapper: {
      display: "flex",
      gap: "3px",
      justifyContent: "flex-end",
      padding: "10px 5px",
    },
    paginationItem: {
      height: "26px",
      minWidth: "26px",
    },
    pageOutlined: {
      border: `1px solid ${theme.colors.monochrome.border}`,
    },
    rowsPerPageSelect: {
      height: "26px",
      padding: "2px",
      border: `1px solid ${theme.colors.monochrome.border}`,
      borderRadius: "4px",
      backgroundColor: theme.colors.monochrome.offWhite,
    },
  };
});
