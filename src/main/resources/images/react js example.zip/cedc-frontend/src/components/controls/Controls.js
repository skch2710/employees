import Input from "../common/FormsInputs/Input";
import Select from "../common/FormsInputs/SelectField";
import RadioGroup from "../common/FormsInputs/RadioGroup";
import Checkbox from "../common/FormsInputs/Checkbox";
import ActionButton from "../common/FormsInputs/ActionButton";
import Button from "../common/FormsInputs/Button";

const Controls = {
    Select,
    RadioGroup,
    Input,
    Checkbox,
    ActionButton,
    Button,
    
}

export default Controls;