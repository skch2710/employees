import React from 'react'
import { FormControl, InputLabel, Select as MuiSelect, MenuItem, FormHelperText } from '@material-ui/core';
import {useFormInputstyle} from "../MuiForminputsStyles/ForminputStyle";

  
  

export default function Select(props) {
  const classes = useFormInputstyle();
    
  const Placeholder = ({ children }) => {
    return <div className={classes.placeholder}>{children}</div>;
  };
  

    const { name, label, value,error=null, onChange, options,placeholder,displayEmpty } = props;

    return (
      <div className={classes.root}> 
        <FormControl variant="outlined"  size="small"
        {...(error && {error:true})}>
            <InputLabel>{label}</InputLabel>
            <MuiSelect
                label={label}
                name={name}
                displayEmpty={displayEmpty}
                value={value}
                onChange={onChange}
                renderValue={
                    value !== "" ? undefined : () => <Placeholder>{placeholder}</Placeholder>
                  }
            >
                <MenuItem value="">None</MenuItem>
                {
                    options.map(
                        item => (<MenuItem key={item.id} value={item.title}>{item.title}</MenuItem>)
                    )
                }
            </MuiSelect>
            {error && <FormHelperText>{error}</FormHelperText>}
        </FormControl>
        </div>
    )
}
