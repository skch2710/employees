import React from "react";
import { Switch } from "@material-ui/core";
import { useToggleStyles } from "./style";

const Toggle = (props = {}) => {
  const { rootStyles, classes, ...rest } = props || {};
  const toggleClasses = useToggleStyles({ rootStyles });

  return (
    <Switch
      classes={{
        root: toggleClasses.root,
        switchBase: toggleClasses.switchBase,
        thumb: toggleClasses.thumb,
        track: toggleClasses.track,
        checked: toggleClasses.checked,
        disabled: toggleClasses.disabledToggle,
        ...classes,
      }}
      {...rest}
    />
  );
};

export default Toggle;
