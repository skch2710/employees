import React from "react";
import { Typography } from "@material-ui/core";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";

const HeaderTitle = ({ variant, title }) => {
  const globalClasses = useGlobalStyles();
  return (
    <Typography variant={variant} className={globalClasses.cardTitle}>
      <strong>{title}</strong>
    </Typography>
  );
};

export default HeaderTitle;
