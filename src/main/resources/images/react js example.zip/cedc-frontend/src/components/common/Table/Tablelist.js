import React, { useEffect } from 'react';
import MaterialTable,{MTablePagination,MTableToolbar} from "material-table";
//react-icons
import { FaSort } from 'react-icons/fa';
import { TiFilter } from "react-icons/ti";
import { USER_MANAGEMENT, LOCATIONS, PROVIDER_COLUMNS, PATIENTS} from './TableHeadCells';
import HeaderTitle from '../Typography/HeaderTitle';
import { Paper} from "@material-ui/core";
import { useStyles } from "./usetableStyle";
import LoaderUI from '../Loader/Loader';

  const CustomUnsortedIcon = () => { 
    return <FaSort  fontSize='small' />
  }
  const ColumnFilterIcon =() =>{
    return <TiFilter  fontSize='small' />
  }
const Tablelist = ({
  loader,
    actions,
    list,
    page,
    count,
    type,
    onChangePagination,
    onChangeRowsperpage,
    onChangeSorting,
    onChangeFilter,
    filter
}) => {
  
     const classes=useStyles();
    let records = [];
    let headCells = [];
    if (type === "User List") {
        headCells = USER_MANAGEMENT;
        records = list
        count = count
        actions = actions
    }
    if (type === "Location List") {
        headCells = LOCATIONS;
        records = list;
        count = count
        actions = actions
    }
    if (type === "Patients List"){
        headCells = PATIENTS;
        records = list;
        count = count
        actions = actions
    }
    if (type === "Providers List")
    {
        headCells = PROVIDER_COLUMNS;
        records = list;
        count = count
        actions = actions
    }
    return (
        <div className={classes.root}>
        <MaterialTable 
          title={ <HeaderTitle variant="h6" title={type}/>}
          columns={headCells}
          data={loader ? <LoaderUI/> : records}
          page={page-1}
          totalCount={count}
          onChangePage={onChangePagination}
          onChangeRowsPerPage={onChangeRowsperpage}
          onOrderChange={onChangeSorting}
          onFilterChange={onChangeFilter}
          actions={actions}
          icons={{ 
            SortArrow: CustomUnsortedIcon , 
            Filter: ColumnFilterIcon
          }}
          components={{
            Container: props => <Paper {...props} elevation={0}/>,
            pagination:props => (
              <MTablePagination {...props}/>
            ),
            Toolbar: props => (
              <div style={{marginRight: "259px",
              marginTop: "-48px", marginBottom:"18px" }}>
                  <MTableToolbar {...props} />
              </div>
          )
          }}
          options={{
            search: false, searchFieldAlignment: "right", searchAutoFocus: true, searchFieldVariant: "standard",actionsColumnIndex: 0,filtering:filter,paginationType:"stepped",paging:"true",
             showFirstLastPageButtons: false, paginationPosition: "top",exportButton: true,
            exportAllData: false, exportFileName:type, headerStyle: { background: "#EFF4FA",color:"#8F9BB3",fontSize:"11px",whiteSpace:"nowrap"},  tableLayout: "auto",
            columnResizable: true,emptyRowsWhenPaging: false,
            }}
           />
        </div>
    )
}

export default Tablelist;