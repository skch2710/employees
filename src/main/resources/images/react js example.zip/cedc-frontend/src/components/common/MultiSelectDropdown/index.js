import React, { useState } from "react";
import { Autocomplete } from "@material-ui/lab";
import { Chip, TextField, Tooltip } from "@material-ui/core";
import { useAutocompleteStyles } from "./style";
import DropdownArrow from "../../../assets/Icons/DropdownArrow.png";
import { createFilterOptions } from "@material-ui/lab/Autocomplete";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import { Checkbox } from "@material-ui/core";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import BasicTypography from "../Typography/BasicTypography";
import { useEffect } from "react";

const MultiSelectDropdown = (props) => {
  const {
    options,
    onChange,
    getOptionLabel,
    rootStyles,
    tagStyles,
    inputStyles,
    inputPlaceholder,
    textFieldProps = {},
    tooltipProps = {},
    value = [],
    inputValue,
    onInputChange,
    allOptionLabel = "All",
    disabled = false,
    ...rest
  } = props || {};
  const allSelected = options.length === value.length;
  const globalClasses = useGlobalStyles();
  const [inputVal, setInputVal] = useState("");

  const classes = useAutocompleteStyles({ rootStyles, tagStyles, inputStyles });

  const handleToggleOption = (e, selectedOptions) =>
    onChange(e, selectedOptions);

  const handleClearOptions = (e) => onChange(e, []);
  const handleSelectAll = (e, isSelected) => {
    if (isSelected) {
      onChange(e, options);
    } else {
      handleClearOptions(e);
    }
  };
  useEffect(() => {
    if (inputValue != undefined && inputVal != inputValue)
      setInputVal(inputValue);
  }, [inputValue]);

  const handleToggleSelectAll = (e) => {
    handleSelectAll && handleSelectAll(e, !allSelected);
  };

  const handleChange = (event, selectedOptions, reason) => {
    if (reason === "select-option" || reason === "remove-option") {
      if (selectedOptions.find((option) => option.id === -1)) {
        handleToggleSelectAll(event);
      } else if (
        event.key === "Backspace" &&
        options.length === value.length &&
        !selectedOptions.find((option) => option.id === -1)
      ) {
        onChange(event, []);
      } else {
        handleToggleOption && handleToggleOption(event, selectedOptions);
      }
    } else if (reason === "clear") {
      handleClearOptions && handleClearOptions(event);
    }
  };

  const optionRenderer = (option, { selected }) => {
    const selectAllProps =
      option.id === -1 // To control the state of 'select-all' checkbox
        ? { checked: allSelected }
        : {};

    return (
      <>
        <Checkbox
          icon={<CheckBoxOutlineBlankIcon fontSize="small" />}
          checkedIcon={
            <CheckBoxIcon
              classes={{
                root: globalClasses.selectedCheckBox,
              }}
              fontSize="small"
            />
          }
          checked={selected}
          {...selectAllProps}
        />
        <BasicTypography variant="subtitle2">
          {option.id === -1 ? allOptionLabel || "All" : getOptionLabel(option)}
        </BasicTypography>
      </>
    );
  };
  const filter = createFilterOptions();
  return (
    <Autocomplete
      classes={{
        root: classes.autocompleteRoot,
        tag: classes.multiselectTag,
        input: classes.autocompleteInput,
        endAdornment: classes.endAdornment,
        popupIndicator: classes.popupIndicator,
        option: classes.option,
        clearIndicator: classes.clearIndicator,
      }}
      options={options}
      getOptionLabel={getOptionLabel}
      onChange={handleChange}
      size="small"
      multiple
      limitTags={1}
      disableCloseOnSelect
      value={value}
      popupIcon={
        <img src={DropdownArrow} width={16} height={16} alt="Dropdown_Icon" />
      }
      filterOptions={(options, params) => {
        const filtered = filter(options, params);
        return filtered.length > 1 && !inputVal
          ? [{ label: allOptionLabel || "All", id: -1 }, ...filtered]
          : [...filtered];
      }}
      renderInput={(params) => (
        <Tooltip title={tooltipProps.title || ""}>
          <TextField
            placeholder={inputPlaceholder}
            classes={{ root: classes.customTextField }}
            {...params}
            {...textFieldProps}
            inputProps={{ ...params.inputProps, ...textFieldProps.inputProps }}
          />
        </Tooltip>
      )}
      renderOption={optionRenderer}
      renderTags={(tagValue, getTagProps) => {
        return options.length > 1 && value.length === options.length ? (
          <Chip
            size="small"
            label={allOptionLabel || "All"}
            disabled={disabled}
            onDelete={(e) => {
              onChange(e, []);
            }}
          />
        ) : (
          tagValue.map((option, index) => (
            <Chip
              size="small"
              label={getOptionLabel(option)}
              {...getTagProps({ index })}
            />
          ))
        );
      }}
      inputValue={inputVal || ""}
      onInputChange={(_e, value) => {
        if (onInputChange) onInputChange(_e, value);
        else{
          setInputVal(value);
        }
      }}
      disabled={disabled}
      {...rest}
    />
  );
};
export default MultiSelectDropdown;
