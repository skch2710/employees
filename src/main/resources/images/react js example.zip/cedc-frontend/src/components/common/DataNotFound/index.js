import React from "react";
import { useDataNotFoundStyle } from "./style";

function DataNotFound() {
  const classes = useDataNotFoundStyle();

  return (
    <div className={classes.bodyContainer}>
      <p>No Results Found </p>
    </div>
  );
}

export default DataNotFound;
