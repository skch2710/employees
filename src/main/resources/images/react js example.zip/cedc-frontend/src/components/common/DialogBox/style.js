import { makeStyles } from "@material-ui/core/styles";

export const useDialogStyles = makeStyles((_theme) => {
  return {
    dialogPaper: ({dialogStyle}) => dialogStyle
  };
});
