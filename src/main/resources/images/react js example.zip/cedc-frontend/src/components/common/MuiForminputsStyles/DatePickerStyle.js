import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        "& .MuiButton-label" :{
            textTransform: 'none'
        },
        '& .MuiTableCell-root': {
              padding:"8px"
        },
    },
 
    formControl:{
        color: "#434653 ",
        width: "98% !important",
        padding: "0 0 0 7px !important",
        border: "1px solid #ebebeb  !important",
        borderRadius: "4px !important",
        boxShadow: "1px 1px 3px rgb(41 84 106 / 7%) !important",
        height: "35px !important",
        fontSize: "small !important",
    
        outline: "none !important"
     },
    title:{
        color:"#43425D"
    },
    subtitle:{
        color:"#071B72F8"
    },
    btnStyle:{
        marginTop:"10px",
        marginLeft:"-8px"

    },
    
  }));