import React from "react";
import ReactExport from "react-data-export";
import { Grid } from "@material-ui/core";
import excel from "../../../assets/excel.png";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;

function getDefaultData(length) {
  const placeholder = new Array(length);
  const filled = placeholder.fill({});

  return [filled];
}

const DownloadTemplate = ({ columns, filename }) => (
  <Grid className="Download_template">
    <ExcelFile
      filename={filename}
      element={
        <div style={{ cursor: "pointer" }}>
          <img src={excel} alt="Active" className="Download_template_icon" />{" "}
          Download Template
        </div>
      }
    >
      <ExcelSheet
        dataSet={[{ columns, data: getDefaultData(columns.length) }]}
        name={filename}
      />
    </ExcelFile>
  </Grid>
);

export default DownloadTemplate;
