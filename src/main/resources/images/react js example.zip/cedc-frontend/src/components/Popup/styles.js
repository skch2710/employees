import { makeStyles } from "@material-ui/core";

export const usePopupStyles = makeStyles((_theme) => {
  return {
    dialogRoot: {
      zIndex: "999 !important",
    },
    formContainer: {
      height: "100%",
      display: "flex",
      flexDirection: "column",
      overflowY: "auto",
    },
    headerContainer: {
      display: "flex",
      justifyContent: "space-between",
      gap: "5px",
      alignItems: "center",
    },
    titleContainer: {
      minWidth: "95%",
    },
    closeIconContainer: {
      maxWidth: "5%",
      display: "flex",
      justifyContent: "flex-end",
      alignItems: "center",
    },
  };
});
