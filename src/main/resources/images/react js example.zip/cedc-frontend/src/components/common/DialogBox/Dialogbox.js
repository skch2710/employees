import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Typography,
  IconButton,
} from "@material-ui/core";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { pagination } from "../../../utils/constants";
import { useDialogStyles } from "./style";

export default function Dialogbox(props) {
  const {
    title,
    children,
    openPopup,
    maxWidth,
    setOpenPopup,
    setPage,
    setRowsPerPage,
    setSortOrder,
    setSortBy,
    po = false,
    typeWidhth = false,
    setprimarystate,
    ciId = { ciId },
    dialogStyle,
  } = props;
  const classes = useDialogStyles({dialogStyle});

  const onClickHandle = () => {
    if (po) {
      setPage(pagination.page);
      setRowsPerPage(pagination.limit);
      setSortOrder("asc");
      setSortBy("");
      setOpenPopup(false);
    } else {
      setOpenPopup(false);
      setprimarystate && setprimarystate(true);
    }
  };

  return (
    <Dialog
      open={openPopup}
      maxWidth={maxWidth}
      style={{ height: "600px" }}
      classes={{ paper: classes.dialogPaper }}
    >
      <DialogTitle>
        <div style={{ display: "flex" }}>
          <Typography variant="body2" component="div" style={{ flexGrow: 1 }}>
            {title}
          </Typography>
          <IconButton onClick={onClickHandle} size="small">
            <IoIosCloseCircleOutline />
          </IconButton>
        </div>
      </DialogTitle>

      <DialogContent dividers style={typeWidhth || {}}>
        {children}
      </DialogContent>
    </Dialog>
  );
}
