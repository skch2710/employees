import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
} from "@material-ui/core";
import classNames from "classnames";
import { Form, Formik } from "formik";
import React, { forwardRef } from "react";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { useGlobalStyles } from "../../Styles/useGlobalStyles";
import BasicTypography from "../common/Typography/BasicTypography";
import { usePopupStyles } from "./styles";

const BasicPopup = forwardRef((props = {}, ref = {}) => {
  const { formRef } = ref || {};
  const {
    children,
    show,
    handleClose,
    title,
    submitProps,
    cancelProps,
    disableCloseButton,
    disableFooter,
    disableHeader,
    dialogProps,
    isCustomFooter,
    footerActionElement,
    dialogActionProps,
    withFormik,
    formikProps,
    dialogContentProps,
    dialogTitleProps,
  } = props;
  const { classes: dialogClasses = {}, ...rest } = dialogProps || {};
  const { buttonTitle: submitBtnTitle, handleSubmit } = submitProps || {};
  const { buttonTitle: cancelBtnTitle, handleCancel } = cancelProps || {};
  const classes = usePopupStyles();
  const globalClasses = useGlobalStyles();

  const getPopupBody = () => {
    return (
      <>
        {!disableHeader && (
          <DialogTitle {...dialogTitleProps}>
            <div className={classes.headerContainer}>
              <div className={classes.titleContainer}>
                <BasicTypography
                  className={globalClasses.textEllipsis}
                  variant="h4"
                  component="div"
                >
                  {title}
                </BasicTypography>
              </div>
              {disableCloseButton ? null : (
                <div className={classes.closeIconContainer}>
                  <IconButton onClick={handleClose} size="small">
                    <IoIosCloseCircleOutline />
                  </IconButton>
                </div>
              )}
            </div>
          </DialogTitle>
        )}

        <DialogContent dividers {...dialogContentProps}>
          {children}
        </DialogContent>

        {!disableFooter && (
          <DialogActions
            style={{ padding: "16px 24px", display: "flex", gap: "10px" }}
            {...dialogActionProps}
          >
            {submitBtnTitle && (
              <Button
                type="submit"
                color="primary"
                size="small"
                variant="contained"
                onClick={handleSubmit}
                className={globalClasses.primaryBtn}
              >
                {submitBtnTitle}
              </Button>
            )}
            {cancelBtnTitle && (
              <Button
                type="submit"
                color="primary"
                size="small"
                variant="contained"
                onClick={handleCancel}
                className={globalClasses.secondaryBtn}
              >
                {cancelBtnTitle}
              </Button>
            )}
          </DialogActions>
        )}
        {isCustomFooter && disableFooter ? (
          <DialogActions
            style={{ padding: "16px 24px" }}
            {...dialogActionProps}
          >
            {footerActionElement}
          </DialogActions>
        ) : null}
      </>
    );
  };

  return (
    <Dialog
      open={show}
      fullWidth
      // minWidth="sm"
      classes={{
        root: classNames(classes.dialogRoot, dialogClasses.root),
        ...dialogClasses,
      }}
      {...rest}
    >
      {withFormik ? (
        <Formik innerRef={formRef || null} {...formikProps}>
          <Form className={classes.formContainer}>{getPopupBody()}</Form>
        </Formik>
      ) : (
        getPopupBody()
      )}
    </Dialog>
  );
});

export default BasicPopup;
