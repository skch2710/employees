import React from "react";
const ComingSoon = () => {
  return (
    <>
       <p className="coming_soon_text">Coming Soon!!</p>
    </>
  );
};
export default ComingSoon;


