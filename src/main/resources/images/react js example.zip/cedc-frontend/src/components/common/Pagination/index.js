import React, { memo } from "react";
import MuiPagination from "@material-ui/lab/Pagination";
import { Box } from "@material-ui/core";
import { PaginationItem } from "@material-ui/lab";
import { usePaginationStyles } from "./styles";

const Pagination = memo((props = {}) => {
  const {
    rowsPerPageOptions,
    count,
    page,
    rowsPerPage,
    onChangePage,
    onChangeRowsPerPage,
  } = props;
  const classes = usePaginationStyles();
  const numericRowPerPage = Number(rowsPerPage);

  return (
    <Box className={classes.paginationWrapper}>
      <MuiPagination
        disabled={count <= 0}
        count={Math.ceil(count / numericRowPerPage) || 1}
        page={page + 1}
        variant="outlined"
        shape="rounded"
        onChange={(e, pageNumber) => {
          onChangePage(e, pageNumber - 1);
        }}
        renderItem={(item) => (
          <PaginationItem
            key={JSON.stringify(item)}
            classes={{
              root: classes.paginationItem,
              outlined: classes.pageOutlined,
            }}
            {...item}
          />
        )}
      />
      <select
        defaultValue={numericRowPerPage}
        className={classes.rowsPerPageSelect}
        onChange={(e) => {
          const propToPageSizeFunc = {
            target: {
              value: Number(e.target.value),
            },
          };
          onChangeRowsPerPage(propToPageSizeFunc);
        }}
        disabled={count <= 0}
        key={numericRowPerPage}
      >
        {rowsPerPageOptions.map((pageSize) => (
          <option key={pageSize} value={pageSize}>
            {pageSize}
          </option>
        ))}
      </select>
    </Box>
  );
});

export default Pagination;
