import { Tooltip } from "@material-ui/core";
import React, { useState } from "react";
import { BorderLinearProgress, useProgressStyles } from "./styles";

const HorizontalProgressBar = ({ value, showValueOnTooltip = false } = {}) => {
  const classes = useProgressStyles();

  const [position, setPosition] = useState({
    x: 0,
    y: 0,
  });

  const handleMouseMove = (e) => {
    setPosition({ x: e.clientX, y: e.clientY });
  };

  return (
    <div className={classes.root}>
      <Tooltip
        title={showValueOnTooltip ? `${value}%` : "Implementation Progress"}
        PopperProps={{
          anchorEl: {
            clientHeight: 0,
            clientWidth: 0,
            getBoundingClientRect: () => ({
              top: position.y,
              left: position.x,
              right: position.x,
              bottom: position.y + 4,
              width: 0,
              height: 0,
            }),
          },
        }}
      >
        <BorderLinearProgress
          onMouseMove={handleMouseMove}
          variant="determinate"
          value={value}
        />
      </Tooltip>
    </div>
  );
};

export default HorizontalProgressBar;
