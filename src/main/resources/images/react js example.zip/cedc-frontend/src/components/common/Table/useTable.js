import React, { useState } from 'react'
import { Table, TableHead, TableRow, TableCell,  TableSortLabel,Tooltip,IconButton } from '@material-ui/core';
import { useStyles } from './usetableStyle';
import Pagination from '@material-ui/lab/Pagination';
import ReactPaginate from "react-paginate";
import { FaSort } from 'react-icons/fa';
import { TiFilter } from "react-icons/ti";



export default function useTable(records, headCells,filterFn,tableId,setFilterOpen) {

    const classes = useStyles();

    const pageSizes = [5, 10, 15,20, 25]
    const [pageCount, setpageCount] = useState(5);
    const [page, setPage] = useState(0)
    const [rowsPerPage, setRowsPerPage] = useState(pageSizes[0])
    const [order, setOrder] = useState()
    const [orderBy, setOrderBy] = useState();

    const TblContainer = props => (
        <Table className={classes.table}  id={tableId}>
            {props.children}
        </Table>
    )

    const TblHead = props => {

        const handleSortRequest = cellId => {
            const isAsc = orderBy === cellId && order === "asc";
            setOrder(isAsc ? 'desc' : 'asc');
            setOrderBy(cellId)
        }
        const handleFilterClick =() =>{
        }

        return (
        <TableHead  scope="row">
            <TableRow>
                {
                    headCells.map(headCell => (
                        <TableCell key={headCell.id}
                            sortDirection={orderBy === headCell.id ? order : false}>
                          
                            {(headCell.disableSorting && headCell.disableFiltering ) ? headCell.label : 
                            <>
                            
                                <TableSortLabel
                                    IconComponent={() => <FaSort fontSize="small"/>}
                                    active={orderBy === headCell.id}
                                    direction={orderBy === headCell.id ? order : 'asc'}
                                    onClick={() => { handleSortRequest(headCell.id) }}>
                                    {headCell.label}
                                </TableSortLabel>
                          
                                <TiFilter fontSize="small" onClick={() => { setFilterOpen(true) }} style={{cursor:"pointer"}}/>
                            
                             
                            </>
                            
                               
                            }
                           
                        </TableCell>))
                }
            </TableRow>
        </TableHead>)
    }
    const handlePageClick = (event) => {
        setPage(event.selected);
        
      };

    const handleChangeRowsPerPage = event => {
        setRowsPerPage(parseInt(event.target.value, 10))
        setPage(0);
    }

    const SelectPageSize = () =>(
       
        <select onChange={handleChangeRowsPerPage} value={rowsPerPage} className={classes.rowperpageStyle}>
        {pageSizes.map((size) => (
          <option key={size} value={size}>
            {size}
          </option>
        ))}
      </select>
    )
    
   

 const TblPagination = () =>(
   

        <ReactPaginate
        previousLabel={"First"}
        nextLabel={"Last"}
        forcePage={page}
        //breakLabel={"..."}
        pageCount={pageCount}
        //marginPagesDisplayed={2}
        // pageRangeDisplayed={3}
        onPageChange={handlePageClick}
        containerClassName={"pagination justify-content-center"}
        pageClassName={"page-item"}
        pageLinkClassName={"page-link"}
        previousClassName={"page-item"}
        previousLinkClassName={"page-link"}
        nextClassName={"page-item"}
        nextLinkClassName={"page-link"}
        
        //pageRangeDisplayed={25}
        //breakClassName={"page-item"}
        //breakLinkClassName={"page-link"}
        activeClassName={"active"}
        //showPaginationTop
        //renderOnZeroPageCount={null}
        />

    )

    function stableSort(array, comparator) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = comparator(a[0], b[0]);
            if (order !== 0) return order;
            return a[1] - b[1];
        });
        return stabilizedThis.map((el) => el[0]);
    }

    function getComparator(order, orderBy) {
        return order === 'desc'
            ? (a, b) => descendingComparator(a, b, orderBy)
            : (a, b) => -descendingComparator(a, b, orderBy);
    }

    function descendingComparator(a, b, orderBy) {
        if (b[orderBy] < a[orderBy]) {
            return -1;
        }
        if (b[orderBy] > a[orderBy]) {
            return 1;
        }
        return 0;
    }
   

    const recordsAfterPagingAndSorting = () => {
        return stableSort(filterFn.fn(records), getComparator(order, orderBy))
            .slice(page * rowsPerPage, (page + 1) * rowsPerPage)
    }

    return {
        TblContainer,
        TblHead,
        TblPagination,
        recordsAfterPagingAndSorting,
        SelectPageSize
    }
}
