import { makeStyles } from "@material-ui/core/styles";

export const useDatePickerStyles = makeStyles((theme) => {
  return {
    root: {
      "&:hover": {
        borderColor: theme.colors.secondary.default,
      },
    },
  };
});
