import { makeStyles } from "@material-ui/core/styles";

export const useTypoStyles = makeStyles((_theme) => {
  return {
    text: (styles) => ({
      ...styles,
    }),
  };
});
