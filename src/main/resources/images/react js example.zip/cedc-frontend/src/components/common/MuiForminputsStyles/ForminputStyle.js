import { makeStyles } from "@material-ui/core/styles";

export const useFormInputstyle = makeStyles(theme => ({
    placeholder: {
      color: "#aaa",
      textAlign: "-webkit-left",
    },
    label: {
      color: "#aaa",
      fontSize:"small"
    },
    root: {
      '& .MuiFormControl-root': {
          width: '80%',
          margin: theme.spacing(0)
      }
  }
  }));
  export const useCheckboxStyle=makeStyles(theme =>({
    root:{
      '&.custom-checkbox-root':{
        width: "30px",
        height: "36px"
        },
      }

  }))

  export  const useRadiobuttonStyle=makeStyles(theme =>({
    root:{
      display: "-webkit-inline-box"
    },
    radioGroupStyle:{
      marginLeft: "11px",
      marginTop: "-9px"
    }
    
  }))
