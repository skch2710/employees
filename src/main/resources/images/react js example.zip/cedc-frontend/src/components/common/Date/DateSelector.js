import React from 'react';


// import TextField from '@mui/material/TextField';
// import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
// import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useStyles } from '../MuiForminputsStyles/DatePickerStyle';
// import { Field } from 'formik';



const DateSelector = ({ label, width, placeholder="" }) => {

    const classes = useStyles()


    // const [value, setValue] = useState(null);

    return (
        <input
            type="date"
            placeholder={placeholder}
            className={classes.formControl}
            onFocus={
                (e)=> {
                e.currentTarget.type = "date";
                e.currentTarget.focus();
                }
            }
            // placeholder={`${placeholder}`}
        />



    )
}

export default DateSelector


{/* <LocalizationProvider 
            dateAdapter={AdapterDateFns}>
            <DatePicker
                label={label}
                value={value}
                onChange={(newValue) => {
                    setValue(newValue);
                }}
                renderInput={(params) => <TextField placeholder={placeholder} {...params} style={{width:`${width}`}} className={classes.formControl}/>}
            />
        </LocalizationProvider> */}