import React from "react";
import { Autocomplete } from "@material-ui/lab";
import { TextField, Tooltip } from "@material-ui/core";
import { useAutocompleteStyles } from "./style";
import DropdownArrow from "../../../assets/Icons/DropdownArrow.png";

const AutoComplete = (props) => {
  const {
    rootStyles,
    tagStyles,
    inputStyles,
    inputPlaceholder,
    textFieldProps = {},
    tooltipProps = {},
    ...rest
  } = props || {};
  const classes = useAutocompleteStyles({ rootStyles, tagStyles, inputStyles });
  return (
    <Autocomplete
      classes={{
        root: classes.autocompleteRoot,
        tag: classes.multiselectTag,
        input: classes.autocompleteInput,
        endAdornment: classes.endAdornment,
        popupIndicator: classes.popupIndicator,
        option: classes.option,
        clearIndicator: classes.clearIndicator,
      }}
      size="small"
      multiple
      limitTags={1}
      disableCloseOnSelect
      popupIcon={
        <img src={DropdownArrow} width={16} height={16} alt="Dropdown_Icon" />
      }
      renderInput={(params) => (
        <Tooltip title={tooltipProps.title || ""}>
          <TextField
            placeholder={inputPlaceholder}
            classes={{ root: classes.customTextField }}
            {...params}
            {...textFieldProps}
            inputProps={{ ...params.inputProps, ...textFieldProps.inputProps }}
          />
        </Tooltip>
      )}
      {...rest}
    />
  );
};

export default AutoComplete;
