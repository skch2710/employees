import { CircularProgress } from "@material-ui/core";
import React from "react";
import { useTableProgressBarStyles } from "./styles";

const TableProgressBar = (props = {}) => {
  const { classes: muiClasses, ...rest } = props;
  const classes = useTableProgressBarStyles();
  return (
    <div className={classes.tableSpinner}>
      <CircularProgress
        size={30}
        classes={{ colorPrimary: classes.spinnerColor, ...muiClasses }}
        {...rest}
      />
    </div>
  );
};

export default TableProgressBar;
