import React from "react";
import { makeStyles } from "@material-ui/core";
import { useTheme } from "@emotion/react";
import { FaSort } from "react-icons/fa";
import { TiFilter } from "react-icons/ti";
// const theme = useTheme()

export const useStyles = makeStyles((theme) => ({
  root: {
    "& .MuiTableCell-root": {
      padding: "12px",
    },
    "& .MuiIconButton-root": {
      padding: "5px",
    },
    "& .MuiToolbar-regular": {
      // marginRight:"200px"
      minHeight: "0px",
    },
    "& .MuiTableCell-footer": {
      border: "none",

      overflow: "hidden",
    },
    "& .MuiTablePagination-root": {
      overflowX: "hidden",
    },
  },
  adminType: {
    fontWeight: "bold",
    fontSize: "0.75rem",
    borderRadius: 8,
    padding: "4px 10px",
    display: "inline-block",
    marginTop: "2px",
    color: "#FFFFFF",
    width: "120px",
    textAlign: "center",
  },
}));

export const CustomUnsortedIcon = () => {
  return <FaSort fontSize="small" />;
};

export const ColumnFilterIcon = () => {
  return <TiFilter fontSize="small" />;
};

export const icons = {
  SortArrow: CustomUnsortedIcon,
  Filter: ColumnFilterIcon,
};

// Material Table cell Styles
export const tableCellGlobalJson = {
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  overflow: "hidden",
  maxWidth: 100,
  fontSize: "11px",
  textAlign: "left",
};

// Material Table Json Style
export const mtStyle = {
  marginRight: "259px",
  marginTop: "-48px",
  marginBottom: "18px",
};

export const headerStyle = {
  // background: useTheme().colors.monochrome.tableHeaderBackground,
  // color: useTheme().colors.monochrome.tableHeaderText,
  background: "#EFF4FA",
  color: "#8F9BB3",
  fontSize: "11px",
  whiteSpace: "nowrap",
  textAlign: "left",
};
