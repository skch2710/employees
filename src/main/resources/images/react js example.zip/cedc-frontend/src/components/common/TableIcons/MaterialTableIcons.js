import React, { forwardRef } from "react";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import Button from "@material-ui/core/Button";
import SendOutlinedIcon from "@material-ui/icons/SendOutlined";
import { RiDeleteBin5Line } from "react-icons/ri";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import BackupOutlinedIcon from "@material-ui/icons/BackupOutlined";
import { FaSort } from "react-icons/fa";
import { AiOutlinePlus } from "react-icons/ai";
import { MdOutlineFilterList } from "react-icons/md";
import { MdOutlineHistory } from "react-icons/md";
import { FaPrescription } from "react-icons/fa";

const tableIcons = {
  Send: forwardRef((props, ref) => (
    <SendOutlinedIcon fontSize="small" {...props} ref={ref} />
  )),
  AddButton: forwardRef((props, ref) => (
    <Button
      variant="contained"
      style={{ backgroundColor: "#4D4F5C", color: "#FFFFFF" }}
      size="small"
      component="button"
      {...props}
      ref={ref}
    >
      New User
    </Button>
  )),
  Delete: forwardRef((props, ref) => (
    <DeleteOutline fontSize="small" {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => (
    <Edit fontSize="small" {...props} ref={ref} />
  )),
  ExportButton: forwardRef((props, ref) => (
    <Button
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Export
    </Button>
  )),
  UploadButton: forwardRef((props, ref) => (
    <Button
      startIcon={<BackupOutlinedIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2"
      {...props}
      ref={ref}
    >
      Upload Patient
    </Button>
  )),
  DeleteWithLine: forwardRef((props, ref) => (
    <RiDeleteBin5Line fontSize="small" color="action" {...props} ref={ref} />
  )),
  Sort: forwardRef((props, ref) => <FaSort {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => (
    <MdOutlineFilterList {...props} ref={ref} />
  )),
  Plus: forwardRef((props, ref) => (
    <AiOutlinePlus fontSize="small" color="action" {...props} ref={ref} />
  )),
  History: forwardRef((props, ref) => (
    <MdOutlineHistory fontSize="small" color="disabled" {...props} ref={ref} />
  )),
  Claim: forwardRef((props, ref) => (
    <FaPrescription fontSize="small" color="disabled" {...props} ref={ref} />
  )),
  AddPharmacyButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2 text-capitalize"
      {...props}
      ref={ref}
    >
      Add Pharmacy Store
    </Button>
  )),
  AddUserButton: forwardRef((props, ref) => (
    <Button
      startIcon={<AddCircleOutlineIcon />}
      variant="outlined"
      size="small"
      component="button"
      className="button2 text-capitalize"
      {...props}
      ref={ref}
    >
      Add User
    </Button>
  )),
};

export default tableIcons;
