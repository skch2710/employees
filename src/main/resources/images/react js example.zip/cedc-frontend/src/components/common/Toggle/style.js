import { makeStyles } from "@material-ui/core/styles";

export const useToggleStyles = makeStyles((theme) => {
  return {
    root: ({ rootStyles }) => ({
      width: "41px",
      height: "18px",
      padding: "0px",
      margin: "0px 12px 0px 0px",
      ...rootStyles,
    }),
    switchBase: {
      top: "-8px",
      left: "-8px",
      color: theme.colors.grey[100],
      padding: "1px",
      "&$checked": {
        "& + $track": {
          backgroundColor: `${theme.colors.green.default} !important`,
        },
      },
    },
    thumb: {
      color: "white",
      width: "17px",
      height: "16px",
      margin: "0px",
    },
    track: {
      borderRadius: "20px",
      backgroundColor: `${theme.colors.red.default} !important`,
      opacity: "1 !important",
      "&:after, &:before": {
        color: "white",
        fontSize: "9px",
        position: "absolute",
        top: "2px",
      },
      "&:after": {
        content: "'ON'",
        left: "4px",
      },
      "&:before": {
        content: "'OFF'",
        right: "3px",
      },
    },
    checked: {
      color: theme.colors.green.default,
      transform: "translateX(21px) !important",
    },
    disabledToggle: {
      top: "-8px !important",
      left: "-8px !important",
    },
  };
});
