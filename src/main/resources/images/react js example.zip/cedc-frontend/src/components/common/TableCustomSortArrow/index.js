import React from "react";
import { AiOutlineDown, AiOutlineUp } from "react-icons/ai";

const TableCustomSortArrow = (controllers = {}) => {
  return controllers.sortOrder === "desc" ? (
    <AiOutlineDown fontSize="small" />
  ) : (
    <AiOutlineUp fontSize="small" />
  );
};

export default TableCustomSortArrow;
