import React from 'react'
import { FormControl, FormLabel, RadioGroup as MuiRadioGroup, FormControlLabel, Radio,Typography } from '@material-ui/core';
import {useRadiobuttonStyle} from "../MuiForminputsStyles/ForminputStyle";

export default function RadioGroup(props) {
    const classes = useRadiobuttonStyle();

    const { name, label, value, onChange, items } = props;

    return (
        <FormControl className={classes.root}>
            <FormLabel className={classes.label}>{label} </FormLabel>
            <MuiRadioGroup row
                name={name}
                value={value}
                onChange={onChange}
               className={classes.radioGroupStyle}
                >
                {
                    items.map(
                        item => (
                            <FormControlLabel key={item.id} value={item.id} control={<Radio size="small" color="primary"/>} label={<Typography variant="caption">{item.title}</Typography>}/>
                        )
                    )
                }
            </MuiRadioGroup>
           
        </FormControl>
    )
}
