import React from "react";
import { DatePicker as AntDDatePicker } from "antd";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";
import { useDatePickerStyles } from "./styles";
import classNames from "classnames";

const DatePicker = (props = {}) => {
  const globalClasses = useGlobalStyles();
  const classes = useDatePickerStyles();

  return (
    <AntDDatePicker
      className={classNames(globalClasses.formControl, classes.root)}
      placeholder="MM/DD/YYYY"
      format="MM/DD/YYYY"
      {...props}
    />
  );
};

export default DatePicker;
