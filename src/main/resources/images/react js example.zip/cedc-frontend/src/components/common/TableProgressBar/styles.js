import { makeStyles } from "@material-ui/core";

export const useTableProgressBarStyles = makeStyles((theme) => ({
  tableSpinner: {
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: theme.colors.grey.tableOverlayBackground,
  },
  spinnerColor: {
    color: theme.colors.blue[400],
  },
}));
