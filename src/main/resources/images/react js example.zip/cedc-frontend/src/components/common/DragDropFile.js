import React, { useMemo } from "react";
import { useDropzone } from "react-dropzone";
import DragDropUpload from "../../assets/dragdropupload.png";
import { CircularBar } from "../../components/common/ProgressBar/CircularBar";
import Excel from "../../assets/excel.png";
import { ALLOWED_FILE_TYPES } from "../../containers/UserManagement/constant";

const baseStyle = {
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  padding: "20px",
  borderWidth: 2,
  borderRadius: 2,
  borderColor: "#eeeeee",
  borderStyle: "dashed",
  backgroundColor: "#fafafa",
  color: "#bdbdbd",
  transition: "border .3s ease-in-out",
  cursor: "pointer",
};

const activeStyle = {
  borderColor: "#2196f3",
};

const acceptStyle = {
  borderColor: "#00e676",
};

const rejectStyle = {
  borderColor: "#ff1744",
};

function DragDropFile({
  progressBarOpen,
  uploadPercentage,
  fileData,
  uploadFile,
}) {
  const onDrop = (acceptedFiles) => {
    acceptedFiles.length && uploadFile(acceptedFiles);
  };

  const {
    getRootProps,
    getInputProps,
    isDragActive,
    isDragAccept,
    isDragReject,
  } = useDropzone({
    onDrop,
    accept: {
      "application/vnd.ms-excel": [".xls", ".xlsx"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        ".xls",
        ".xlsx",
      ],
    },
  });

  const style = useMemo(
    () => ({
      ...baseStyle,
      ...(isDragActive ? activeStyle : {}),
      ...(isDragAccept ? acceptStyle : {}),
      ...(isDragReject ? rejectStyle : {}),
    }),
    [isDragActive, isDragReject, isDragAccept]
  );

  const isFilesSelected = fileData && fileData.length;

  return (
    <>
      {progressBarOpen ? (
        <div
          style={{
            border: "2px dashed #eeeeee",
            borderRadius: 2,
            display: "flex",
            justifyContent: "center",
            padding: "20px",
          }}
        >
          <CircularBar
            value={uploadPercentage}
            active
            label={`${uploadPercentage}%`}
            style={{ color: "#008000" }}
          />
        </div>
      ) : isFilesSelected ? (
        <div style={style}>
          <img
            src={Excel}
            style={{ width: "35px", height: "35px", marginRight: "6px" }}
          />
          <div>
            {fileData.length > 1
              ? `${fileData.length} files selected`
              : fileData[0].name}
          </div>
        </div>
      ) : (
        <div {...getRootProps({ style })}>
          <input {...getInputProps()} />
          fileData
          <>
            <img src={DragDropUpload} />
            <div>Drag and drop a file here.</div>
          </>
        </div>
      )}
    </>
  );
}

export default DragDropFile;
