import React from "react";
import { useGlobalStyles } from "../../../Styles/useGlobalStyles";

const ColumnLevelFilterInput = (props = {}) => {
  const { columnDef = {}, onFilterChanged, value } = props;
  const globalClasses = useGlobalStyles();

  return (
    <input
      {...props}
      className={globalClasses.formControl}
      type={columnDef.type === "numeric" ? "number" : "text"}
      onChange={(e) => {
        onFilterChanged(columnDef.tableData.id, e.target.value);
      }}
      defaultValue={value || ""}
    />
  );
};

export default ColumnLevelFilterInput;
