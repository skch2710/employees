import React from "react";

export const a11yProps = (index) => {
  return {
    id: `tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  };
};

export const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabPanel"
      hidden={value !== index}
      id={`tabPanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && <>{children}</>}
    </div>
  );
};
