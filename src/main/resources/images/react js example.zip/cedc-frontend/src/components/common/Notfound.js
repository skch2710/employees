import React from "react";
import { Paper, Typography, Grid, Link } from "@material-ui/core";
import { Link as RouteLink } from "react-router-dom";
import Embarrassed from "../../assets/embarrassed.png";
import { useStyles } from "../../mui-styles/createpasswordStyle";
import { useDispatch } from "react-redux";
import { regenarateLink } from "../../context/actions/Auth";

const Notfound = ({ value, linkType, cp, uuid = "", nameOfUser, usedLink }) => {
  const classes = useStyles();
  const dispatch = useDispatch();

  return (
    <>
      <Paper
        elevation={0}
        className={classes.paper}
        style={{ textAlign: "center", marginTop: "95px" }}
      >
        {!usedLink && (
          <>
            <Typography component="span" className="form-text m-b-30">
              Welcome :
            </Typography>
            <strong>{nameOfUser}</strong>
          </>
        )}
        <Grid style={{ marginTop: "20px" }}>
          <img src={Embarrassed} width={86} height={84} />
          <Typography variant="h6" className={classes.subtitle2}>
            <strong> {value}</strong>
          </Typography>
          <Grid>
            <p style={{ marginTop: "12px" }}>{linkType}</p>
            {cp ? (
              <p style={{ marginTop: "-9px" }}>
                Please click{" "}
                <Link
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    if (uuid) dispatch(regenarateLink(uuid));
                  }}
                >
                  here
                </Link>{" "}
                to regenerate the email
              </p>
            ) : (
              <p style={{ marginTop: "-9px" }}>
                <RouteLink to={{ pathname: "/login" }}>Back</RouteLink> to login
                page
              </p>
            )}
          </Grid>
        </Grid>
      </Paper>
    </>
  );
};

export default Notfound;
