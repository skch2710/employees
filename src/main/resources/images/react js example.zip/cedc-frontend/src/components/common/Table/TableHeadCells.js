//  User Management -> User list Headers

import React from "react";
import { Switch } from "@material-ui/core";
import { Tooltip } from "@material-ui/core";
import { Field } from "formik";
import { checkValue } from "../../../utils/common";
import { tableCellGlobalJson } from "../../../components/common/Table/usetableStyle";
import { LABELS } from "../../../utils/constants";

export const USER_MANAGEMENT = [
  {
    title: "First Name",
    field: "firstName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.firstName}>
          <span>{rowData.firstName}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Last Name",
    field: "lastName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.lastName}>
          <span>{rowData.lastName}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Email Id",
    field: "emailID",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.emailID}>
          <span>{rowData.emailID}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Role Type",
    field: "userType",
    cellStyle: { fontSize: "11px" },
    render: (row) => (
      <div
        style={{
          fontWeight: "bold",
          fontSize: "0.75rem",
          borderRadius: 8,
          padding: "4px 10px",
          display: "inline-block",
          marginTop: "2px",
          color: "#FFFFFF",
          width: "120px",
          textAlign: "center",
          ...rolesStyle(row),
        }}
      >
        {row.userType}
      </div>
    ),
  },
  {
    title: "Customized",
    field: "customized",
  },
  {
    title: "Entity Name",
    field: "entityName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.entityName}>
          <span>{rowData.entityName}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Created Date",
    field: "createdDate",
    cellStyle: { fontSize: "11px" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.createdDate}>
          <span>{rowData.createdDate}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Last Login Date",
    field: "lastLogInDate",
    width: "null",
    cellStyle: { fontSize: "11px", width: "12%" },
  },
];

const rolesStyle = (item) => {
  const ColorRoleWise = {
    1: "#FF2D55",
    2: "#FF2D55",
    5: "#FF2D55",
    3: "#0095FF",
    6: "#0095FF",
    7: "#0000002F",
    4: "#eff4fa",
  };
  return {
    background: ColorRoleWise[Number(item.roleID)],
    ...(item.roleID === 4 ? { color: "#A7B1C5" } : {}),
  };
};

//User Management -> User Module Permission Header

export const modulePermissionHeader = [
  { id: "permission", label: "Module", tooltipContent: "" },
  {
    id: "read",
    label: "Read",
    tooltipContent:
      "The user can only read and download the data from the module",
  },
  {
    id: "write",
    label: "Add/Edit",
    tooltipContent:
      "The user can add a new record or can update an existing record in the module",
  },
  {
    id: "terminate",
    label: "Inactivate",
    tooltipContent: "The user can make an active record inactive in the module",
  },
];

//  Locations -> Locations list Headers

export const LOCATIONS = [
  {
    title: "Verified",
    field: "verified",
  },
  {
    title: "Source",
    field: "source",
  },
  {
    title: "Participating 340B Site",
    field: "site340b",
  },
  {
    title: "Covered Entity",
    field: "coveredEntity",
  },

  {
    title: "Location Name",
    field: "locationName",
  },

  {
    title: "Location HRSA ID",
    field: "locationHrsaId",
  },
  {
    title: "Address Line 1",
    field: "addressLine1",
  },

  {
    title: "Address Line 2",
    field: "addressLine2",
  },

  {
    title: "City",
    field: "city",
  },

  {
    title: "State",
    field: "state",
  },

  {
    title: "Zip",
    field: "zip",
  },

  {
    title: "Start Date",
    field: "startDate",
  },

  {
    title: "End Date",
    field: "endDate",
  },

  {
    title: "Last Modified Date",
    field: "lastModifiedDate",
  },
  {
    title: "Status",
    field: "locationStatus",
  },
];

// Covered Entity Patient

export const COVERED_ENTITY_PATIENTS = [
  {
    title: "Covered Entity",
    field: "ceName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "340B ID",
    field: "three40bID",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "MRN",
    field: "mrn",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "First Name",
    field: "firstName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Middle Name",
    field: "middleName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Last Name",
    field: "lastName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Suffix",
    field: "suffix",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "DOB",
    field: "dob",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Gender",
    field: "gender",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Admin/Visit Date",
    field: "admitType",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Hospital Service",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Admin Type",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Servicing Facility",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Assigned Patient Location",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Exclude ?",
    field: "exclude",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Sliding Scale Indicator",
    field: "slidingScaleInd",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Sliding Scale Effective Date",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  //
  {
    title: "Provider last Name",
    field: "exclude",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Provider first Name",
    field: "slidingScaleInd",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Provider DEA",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Provider NPI",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Provider SPI",
    field: "slidingScaleEffDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "First Date Seen",
    field: "startDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Last Date Seen",
    field: "startDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "End Date",
    field: "endDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Last Modified Date",
    field: "lastModifiedDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
];
//  Patients -> Patients list Headers

export const PATIENTS = [
  {
    title: "Status",
    field: "status",
    cellStyle: tableCellGlobalJson,
  },
  {
    title: "MRN",
    field: "mrn",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "First Name",
    field: "firstName",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Middle Name",
    field: "middleName",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Last Name",
    field: "lastName",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Suffix",
    field: "suffix",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "DOB",
    field: "dob",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Gender",
    field: "gender",
    cellStyle: tableCellGlobalJson,
  },
  {
    title: "Exclude ?",
    field: "patientType",
    //lookup: { Included: "No", Excluded: "Yes" },
    cellStyle: tableCellGlobalJson,
  },
  {
    title: "Sliding Scale Category",
    field: "slidingScaleIndicator",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Sliding Scale Effective Date",
    field: "slidingScaleEffectiveDate",
    cellStyle: tableCellGlobalJson,
  },
  {
    title: "First Visit Date",
    field: "startDate",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Recent Visit Date",
    field: "recentVisitDate",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Eligibility End Date",
    field: "endDate",
    width: "null",
    cellStyle: tableCellGlobalJson,
  },

  {
    title: "Last Modified Date",
    field: "lastModifiedDate",
    width: "null",
    cellStyle: tableCellGlobalJson,
  },
];

// CE Table list
export const CELIST = [
  {
    title: LABELS.CoveredEntity,
    field: "ceName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Go-Live Date",
    field: "goliveDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Start Date",
    field: "startDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "End Date ",
    field: "endDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Primary Contact Name",
    field: "primaryContactName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Primary Phone",
    field: "primaryPhone",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Active Providers",
    field: "activeProviders",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Active Pharmacies",
    field: "activePharmacies",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Admin Fee Brand $+%",
    field: "adminFeeBrand",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Admin Fee Generic $+%",
    field: "adminFeeGeneric",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Speciality Admin Fee $+%",
    field: "specilityAdminFee",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Flat Monthly Fee(minimum)",
    field: "flatMonthlyFee",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Config Status",
    field: "configStatus",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
];

//Patients inner Table Headers

export const PATIENTS_INNERTABLE = [
  {
    title: "Covered Entity",
    field: "ceName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "340B ID",
    field: "three40bID",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Admit/Visit Date",
    field: "visitDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Discharge Date",
    field: "dischargeDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Hospital Service",
    field: "hosptalService",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Admit Type",
    field: "admitType",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Servicing Facility",
    field: "servicingFacility",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Assigned Patient Location",
    field: "assignedPatientLocation",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Provider NPI",
    field: "npi",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Provider Fn",
    field: "firstName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Provider Ln",
    field: "lastName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "First Date Seen",
    field: "visitStartDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Last Date Seen",
    field: "visitEndDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
];

export const COVERED_ENTITY_PROVIDERS = [
  {
    title: "Covered Entity",
    field: "coveredEntity",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "340B ID",
    field: "id340B",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "First Name",
    field: "firstName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "last Name",
    field: "lastName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "Provider NPI",
    field: "providerNPI",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "Provider DEA",
    field: "providerDEA",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "Prescriber SPI",
    field: "prescriberSPI",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "Exclusive",
    field: "exclusive",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      if (rowData.exclusive === "Exclusive") {
        return "YES";
      } else {
        return "NO";
      }
    },
  },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
];
//  Providers -> Providers list Headers

export const PHARMACY_NETWORK_BIN_BLOCKS = [
  {
    title: LABELS.PharmacyChain,
    field: "phGroupName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.phGroupName}>
          <span>{rowData.phGroupName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Admin Co",
    field: "adminCo",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.adminCo}>
          <span>{rowData.adminCo}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "BIN",
    field: "bin",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.bin}>
          <span>{rowData.bin}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "PCN",
    field: "pcn",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pcn}>
          <span>{rowData.pcn}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Group No.",
    field: "groupNumber",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.groupNumber}>
          <span>{rowData.groupNumber}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "BIN Reason",
    field: "binReason",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.binReason}>
          <span>{rowData.binReason}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.startDate}>
          <span>{rowData.startDate}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.endDate}>
          <span>{rowData.endDate}</span>
        </Tooltip>
      );
    },
  },
];

export const COVERED_CONFIG_BIN_BLOCKS = [
  {
    title: LABELS.PharmacyChain,
    field: "phGroupName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.phGroupName}>
          <span>{rowData.phGroupName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Covered Entity",
    field: "ceName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.ceName}>
          <span>{rowData.ceName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Admin Co",
    field: "adminCo",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.adminCo}>
          <span>{rowData.adminCo}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "BIN",
    field: "bin",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.bin}>
          <span>{rowData.bin}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "PCN",
    field: "pcn",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pcn}>
          <span>{rowData.pcn}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Group No.",
    field: "groupNumber",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.groupNumber}>
          <span>{rowData.groupNumber}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "BIN Reason",
    field: "binReason",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.binReason}>
          <span>{rowData.binReason}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.startDate}>
          <span>{rowData.startDate}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.endDate}>
          <span>{rowData.endDate}</span>
        </Tooltip>
      );
    },
  },
];

export const CLIENT_BIN_BLOCKS = [
  {
    title: "BIN",
    field: "bin",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.bin}>
          <span>{rowData.bin}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "PCN",
    field: "pcn",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pcn}>
          <span>{rowData.pcn}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Group No.",
    field: "groupNumber",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.groupNumber}>
          <span>{rowData.groupNumber}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "BIN Reason",
    field: "binReason",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.binNumber}>
          <span>{rowData.binNumber}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Covered Entity",
    field: "ceName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.ceName}>
          <span>{rowData.ceName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Admin Co",
    field: "adminCo",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.adminCo}>
          <span>{rowData.adminCo}</span>
        </Tooltip>
      );
    },
  },
  {
    title: LABELS.PharmacyChain,
    field: "phGroupName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.phGroupName}>
          <span>{rowData.phGroupName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: LABELS.PharmacyStore,
    field: "pharmacy",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pharmacy}>
          <span>{rowData.pharmacy}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.startDate}>
          <span>{rowData.startDate}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.endDate}>
          <span>{rowData.endDate}</span>
        </Tooltip>
      );
    },
  },
];

export const GLOBAL_BIN_BLOCKS = [
  {
    title: "BIN Block Group",
    field: "Binblockgroup",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.Binblockgroup}>
          <span>{rowData.Binblockgroup}</span>
        </Tooltip>
      );
    },
    // editComponent: (rowData) => {
    //   return (
    //     <input className="formControl"></input>

    //   );
    // },
  },
  {
    title: "Bin Block Type",
    field: "Binblocktype",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.Binblocktype}>
          <span>{rowData.Binblocktype}</span>
        </Tooltip>
      );
    },
  },
  {
    title: LABELS.PharmacyChain,
    field: "Pharmacygroup",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.Pharmacygroup}>
          <span>{rowData.Pharmacygroup}</span>
        </Tooltip>
      );
    },
  },
  {
    title: LABELS.PharmacyStore,
    field: "Pharmacy",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.Pharmacy}>
          <span>{rowData.Pharmacy}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "BIN",
    field: "BIN",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.BIN}>
          <span>{rowData.BIN}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "PCN",
    field: "PCN",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.PCN}>
          <span>{rowData.PCN}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Group No",
    field: "Groupno",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.Groupno}>
          <span>{rowData.Groupno}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.startDate}>
          <span>{rowData.startDate}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.endDate}>
          <span>{rowData.endDate}</span>
        </Tooltip>
      );
    },
  },
];

export const PROVIDER_COLUMNS = [
  {
    title: "First Name",
    field: "firstName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "last Name",
    field: "lastName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "Provider NPI",
    field: "providerNpi",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  {
    title: "Provider DEA",
    field: "providerDea",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "Prescriber SPI",
    field: "prescriberSpi",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "Exclusive",
    field: "exclusive",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      if (rowData.exclusive === "Exclusive") {
        return "YES";
      } else {
        return "NO";
      }
    },
  },
  // {
  //   title: "Referral Provider",
  //   field: "refferalProvider",
  //   cellStyle: {
  //     textOverflow: "ellipsis",
  //     whiteSpace: "nowrap",
  //     overflow: "hidden",
  //     maxWidth: 100,
  //     fontSize: "11px",
  //   },
  // },
  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },
  {
    title: "Last Modified Date",
    field: "lastModifiedDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
  },

  // {title:"Created Date",field:"createdDate",cellStyle: {fontSize:"11px"}},

  // {title:"Last Login Date",field:"lastLoginDate",width:"null",cellStyle: {fontSize:"11px",width:"12%"}},
];
export const COVERED_ENTITY_PHARMACIES = [
  {
    title: LABELS.PharmacyStore,
    field: "pharmacyName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pharmacyName}>
          <span>{rowData.pharmacyName}</span>
        </Tooltip>
      );
    },
  },

  {
    title: LABELS.PharmacyChain,
    field: "pharmacyNetwork",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pharmacyNetwork}>
          <span>{rowData.pharmacyNetwork}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Go-Live Date",
    field: "goLiveDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.goLiveDate}>
          <span>{rowData.goLiveDate}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Start Date",
    field: "startDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.startDate}>
          <span>{rowData.startDate}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "End Date",
    field: "endDate",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.endDate}>
          <span>{rowData.endDate}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Brand Dispensing Fee $+%",
    field: "brandDispensingFee",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.brandDispensingFee}>
          <span>{rowData.brandDispensingFee}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Generic Dispensing Fee $+%",
    field: "genericDispensingFee",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.genericDispensingFee}>
          <span>{rowData.genericDispensingFee}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Specialty Dispense Fee $+%",
    field: "specialityDispensingFee",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.specialityDispensingFee}>
          <span>{rowData.specialityDispensingFee}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Program Type",
    field: "programType",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.programType}>
          <span>{rowData.programType}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Billing Model",
    field: "billingModel",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.billingModel}>
          <span>{rowData.billingModel}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Wholesaler",
    field: "wholesaler",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.wholesaler}>
          <span>{rowData.wholesaler}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Participating in Cash Program",
    field: "participatinginCashProgram",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.participatinginCashProgram}>
          <span>{rowData.participatinginCashProgram}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Config Status",
    field: "configStatus",
    width: "null",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.configStatus}>
          <span>{rowData.configStatus}</span>
        </Tooltip>
      );
    },
  },
];

export const PHARMACIES = [
  {
    title: LABELS.CoveredEntity,
    field: "coveredEntity",
  },

  {
    title: LABELS.PharmacyStore,
    field: "pharmacyName",
  },

  {
    title: LABELS.PharmacyChain,
    field: "pharmacyNetwork",
  },

  {
    title: "Go-Live Date",
    field: "goLiveDate",
  },

  {
    title: "Start Date",
    field: "startDate",
  },

  {
    title: "End Date",
    field: "endDate",
  },

  {
    title: "Brand Dispensing Fee Third Party $+%",
    field: "brandDispensingFeeThirdParty",
  },
  {
    title: "Brand Dispensing Fee Cash $+%",
    field: "brandDispensingFeeTCash",
  },

  {
    title: "Generic Dispensing Fee Third Party $+%",
    field: "genericDispensingFeeThirdParty",
  },
  {
    title: "Generic Dispensing Fee Cash $+%",
    field: "genericDispensingFeeCash",
  },

  {
    title: "Specialty Dispensing Fee Third Party $+%",
    field: "specialityDispensingFeeThirdParty",
  },

  {
    title: "Specialty Dispensing Fee Cash $+%",
    field: "specialityDispensingFeeCash",
  },

  {
    title: "Program Type",
    field: "programType",
  },

  {
    title: "Billing Model",
    field: "billingModel",
  },

  {
    title: "Wholesaler",
    field: "wholesaler",
  },

  {
    title: "Participating in Cash Program",
    field: "participatinginCashProgram",
  },

  {
    title: "Configuration Status",
    field: "configStatus",
  },
];

export const INVENTORY = [
  {
    title: "NDC",
    field: "ndc",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.ndc}>
          <span>{rowData.ndc}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Drug Name",
    field: "drugName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.drugName}>
          <span>{rowData.drugName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Wholesaler Name",
    field: "wholesalerName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.wholesalerName}>
          <span>{rowData.wholesalerName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Package Size",
    field: "packageSize",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.packageSize}>
          <span>{rowData.packageSize}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Opening Units",
    field: "openingUnits",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.openingUnits}>
          <span>{rowData.openingUnits}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Units Dispensed",
    field: "unitsDispensed",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.unitsDispensed}>
          <span>{rowData.unitsDispensed}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Units Replenished",
    field: "unitsReplenished",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.unitsReplenished}>
          <span>{rowData.unitsReplenished}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Returned Units",
    field: "returnedUnits",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.returnedUnits}>
          <span>{rowData.returnedUnits}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Px Owed Inventory",
    field: "pxOwedInventory",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.pxOwedInventory}>
          <span>{rowData.pxOwedInventory}</span>
        </Tooltip>
      );
    },
  },
  {
    title: LABELS.CoveredEntity +" Owned Inventory",
    field: "ceOwnedInventory",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.ceOwnedInventory}>
          <span>{rowData.ceOwnedInventory}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Inventory Cost - 340B",
    field: "three40BInventoryCost",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.three40BInventoryCost}>
          <span>{rowData.three40BInventoryCost}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Schedule Type",
    field: "scheduleType",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.scheduleType}>
          <span>{rowData.scheduleType}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Drug Manufacturer",
    field: "drugManufacturerName",
    cellStyle: {
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden",
      maxWidth: 100,
      fontSize: "11px",
    },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.drugManufacturerName}>
          <span>{rowData.drugManufacturerName}</span>
        </Tooltip>
      );
    },
  },
];

export const INVENTORY_INNERTABLE = [
  {
    title: "claim(RX)",
    field: "claimRx",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.claimRx}>
          <span>{rowData.claimRx}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Dispensed Date",
    field: "dispensedDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.dispensedDate}>
          <span>{rowData.dispensedDate}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Disp.Qty",
    field: "dispensedQty",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.dispensedQty}>
          <span>{rowData.dispensedQty}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Replenishment %",
    field: "replenishmentPercentage",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.replenishmentPercentage}>
          <span>{rowData.replenishmentPercentage}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Latest Status",
    field: "latestStatus",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.latestStatus}>
          <span>{rowData.latestStatus}</span>
        </Tooltip>
      );
    },
  },
];
export const INVENTORY_INNERSUB_TABLE = [
  {
    title: "Action Date",
    field: "actionDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.actionDate}>
          <span>{rowData.actionDate}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Action",
    field: "action",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.action}>
          <span>{rowData.action}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Captured Date",
    field: "captureDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.captureDate}>
          <span>{rowData.captureDate}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Ref.No.",
    field: "refNo",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.refNo}>
          <span>{rowData.refNo}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Dispensed Qty",
    field: "dispensedQty",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.dispensedQty}>
          <span>{rowData.dispensedQty}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Replenished Qty",
    field: "replenishedQty",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.replenishedQty}>
          <span>{rowData.replenishedQty}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Returned Qty",
    field: "returnedQty",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.returnedQty}>
          <span>{rowData.returnedQty}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "True Up Qty",
    field: "trueUpQty",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.trueUpQty}>
          <span>{rowData.trueUpQty}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Replenished %",
    field: "replenishedPerc",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.replenishedPerc}>
          <span>{rowData.replenishedPerc}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Total Price",
    field: "totalPrice",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.totalPrice}>
          <span>{rowData.totalPrice}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Wholesaler",
    field: "wholesaler",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.wholesaler}>
          <span>{rowData.wholesaler}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Status",
    field: "status",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.status}>
          <span>{rowData.status}</span>
        </Tooltip>
      );
    },
  },
];
//Purchase orders -> Purchase orders list Headers
export const PURCHASE_ORDER = [
  {
    title: "PO#",
    field: "poID",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "PO Date",
    field: "poDate",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Order Type",
    field: "orderType",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: LABELS.PharmacyStore,
    field: "pharmacy",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Wholesaler Account Number",
    field: "wholeSalerAccountDivisionCode",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "Wholesaler Name",
    field: "wholesaler",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "PO Status",
    field: "poStatus",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "PO Total Order Amount",
    field: "totalOrderAmount",
    type: "currency",
    currencySetting: {
      currencyCode: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    },
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "PO Total Billed Amount",
    field: "totalBilledAmount",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    type: "currency",
    currencySetting: {
      currencyCode: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    },
  },
];

//Purchase Inner Grid Header
export const PO_INNERTABLE = [
  {
    title: "NDC 11",
    field: "ndc",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Drug Name",
    field: "drugName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },

  {
    title: "Item Status",
    field: "itemStatus",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
  {
    title: "PO Value of the Item",
    field: "poItemValue",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
  },
];

export const CLAIMS_MANAGEMENT = [
  {
    title: "Rx Number",
    field: "rxNumber",
  },
  {
    title: "NDC",
    field: "ndc",
  },
  {
    title: "Drug Name",
    field: "drugName",
  },
  {
    title: LABELS.CoveredEntity+ "Savings",
    field: "ceSavings",
  },
  {
    title: "Patient Name",
    field: "patientName",
  },
  {
    title: "Provider",
    field: "provider",
  },
  {
    title: "Provider NPI",
    field: "providerNPI",
  },
  {
    title: LABELS.PharmacyStore,
    field: "pharmacy",
  },
  {
    title: "Pharmacy NPI",
    field: "pharmacyNPI",
  },
  {
    title: "DOS",
    field: "dos",
  },
  {
    title: "Claim Captured",
    field: "claimCaptured",
  },
  {
    title: "Status",
    field: "status",
  },
  {
    title: "Reason(s)",
    field: "reasons",
  },
  {
    title: "Score",
    field: "score",
  },
];

export const Provider_INNERTABLE = [
  {
    title: "Covered Entity",
    field: "ceName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.ceName}>
          <span>{rowData.ceName}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "340B ID",
    field: "three40BID",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.three40BID}>
          <span>{rowData.three40BID}</span>
        </Tooltip>
      );
    },
  },

  {
    title: "Location Name",
    field: "locationName",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.locationName}>
          <span>{rowData.locationName}</span>
        </Tooltip>
      );
    },
  },
  {
    title: "Location HRSA ID",
    field: "locationHRSAID",
    cellStyle: { fontSize: "11px", whiteSpace: "nowrap" },
    render: (rowData) => {
      return (
        <Tooltip title={rowData.locationHRSAID}>
          <span>{rowData.locationHRSAID}</span>
        </Tooltip>
      );
    },
  },
];

export const INVOICE = [
  {
    title: LABELS.CoveredEntity,
    field: "ceName",
  },

  {
    title: "Billing Period",
    field: "billingPeriod",
  },
  {
    title: "Total Invoiced",
    field: "savings",
  },

  {
    title: "Covered Entity Total Received Amount",
    field: "ceTotalReceivedAmount",
  },

  {
    title: "Pharmacy Invoice Period",
    field: "invoicePeriodStartDate",
  },

  {
    title: "Pharmacy Invoice Period",
    field: "invoicePeriodEndDate",
  },

  {
    title: "Adjustments",
    field: "adjustments",
  },

  {
    title: "True Up",
    field: "trueup",
  },

  {
    title: "Admin Fees",
    field: "adminFees",
  },

  {
    title: "Covered Entity Invoice",
    field: "ceInvoice",
  },

  {
    title: "ACH Status",
    field: "achStatus",
  },
];

export const VIEW_PHARMACIES = [
  {
    title: "Config Status",
    field: "configStatus",
  },

  {
    title: LABELS.PharmacyStore,
    field: "pharmacyName",
  },

  {
    title: LABELS.PharmacyChain,
    field: "pharmacyNetwork",
  },

  {
    title: "Go-Live Date",
    field: "goLiveDate",
  },

  {
    title: "Start Date",
    field: "startDate",
  },

  {
    title: "End Date",
    field: "endDate",
  },

  {
    title: "Brand Dispensing Fee $+%",
    field: "brandDispensingFeeThirdParty",
  },
  {
    title: "Brand Dispensing Fee Cash $+%",
    field: "brandDispensingFeeCash",
  },

  {
    title: "Generic Dispensing Fee",
    field: "genericDispensingFeeThirdParty",
  },
  {
    title: "Generic Dispensing Fee Cash $ +%",
    field: "genericDispensingFeeCash",
  },

  {
    title: "Speciality Dispense Fee $+%",
    field: "specialityDispensingFeeThirdParty",
  },
  {
    title: "Specialty Dispense Fee Cash $+%",
    field: "specialityDispensingFeeCash",
  },

  {
    title: "Program Type",
    field: "programType",
  },

  {
    title: "Billing Model",
    field: "billingModel",
  },

  {
    title: "Wholesaler",
    field: "wholesaler",
  },

  {
    title: "Participating in Cash Program",
    field: "participatingInCashProgram",
  },
];

export const CE_MEMBERS = [
  {
    title: "Covered Entity",
    field: "coveredEntity",
  },

  {
    title: "340B ID",
    field: "id340b",
  },

  {
    title: "MRN",
    field: "mrn",
  },

  {
    title: "First Name",
    field: "firstName",
  },

  {
    title: "Middle Name",
    field: "middleName",
  },

  {
    title: "Last Name",
    field: "lastName",
  },

  {
    title: "Suffix",
    field: "suffix",
  },

  {
    title: "DOB",
    field: "dob",
  },

  {
    title: "Gender",
    field: "gender",
  },

  {
    title: "Visit Date",
    field: "visitDate",
  },

  {
    title: "Hospital Service",
    field: "hosptalService",
  },

  {
    title: "Admit Type",
    field: "admitType",
  },

  {
    title: "Servicing Facility",
    field: "servicingFacility",
  },

  {
    title: "Assigned Patient Location",
    field: "assignedPatientLocation",
  },

  {
    title: "Sliding Scale Category",
    field: "slidingScaleIndicator",
  },

  {
    title: "Sliding Scale Effective Date",
    field: "slidingScaleEffectiveDate",
  },

  {
    title: "Provider Fn",
    field: "providerFn",
  },

  {
    title: "Provider Ln",
    field: "providerLn",
  },

  {
    title: "Provider DEA",
    field: "providerDEA",
  },

  {
    title: "Provider NPI",
    field: "providerNpi",
  },

  {
    title: "Provider SPI",
    field: "providerSpi",
  },
];
