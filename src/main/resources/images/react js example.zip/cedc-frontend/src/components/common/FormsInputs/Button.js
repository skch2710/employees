import React from 'react'
import { Button as MuiButton } from "@material-ui/core";
import {useFormInputstyle} from "../MuiForminputsStyles/ForminputStyle";


export default function Button(props) {
    const classes=useFormInputstyle();
    const { text, size, color, variant, onClick, ...other } = props

    return (
        <div className={classes.root}>
            <MuiButton
                variant={variant || "contained"}
                size={size || "small"}
                color={color || "primary"}
                onClick={onClick}
                {...other}
            >
                {text}
            </MuiButton>
        </div>
    )
}
