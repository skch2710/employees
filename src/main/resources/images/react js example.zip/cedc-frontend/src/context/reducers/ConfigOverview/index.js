import {
  CE_ACH_CONFIG_LOADING,
  CE_BASIC_DETAILS_LOADING,
  CE_FREQUENCY_LOADING,
  CE_LOCATIONS_LIST_LOADING,
  CE_PRIMARY_DETAILS_LOADING,
  ELIGIBILITY_CONFIG_LOADING,
  initialGridList,
  MEMBERS_LIST_LOADING,
  PROVIDERS_LIST_LOADING,
  SERVICE_AREA_CONFIG_LOADING,
  SET_CE_ACH_CONFIG,
  SET_CE_BASIC_DETAILS,
  SET_CE_FREQUENCY,
  SET_CE_LOCATIONS_LIST,
  SET_CE_PRIMARY_CONTACT_DETAILS,
  SET_CO_MEMBERS_LIST,
  SET_CO_PROVIDERS_LIST,
  SET_CO_TERMS_LIST,
  SET_ELIGIBILITY_CONFIG,
  SET_SERVICE_AREA_CONFIG,
  TERMS_LIST_LOADING,
  CE_ADMIN_FEES_LIST_LOADING,
  SET_CE_ADMIN_FEES_LIST,
  BILLING_CONTACTS_LOADING,
  SET_BILLING_CONTACT_LIST,
  VISIT_WINDOW_CONFIG_LOADING,
  SET_VISIT_WINDOW_CONFIG,
} from "./constants";

const basicdetailsinitialState = {
  records: [],
  basicdetails: {},
  count: 0,
  isActive: "",
  loading: false,
};
const getachdetailsinitialState = {
  records: [],
  getachdetails: {},
  count: 0,
  isActive: "",
  loading: false,
};

const billingfeewinitialState = {
  records: [],
  billingfeedetail: {},
  count: 0,
  isActive: "",
  loading: false,
};

const serviceareaconfiginitialState = {
  records: [],
  serviceareaconfig: {},
  count: 0,
  isActive: "",
  loading: false,
};

const visitWindowinitialState = {
  records: [],
  serviceareaconfig: {},
  count: 0,
  isActive: "",
  loading: false,
};

const ConfigSearchinitialState = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const serviceconfiginitialState = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const visitwindowinitialState = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const binpcninitialState = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const billingfeeinitialState = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const eligibilityRulesIntialState = {
  records: [],
  isActive: "",
  loading: false,
};

const coProviderInitialState = {
  records: [],
  isActive: "",
  loading: false,
};

const getProvidertypeintial = {
  records: [],
  isActive: "",
  loading: false,
};
const getCustomconfigvariableintial = {
  records: [],
  isActive: "",
  loading: false,
};

// GET_SERVICE_LOOKUP
const getServiceLookupIntial = {
  records: [],
  isActive: "",
  loading: false,
};

const getVisitWindowIntial = {
  records: [],
  isActive: "",
  loading: false,
};

const getLatestCEInitla = {
  records: [],
  isActive: "",
  loading: false,
};

const getVisitWindowLukUp = {
  records: [],
  isActive: "",
  loading: false,
};
export const getVisitLukUp = (state = getVisitWindowLukUp, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_VISIT_CONFIG_LUKUP":
      return { ...state.getVisitLukUp, data: action.data };
    default:
      return state;
  }
};
//
export const getLatestCE = (state = getLatestCEInitla, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_LATEST_CE":
      return { ...state.getLatestCE, data: action.data };
    default:
      return state;
  }
};
export const getVisitWinow = (state = getVisitWindowIntial, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_VISIT_WINDOW":
      return { ...state.getVisitWinow, data: action.data };
    default:
      return state;
  }
};
export const getServiceLookUp = (state = getServiceLookupIntial, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_SERVICE_LOOKUP":
      return { ...state.getServiceLookUp, data: action.data };
    default:
      return state;
  }
};
export const getProvidertype = (state = getProvidertypeintial, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_PROVIDER_LIST":
      return { ...state.getProvidertype, data: action.data };
    default:
      return state;
  }
};
export const getCustomconfigvariable = (
  state = getCustomconfigvariableintial,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_CUSTOM_VARIABLES":
      return { ...state.getCustomconfigvariable, data: action.data };
    default:
      return state;
  }
};

const coMemberInitialState = {
  records: [],
  isActive: "",
  loading: false,
};

const getServiceAreaState = {
  records: [],
  isActive: "",
  loading: false,
};

export const getServiceData = (state = getServiceAreaState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_SERVICE_AREA":
      return { ...state.getServiceData, data: action.data };
    default:
      return state;
  }
};

export const billingfeeconfig = (state = billingfeeinitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_BILLING_CONFIG":
      return { ...state.billingfeeconfig, data: action.data };
    default:
      return state;
  }
};

export const binpcnConfig = (state = binpcninitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_BIN_PCN_CONFIG":
      return { ...state.binpcnConfig, data: action.data };
    default:
      return state;
  }
};

export const visitWindowConfig = (state = visitwindowinitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_VISIT_CONFIG":
      return { ...state.visitWindowConfig, data: action.data };
    default:
      return state;
  }
};

export const getServiceConfigData = (
  state = serviceconfiginitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_SERVICE_CONFIG":
      return { ...state.getServiceConfigSearchData, data: action.data };
    default:
      return state;
  }
};
export const getConfigSearchData = (
  state = ConfigSearchinitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_CONFIG_DETAIL":
      return { ...state.getConfigSearchData, searchdata: action.data };
    default:
      return state;
  }
};

export const getConfigSearchfiltersdata = (
  state = ConfigSearchinitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_CONFIG_DETAIL_Data":
      return { ...state.getConfigSearchfiltersdata, searchdata: action.data };
    default:
      return state;
  }
};

export const getCEConfigDetailData = (
  state = ConfigSearchinitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_CE_CONFIG_DETAIL":
      return { ...state.getCEConfigDetailData, detaildata: action.data };
    default:
      return state;
  }
};

export const getVisitWindowData = (state = visitWindowinitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_VISIT_DETAIL":
      return { ...state.getVisitWindowData, visit: action.data };
    default:
      return state;
  }
};
export const getServiceAreaData = (
  state = serviceareaconfiginitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_SERVICE_CONFIG_DETAIL":
      return { ...state.getServiceAreaData, serviceareaconfig: action.data };
    default:
      return state;
  }
};

export const getbasicdetailData = (
  state = basicdetailsinitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_BASIC_DETAIL":
      return { ...state.getbasicdetailData, basicdetails: action.data };
    default:
      return state;
  }
};

export const getachData = (state = getachdetailsinitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_ACH_DETAIL":
      return { ...state.getachData, achdetails: action.data };
    default:
      return state;
  }
};
export const getbillingfeeData = (state = billingfeewinitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_BILLING_FEE_DETAIL":
      return { ...state.getbillingfeeData, billingfeedetail: action.data };
    default:
      return state;
  }
};

export const getbasicdetailsdata = (
  state = basicdetailsinitialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "getCO_BasicDetails":
      return { ...state.getbasicdetailsdata, Basicdetails: action.data };
    default:
      return state;
  }
};

export const ceBasicDetails = (
  state = { loading: false, basicDetails: {} },
  action
) => {
  switch (action.type) {
    case CE_BASIC_DETAILS_LOADING:
      return { ...state, loading: action.data };
    case SET_CE_BASIC_DETAILS:
      return { ...state, basicDetails: action.data };
    default:
      return state;
  }
};

export const ceContactDetails = (
  state = { loading: false, contactDetails: {} },
  action
) => {
  switch (action.type) {
    case CE_PRIMARY_DETAILS_LOADING:
      return { ...state, loading: action.data };
    case SET_CE_PRIMARY_CONTACT_DETAILS:
      return { ...state, contactDetails: action.data };
    default:
      return state;
  }
};

export const ceFrequency = (
  state = { loading: false, frequency: [] },
  action
) => {
  switch (action.type) {
    case CE_FREQUENCY_LOADING:
      return { ...state, loading: action.data };
    case SET_CE_FREQUENCY:
      return { ...state, frequency: action.data };
    default:
      return state;
  }
};

export const ceAchConfig = (
  state = { loading: false, achConfig: [] },
  action
) => {
  switch (action.type) {
    case CE_ACH_CONFIG_LOADING:
      return { ...state, loading: action.data };
    case SET_CE_ACH_CONFIG:
      return { ...state, achConfig: action.data };
    default:
      return state;
  }
};

export const eligibilityRules = (
  state = eligibilityRulesIntialState,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "SAVE_ELIGIBILITY_RULES":
      return { ...state };
    default:
      return state;
  }
};

export const coProviderDetails = (state = coProviderInitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_COPROVIDER_DETAILS":
      return { ...state.coProviderDetails, data: action.data };
    default:
      return state;
  }
};
export const coMemberDetails = (state = coMemberInitialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "GET_COMEMBER_DETAILS":
      return { ...state.coMemberDetails, data: action.data };
    default:
      return state;
  }
};

export const coTermsList = (state = initialGridList, action) => {
  switch (action.type) {
    case TERMS_LIST_LOADING:
      return { ...state, loading: action.data };
    case SET_CO_TERMS_LIST:
      return { ...state, records: action.data };
    default:
      return state;
  }
};

export const ceAdminBillingFeesList = (state = initialGridList, action) => {
  switch (action.type) {
    case CE_ADMIN_FEES_LIST_LOADING:
      return { ...state, loading: action.data };
    case SET_CE_ADMIN_FEES_LIST:
      return { ...state, records: action.data };
    default:
      return state;
  }
};

export const coProvidersList = (state = initialGridList, action) => {
  switch (action.type) {
    case PROVIDERS_LIST_LOADING:
      return { ...state, loading: action.data };
    case SET_CO_PROVIDERS_LIST:
      return { ...state, records: action.data };
    default:
      return state;
  }
};

export const coMembersList = (state = initialGridList, action) => {
  switch (action.type) {
    case MEMBERS_LIST_LOADING:
      return { ...state, loading: action.data };
    case SET_CO_MEMBERS_LIST:
      return { ...state, records: action.data };
    default:
      return state;
  }
};

export const coServiceAreaConfig = (
  state = { loading: false, serviceAreaConfig: [] },
  action
) => {
  switch (action.type) {
    case SERVICE_AREA_CONFIG_LOADING:
      return { ...state, loading: action.data };
    case SET_SERVICE_AREA_CONFIG:
      return { ...state, serviceAreaConfig: action.data };
    default:
      return state;
  }
};

export const coEligibilityConfig = (
  state = { loading: false, eligibilityConfig: [] },
  action
) => {
  switch (action.type) {
    case ELIGIBILITY_CONFIG_LOADING:
      return { ...state, loading: action.data };
    case SET_ELIGIBILITY_CONFIG:
      return { ...state, eligibilityConfig: action.data };
    default:
      return state;
  }
};

export const coVisitWindowConfig = (
  state = { loading: false, visitWindowConfig: {} },
  action
) => {
  switch (action.type) {
    case VISIT_WINDOW_CONFIG_LOADING:
      return { ...state, loading: action.data };
    case SET_VISIT_WINDOW_CONFIG:
      return { ...state, visitWindowConfig: action.data || {} };
    default:
      return state;
  }
};

export const coBillingContactList = (state = initialGridList, action) => {
  switch (action.type) {
    case BILLING_CONTACTS_LOADING:
      return { ...state, loading: action.data };
    case SET_BILLING_CONTACT_LIST:
      return { ...state, records: action.data };
    default:
      return state;
  }
};

export const coLocationsList = (state = initialGridList, action) => {
  switch (action.type) {
    case CE_LOCATIONS_LIST_LOADING:
      return { ...state, loading: action.data };
    case SET_CE_LOCATIONS_LIST:
      return { ...state, records: action.data };
    default:
      return state;
  }
};
