import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  configService,
  managedService,
} from "../../../environment";
import {
  INVENTORY_SEARCH,
  GET_INVENTORY_INNER_LIST,
  GET_INVENTORY_INNER_SUBGRIDLIST,
  INVENTORY_LOADING,
  GLOBAL_LOADING,
} from "../../constants";
import { DEFAULT_ERROR_TOAST_MSG } from "../constants";

export const InventorySearchList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: INVENTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: INVENTORY_SEARCH, data: response.data });
          callback(response.data);
        } else {
          callback({});
          dispatch({ type: INVENTORY_SEARCH, data: response.data });
        }
      })
      .catch((error) => {
        toast.dismiss();
        toast.error(error.message || DEFAULT_ERROR_TOAST_MSG);
      })
      .finally(() => dispatch({ type: INVENTORY_LOADING, data: false }));
  };
};

export const InventorymainExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: INVENTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "Inventory_main_Export", data: response.data });
          toast.success(response.successMessage);
          return callback && callback(response.data);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: INVENTORY_LOADING, data: false }));
  };
};

export const InventoryinnerSubgridExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: INVENTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/InventoryInnerGrid`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: INVENTORY_LOADING, data: false }));
  };
};
export const InventoryinnergridExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: INVENTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/claimDispenseGrid`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: INVENTORY_LOADING, data: false }));
  };
};

export const Get340values = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/inventory/organization`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "340bAvalues", data: response.data });
        } else {
          // toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const GetCEvalues = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/inventory/CoveredEntity/${data.orgID}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "CoveredEntityvalues", data: response.data });
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const GetCEPharmacyGroup = (data, callback, disableLoader = false) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityPharmacyGroup`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "Pharmacygroupvalues", data: response.data });
          callback && callback(response.data);
        } else {
          toast.error(response.errorMessage);
          callback && callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(
        () => !disableLoader && dispatch({ type: "ISLOADING", data: false })
      );
  };
};

export const Getpharmacystorevalues = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyStore`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "Pharmacystorevalues", data: response.data });
          callback && callback(response.data);
        } else {
          toast.error(response.errorMessage);
          callback && callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const Getwholesalervalues = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/searchWholesaler/${data.ceId}/${data.pharmacyId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "WholeSalervalues", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const GetdrugMvalues = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/DrugManufacturer`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "DrugManufacturervalues", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const GetScheduleTypevalues = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/scheduletypelkp`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "ScheduleTypevalues", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const GetFilterTypes = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/inventoryFilterTypes`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "inventoryFilterTypes", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getinventoryInnerList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/claimDispenseGrid`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_INVENTORY_INNER_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_INVENTORY_INNER_LIST, data: response.data });
        }
      })
      .catch((error) => {
        toast.dismiss();
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getinventoryInnerSubGridList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/InventoryInnerGrid`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: GET_INVENTORY_INNER_SUBGRIDLIST,
            data: response.data,
          });
          callback && callback(response.data);
        } else {
          dispatch({
            type: GET_INVENTORY_INNER_SUBGRIDLIST,
            data: response.data,
          });
        }
      })
      .catch((error) => {
        toast.dismiss();
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getPharmacyStore = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyStore`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "pharmacyStore", data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getWholeSaler = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/searchWholesaler/${data.ceid}/${data.pharmacyId}`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getDrugManufacturer = (payload, { setIsManufLoading }) => {
  return ApiClient.post(
    `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/drugManufacturer`,
    payload
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      } else return [];
    })
    .catch((error) => {
      toast.error(error);
      return [];
    })
    .finally(() => {
      setIsManufLoading(false);
      return [];
    });
};

export const getPharmacyGroups = (data, disableLoader, callback) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityPharmacyGroup`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
        callback([]);
      })
      .finally(
        () => !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};
