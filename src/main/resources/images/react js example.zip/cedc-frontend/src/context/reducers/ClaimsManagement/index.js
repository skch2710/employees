import {
  CLAIMS_LIST_LOADING,
  RX_NUMBER_DETAILS,
  RX_NUMBER_DETAILS_LOADING,
  SET_CLAIMS_LIST,
} from "./constants";

const initialState1 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialState2 = {
  records: [],
};

const initialState3 = {
  records: [],
};

const initialState4 = {
  records: [],
};

const initialState5 = {
  records: [],
};

const initialState6 = {
  records: [],
};

const initialState7 = {
  records: [],
};

const initialState8 = {
  records: [],
};

const initialState9 = {
  records: [],
};

const initialState10 = {
  record: {},
  loading: false,
};

export const getClaimsListTableData = (state = initialState1, action) => {
  switch (action.type) {
    case CLAIMS_LIST_LOADING:
      return { ...state, loading: action.data };
    case SET_CLAIMS_LIST:
      return { ...state.getClaimsListTableData, records: action.data };
    default:
      return state;
  }
};

export const claimsExportdata = (state = initialState1, action) => {
  switch (action.type) {
    case "claims_Export":
      return {
        ...state.claimsExportdata,
        records: action.data,
        count: action.data.totalElements,
      };
    case "LOGOUT":
      return initialState1;
    default:
      return state;
  }
};

export const getPatientMRN = (state = initialState2, action) => {
  switch (action.type) {
    case "patientMRN":
      return { ...state.getPatientMRN, records: action.data };
    default:
      return state;
  }
};

export const getRxNumber = (state = initialState3, action) => {
  switch (action.type) {
    case "RxNumber":
      return { ...state.getRxNumber, records: action.data };
    default:
      return state;
  }
};

export const getClaimStatus = (state = initialState4, action) => {
  switch (action.type) {
    case "claimStatus":
      return { ...state.getClaimStatus, records: action.data };
    default:
      return state;
  }
};

export const getClaimType = (state = initialState5, action) => {
  switch (action.type) {
    case "claimType":
      return { ...state.getClaimType, records: action.data };
    default:
      return state;
  }
};

export const getBrandGenericBoth = (state = initialState6, action) => {
  switch (action.type) {
    case "brandGenericBoth":
      return { ...state.getBrandGenericBoth, records: action.data };
    default:
      return state;
  }
};

export const getShowPatientInformation = (state = initialState7, action) => {
  switch (action.type) {
    case "yesNo":
      return { ...state.getShowPatientInformation, records: action.data };
    default:
      return state;
  }
};

export const getFalloutReason = (state = initialState8, action) => {
  switch (action.type) {
    case "fallout_reason":
      return { ...state.getFalloutReason, records: action.data };
    default:
      return state;
  }
};

export const getBIN = (state = initialState9, action) => {
  switch (action.type) {
    case "BIN":
      return { ...state.getBIN, records: action.data };
    default:
      return state;
  }
};

export const rxNumberPopupDetails = (
  state = {
    loading: false,
    details: {},
  },
  action
) => {
  switch (action.type) {
    case RX_NUMBER_DETAILS_LOADING:
      return { ...state, loading: action.data };
    case RX_NUMBER_DETAILS:
      return { ...state.rxNumberPopupDetails, details: action.data };
    default:
      return state;
  }
};
