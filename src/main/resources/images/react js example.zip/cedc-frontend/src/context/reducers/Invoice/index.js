import _get from "lodash/get";
import {
  INVOICE_GRID_LOADING,
  GET_INVOICE_LIST,
  GET_INVOICE_INNER_LIST,
  GET_INVOICE_INNER_SUBGRID_LIST,
  GET_CLAIM_LIST,
  GET_TRUE_UP_LIST,
  GET_REMITTANCE_LIST,
  GET_INVOICE_INNER_SUBGRID_LIST_LOADING,
  GET_INVOICE_INNER_LIST_LOADING,
  INVOICE_CLAIMS_LOADING,
  INVOICE_TRUE_UP_LOADING,
  REMITTANCE_LIST_LOADING,
  GET_INVOICEDETAILS_LIST,
  GET_REMITTANCEDETAILS_LIST,
} from "../../constants";

const initialState1 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetInvoicelist = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetInvoiceInnerGrid = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInvoiceInnerSubGrid = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetInvoiceMainExport = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetClaimsList = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetTrueupList = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetRemmittanceList = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetInvoiceDetailsList = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

export const getInvoiceList = (state = initialgetInvoicelist, action) => {
  switch (action.type) {
    case INVOICE_GRID_LOADING:
      return { ...state, loading: action.data };
    case "ADD_USER":
      return { ...state };
    case GET_INVOICE_LIST:
      return {
        ...state.getInvoiceList,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    case "LOGOUT":
      return initialgetInvoicelist;
    default:
      return state;
  }
};

export const getInvoicereports = (state = initialState1, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "Invoice_reports":
      return { ...state.getInvoicereports, records: action.data };
    default:
      return state;
  }
};

export const getTrueUpreports = (state = initialState1, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "Trueup_reports":
      return { ...state.getTrueUpreports, records: action.data };
    default:
      return state;
  }
};

export const getThree40BDReports = (state = initialState1, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "Three40BDirect_Reports":
      return { ...state.getThree40BDReports, records: action.data };
    default:
      return state;
  }
};

export const getInvoiceInnerGrid = (
  state = initialgetInvoiceInnerGrid,
  action
) => {
  switch (action.type) {
    case GET_INVOICE_INNER_LIST_LOADING:
      return { ...state, loading: action.data };
    case GET_INVOICE_INNER_LIST:
      return {
        ...state.getInvoiceInnerGrid,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    case "LOGOUT":
      return initialgetInvoiceInnerGrid;
    default:
      return state;
  }
};

export const getInvoiceMainGridExport = (
  state = initialgetInvoiceMainExport,
  action
) => {
  switch (action.type) {
    case "GET_INVOICE_LIST_EXPORT":
      return {
        ...state.getInvoiceMainExport,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    case "LOGOUT":
      return initialgetInvoiceMainExport;
    default:
      return state;
  }
};

export const getInvoiceSubInnerGrid = (
  state = initialgetInvoiceInnerSubGrid,
  action
) => {
  switch (action.type) {
    case GET_INVOICE_INNER_SUBGRID_LIST_LOADING:
      return { ...state, loading: action.data };
    case GET_INVOICE_INNER_SUBGRID_LIST:
      return {
        ...state.getInvoiceSubInnerGrid,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    case "LOGOUT":
      return initialgetInvoiceInnerSubGrid;
    default:
      return state;
  }
};

export const getClaimData = (state = initialgetClaimsList, action) => {
  switch (action.type) {
    case INVOICE_CLAIMS_LOADING:
      return { ...state, loading: action.data };
    case GET_CLAIM_LIST:
      return {
        ...state.getClaimData,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    default:
      return state;
  }
};

export const getTrueupData = (state = initialgetTrueupList, action) => {
  switch (action.type) {
    case INVOICE_TRUE_UP_LOADING:
      return { ...state, loading: action.data };
    case GET_TRUE_UP_LIST:
      return {
        ...state.getTrueupData,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    case "LOGOUT":
      return initialgetTrueupList;
    default:
      return state;
  }
};

export const getRemittanceData = (
  state = initialgetRemmittanceList,
  action
) => {
  switch (action.type) {
    case REMITTANCE_LIST_LOADING:
      return { ...state, loading: action.data };
    case GET_REMITTANCE_LIST:
      return {
        ...state.getRemittanceData,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    case "LOGOUT":
      return initialgetRemmittanceList;
    default:
      return state;
  }
};

export const getInvoiceDetailsData = (
  state = initialgetInvoiceDetailsList,
  action
) => {
  switch (action.type) {
    case REMITTANCE_LIST_LOADING:
      return { ...state, loading: action.data };
    case GET_INVOICEDETAILS_LIST:
      return {
        ...state.getInvoiceDetailsData,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    default:
      return state;
  }
};

export const getRemittanceDetailsData = (
  state = initialgetInvoiceDetailsList,
  action
) => {
  switch (action.type) {
    case REMITTANCE_LIST_LOADING:
      return { ...state, loading: action.data };
    case GET_REMITTANCEDETAILS_LIST:
      return {
        ...state.getRemittanceDetailsData,
        records: action.data,
        count: _get(action.data, "totalElements", 0),
      };
    default:
      return state;
  }
};
