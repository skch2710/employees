import { toast } from "react-toastify";
import ApiClient from "../../../api-client";

import { PORT, apiUrlUser, userService } from "../../../environment";
import { setUserSessions } from "../../../utils/helper";

toast.configure();

export const login = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/authenticate`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          if (response.otpEnable) {
            toast.success(response.successMessage);
          } else {
            setUserSessions(response);
          }
          dispatch({ type: "LOGIN", data: { ...response.user, ...data } });
          return callback(response);
        } else {
          toast.error(response.error);
          return callback(response);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};
// login-verification API
export const validateOTP = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/validateOTP`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          response.resetPasswordAlert !== null &&
            toast.error(response.resetPasswordAlert);
          dispatch({ type: "validateOTP", data: response.user });
          setUserSessions(response);
          return callback(response);
        } else {
          toast.error(response.error);
          return callback(response);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};
//API Of Security questions
export const getSecurityQuestions = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/securityQuestions`,
      data
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      // toast.dismiss();
      if (response.statusCode === 200) {
        // toast.success(response.successMessage);
        dispatch({ type: "getSecurityQuestions", data: response.data });
        // return callback(response.data);
      } else if (response.statusCode === 404) {
        toast.error(response.errorMessage);
        return callback(response);
      } else {
        //Error message 500
        toast.error(response.errorMessage);
      }
    });
  };
};

// Verify Uuid
export const validateUUID = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/verifyPassword`,
      data
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      localStorage.setItem(
        "validateUUID",
        response.statusCode === 200 ? true : false
      );
      localStorage.setItem(
        "userData",
        response.statusCode === 200 ? JSON.stringify(response.data) : false
      );
      if (response.statusCode === 200) {
        toast.success(response.message);
        dispatch({ type: "validateUUID", data: response.data });
        return callback(response);
      } else if (response.statusCode === 400) {
        toast.error(response.errorMessage);
        return callback(response);
      } else if (response.statusCode === 404) {
        toast.error(response.errorMessage);
        return callback(response);
      } else {
        toast.error(response.error);
      }
    });
  };
};

// Login Create Password logincreatepassword

export const logincreatepassword = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/createPassword`,
      data
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          toast.success(response.message);
          return callback(response);
        } else if (response.statusCode === 400) {
          toast.error(response.errorMessage);
        } else {
          toast.error(response.error);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const loader = (flag) => {
  return (dispatch, getState) => {
    dispatch({ type: "ISLOADING", data: flag });
  };
};

export const getForgotPassword = ({ em, un }, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/forgotPassword/${encodeURIComponent(
        em
      )}/${em}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return callback(response);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(
          res.errorMessage ||
            "The username or email ID you entered is incorrect"
        );
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const verifyUUId = (id, cb) => {
  const encoded = id ? encodeURIComponent(id) : "";
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/verifyuuid/${encoded}`
    )
      .then((res) => {
        cb(res);
        return;
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      });
  };
};

export const validateSecurityAns = (data, cb) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/validateSecurityAnswers`,
      data
    )
      .then((res) => {
        if (res.statusCode === 200) {
          cb(res);
          return;
        } else {
          cb(res);
          //  toast.error(res.errorMessage);
        }
      })
      .catch((res) => {
        if (res.errorMessage) cb(res);
        else {
          toast.error("Something went wrong");
        }
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const updatePassword = (payload, cb) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/saveupdatedpassword`,
      payload
    )
      .then((res) => {
        if (res.statusCode === 200) {
          toast.success(res.successMessage);
          cb();
          return;
        } else toast.error(res.errorMessage);
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const resetPassword = (payload, cb) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/resetpassword`,
      payload
    )
      .then((res) => {
        if (res.statusCode === 200) {
          toast.success(res.successMessage);
          cb();
          return;
        } else toast.error(res.errorMessage);
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const regenarateLink = (uuid) => {
  const encoded = uuid ? encodeURIComponent(uuid) : "";
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/regeneratedPassword?uuid=${encoded}`
    )
      .then((res) => {
        if (res.statusCode === 200) {
          toast.success(res.successMessage);
          return;
        } else toast.error(res.errorMessage);
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};
