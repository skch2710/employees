import { toast } from "react-toastify";
import ApiClient, { axiosInstance } from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  configService,
} from "../../../environment";
import "react-toastify/dist/ReactToastify.css";
import {
  LOCATIONS_LIST_LOADING,
  LOCATION_HISTORY,
  LOCATION_HISTORY_LOADING,
  OPA_REGISTERED_LOCATIONS_LOADING,
  PROVIDER_ASSOCIATION,
  PROVIDER_ASSOCIATION_LOADING,
  SET_LOCATIONS_LIST,
  SET_LOCATIONS_VARIATIONS_LIST,
  SET_OPA_REGISTERED_LOCATIONS_LIST,
} from "../../reducers/Locations/constants";
import { GLOBAL_LOADING } from "../../constants";
import FileSaver from "file-saver";

let token = localStorage.Accesstoken;
export const getLocationList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/location`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "locationList", data: response.data });
          dispatch({ type: GLOBAL_LOADING, data: false });
          return response.data;
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getLocationsGridData = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: LOCATIONS_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: SET_LOCATIONS_LIST, data: response.data });
          callback && callback(response.data);
          return response.data;
        } else {
          dispatch({ type: SET_LOCATIONS_LIST, data: response.data });
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => {
        dispatch({ type: LOCATIONS_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const locationsExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/search`,
      data
    )
      .then((response) => {
        if (response.data) {
          toast.success(response.successMessage);
          dispatch({ type: GLOBAL_LOADING, data: false });
          return callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const addLocation = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/save`,
      data,
      token
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          dispatch({ type: "ADD_LOCATION", data: response.data });
          return callback && callback(response);
        } else if (response.status === 404) {
          toast.error(response.error);
          // return callback(response);
        } else {
          //Error message 500
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getlocationNameExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/LocationNameExist/${data}`
    )
      .then((response) => {
        callback && callback(response);
        dispatch({ type: "ISLOADING", data: false });
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getlocationHrsaIdExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/HrsaIdexist/${data.hrsaId}`
    )
      .then((response) => {
        callback && callback(response);
        dispatch({ type: GLOBAL_LOADING, data: false });
        return response;
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const deleteLocation = (payload, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/terminate-location`,
      payload
    )
      .then((response) => {
        toast.success(response.successMessage);
        callback && callback(response);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const validateStandardAddress = (payload, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/standard-address`,
      payload
    )
      .then((response) => callback && callback(response))
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};
export const getOPASearchResultTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export &&
      dispatch({ type: OPA_REGISTERED_LOCATIONS_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/opaDetails`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({
              type: SET_OPA_REGISTERED_LOCATIONS_LIST,
              data: response.data,
            });
          return response.data;
        } else {
          !payload.export &&
            dispatch({
              type: SET_OPA_REGISTERED_LOCATIONS_LIST,
              data: response.data,
            });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: OPA_REGISTERED_LOCATIONS_LOADING, data: false });
        return {};
      });
  };
};
export const exportOPASearchResultTableData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/opaDetails`,
      payload
    )
      .then((response) => {
        const blob = new Blob([response], {
          type: "application/octet-stream",
        });
        FileSaver.saveAs(blob, `Registered Locations List.xlsx`);
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};
export const getAllCesAssociatedToAddresses = (payload, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/multiple-ce-address`,
      payload
    )
      .then((response) => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        callback && callback(response);
      })
      .catch((error) => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        toast.error(error.message);
      });
  };
};
export const opaLocationSave = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/location-opa`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else {
          toast.error(response.errorMessage);
        }
        return callback(response);
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const changeParticipatingStatus = (payload, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/participating-status`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getNewLocationsCount = (ceId, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/location-is-new/${ceId}`
    )
      .then((response) => {
        callback && callback(response);
      })
      .catch((error) => toast.error(error.message));
  };
};

export const updateLocationStatus = (payload, callback) => {
  return (dispatch) => {
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/location-is-new`,
      payload
    )
      .then((response) => {
        callback && callback(response);
      })
      .catch((error) => toast.error(error.message));
  };
};

export const getHRSAID = (payload) => {
  return (dispatch) => {
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/location-hrsa-id`,
      payload
    ).then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      } else {
        return [];
      }
    });
  };
};

export const fetchLocationHistory = (payload) => {
  return (dispatch) => {
    if (payload.export) {
      axiosInstance.defaults.responseType = "blob";
      dispatch({ type: GLOBAL_LOADING, data: true });
    } else {
      dispatch({ type: LOCATION_HISTORY_LOADING, data: true });
    }
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/search-location-history`,
      payload
    )
      .then((response) => {
        if (payload.export) {
          const blob = new Blob([response], {
            type: "application/octet-stream",
          });
          FileSaver.saveAs(blob, `Location History.xlsx`);
        } else {
          if (response.statusCode === 200 || response.statusCode === 404) {
            dispatch({ type: LOCATION_HISTORY, data: response.data });
            return response.data;
          } else {
            dispatch({ type: LOCATION_HISTORY, data: response.data });
            return {};
          }
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: LOCATION_HISTORY, data: {} });
        return {};
      })
      .finally(() => {
        if (payload.export) {
          axiosInstance.defaults.responseType = undefined;
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else {
          dispatch({ type: LOCATION_HISTORY_LOADING, data: false });
          return {};
        }
      });
  };
};

export const getLocationVariationData = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: LOCATIONS_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_LOCATIONS_VARIATIONS_LIST,
            data: response.data,
          });
          callback && callback(response.data);
          return response.data;
        } else {
          dispatch({
            type: SET_LOCATIONS_VARIATIONS_LIST,
            data: response.data,
          });
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: LOCATIONS_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const fetchProviderAssociationGridData = (payload) => {
  return (dispatch) => {
    if (payload.export) {
      axiosInstance.defaults.responseType = "blob";
      dispatch({ type: GLOBAL_LOADING, data: true });
    } else {
      dispatch({ type: PROVIDER_ASSOCIATION_LOADING, data: true });
    }
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/search-provider-association`,
      payload
    )
      .then((response) => {
        if (payload.export) {
          const blob = new Blob([response], {
            type: "application/octet-stream",
          });
          FileSaver.saveAs(blob, `Provider Association.xlsx`);
        } else {
          if (response.statusCode === 200 || response.statusCode === 404) {
            dispatch({ type: PROVIDER_ASSOCIATION, data: response.data });
            return response.data;
          } else {
            dispatch({ type: PROVIDER_ASSOCIATION, data: response.data });
            return {};
          }
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: PROVIDER_ASSOCIATION, data: {} });
        return {};
      })
      .finally(() => {
        if (payload.export) {
          axiosInstance.defaults.responseType = undefined;
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else {
          dispatch({ type: PROVIDER_ASSOCIATION_LOADING, data: false });
          return {};
        }
      });
  };
};
