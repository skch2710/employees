import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  managedService,
  configService,
} from "../../../environment";
import { DEFAULT_ERROR_TOAST_MSG } from "../constants";
import {
  GET_PO_CLAIM_LIST,
  GET_PO_HISTORY_LIST,
  GET_PO_ITEM_HISTORY_LIST,
  GET_PO_LIST,
  GLOBAL_LOADING,
  IS_PO_HISTORY_LOADING,
  IS_PO_ITEM_HISTORY_LOADING,
  PO_CLAIM_LIST_LOADING,
  PO_INFO,
  PO_INFO_LOADING,
  PO_LOADING,
} from "../../constants";

export const getPharmacyStore = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyStore`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "pharmacyStore", data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getOrderStatus = (data) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/OrderStatus`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "otherstatus", data: response.data });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      });
  };
};

export const getScheduleType = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/scheduletypelkp`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getPoCategories = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/purchaseordercategorylkp`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getManufacturers = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/DrugManufacturer`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getPharmacyGroups = (ceIds, disableLoader, callback) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityPharmacyGroup`,
      {
        ceid: ceIds,
      }
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
        callback([]);
      })
      .finally(
        () => !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};

export const getManufacturer = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/DrugManufacturer`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getPOSearchCriteria = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/purchaseSearchorderCriterialkp`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    })
    .finally(() => {
      return [];
    });
};

export const getPurchaseList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: PO_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/search`,
      data
    )
      .then((response) => {
        dispatch({ type: GET_PO_LIST, data: response.data });
        callback(response.data);
      })
      .catch((error) => {
        toast.error(error.message || DEFAULT_ERROR_TOAST_MSG);
      })
      .finally(() => dispatch({ type: PO_LOADING, data: false }));
  };
};

export const getPurchaseListExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

// Purchase Order Inner grid
export const getPOInfo = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: PO_INFO_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/POItemInfoSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: PO_INFO, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: PO_INFO, data: response.data });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: PO_INFO_LOADING, data: false }));
  };
};

// Purchase Order Inner Export Data
export const getPOInfoExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: PO_INFO_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/POItemInfoSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: PO_INFO_LOADING, data: false }));
  };
};

// Purchase Order History Data
export const getPOHistoryList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: IS_PO_HISTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/PurchaseOrderHistory`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_PO_HISTORY_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_PO_HISTORY_LIST, data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: IS_PO_HISTORY_LOADING, data: false }));
  };
};

// Purchase Order History Export
export const getPOHistoryExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: IS_PO_HISTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/PurchaseOrderHistory`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: IS_PO_HISTORY_LOADING, data: false }));
  };
};

// Purchase Order Item History Data
export const getPOItemHistoryList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: IS_PO_ITEM_HISTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/PurchaseOrderItemHistory`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_PO_ITEM_HISTORY_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_PO_ITEM_HISTORY_LIST, data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() =>
        dispatch({ type: IS_PO_ITEM_HISTORY_LOADING, data: false })
      );
  };
};

// Purchase Order Item History Export
export const getPOItemHistoryExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: IS_PO_ITEM_HISTORY_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/PurchaseOrderItemHistory`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() =>
        dispatch({ type: IS_PO_ITEM_HISTORY_LOADING, data: false })
      );
  };
};

// Purchase Order Claims Data
export const getPOClaimsList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: PO_CLAIM_LIST_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/PurchaseOrderPXClaims`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_PO_CLAIM_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_PO_CLAIM_LIST, data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: PO_CLAIM_LIST_LOADING, data: false }));
  };
};

// Purchase Order Claims Export

export const getPOClaimExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: PO_CLAIM_LIST_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/PurchaseOrder/PurchaseOrderPXClaims`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: PO_CLAIM_LIST_LOADING, data: false }));
  };
};
