import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  managedService,
  configService,
} from "../../../environment";
import {
  INVOICE_GRID_LOADING,
  GET_INVOICE_LIST,
  GET_INVOICE_INNER_LIST,
  GET_INVOICE_INNER_SUBGRID_LIST,
  GET_CLAIM_LIST,
  GET_TRUE_UP_LIST,
  GET_REMITTANCE_LIST,
  GET_INVOICE_INNER_LIST_LOADING,
  GET_INVOICE_INNER_SUBGRID_LIST_LOADING,
  GLOBAL_LOADING,
  GET_INVOICEDETAILS_LIST,
  GET_INVOICEDETAILS_SUMMARY,
  GET_REMITTANCEDETAILS_LIST,
} from "../../constants";
import { axiosInstance } from "../../../api-client";
import "react-toastify/dist/ReactToastify.css";
import { DEFAULT_ERROR_TOAST_MSG } from "../constants";

export const getInvoiceGridData = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: INVOICE_GRID_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchInvoices`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_INVOICE_LIST, data: response.data });
          callback(response.data);
        } else {
          callback({});
          dispatch({ type: GET_INVOICE_LIST, data: {} });
        }
      })
      .catch((error) => {
        toast.dismiss();
        toast.error(error.message || DEFAULT_ERROR_TOAST_MSG);
      })
      .finally(() => dispatch({ type: INVOICE_GRID_LOADING, data: false }));
  };
};

export const getInvoiceGridDataExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchInvoices`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_INVOICE_LIST_EXPORT", data: response.data });
          return callback && callback(response.data);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getPharmacyStore = (data, disableLoader, callback) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyStore`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
        callback([]);
      })
      .finally(
        () => !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};


export const getPharmacyGroups = (data, disableLoader, callback) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityPharmacyGroup`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
        callback([]);
      })
      .finally(
        () => !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};

export const invoiceExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/invoice/search`,
      data
    )
      .then((response) => {
        if (response.data) {
          toast.success(response.successMessage);
          return callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({ type: "invoice_Export", data: response.data });
          toast.error(response.errorMessage);
          return callback(response.data);
        } else {
          dispatch({ type: "invoice_Export", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((e) => toast.error(e.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const Invoicereports = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/pharmacyInvoiceDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "Invoice_reports", data: response.data });
          toast.success(response.successMessage);
        } else if (response.statusCode === 0) {
          return callback && callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({ type: "Invoice_reports", data: response.data });
          toast.error(response.errorMessage);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const TrueUPreports = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/TrueUpReportPopupDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "Trueup_reports", data: response.data });
          toast.success(response.successMessage);
        } else if (response.statusCode === 0) {
          return callback && callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({ type: "Trueup_reports", data: response.data });
          toast.error(response.errorMessage);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const Three40BDirectReports = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/tfbDirectPlusFeesReport`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "Three40BDirect_Reports", data: response.data });
          toast.success(response.successMessage);
        } else if (response.statusCode === 0) {
          return callback && callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({ type: "Three40BDirect_Reports", data: response.data });
          toast.error(response.errorMessage);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getinvoiceInnerList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GET_INVOICE_INNER_LIST_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchPharmacyGroupInvoiceDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_INVOICE_INNER_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_INVOICE_INNER_LIST, data: {} });
        }
      })
      .catch((error) => {
        toast.dismiss();
      })
      .finally(() =>
        dispatch({ type: GET_INVOICE_INNER_LIST_LOADING, data: false })
      );
  };
};

export const getInoiceInnerSubGridList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GET_INVOICE_INNER_SUBGRID_LIST_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchPharmacyInvoiceDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: GET_INVOICE_INNER_SUBGRID_LIST,
            data: response.data,
          });
          callback && callback(response.data);
        } else {
          dispatch({
            type: GET_INVOICE_INNER_SUBGRID_LIST,
            data: {},
          });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() =>
        dispatch({ type: GET_INVOICE_INNER_SUBGRID_LIST_LOADING, data: false })
      );
  };
};

export const InvoicePharmacyGroupExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchPharmacyGroupInvoiceDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const InvoiceClientLevelExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GET_INVOICE_INNER_SUBGRID_LIST_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchPharmacyInvoiceDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() =>
        dispatch({ type: GET_INVOICE_INNER_SUBGRID_LIST_LOADING, data: false })
      );
  };
};

export const getClaimsList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchInvoiceClaims`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_CLAIM_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_CLAIM_LIST, data: {} });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getTrueupList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/TrueUpDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_TRUE_UP_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_TRUE_UP_LIST, data: {} });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getRemittanceList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchInvoiceRemittance`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_REMITTANCE_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_REMITTANCE_LIST, data: {} });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getCERemittanceTotal = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchCERemittanceTotal`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getRemittanceExportPdf = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/remittance-pdf`,
      payload
    )
      .then((res) => {
        const remittance = document.createElement("a");
        remittance.style.display = "none";
        document.body.appendChild(remittance);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        remittance.href = url;
        remittance.download = "Remittance Summary.pdf";
        remittance.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getInvoiceDetailsExportPdf = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/invoicepdf`,
      payload
    )
      .then((res) => {
        const invoiceDetailsExportPdf = document.createElement("a");
        invoiceDetailsExportPdf.style.display = "none";
        document.body.appendChild(invoiceDetailsExportPdf);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        invoiceDetailsExportPdf.href = url;
        invoiceDetailsExportPdf.download = "Invoice Fee Details.pdf";
        invoiceDetailsExportPdf.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getZipFolder = (payload, rowData) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/invoice-zip`,
      payload
    )
      .then((res) => {
        const zipFolder = document.createElement("a");
        zipFolder.style.display = "none";
        document.body.appendChild(zipFolder);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        zipFolder.href = url;
        zipFolder.download = rowData.ceName + "Invoice Package.zip";
        zipFolder.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getClaimsListExport = (TrueupClaimsPayload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchInvoiceClaims`,
      TrueupClaimsPayload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getRemittanceListExport = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/searchInvoiceRemittance`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getTrueupListExport = (TrueupClaimsPayload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/TrueUpDetails`,
      TrueupClaimsPayload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getInvoiceDetailsList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/invoice-details`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_INVOICEDETAILS_LIST, data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: GET_INVOICEDETAILS_LIST, data: {} });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getInvoiceDetailsSummary = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/invoice-details-summary`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return {};
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getRemittanceDetailsList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/remittance-details`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GET_REMITTANCEDETAILS_LIST, data: response.data });
          callback && callback(response.data);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getRemittanceDetailsSummary = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/invoice/remittance-summary`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return {};
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};
