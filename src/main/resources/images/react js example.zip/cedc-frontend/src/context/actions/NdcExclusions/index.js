import { toast } from "react-toastify";
import FileSaver from "file-saver";
import ApiClient, { axiosInstance } from "../../../api-client";
import { apiUrlUser, PORT, configService } from "../../../environment";
import { GLOBAL_LOADING } from "../../constants";
import {
  APPLIED_CLIENT_EXCLUSION_GRID_DATA,
  APPLIED_CLIENT_EXCLUSION_LOADING,
  NDC_DETAILS_LOADING,
  NDC_SELECTION_DRAFT_LIST_LOADING,
  NDC_SELECTION_SEARCH_LOADING,
  SET_NDC_CLIENT_EXCLUSIONS,
  SET_NDC_DETAILS_LIST,
  SET_NDC_SELECTION_SEARCH_LIST,
  NDC_CLIENT_EXCEPTION_LIST_LOADING,
  NDC_CLIENT_EXCLUSIONS_LOADING,
  DRAFT_EXCLUSION_LOADING,
  DRAFT_EXCLUSION_GRID_DATA,
  NDC_CLIENT_RELATIONSHIP_LOADING,
  SET_NDC_CLIENT_RELATIONSHIP,
  NDC_DYNAMIC_EXCLUSION_TABLE_LOADING,
  NDC_DYNAMIC_LIST_PARAMS_LOADING,
  NDC_DYNAMIC_LIST_PARAMS_LOADED,
  NDC_FILTERS_LOADING,
} from "../../reducers/NdcExclusions/constants";
import { SET_NDC_LISTS } from "../../reducers/Common/constants";

export const getExclusionTypeValues = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/exclusionType`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

//
export const getNdcSearchResultTableData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_SELECTION_SEARCH_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcSelection`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({
              type: SET_NDC_SELECTION_SEARCH_LIST,
              data: response.data,
            });
          return response.data;
        } else {
          !payload.export &&
            dispatch({
              type: SET_NDC_SELECTION_SEARCH_LIST,
              data: response.data,
            });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: NDC_SELECTION_SEARCH_LOADING, data: false });
        return {};
      });
  };
};

export const exportNdcSearchResultTableData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcSelection`,
      payload
    )
      .then((response) => {
        if (response) {
          const blob = new Blob([response], {
            type: "application/octet-stream",
          });
          FileSaver.saveAs(blob, `NDC List.xlsx`);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const fetchNdcDetailsTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: NDC_DETAILS_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-drug-history-details`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({
              type: SET_NDC_DETAILS_LIST,
              data: response.data,
            });
          return response.data;
        } else {
          !payload.export &&
            dispatch({
              type: SET_NDC_DETAILS_LIST,
              data: response.data,
            });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export && dispatch({ type: NDC_DETAILS_LOADING, data: false });
        return {};
      });
  };
};

export const getNdcDraftListTableData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_SELECTION_DRAFT_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-draft-exclusion-list-details`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_SELECTION_DRAFT_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const saveNdcSelection = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-draft-exclusion-lists`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getListNames = () => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/listNames`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: SET_NDC_LISTS, data: response.data });
          return response.data;
        } else {
          dispatch({ type: SET_NDC_LISTS, data: [] });
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getNdcListHistory = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcListHistory/${data.listId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return (callback && callback(response.data)) || response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const ndcSearchList = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "NDC_LIST_LOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-list-main-grid`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "NDC_LIST", data: response.data });
          callback && callback(response.data);
        } else {
          dispatch({ type: "NDC_LIST", data: [] });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: "NDC_LIST_LOADING", data: false }));
  };
};

// NDC LIST BASIC DETAILS TAB
export const checkForDuplicateListName = async (listName = "") => {
  return await ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/listNameExist?listName=${listName}`
  )
    .then((response) => {
      return response.errorMessage;
    })
    .catch((error) => {
      toast.error(error.message);
      return false;
    })
    .finally(() => false);
};

export const getNdcListBasicDetails = async (listId) => {
  return await ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/listDetails/${listId}`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const saveNdcListBasicDetails = async (payload) => {
  return await ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/saveNDCExclusionList`,
    payload
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const copyNdcList = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/new-list-details`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return response.data;
        }
        return false;
      })
      .catch((error) => {
        toast.error(error.message);
        return false;
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

// NDC LIST APPLICATION TAB
export const getExclusionManufacturers = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/DrugManufacturer`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      } else return [];
    })
    .catch((error) => {
      toast.error(error.message);
      return [];
    });
};

export const getTherapeuticClassValues = () => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/therapeutic-class-initial-load`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getManufacturerValues = () => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/manufacturer-initial-load`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getClientDropDownValues = () => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/client-dropdown-details`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getExclusionWholesalers = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/wholesalers`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      } else return [];
    })
    .catch((error) => {
      toast.error(error.message);
      return [];
    });
};

export const getExclusionPhGroups = (ceIds = []) => {
  return ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityPharmacyGroup`,
    {
      ceid: ceIds,
    }
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      } else return [];
    })
    .catch((error) => {
      toast.error(error.message);
      return [];
    });
};

export const getExclusionCoveredEntities = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/activeCoveredEntities?resultObject=true`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        let array = [];
        if (response.data && response.data.length > 0) {
          array = response.data.map((item) => {
            item["label"] = item.ceName;
            item["value"] = item.ceID;
            return item;
          });
        }
        return array;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getExclusionPharmacies = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyNamesList`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        let array = [];
        if (response.data && response.data.length > 0) {
          array = response.data.map((item) => {
            item["label"] = item.phName;
            item["value"] = item.phid;
            return item;
          });
        }
        return array;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getClaimTypes = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/claim-type`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        let array = [];
        if (response.data && response.data.length > 0) {
          array = response.data.map((item) => {
            item["label"] = item.claimType;
            item["value"] = item.claimTypeId;
            return item;
          });
        }
        return array;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

export const getClientExclusionData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_CLIENT_EXCLUSIONS_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcAppliedClientExclusion`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          return response.data;
        } else {
          dispatch({
            type: SET_NDC_CLIENT_EXCLUSIONS,
            data: {},
          });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_CLIENT_EXCLUSIONS_LOADING, data: false });
        return {};
      });
  };
};

export const getClientExceptionsData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_CLIENT_EXCEPTION_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcClientExceptions`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_CLIENT_EXCEPTION_LIST_LOADING, data: false });
        return {};
      });
  };
};

// NDC LIST REVIEW TAB
export const getNdcListReview = (listId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcListReview/${listId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getDynamicListParametersTblData = (payload) => {
  return () => {
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-dynamic-list-parameters-details`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        return {};
      });
  };
};

export const getAppliedClientExclusion = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: APPLIED_CLIENT_EXCLUSION_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcAppliedClientExclusion`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: APPLIED_CLIENT_EXCLUSION_GRID_DATA,
            data: response.data,
          });
          callback && callback(response.data);
        } else {
          dispatch({
            type: APPLIED_CLIENT_EXCLUSION_GRID_DATA,
            data: response.data || {},
          });
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({
          type: APPLIED_CLIENT_EXCLUSION_GRID_DATA,
          data: {},
        });
      })
      .finally(() =>
        dispatch({ type: APPLIED_CLIENT_EXCLUSION_LOADING, data: false })
      );
  };
};

export const exportNdcAppliedClientExclusions = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndcAppliedClientExclusion`,
      payload
    )
      .then((response) => {
        if (response) {
          const blob = new Blob([response], {
            type: "application/octet-stream",
          });
          FileSaver.saveAs(blob, `NDC Applied Client Exclusion List.xlsx`);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getDraftExclusionList = (data) => {
  return (dispatch) => {
    dispatch({ type: DRAFT_EXCLUSION_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-draft-exclusion-list-details`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: DRAFT_EXCLUSION_GRID_DATA,
            data: response.data,
          });
        } else {
          dispatch({
            type: DRAFT_EXCLUSION_GRID_DATA,
            data: response.data,
          });
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({
          type: DRAFT_EXCLUSION_GRID_DATA,
          data: [],
        });
      })
      .finally(() => {
        dispatch({ type: DRAFT_EXCLUSION_LOADING, data: false });
      });
  };
};

export const exportNdcDraftExclusionList = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-draft-exclusion-list-details`,
      payload
    )
      .then((response) => {
        if (response) {
          const blob = new Blob([response], {
            type: "application/octet-stream",
          });
          FileSaver.saveAs(blob, `NDC Draft Exclusion List.xlsx`);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getNdcClientRelationshipList = (data) => {
  return (dispatch) => {
    dispatch({ type: NDC_CLIENT_RELATIONSHIP_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/global-clients`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_NDC_CLIENT_RELATIONSHIP,
            data: response.data,
          });
        } else {
          dispatch({
            type: SET_NDC_CLIENT_RELATIONSHIP,
            data: response.data,
          });
        }
        return response.data;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({
          type: SET_NDC_CLIENT_RELATIONSHIP,
          data: {},
        });
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_CLIENT_RELATIONSHIP_LOADING, data: false });
      });
  };
};

export const getReviewNdcHistory = (listHistoryId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.put(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/review-ndc-history?listHistoryId=${listHistoryId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return true;
        } else {
          toast.error(response.errorMessage);
          return false;
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return false;
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getNdcListExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-list-main-grid`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getNdcListApplicationData = (listHistoryId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/list-auto/${listHistoryId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return {};
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const saveNdcListApplication = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/client-list-exceptions`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getWholeSalers = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/search-wholesalers`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getManufacturers = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/search-manufacturer`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const NdcListDelete = (data, callback) => {
  const { listId, inactiveFlag } = data;
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.delete(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-list-delete/${listId}/${inactiveFlag}`
    ).then((response) => {
      toast.success(response.successMessage);
      callback && callback(response);
      dispatch({ type: GLOBAL_LOADING, data: false });
    });
  };
};
export const getNdcAllDropdowns = (data, callback, setLoading) => {
  return (dispatch) => {
    dispatch({ type: NDC_FILTERS_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-filters`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        setLoading && setLoading(false);
      });
  };
};

export const getNdcFiltersTherapeuticClass = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-filters-therapeutic-class`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getNdcFiltersManufacturer = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-filters-manufacturer`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const fetchNdcSectionStatus = (listId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-section-status/${listId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return {};
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const getListReviewTabExportPdf = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-pdf`,
      payload
    )
      .then((res) => {
        const listReview = document.createElement("a");
        listReview.style.display = "none";
        document.body.appendChild(listReview);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        listReview.href = url;
        listReview.download = "NDC List Review.pdf";
        listReview.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getDynamicListSourceTypes = () => {
  return async (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return await ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/sourceTypes`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getDrugAttributeOneTypes = (sourceId = 0) => {
  return async (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return await ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/drugAttributeOne/${sourceId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getDrugAttributeTwoTypes = (drugAttributeOneId = 0) => {
  return async (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return await ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/drug-attribute-two/${drugAttributeOneId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const saveDynamicListParameters = (payload) => {
  return async (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return await ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-exclusion-dynamic-list`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response;
        } else return {};
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

//
export const getDynamicListParametersTableData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_DYNAMIC_LIST_PARAMS_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-dynamic-list-parameters-details`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: NDC_DYNAMIC_LIST_PARAMS_LOADED,
            data: response.data,
          });
          return response.data;
        } else {
          dispatch({
            type: NDC_DYNAMIC_LIST_PARAMS_LOADED,
            data: {},
          });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({
          type: NDC_DYNAMIC_LIST_PARAMS_LOADED,
          data: {},
        });
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_DYNAMIC_LIST_PARAMS_LOADING, data: false });
        return {};
      });
  };
};

export const getAppliedNdcExclusions = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_DYNAMIC_EXCLUSION_TABLE_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/appliedNDCExclusionList`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_DYNAMIC_EXCLUSION_TABLE_LOADING, data: false });
        return {};
      });
  };
};

export const getDynamicNdcExceptions = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: NDC_CLIENT_EXCEPTION_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/dynamic-ndc-exceptions`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => {
        dispatch({ type: NDC_CLIENT_EXCEPTION_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const saveDynamicExclusionsAndExceptions = (
  payload = {},
  setLoading
) => {
  return async (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return await ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/ndc-exclusion-list-client-map`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return true;
        } else {
          return false;
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return false;
      })
      .finally(() => {
        setLoading && setLoading(false);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const validateNdcFile = ({
  data,
  successCallback,
  setProgress,
  setLoading,
}) => {
  return async (_dispatch) => {
    return await ApiClient._postFormData(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/validate-upload-file`,
      data,
      { setProgress }
    )
      .then((response) => {
        successCallback(response);
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        return error;
      })
      .finally(() => {
        setLoading(false);
      });
  };
};

export const ndcBulkUpload = ({
  data,
  listHistoryId,
  callback,
  setProgress,
}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient._postFormData(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/upload-ndc/${listHistoryId}`,
      data,
      { setProgress }
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
        } else {
          toast.error(response.errorMessage);
        }
        callback(response);
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const downloadNdcErrorFile = (path) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ndcexclusion/download-error-file?filePath=${encodeURIComponent(
        path
      )}`
    )
      .then((res) => {
        const a = document.createElement("a");
        a.style.display = "none";
        document.body.appendChild(a);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        a.href = url;
        a.download = "Error_File.xlsx";
        a.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};
