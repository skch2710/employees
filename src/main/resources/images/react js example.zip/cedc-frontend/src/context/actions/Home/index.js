import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import { apiUrlUser, PORT, reportService } from "../../../environment";
import "react-toastify/dist/ReactToastify.css";
import _isArray from "lodash/isArray";
export const Homeclaimsavings = (data, setgetHomeclaimsavings) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/claimsavings`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setgetHomeclaimsavings(response.data);
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          setgetHomeclaimsavings({});
          dispatch({ type: "ISLOADING", data: false });
        } else {
          setgetHomeclaimsavings({});
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const totalUnrealizedSavingsCOGS = (
  data,
  setgetTotalUnrealizedSavingsCOGS
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/unrealizedsavings`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setgetTotalUnrealizedSavingsCOGS(response.data);
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          setgetTotalUnrealizedSavingsCOGS({});
          dispatch({ type: "ISLOADING", data: false });
        } else {
          setgetTotalUnrealizedSavingsCOGS({});
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const HomeActivCountslocations = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/activeLocation/${data.ceId}`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "HomeActivCounts_locations", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          dispatch({ type: "HomeActivCounts_locations", data: response.data });
        } else {
          dispatch({ type: "HomeActivCounts_locations", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const HomeActivCountspatients = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/activePatient/${data.ceId}`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "HomeActivCounts_patients", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          dispatch({ type: "HomeActivCounts_patients", data: response.data });
        } else {
          dispatch({ type: "HomeActivCounts_patients", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const HomeActivCountsproviders = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/activeProvider/${data.ceId}`
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      if (response.statusCode === 200) {
        dispatch({ type: "HomeActivCounts_providers", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "HomeActivCounts_providers", data: response.data });
      } else {
        dispatch({ type: "HomeActivCounts_providers", data: response.data });
      }
    });
  };
};

export const HomeActivCountspharmacies = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/activePharmacy/${data.ceId}`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "HomeActivCounts_pharmacies", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          dispatch({ type: "HomeActivCounts_pharmacies", data: response.data });
        } else {
          dispatch({ type: "HomeActivCounts_pharmacies", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const Homefalloutfirstpiechart = (
  data,
  setgetHomefalloutfirstpiechart
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/falloutSavingsSearchDonut`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        setgetHomefalloutfirstpiechart(response.data);
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        setgetHomefalloutfirstpiechart({});
        dispatch({ type: "ISLOADING", data: false });
      } else {
        setgetHomefalloutfirstpiechart({});
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const Homeunreplinvsecoundpiechart = (
  data,
  setgetHomeunreplinvsecoundpiechart
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/unreplenishedInventoryCostDonut`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setgetHomeunreplinvsecoundpiechart(response.data);
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          setgetHomeunreplinvsecoundpiechart({});
          dispatch({ type: "ISLOADING", data: false });
        } else {
          setgetHomeunreplinvsecoundpiechart({});
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const Homefalloutfirstfiverecords = (
  data,
  setgetHomefalloutfirstfiverecords
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/falloutSavingsSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setgetHomefalloutfirstfiverecords(response.data);
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          setgetHomefalloutfirstfiverecords({});
          dispatch({ type: "ISLOADING", data: false });
        } else {
          setgetHomefalloutfirstfiverecords({});
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const Homeinventoryreplirecords = (
  data,
  setgetHomeinventoryreplirecords
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/unreplenishedInventoryCostSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setgetHomeinventoryreplirecords(response.data);
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          setgetHomeinventoryreplirecords({});
          dispatch({ type: "ISLOADING", data: false });
        } else {
          setgetHomeinventoryreplirecords({});
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const Homebarchatsavbypharma = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/savingsByPharmacy`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: "SAVE_BY_PHARMA_BAR_CHART_DATA",
            data: response.data,
          });
          return callback && callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({
            type: "SAVE_BY_PHARMA_BAR_CHART_DATA",
            data: {},
          });
          return callback && callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error);
        dispatch({
          type: "SAVE_BY_PHARMA_BAR_CHART_DATA",
          data: {},
        });
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const ViewFullreportdonut1fallout = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/falloutSavingsViewFullReport`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: "ViewFullreport_donut1fallout",
            data: response.data,
          });
          return callback && callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const ViewFullreportdonut1falloutexport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/falloutSavingsViewFullReport`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: "ViewFullreport_donut1fallout_export",
            data: response.data,
          });
          return callback && callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const ViewFullReportUnrep = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/unreplenishedViewFullReportSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "ViewFullreport_donut2", data: response.data });
          return callback && callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const ViewFullReportUnrepExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/unreplenishedViewFullReportSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: "ViewFullreport_donut2export",
            data: response.data,
          });
          return callback && callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const invoiceCycle = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/dashBoard/invoiceCycle`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else {
          callback({});
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};
