export const initialCEs = {
  ceList: [],
  isLoading: false,
};
export const initialNdcList = {
  ndcLists: [],
  isLoading: false,
};
export const initialGridList = {
  records: {},
  loading: false,
};

export const SET_COVERED_ENTITIES = "SET_COVERED_ENTITIES";
export const IS_CE_LOADING = "IS_CE_LOADING";
export const SET_NDC_LISTS = "SET_NDC_LISTS";
export const SET_NDC_LIST_LOADING = "SET_NDC_LIST_LOADING";
