import { Auth } from './Auth';
import { Usermanagement } from './Usermanagement';
import {Patients} from "./Patients";
import {providersalldata} from "./providers";
import {inventoryListData} from "./Inventory";




export const useActions = (state, dispatch) => {
    return {
        Auth: Auth({ state, dispatch }),
        Usermanagement: Usermanagement({ state, dispatch }),
        providersalldata: providersalldata({ state, dispatch }),
        Patients:Patients({state,dispatch},),
        inventoryListData:inventoryListData({state,dispatch},)
    
    }

}

