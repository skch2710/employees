import {
  initialCEs,
  initialNdcList,
  IS_CE_LOADING,
  SET_COVERED_ENTITIES,
  SET_NDC_LIST_LOADING,
  SET_NDC_LISTS,
} from "./constants";

export const coveredEntities = (state = initialCEs, action) => {
  switch (action.type) {
    case SET_COVERED_ENTITIES:
      return {
        ceList: action.data,
      };
    case IS_CE_LOADING:
      return {
        isLoading: action.data,
      };
    default:
      return state;
  }
};

export const ndcLists = (state = initialNdcList, action) => {
  switch (action.type) {
    case SET_NDC_LISTS:
      return {
        ...state,
        ndcLists: action.data,
      };
    case SET_NDC_LIST_LOADING:
      return {
        ...state,
        loading: action.data,
      };
    default:
      return state;
  }
};
