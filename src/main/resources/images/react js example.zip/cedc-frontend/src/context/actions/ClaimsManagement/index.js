import { toast } from "react-toastify";
import ApiClient, { axiosInstance } from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  configService,
  managedService,
} from "../../../environment";
import axios from "axios";
import {
  CLAIMS_LIST_LOADING,
  RX_NUMBER_DETAILS,
  RX_NUMBER_DETAILS_LOADING,
  SET_CLAIMS_LIST,
} from "../../reducers/ClaimsManagement/constants";
import { GLOBAL_LOADING } from "../../constants";
import { getUserSession } from "../../../utils/helper";

const token = localStorage.Accesstoken;
const userSession = getUserSession();

export const getClaimsManagementTableData = (data) => {
  return (dispatch) => {
    dispatch({ type: CLAIMS_LIST_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/search`,
      data,
      token
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: SET_CLAIMS_LIST, data: response.data });
        } else {
          dispatch({ type: SET_CLAIMS_LIST, data: response.data });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: CLAIMS_LIST_LOADING, data: false });
      });
  };
};

export const claimsManagementExport = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/search`,
      data
    )
      .then((res) => {
        const claimsExport = document.createElement("a");
        claimsExport.style.display = "none";
        document.body.appendChild(claimsExport);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        claimsExport.href = url;
        claimsExport.download = "Claims Management List.xlsx";
        claimsExport.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getPatientMRN = (data, callback) => {
  return () => {
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/PatientMRN`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response.data);
        }
      })
      .catch((error) => toast.error(error.message));
  };
};

export const getRxNumber = (data, callback) => {
  ApiClient.post(
    `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/RxNumber`,
    data
  )
    .then((response) => {
      if (response.statusCode === 200) {
        callback && callback(response.data);
      }
    })
    .catch((error) => {
      toast.error(error.message);
      callback && callback([]);
    });
};

export const getPatientFn = (data, callback) => {
  return (dispatch) => {
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/patientFirstName`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        callback && callback(response.data);
      }
    });
  };
};

export const getPatientLn = (data, callback) => {
  return (dispatch) => {
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/patientLastName`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        callback && callback(response.data);
      }
    });
  };
};

export const getClaimStatus = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/claimsStatuslkp`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "claimStatus", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "claimStatus", data: response.data });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "claimStatus", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getClaimType = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/claimType`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "claimType", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "claimType", data: response.data });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "claimType", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getBrandGenericBoth = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/brandGenericBoth`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "brandGenericBoth", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "brandGenericBoth", data: response.data });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "brandGenericBoth", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getShowPatientInformation = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pateintyesornoinformation`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "yesNo", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "yesNo", data: response.data });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "yesNo", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getFalloutReason = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/falloutReason/${userSession.isInternalUser}`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "fallout_reason", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "fallout_reason", data: response.data });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "fallout_reason", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getBIN = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/bin`
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response.statusCode === 200) {
          dispatch({ type: "BIN", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "BIN", data: response.data });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "BIN", data: response.data });
          toast.error(response.errorMessage);
        }
      })
      .catch((res) => {
        toast.error(res.errorMessage || "Something went wrong");
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getRxNumberDetails = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/claimsManagement/getRxDetails`,
      data,
      token
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: RX_NUMBER_DETAILS, data: response.data });
        } else {
          dispatch({ type: RX_NUMBER_DETAILS, data: response.data });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};
