const initialState = {
  loggedIn: false,
  isActive: "",
  user: {},
  loading: false,
};
export const user = (state = initialState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "LOGIN":
      return { ...state, ...{ loggedIn: true }, ...action.data };
    case "validateOTP":
      return { ...state, ...{ loggedIn: true }, ...action.data };
    case "LOGOUT":
      localStorage.removeItem("Accesstoken");
      localStorage.removeItem("Refreshtoken");
      localStorage.removeItem("sessionslogindata");
      return initialState;
    default:
      return state;
  }
};

const initialSecurityState = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

export const securityQuestionList = (state = initialSecurityState, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "getSecurityQuestions":
      return {
        ...state.securityQuestionList,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};
