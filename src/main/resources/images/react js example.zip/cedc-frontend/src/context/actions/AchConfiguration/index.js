import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import { PORT, apiUrlUser, configService } from "../../../environment";
import { GLOBAL_LOADING } from "../../constants";

export const saveAchConfiguration = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredEntitiesAchConfigurations`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return callback(response);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      })
      .catch((error) => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        toast.error(error.message);
      });
  };
};

export const achMessageUUID = (data, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredEntities/AchConfigurations/messageUUID/${data}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode == 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};
