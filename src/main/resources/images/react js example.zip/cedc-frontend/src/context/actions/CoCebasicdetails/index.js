import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  userService,
  configService,
} from "../../../environment";
import "react-toastify/dist/ReactToastify.css";
import { GLOBAL_LOADING } from "../../constants";


export const CoCebasicdetails = (payload) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredEntitiesBasicDetails`,
      payload
    )
      .then((response) => {
        return response;
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
        return {};
      });
  };
};

export const Cobasicdetailsmsguuid = (Uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredEntities/basicDetails/messageUUID/${Uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const getstates = (data, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/states`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "states_list", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        toast.error(response.errorMessage);
      } else {
        toast.error(response.errorMessage);
      }
    });
  };
};

export const CETypedropdownlist = (data, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityType`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "CE_Type_dropdownlist", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        toast.error(response.errorMessage);
      } else {
        toast.error(response.errorMessage);
      }
    });
  };
};

export const getCecodeExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/cecodeexist/${data}`
    )
      .then((response) => {
        callback && callback(response);
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getEmailExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/emailexist/${data.email}` )
      .then((response) => {
        if (response.statusCode === 200) {
          return callback(true);
        } else if (response.statusCode === 404) {
          return callback(false);
        } 
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const PrimaryContactdetails = (ceId) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/userPrimaryContact/${ceId}` )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};