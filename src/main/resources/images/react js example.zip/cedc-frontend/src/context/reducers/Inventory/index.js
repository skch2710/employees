import {

  INVENTORY_SEARCH,
  INVENTORY_LOADING,
  GET_INVENTORY_INNER_LIST,
  GET_INVENTORY_INNER_SUBGRIDLIST,
} from "../../constants";

const initialgetInventoryrole = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetInventoryrole1 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};

const initialgetInventoryrole2 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole3 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole4 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole5 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole6 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole7 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole8 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};
const initialgetInventoryrole9 = {
  records: [],
  count: 0,
  isActive: "",
  loading: false,
};




export const inventoryListData = (state = initialgetInventoryrole1, action) => {
  const { data = {} } = action || {};
  switch (action.type) {
    case INVENTORY_LOADING:
      return { ...state, loading: data };
    case INVENTORY_SEARCH:
      return {
        ...state.inventoryListData,
        records: data,
        count: data ? data.totalElements : 0,
      };
    case "LOGOUT":
      return initialgetInventoryrole1;
    default:
      return state;
  }
};



export const Inventorymainexportdata = (
  state = initialgetInventoryrole2,
  action
) => {
  switch (action.type) {
    case "Inventory_main_Export":
      return {
        ...state.Inventorymainexportdata,
        records: action.data,
        count: action.data.totalElements,
      };
    case "LOGOUT":
      return initialgetInventoryrole2;
    default:
      return state;
  }
};

export const getPharamacyInv = (state = initialgetInventoryrole2, action) => {
  switch (action.type) {
    case "pharmacyStore":
      return {
        ...state.getPharamacyInv,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const Inventoryinnergridexportdata = (
  state = initialgetInventoryrole3,
  action
) => {
  switch (action.type) {
    case "Inventory_innergrid_Export":
      return {
        ...state.Inventoryinnergridexportdata,
        records: action.data,
        count: action.data.totalElements,
      };
    case "LOGOUT":
      return initialgetInventoryrole3;
    default:
      return state;
  }
};

export const InventoryinnerSubgridexportdata = (
  state = initialgetInventoryrole4,
  action
) => {
  switch (action.type) {
    case "Inventory_innerSubgrid_Export":
      return {
        ...state.InventoryinnerSubgridexportdata,
        records: action.data,
        count: action.data.totalElements,
      };
    case "LOGOUT":
      return initialgetInventoryrole4;
    default:
      return state;
  }
};

export const getinventoryInnerGrid = (
  state = initialgetInventoryrole5,
  action
) => {
  switch (action.type) {
    case "INVENTORY_LOADING":
      return { ...state, loading: action.data };
    case "GET_INVENTORY_INNER_LIST":
      return {
        ...state.getinventoryInnerGrid,
        records: action.data,
        count: action.data.totalElements,
      };
    case "LOGOUT":
      return initialgetInventoryrole5;
    default:
      return state;
  }
};


export const getinventorySubInnerGrid = (
  state = initialgetInventoryrole6,
  action
) => {
  switch (action.type) {
    case "INVENTORY_LOADING":
      return { ...state, loading: action.data };
    case "GET_INVENTORY_INNER_SUBGRIDLIST":
      return {
        ...state.getinventorySubInnerGrid,
        records: action.data,
        count: action.data.totalElements,
      };
    case "LOGOUT":
      return initialgetInventoryrole6;
    default:
      return state;
  }
};



export const get340bAvalues = (state = initialgetInventoryrole7, action) => {
  switch (action.type) {
    case "340bAvalues":
      return {
        ...state.get340bAvalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getWholeSalervalues = (
  state = initialgetInventoryrole8,
  action
) => {
  switch (action.type) {
    case "WholeSalervalues":
      return {
        ...state.getWholeSalervalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getScheduleTypevalues = (
  state = initialgetInventoryrole9,
  action
) => {
  switch (action.type) {
    case "ScheduleTypevalues":
      return {
        ...state.getScheduleTypevalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getDrugManufacturervalues = (
  state = initialgetInventoryrole,
  action
) => {
  switch (action.type) {
    case "DrugManufacturervalues":
      return {
        ...state.getDrugManufacturervalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getPharmacystorevalues = (
  state = initialgetInventoryrole,
  action
) => {
  switch (action.type) {
    case "Pharmacystorevalues":
      return {
        ...state.getPharmacystorevalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getPharmacyvalues = (state = initialgetInventoryrole, action) => {
  switch (action.type) {
    case "Pharmacyvalues":
      return {
        ...state.getPharmacyvalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getPharmacygroupvalues = (
  state = initialgetInventoryrole,
  action
) => {
  switch (action.type) {
    case "Pharmacygroupvalues":
      return {
        ...state.getPharmacygroupvalues,
        records: action.data,
        count: action.data ? action.data.length : 0,
      };
    default:
      return state;
  }
};
export const getCoveredEntityvalues = (
  state = initialgetInventoryrole,
  action
) => {
  switch (action.type) {
    case "CoveredEntityvalues":
      return {
        ...state.getCoveredEntityvalues,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};

export const getinventoryFilterTypes = (
  state = initialgetInventoryrole,
  action
) => {
  switch (action.type) {
    case "inventoryFilterTypes":
      return {
        ...state.getinventoryFilterTypes,
        records: action.data,
        count: action.data.length,
      };
    default:
      return state;
  }
};
