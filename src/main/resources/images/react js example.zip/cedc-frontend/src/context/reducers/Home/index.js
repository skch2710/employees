const initialgethomeClaims = {
  records: {},
  count: 0,
  isActive: "",
  loading: false,
};

export const getHomeclaimsavings = (state = initialgethomeClaims, action) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "Home_claim_savings":
      return { ...state.getHomeclaimsavings, records: action.data };
    default:
      return state;
  }
};

export const getHomeActivCountslocations = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "HomeActivCounts_locations":
      return { ...state.getHomeActivCountslocations, records: action.data };
    default:
      return state;
  }
};

export const getHomeActivCountspatients = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "HomeActivCounts_patients":
      return { ...state.getHomeActivCountspatients, records: action.data };
    default:
      return state;
  }
};

export const getHomeActivCountsproviders = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "HomeActivCounts_providers":
      return { ...state.getHomeActivCountsproviders, records: action.data };
    default:
      return state;
  }
};

export const getHomeActivCountspharmacies = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "HomeActivCounts_pharmacies":
      return { ...state.getHomeActivCountspharmacies, records: action.data };
    default:
      return state;
  }
};

export const getViewFullreportdonut1fallout = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "VIEW_FULL_REPORT_1_DONUT_LOADING":
      return { ...state, loading: action.data };
    case "ViewFullreport_donut1fallout":
      return { ...state.getViewFullreportdonut1fallout, records: action.data };
    default:
      return state;
  }
};

export const getViewFullreportdonut1falloutexport = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "ViewFullreport_donut1fallout_export":
      return {
        ...state.getViewFullreportdonut1falloutexport,
        records: action.data,
      };
    default:
      return state;
  }
};

export const getViewFullReportUnrep = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "VIEW_FULL_REPORT_2_DONUT_LOADING":
      return { ...state, loading: action.data };
    case "ViewFullreport_donut2":
      return { ...state.getViewFullReportUnrep, records: action.data };
    default:
      return state;
  }
};

export const getViewFullreportdonut2export = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "ISLOADING":
      return { ...state, loading: action.data };
    case "ViewFullreport_donut2export":
      return { ...state.getViewFullreportdonut2export, records: action.data };
    default:
      return state;
  }
};

export const getHomeBarChatSavingByPharma = (
  state = initialgethomeClaims,
  action
) => {
  switch (action.type) {
    case "SAVE_BY_PHARMA_BAR_CHART_LOADING":
      return { ...state, loading: action.data };
    case "SAVE_BY_PHARMA_BAR_CHART_DATA":
      return { ...state.getHomeBarChatSavingByPharma, records: action.data };
    default:
      return state;
  }
};
