import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import { PORT, apiUrlUser, userService } from "../../../environment";
import { axiosInstance } from "../../../api-client";
import { GLOBAL_LOADING, UM_LOADING } from "../../constants";

export const getUserrole = (data, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/login/roles`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "userrole", data: response.data });
        } else if (response.statusCode === 404) {
          return callback(response);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      });
  };
};

export const getEmailExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: UM_LOADING, data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/emailexist/${data.email}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(true);
        } else {
          callback(false);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: UM_LOADING, data: false }));
  };
};

export const getUsernameExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: UM_LOADING, data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/usernameexist/${data.userName}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return callback(true);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: UM_LOADING, data: false }));
  };
};

export const getprivilegesByRole = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: UM_LOADING, data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/privilegesByRole/${data.roleid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response);
        } else {
          callback({});
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: UM_LOADING, data: false }));
  };
};

export const coveredEntity = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/coveredEntity`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "coveredEntity", data: response.data });
          callback && callback(response);
        } else if (response.statusCode === 404) {
          return callback && callback(response);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getInternalTeam = (data, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/InternalTeam`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "internalteam", data: response.data });
        } else if (response.statusCode === 404) {
          return callback(response);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      });
  };
};

export const addUser = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/register`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return callback(response);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getAddUserMessageUUIDResponse = (messageUUID, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/findUserDetailsBymessageUUID/${messageUUID}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
          dispatch({ type: "ADD_USER", data: response.data });
        } else if (response.statusCode == 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const getUserList = (data) => {
  return (dispatch) => {
    dispatch({ type: UM_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_USER_LIST", data: response.data });
        } else {
          dispatch({ type: "GET_USER_LIST", data: response.data });
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: UM_LOADING, data: false }));
  };
};

export const bulkUpload = (data, json, callback, setProgress) => {
  return (dispatch) => {
    const { roleId, ceId, internalUser } = json;
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient._postFormData(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/upload/${roleId}/${ceId}/${internalUser}`,
      data,
      { setProgress }
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          dispatch({ type: "Bulk_Upload", data: response.data });
          return callback(response);
        } else {
          toast.error(response.errorMessage);
          dispatch({ type: "Bulk_Upload", data: response.data });
          return callback(response);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const validateUsersFile = (
  data,
  successCallback,
  rejectCallback,
  setProgress
) => {
  return (_dispatch) => {
    ApiClient._postFormData(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/validateUploadFile`,
      data,
      { setProgress }
    )
      .then((response) => {
        successCallback(response);
      })
      .catch((error) => {
        rejectCallback();
        toast.error(error.message);
      });
  };
};

export const editUser = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: UM_LOADING, data: true });
    ApiClient.put(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/editUser`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          dispatch({ type: "GET_UPDATE_USER_LIST", data: response.data });
          callback(response.statusCode);
        } else {
          dispatch({ type: "GET_UPDATE_USER_LIST", data: response.data });
          callback(response.statusCode);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: UM_LOADING, data: false });
      });
  };
};

export const getUserListExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/search`,
      data
    )
      .then((response) => {
        if (response.data) {
          toast.success(response.successMessage);
          return callback(response.data);
        }
        return callback(response);
      })
      .catch((error) => {
        toast.error(error.message || "Something went wrong");
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getActiveDeactive = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/activeDeactive/${data.userId}/${data.isActive}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          callback(response);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const DownloadErrorFile = (path) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    axiosInstance.defaults.responseType = "blob";
    ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/downloadErrorFile?filePath=${encodeURIComponent(
        path
      )}`
    )
      .then((res) => {
        const a = document.createElement("a");
        a.style.display = "none";
        document.body.appendChild(a);
        const blobFile = new Blob([res]);
        const url = window.URL.createObjectURL(blobFile);
        a.href = url;
        a.download = "Error_File.xlsx";
        a.click();
        window.URL.revokeObjectURL(url);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: "Bulk_Upload", data: null });
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};
