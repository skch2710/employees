import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  configService,
  managedService,
} from "../../../environment";
import { checkResponse } from "../../../utils/helper";
import { GLOBAL_LOADING } from "../../constants";
import { SET_COVERED_ENTITIES } from "../../reducers/Common/constants";
import {
  PH_BASIC_DETAILS_LOADING,
  SET_PH_BASIC_DETAILS,
} from "../../reducers/Pharmacies/constants";

export const getAllCoveredEntities = ({ disableLoader = false } = {}) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/activeCoveredEntities?resultObject=true`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: SET_COVERED_ENTITIES, data: response.data });
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getWholeSaler = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/searchWholesaler/${data.ceId}/${data.pharmacyId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getDrugManufacturer = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${managedService}/api/v1/inventory/drugManufacturer`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getPharmacyStore = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyStore`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getPharmacyGroups = (ceIds, disableLoader = false) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CoveredEntityPharmacyGroup`,
      {
        ceid: ceIds,
      }
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(
        () => !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};

export const getStates = (data) => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/states`,
    data
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    })
    .finally(() => {
      return [];
    });
};

export const getPharmacyNetworks = (disableLoader) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyNetworkList`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const validateNABP = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/NABPexist`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return true;
        } else if (response.statusCode === 404) {
          return false;
        } else {
          return true;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getRegions = ({ disableLoader }) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/regionLkp`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getDivisions = ({ disableLoader }) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/divisions`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getDistricts = ({ disableLoader }) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyDistrict`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const fetchPhBasicDetails = (
  clientId,
  { disableLoader = false, callback } = {}
) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader && dispatch({ type: PH_BASIC_DETAILS_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyBasicDetails/${clientId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          dispatch({ type: SET_PH_BASIC_DETAILS, data: response.data });
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader &&
          dispatch({ type: PH_BASIC_DETAILS_LOADING, data: false });
        return {};
      });
  };
};

export const getPhDrugManufacturers = ({ showLoader = true } = {}) => {
  return (dispatch) => {
    showLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/DrugManufacturer`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => {
        showLoader && dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};
