export const initialGridList = {
  records: {},
  loading: false,
};
