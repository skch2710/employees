import { toast } from "react-toastify";
import { PORT, apiUrlUser, reportService } from "../../../environment";
import { GLOBAL_LOADING } from "../../constants";
import { SET_POWER_BI_DETAILS } from "../../reducers/PowerBiReports/constants";
import ApiClient from "../../../api-client";

export const getAllPowerBiReports = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${reportService}/api/v1/powerBi/getEmbedValues`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: SET_POWER_BI_DETAILS, data: response.data });
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};
