import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import { apiUrlUser, PORT, configService } from "../../../environment";
import { checkResponse } from "../../../utils/helper";
import { GLOBAL_LOADING } from "../../constants";

export const savePhBasicDetails = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/addPharmacy`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const basicDetailsMessageUuidTest = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyConfigBasicDetails/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else if (response.statusCode === 500) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const fetchNpiOptions = (payload, setIsLoading) => {
  setIsLoading(true);
  return ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyNPI`,
    payload
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => setIsLoading(false));
};

export const fetchPhNameOptions = (payload, setIsLoading) => {
  setIsLoading(true);
  return ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyStore`,
    payload
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => setIsLoading(false));
};

export const fetchPhNPIOptions = (payload, setIsLoading) => {
  setIsLoading(true);
  return ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyNPI`,
    payload
  )
    .then((response) => {
      checkResponse(response);
      return response;
    })
    .catch((error) => toast.error(error.message))
    .finally(() => {
      setIsLoading(false);
      return [];
    });
};

export const fetchPhBasicDetails = (clientId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyBasicDetails/${clientId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const fetchClientFrequency = (clientId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/ClientAdminFeeFreqPlus/${clientId}`
    )
      .then((response) => {
        checkResponse(response);
        return response.data;
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const saveAdminFeeData = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/saveClientAdminFee`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          toast.success(response.successMessage);
          return true;
        } else if (response.statusCode === 404) {
          toast.error(response.errorMessage);
          return false;
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return false;
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

// export const fetchAdminFeeTableData = (payload) => {
//   return (dispatch) => {
//     dispatch({ type: GLOBAL_LOADING, data: true });
//     return ApiClient.post(
//       `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phAdminFeesDetails`,
//       payload
//     )
//       .then((response) => {
//         if (checkResponse(response)) {
//           return response.data;
//         } else {
//           return response.data;
//         }
//       })
//       .catch((error) => {
//         toast.error(error.message);
//       })
//       .finally(() => {
//         dispatch({ type: GLOBAL_LOADING, data: false });
//         return {};
//       });
//   };
// };

export const fetchDispensingFeeTypes = () => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/dispensingFeeType`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const fetchCeReimbursementModels = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/ceReimbursmentModelLkp`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => []);
};

export const fetchDispenseFeeCalcOptions = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/dispensingFeeCalculation`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => []);
};

export const fetchAppliedAcTypeOptions = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/appliedAcType`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => []);
};

export const getFormularyTypeOptions = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/FormulaType`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => []);
};

export const getDrugTypeOptions = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/DrugType`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message))
    .finally(() => []);
};

// export const fetchDispensingFeesTableData = (payload) => {
//   return (dispatch) => {
//     dispatch({ type: GLOBAL_LOADING, data: true });
//     return ApiClient.post(
//       `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phDispensingAddedFeesDetails`,
//       payload
//     )
//       .then((response) => {
//         if (checkResponse(response)) {
//           return response.data;
//         } else {
//           return response.data;
//         }
//       })
//       .catch((error) => toast.error(error.message))
//       .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
//   };
// };

export const saveDispensingFees = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/pharmacyConfigDispensingFee`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const validateDispensingFee = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/validateDispenFee`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const dispensingFeeMessageUuidTest = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/pharmacyConfigDispensingFee/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else if (response.statusCode === 500) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const editBillingAndFees = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.put(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/UpdateClientAdminFeeFreqPlus`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          toast.success(response.successMessage);
          return true;
        }
        return false;
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const saveBillingAndFees = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/saveClientAdminFeeFreqPlus`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          toast.success(response.successMessage);
          return true;
        }
        return false;
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};
