import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import { apiUrlUser, PORT, configService } from "../../../environment";
import { GLOBAL_LOADING } from "../../constants";

export const PhBillingModelList = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phbillingmodel`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const InventorySwellProgramLKPList = () => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/inventorySwellProgramLKP`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const phGroupOrderAndReplenishDetails = ({ clientId }) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phGroupOrderAndReplenishDetails/${clientId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const PhOrderingandReplMessageUuid = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/orderingAndReplenishment`,
      payload
    )
      .then((response) => {
        return response;
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const phOrderingAndReplenishmentSave = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/orderingAndReplenishment/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};
