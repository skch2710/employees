import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  configService,
} from "../../../environment";
import { checkResponse } from "../../../utils/helper";
import { GLOBAL_LOADING } from "../../constants";
import {
  PROVIDERS_LOCATION_TABLE_DATA_LOADING,
  SET_PROVIDERS_LOCATION_TABLE_DATA,
  SET_PROVIDERS_DEA_TABLE_DATA,
  SET_PROVIDERS_DEA_TABLE_DATA_LOADING,
} from "./constants";

let token = localStorage.Accesstoken;

export const providersExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const coveredEntity = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/user/coveredEntity`,
      data
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      // toast.dismiss();
      if (response.statusCode === 200) {
        // toast.success(response.successMessage);
        dispatch({ type: "coveredEntity", data: response.data });
        // return callback(response.data);
      } else if (response.statusCode === 404) {
        dispatch({ type: "PROVIDER_SEARCH", data: response.data });
        toast.error(response.errorMessage);
        return callback(response);
      } else {
        dispatch({ type: "PROVIDER_SEARCH", data: response.data });
        //Error message 500
        toast.error(response.errorMessage);
      }
    });
  };
};

export const ProvidersSearch = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING_PROVIDER", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "PROVIDER_SEARCH", data: response.data });
          return callback && callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({ type: "PROVIDER_SEARCH", data: response.data });
          return callback(response);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING_PROVIDER", data: false }));
  };
};

export const GetProviderstype = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });

    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/providerType`,
      data
    )
      .then((response) => {
        dispatch({ type: "ISLOADING", data: false });
        if (response) {
          dispatch({ type: "Providers_type", data: response.data });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getProvidersLocationGridData = (payload = {}, callback) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export &&
      dispatch({ type: PROVIDERS_LOCATION_TABLE_DATA_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}/${configService}/api/v1/provider/providerLocation`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          dispatch({
            type: SET_PROVIDERS_LOCATION_TABLE_DATA,
            data: response.data,
            isSelectedLocation: true,
          });
          return callback && callback(response.data);
        } else {
          return dispatch({
            type: SET_PROVIDERS_LOCATION_TABLE_DATA,
            data: response.data,
            isSelectedLocation: false,
          });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({
            type: PROVIDERS_LOCATION_TABLE_DATA_LOADING,
            data: false,
          });
      });
  };
};

export const saveProvider = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/addProvider`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const saveProviderMessageUuid = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/addProvider/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const getDropdownValue = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ceconfig/lookUp/${data}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type:
              data === "Providers"
                ? "PROVIDER_DROPDOWN_LIST"
                : "MEMBER_DROPDOWN_LIST",
            data: response.data,
          });
          return callback && callback(response);
        } else {
          toast.error(response.errorMessage);
        }
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const saveProviderDropVal = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/saveProviderBlkUploadFile`,
      data,
      token
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      // toast.dismiss();
      if (response.statusCode === 200) {
        dispatch({ type: "ISLOADING", data: false });
        toast.success(response.successMessage);
        callback && callback(response);
      } else if (response.status === 404) {
        dispatch({ type: "ISLOADING", data: false });
        toast.error(response.error);
        // return callback(response);
      } else {
        //Error message 500
        toast.error(response.error);
      }
    });
  };
};

export const fetchProviderConfigFile = (ceId, loading = true) => {
  return (dispatch) => {
    loading && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/providerBlkUploadFile/${ceId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(
        () => loading && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};

export const getProviderNpiExist = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/providerNPIexist/${data.ceid}/${data.npi}`
    )
      .then((response) => {
        if (response) {
          return response;
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getProviderNpi = (payload, setIsLoading) => {
  setIsLoading && setIsLoading(true);
  return ApiClient.post(
    `${apiUrlUser}${PORT}/${configService}/api/v1/provider/searchProviderNpi`,
    payload
  )
    .then((response) => {
      checkResponse(response);
      return response;
    })
    .catch((error) => toast.error(error.message))
    .finally(() => {
      setIsLoading && setIsLoading(false);
      return [];
    });
};

export const deleteProvider = (data, callback) => {
  const { ceid, prescriberId, id } = data;
  return (dispatch) => {
    dispatch({ type: "IS_ADDPR_LOADING", data: true });
    return ApiClient.delete(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/deleteProvider/${ceid}/${prescriberId}/${id}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: "IS_ADDPR_LOADING", data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: "IS_ADDPR_LOADING", data: false });
      });
  };
};

export const deleteProviderMessageUuid = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: "IS_ADDPR_LOADING", data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/deleteProviderStatus/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "IS_ADDPR_LOADING", data: false });
          toast.success("Provider terminated successfully");
        } else if (response.statusCode === 102) {
          dispatch({ type: "IS_ADDPR_LOADING", data: true });
        } else {
          dispatch({ type: "IS_ADDPR_LOADING", data: false });
          toast.error(response.errorMessage);
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: "IS_ADDPR_LOADING", data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: "IS_ADDPR_LOADING", data: false });
        }
      });
  };
};

export const getProviderSPIExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/providerSPI//${data}`
    )
      .then((response) => {
        return response;
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getProviderDEAExist = (data, loading = true) => {
  return (dispatch) => {
    loading && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/providerDEA/${data}`
    )
      .then((response) => {
        return response;
      })
      .catch((error) => toast.error(error))
      .finally(
        () => loading && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};

export const checkProviderType = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/validateProviderType/${data}`
    )
      .then((response) => {
        if (response) {
          return response;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return {};
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getProvidersDeaGridData = (payload = {}, callback) => {
  return (dispatch) => {
    dispatch({ type: SET_PROVIDERS_DEA_TABLE_DATA_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}/${configService}/api/v1/provider/DEADetailsSearch`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          dispatch({
            type: SET_PROVIDERS_DEA_TABLE_DATA,
            data: response.data,
          });
          return callback && callback(response.data);
        } else {
          dispatch({
            type: SET_PROVIDERS_DEA_TABLE_DATA,
            data: response.data,
          });
          return callback(response);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({
          type: SET_PROVIDERS_DEA_TABLE_DATA_LOADING,
          data: false,
        });
      });
  };
};

export const saveProviderDea = (payload, loading = true) => {
  return (dispatch) => {
    loading && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/saveOrUpdateProviderDEA`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        loading && dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const saveProviderDeaMessageUuid = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/findProviderDEABymessageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};
