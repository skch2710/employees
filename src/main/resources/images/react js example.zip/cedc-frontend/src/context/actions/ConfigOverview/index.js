import { toast } from "react-toastify";
import ApiClient, { axiosInstance } from "../../../api-client";
import {
  PORT,
  apiUrlUser,
  backendService,
  configService,
  userService,
} from "../../../environment";
import { GLOBAL_LOADING } from "../../constants";
import "react-toastify/dist/ReactToastify.css";
import { checkResponse } from "../../../utils/helper";
import _get from "lodash/get";
import {
  CE_ACH_CONFIG_LOADING,
  CE_BASIC_DETAILS_LOADING,
  CE_LOCATIONS_LIST_LOADING,
  CE_PRIMARY_DETAILS_LOADING,
  MEMBERS_LIST_LOADING,
  PROVIDERS_LIST_LOADING,
  SERVICE_AREA_CONFIG_LOADING,
  SET_CE_ACH_CONFIG,
  SET_CE_BASIC_DETAILS,
  SET_CE_LOCATIONS_LIST,
  SET_CE_PRIMARY_CONTACT_DETAILS,
  SET_CO_MEMBERS_LIST,
  SET_CO_PROVIDERS_LIST,
  SET_CO_TERMS_LIST,
  SET_SERVICE_AREA_CONFIG,
  SET_VISIT_WINDOW_CONFIG,
  TERMS_LIST_LOADING,
  VISIT_WINDOW_CONFIG_LOADING,
} from "../../reducers/ConfigOverview/constants";
import moment from "moment";
import FileSaver from "file-saver";

let token = localStorage.Accesstoken;
toast.configure();

export const getBasicDetailData = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/ceBasicDetails`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_BASIC_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_BASIC_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_BASIC_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const getConfigSearchData = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/search`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_CONFIG_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_CONFIG_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_CONFIG_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const getConfigSearchexport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/configSearch`,
      data
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      if (response.statusCode === 200) {
        return callback(response.data);
      } else {
        return callback([]);
      }
    });
  };
};

export const getConfigSearchData_ = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/configSearch`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_CONFIG_DETAIL_Data", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
          callback(response.data);
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_CONFIG_DETAIL_Data", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
          callback(response.data);
        } else if (response.statusCode === 500) {
          dispatch({ type: "GET_CONFIG_DETAIL_Data", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
          callback(false);
        } else {
          dispatch({ type: "GET_CONFIG_DETAIL_Data", data: [] });
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => {
        callback(false);
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const fetchTermsGridTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: TERMS_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/configSearch`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_CO_TERMS_LIST, data: response.data });
          return response.data;
        } else {
          !payload.export &&
            dispatch({ type: SET_CO_TERMS_LIST, data: response.data });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export && dispatch({ type: TERMS_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const fetchTermsSingleData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/configSearch`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const fetchProvidersTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: PROVIDERS_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/search`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_CO_PROVIDERS_LIST, data: response.data });
          return response.data;
        } else {
          !payload.export &&
            dispatch({ type: SET_CO_PROVIDERS_LIST, data: response.data });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: PROVIDERS_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const fetchMembersTableData = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: MEMBERS_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/search`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_CO_MEMBERS_LIST, data: response.data });
          return response.data;
        } else {
          !payload.export &&
            dispatch({ type: SET_CO_MEMBERS_LIST, data: response.data });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: MEMBERS_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const getConfigceConfigDetails = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/ceConfigDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_CE_CONFIG_DETAIL", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_CE_CONFIG_DETAIL", data: response.data });
        } else {
          dispatch({ type: "GET_CE_CONFIG_DETAIL", data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getACHDetailData = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/ceACHDetails`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_ACH_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_ACH_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_ACH_DETAIL", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const getPHBasicDetailsData = (clientId, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmacyBasicDetails/${clientId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback(response.data);
        } else if (response.statusCode === 404) {
          callback(response.data);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getphEligibilityDetails = (clientId, setElData) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phEligibilityDetails/${clientId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setElData(response);
        } else if (response.statusCode === 404) {
          setElData(response);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

//phGroupOrderAndReplenishDetails
export const phGroupOrderAndReplenishDetails = (clientId, setphGroupOrder) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phGroupOrderAndReplenishDetails/${clientId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setphGroupOrder(response.data);
        } else if (response.statusCode === 404) {
          setphGroupOrder(response.data);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};
// phEligibilityDetails
export const phEligibilityDetails = (clientId, setphElOrder) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phEligibilityDetails/${clientId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setphElOrder(response.data);
        } else if (response.statusCode === 404) {
          setphElOrder(response.data);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

// uploadDocAPI

export const uploadDocAPI = (data, setUploadApiData) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phUploadedDocDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setUploadApiData(response.data);
        } else if (response.statusCode === 404) {
          setUploadApiData(response.data);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};
// trueUpAddedAPI
export const trueUpAddedAPI = (data, setTrueUpData) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/TrueUpAddedFeesDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setTrueUpData(response.data);
        } else if (response.statusCode === 404) {
          setTrueUpData(response.data);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

//phNetworkBINBlocksDetails
export const phNetworkBINBlocksDetails = (
  data,
  setPhNetworkData,
  setloader
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phNetworkBINBlocksDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setPhNetworkData(response.data);
          setloader(false);
        } else if (response.statusCode === 404) {
          setPhNetworkData(response.data);
          setloader(false);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

// Global BIn Blocks
export const globalBinBlocks = (data, setGlobalBinData, setloader) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/binPcnConfigDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setGlobalBinData(response.data);
          setloader(false);
        } else if (response.statusCode === 404) {
          setGlobalBinData(response.data);
          setloader(false);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

// CE Bin Blocks
export const ceBinBlocks = (data, setCeBinData, setloader) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/phCEBINBlocksDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setCeBinData(response.data);
          setloader(false);
        } else if (response.statusCode === 404) {
          setCeBinData(response.data);
          setloader(false);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

// cleint bin blocks
export const clientBinBlocks = (data, setClientBinData, setloader) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phClientBINBlocksDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setClientBinData(response.data);
          setloader(false);
        } else if (response.statusCode === 404) {
          setClientBinData(response.data);
          setloader(false);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};
// phDispensingAPI
export const phDispensingAPI = (data, setphDispensingData, setLoader) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phDispensingAddedFeesDetails`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          setphDispensingData(response.data);
          setLoader(false);
        } else if (response.statusCode === 404) {
          setphDispensingData(response.data);
          setLoader(false);
        }
      })
      .catch((error) => {
        setLoader(false);
        toast.error(error.message);
      })
      .finally(() => {
        setLoader(false);
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getBillingfeeDetailData = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/ceBillingFee`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_BILLING_FEE_DETAIL", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_BILLING_FEE_DETAIL", data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getServiceAreaConfigDetailData = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/ceServiceAreaConfig`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_SERVICE_CONFIG_DETAIL", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_SERVICE_CONFIG_DETAIL", data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getVisitWindowDetailData = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/ceconfiguration/ceVisitWindow`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_VISIT_DETAIL", data: response.data });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_VISIT_DETAIL", data: response.data });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getCeVisitWindowConfig = (ceId, { callback } = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    dispatch({ type: VISIT_WINDOW_CONFIG_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ceVisitWindow/${ceId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_VISIT_WINDOW_CONFIG,
            data: response.data,
          });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          dispatch({
            type: SET_VISIT_WINDOW_CONFIG,
            data: response.data || {},
          });
          return response.data || {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        dispatch({ type: VISIT_WINDOW_CONFIG_LOADING, data: false });
        return {};
      });
  };
};

export const phDispensingAddedFeesDetailsExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phDispensingAddedFeesDetails`,
      data
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        return callback([]);
      } else {
        return callback([]);
      }
    });
  };
};

// phTrueUpFeesDetailsExport

export const phTrueUpFeesDetailsExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/pharmacyconfiguration/phTrueUpAddedFeesDetails`,
      data
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        return callback([]);
      } else {
        return callback([]);
      }
    });
  };
};
export const phGlobalBinBlocksExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/pharmacyconfiguration/phGlobalBINBlocksDetails`,
      data
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        return callback([]);
      } else {
        return callback([]);
      }
    });
  };
};
export const phNetworkBINBlocksExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/pharmacyconfiguration/phNetworkBINBlocksDetails`,
      data
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        return callback([]);
      } else {
        return callback([]);
      }
    });
  };
};
export const phClientBINBlocksExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/pharmacyconfiguration/phClientBINBlocksDetails`,
      data
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        return callback([]);
      } else {
        return callback([]);
      }
    });
  };
};

export const CEBinExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${backendService}/api/pharmacyconfiguration/phCEBINBlocksDetails`,
      data
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        return callback([]);
      } else {
        return callback([]);
      }
    });
  };
};

// New API
export const serviceAreaConfig = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ceServiceAreaDetails`,
      data,
      token
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "GET_SERVICE_CONFIG", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_SERVICE_CONFIG", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_SERVICE_CONFIG", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};
const serviceAreas = [
  { configItemId: 1, configurationItem: "Servicing Facility" },
  { configItemId: 2, configurationItem: "Patient Type" },
  { configItemId: 3, configurationItem: "Admit Type" },
  { configItemId: 4, configurationItem: "Hospital Service" },
  { configItemId: 5, configurationItem: "Patient Location" },
  { configItemId: 6, configurationItem: "Prescriber" },
  { configItemId: 7, configurationItem: "Prescriber Panel Type" },
];

const getServiceAreaType = (value) => {
  const filterArray = serviceAreas.filter(
    (key) =>
      key.configurationItem === value.replace(/\s+/g, " ").trim() ||
      key.configItemId == value
  );
  return (
    filterArray &&
    filterArray.length > 0 &&
    filterArray[0].configItemId.toString()
  );
};

export const visitWindowConfig = (
  data,
  value = false,
  setFormState,
  arr,
  trueFalseValue
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ceVisitWindow/${data.ceid}`,
      token
    )
      .then((response) => {
        if (response.data) {
          dispatch({ type: "GET_VISIT_CONFIG", data: response.data });
          value &&
            setFormState({
              daysBeforeVisit:
                response.data.defaultVisitWindow !== null
                  ? response.data.defaultVisitWindow.daysBeforeVisitDate
                  : 0,
              daysAfterVisit:
                response.data.defaultVisitWindow !== null
                  ? response.data.defaultVisitWindow.daysAfterVisitDate
                  : 365,
              enabled: !_get(
                response.data,
                "defaultVisitWindow.disabled",
                true
              ),
              customVisitWindows:
                response.data.customVisitWindows.length > 0
                  ? response.data.customVisitWindows.map(
                      (
                        {
                          customValueType,
                          daysAfterVisitDate,
                          daysBeforeVisitDate,
                          customValueIds,
                          inactive,
                          disabled,
                          serviceAreaConfigurations,
                        },
                        index
                      ) => ({
                        ceid: data.ceid,
                        value: trueFalseValue,
                        daysBeforeVisit: daysBeforeVisitDate,
                        customWindowType:
                          customValueType === "Provider Type" ||
                          customValueType === "Provider"
                            ? customValueType
                            : "Service Area",
                        daysAfterVisit: daysAfterVisitDate,
                        providerTypeValue:
                          customValueType === "Provider Type"
                            ? customValueIds && customValueIds[0].customValueId
                            : "",
                        serviceAreaType:
                          customValueType === "Provider Type" ||
                          customValueType === "Provider"
                            ? ""
                            : getServiceAreaType(customValueType),
                        visitWindowId:
                          customValueIds && customValueIds[0].visitWindowId,
                        providerValues:
                          customValueType === "Provider" ? customValueIds : "",
                        serviceAreaTypeOptions:
                          customValueType === "Provider Type" ||
                          customValueType === "Provider"
                            ? ""
                            : serviceAreaConfigurations,
                        serviceAreaTypeValues:
                          customValueType === "Provider Type" ||
                          customValueType === "Provider"
                            ? ""
                            : customValueIds &&
                              customValueIds.map(
                                ({ visitWindowId, customValueId }) => ({
                                  visitWindowId: visitWindowId,
                                  customValueId: customValueId,
                                })
                              ),
                        active: !inactive,
                        enabled: !disabled,
                        isNew: false,
                        uid: `cvw${index}`,
                      })
                    )
                  : arr,
            });
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_VISIT_CONFIG", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
        } else {
          dispatch({ type: "GET_VISIT_CONFIG", data: response.data });
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch(() => {
        // Possible fix for screen crash in Visit Window, setting default config to display in UI if failed to fetch data
        setFormState({
          daysBeforeVisit: 0,
          daysAfterVisit: 365,
          enabled: false,
          customVisitWindows: arr,
        });
      });
  };
};

export const serviceAreaVisit = (data, setLoader, callback) => {
  return () => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/serviceAreaVisit/${data.ceid}/${data.id}`,
      token
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response.data);
        } else {
          callback && callback([]);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        setLoader(false);
      });
  };
};

export const visitWindowConfigLookup = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/visitConfigurationTypeLkp`,
      token
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "GET_VISIT_CONFIG_LUKUP", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_VISIT_CONFIG_LUKUP", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_VISIT_CONFIG_LUKUP", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const binpcnConfig = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/binPcnConfigDetails/${data.ceid}`,
      token
    ).then((response) => {
      if (response.data) {
        dispatch({ type: "GET_BIN_PCN_CONFIG", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_BIN_PCN_CONFIG", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_BIN_PCN_CONFIG", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const validateAcNo = (value) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/AccountNumberExistorNot/${value}`
    )
      .then((response) => {
        if (response.statusCode === 404) {
          return false;
        } else {
          return true;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const validateRoutingNo = (value) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/RoutingNumberExistorNot/${value}`
    )
      .then((response) => {
        if (response.statusCode === 404) {
          return false;
        } else {
          return true;
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const getCOBasicDetails = (
  payload = {},
  { disableLoader = false, callback } = {}
) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader && dispatch({ type: CE_BASIC_DETAILS_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ceBasicDetails`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: SET_CE_BASIC_DETAILS, data: response.data });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          dispatch({ type: SET_CE_BASIC_DETAILS, data: response.data || {} });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader &&
          dispatch({ type: CE_BASIC_DETAILS_LOADING, data: false });
        return {};
      });
  };
};

export const getCoServiceAreaConfig = (ceId = "", callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    dispatch({ type: SERVICE_AREA_CONFIG_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CEServiceAreaConfiguration/${ceId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_SERVICE_AREA_CONFIG,
            data: response.data || [],
          });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          dispatch({
            type: SET_SERVICE_AREA_CONFIG,
            data: response.data || [],
          });
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        dispatch({ type: SERVICE_AREA_CONFIG_LOADING, data: false });
        return {};
      });
  };
};

export const getPrimaryContactDetails = (
  ceId,
  { disableLoader = false, callback } = {}
) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader &&
      dispatch({ type: CE_PRIMARY_DETAILS_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/userPrimaryContact/${ceId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_CE_PRIMARY_CONTACT_DETAILS,
            data: response.data,
          });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          dispatch({
            type: SET_CE_PRIMARY_CONTACT_DETAILS,
            data: response.data || {},
          });
          return response.data || {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader &&
          dispatch({ type: CE_PRIMARY_DETAILS_LOADING, data: false });
      });
  };
};

export const getCeAchConfig = (ceId, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    dispatch({ type: CE_ACH_CONFIG_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/AchConfigurations/ceId/${ceId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_CE_ACH_CONFIG,
            data: response.data,
          });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          dispatch({
            type: SET_CE_ACH_CONFIG,
            data: response.data || {},
          });
          return response.data || {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        dispatch({ type: CE_ACH_CONFIG_LOADING, data: false });
      });
  };
};
export const getCeLocations = (payload, callback) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export &&
      dispatch({ type: CE_LOCATIONS_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/location/search`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          !payload.export &&
            dispatch({
              type: SET_CE_LOCATIONS_LIST,
              data: response.data,
            });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          !payload.export &&
            dispatch({
              type: SET_CE_LOCATIONS_LIST,
              data: response.data || {},
            });
          return response.data || {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: CE_LOCATIONS_LIST_LOADING, data: false });
      });
  };
};

export const getEligibilityRules = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ceEligibilityRules?ceid=${data.ceID}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          toast.error(response.errorMessage);
          return [];
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getServiceConfigLookup = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CEServiceAreaConfiguration/${data.ceid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_SERVICE_LOOKUP", data: response.data });
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_SERVICE_LOOKUP", data: response.data });
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else {
          dispatch({ type: "GET_SERVICE_LOOKUP", data: response.data });
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      })
      .catch(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        toast.error("Something went wrong.");
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const saveServiceArea = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredentity/servicearea`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return callback(response);
        } else if (response.statusCode === 404) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const saveVisitWindow = (data, setloader, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredEntityVisitWindows`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "ISLOADING", data: false });
          toast.success(response.successMessage);
          return callback(response);
        } else {
          setloader(false);
          toast.error(response.successMessage);
        }
      })
      .catch((error) => {
        setloader(false);
        toast.error(error.message);
      })
      .finally(() => {
        dispatch({ type: "ISLOADING", data: false });
      });
  };
};

export const getVisitWindow = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredEntityVisitWindows/messageUUID/${data.messageUUID}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return callback(response);
        } else if (response.statusCode === 102) {
          return callback(response);
        } else {
          toast.error(response.errorMessage);
          return callback(response);
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getLatestCE = (
  value = false,
  secEList,
  setCeSelected,
  ALL_OPTION = false,
  callback
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/activeCoveredEntities?resultObject=true`
    ).then((response) => {
      if (response.statusCode === 200) {
        if (value) {
          secEList(response.data);
          ALL_OPTION !== false && setCeSelected([ALL_OPTION]);
        }
        dispatch({ type: "GET_LATEST_CE", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        callback && callback(response.data);
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_LATEST_CE", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        callback && callback(response.data);
      } else {
        dispatch({ type: "GET_LATEST_CE", data: response });
        dispatch({ type: "ISLOADING", data: false });
        callback && callback(response.data);
      }
    });
  };
};

// https://api.synerzip.in/config-service/api/v1/coveredentity/servicearea/messageUUID/{messageuuid}
export const getServiceArea = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/coveredentity/servicearea/messageUUID/${data.messageuuid}`
    ).then((response) => {
      if (response.statusCode === 200) {
        toast.success(response.successMessage);
        dispatch({ type: "GET_SERVICE_LOOKUP", data: response.data });
        return callback(response);
      } else if (response.statusCode === 404) {
        toast.error(response.errorMessage);
        dispatch({ type: GLOBAL_LOADING, data: false });
        return callback(response);
      } else if (response.statusCode === 102) {
        return callback(response);
      } else {
        toast.error(response.errorMessage);
        dispatch({ type: GLOBAL_LOADING, data: false });
        return callback(response);
      }
    });
  };
};

export const saveConfigData = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/saveCEAdminFee`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "SAVE_CE_ADMIN_DATA", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        callback && callback(response);
      } else if (response.statusCode === 404) {
        dispatch({ type: "SAVE_CE_ADMIN_DATA", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "SAVE_CE_ADMIN_DATA", data: response.data });
      }
    });
  };
};
// getConfigSearchexport
export const getCOProviderDetails = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/provider/prescriberfiledtl/${data.ceID}`
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_COPROVIDER_DETAILS", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_COPROVIDER_DETAILS", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_COPROVIDER_DETAILS", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const getCOMemberDetails = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/getMembersFileDetails/${data.ceID}`
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_COMEMBER_DETAILS", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_COMEMBER_DETAILS", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_COMEMBER_DETAILS", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};
export const getProvidertype = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/providerType`
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_PROVIDER_LIST", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_PROVIDER_LIST", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_PROVIDER_LIST", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const getCustomconfigvariable = (data) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/customConfigVariableType`
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_CUSTOM_VARIABLES", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_CUSTOM_VARIABLES", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        dispatch({ type: "GET_CUSTOM_VARIABLES", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      }
    });
  };
};

export const updateSectionStatus = ({ ceId, sectionId, callback }) => {
  return (dispatch) => {
    ApiClient.put(
      `${apiUrlUser}${PORT}/${configService}/api/v1/updateCeSectionStatus/${ceId}/${sectionId}`
    )
      .then((response) => {
        callback && callback(response);
      })
      .catch((error) => toast.error(error.message));
  };
};

export const getSectionStatusByCEID = (ceId, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CeSectionStatus/${ceId}`
      //token
    ).then((response) => {
      callback && callback(response);
    });
  };
};

export const getPhSectionStatus = (ceId, clientId, callback) => {
  return (dispatch) => {
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/getPhSectionStatus/${ceId}/${clientId}`
    ).then((response) => {
      callback && callback(response);
    });
  };
};

export const updatePharmacySectionStatus = ({
  ceId,
  clientId,
  sectionId,
  callback,
}) => {
  return (dispatch) => {
    ApiClient.put(
      `${apiUrlUser}${PORT}/${configService}/api/v1/updatePhSectionStatus/${ceId}/${clientId}/${sectionId}`
    )
      .then((response) => {
        callback && callback(response);
      })
      .catch((error) => toast.error(error.message));
  };
};

export const fetchFeesTypes = ({ ceId, clientId } = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/adminfeeType/${ceId}/${clientId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const fetchClaimTypesOption = (addClaimTypeId = "") => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/adminFeeClaimType/${addClaimTypeId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const fetchAddClaimTypesOption = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/adminFeeAddlClaimType`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message));
};

export const fetchSwitchOptions = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/adminFeeSwitchType`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message));
};

export const fetchBasisOfOptions = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/adminFeePercentageBasis`
  )
    .then((response) => {
      if (checkResponse(response)) {
        return response.data;
      } else {
        return [];
      }
    })
    .catch((error) => toast.error(error.message));
};

export const exportConfigDataToPdf = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    axiosInstance.defaults.responseType = "blob";
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/configExportPDF`,
      payload
    )
      .then((response) => {
        if (response) {
          const blob = new Blob([response], {
            type: "application/pdf",
          });
          FileSaver.saveAs(
            blob,
            `Covered Entity Configuration ${payload.ceId} ${moment().format(
              "YYYY-MM-DD hh:mm:ss"
            )}.pdf`
          );
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        axiosInstance.defaults.responseType = undefined;
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

// Visit Window Providers GET API
export const getAllCeProviders = (ceId, setProviders) => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/provider/providers/${ceId}`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        setProviders([...response.data]);
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
      return [];
    })
    .finally(() => {
      return [];
    });
};

// Get CO Ordering Config Wholesalers data
export const getCeWholesalers = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/ordering-configuration`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch(() => {
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};
