import { toast } from "react-toastify";
import ApiClient, { axiosInstance } from "../../../api-client";
import {
  apiUrlUser,
  PORT,
  backendService,
  configService,
} from "../../../environment";
import "react-toastify/dist/ReactToastify.css";
import { checkResponse } from "../../../utils/helper";
import { GLOBAL_LOADING } from "../../constants";
import {
  GET_MEMBER_LIST,
  GET_PATIENT_INNER_LIST,
  GET_PATIENT_LIST,
  PATIENTS_INFO_LOADING,
  PATIENTS_LOADING,
} from "../../reducers/Patients/constants";
import FileSaver from "file-saver";

let token = localStorage.Accesstoken;

export const getPatientType = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${backendService}/api/patient/patientType`,
      data
    ).then((response) => {
      // toast.dismiss();
      if (response.statusCode === 200) {
        dispatch({ type: "patientType", data: response.data });
        //toast.success(response.successMessage);
        dispatch({ type: "ISLOADING", data: false });
        // return callback(response);
      } else if (response.statusCode === 404) {
        toast.error(response.errorMessage);
        // return callback(response);
      } else {
        //Error message 500
        toast.error(response.errorMessage);
      }
    });
  };
};

export const fetchPatientType = () => {
  return ApiClient.get(
    `${apiUrlUser}${PORT}/${configService}/api/v1/patient/patientType`
  )
    .then((response) => {
      if (response.statusCode === 200) {
        return response.data;
      }
    })
    .catch((error) => {
      toast.error(error.message);
    });
};

//patient Export

export const getPatientExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/patient/search`,
      data
    ).then((response) => {
      // toast.dismiss();
      if (response.data) {
        toast.success(response.successMessage);
        dispatch({ type: "ISLOADING", data: false });
        return callback(response.data);
      } else if (response.statusCode === 404) {
        dispatch({ type: "PATIENT_EXPORT", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        toast.error(response.errorMessage);
        return callback(response);
      } else {
        //Error message 500
        //dispatch({ type: "PATIENT_EXPORT", data:response.data });
        dispatch({ type: "ISLOADING", data: false });
        toast.error(response.errorMessage);
      }
    });
  };
};

export const patientExport = (data, Co, callback) => {
  const fetchPatientUrl = `${Co ? "CEMembers" : "patient/search"}`;
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/${fetchPatientUrl}`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getPatientSearchData = (payload, Co, callback) => {
  const fetchPatientUrl = `${Co ? "CEMembers" : "patient/search"}`;
  return (dispatch) => {
    if (payload.export) {
      axiosInstance.defaults.responseType = "blob";
      dispatch({ type: GLOBAL_LOADING, data: true });
    } else {
      dispatch({ type: PATIENTS_LOADING, data: true });
    }
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/${fetchPatientUrl}`,
      payload
    )
      .then((response) => {
        if (payload.export) {
          const blob = new Blob([response], {
            type: "application/octet-stream",
          });
          FileSaver.saveAs(
            blob,
            `${Co ? "CO_Patients List" : "Patients List"}.xlsx`
          );
        } else {
          if (response.statusCode === 200) {
            dispatch({
              type: Co ? GET_MEMBER_LIST : GET_PATIENT_LIST,
              data: response.data,
            });
            return callback && callback(response.data);
          } else if (response.statusCode === 404) {
            dispatch({
              type: Co ? GET_MEMBER_LIST : GET_PATIENT_LIST,
              data: response.data,
            });
            return callback && callback(response.data);
          }
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => {
        if (payload.export) {
          axiosInstance.defaults.responseType = undefined;
          dispatch({ type: GLOBAL_LOADING, data: false });
        } else {
          dispatch({ type: PATIENTS_LOADING, data: false });
          return {};
        }
      });
  };
};

//Patient Table List
export const getPatientList = (data, Co, popup = true) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/CEMembers`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "GET_PATIENT_LIST", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "GET_PATIENT_LIST", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
      } else {
        //Error message 500
        dispatch({ type: "GET_PATIENT_LIST", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        toast.error(response.errorMessage);
      }
    });
  };
};

export const getPatientVisitInfo = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: PATIENTS_INFO_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}/${configService}/api/v1/patient/patientVisitInfo`,
      data
    )
      .then((response) => {
        if (checkResponse(response)) {
          return dispatch({
            type: GET_PATIENT_INNER_LIST,
            data: response.data,
          });
        } else {
          return dispatch({
            type: GET_PATIENT_INNER_LIST,
            data: response.data,
          });
        }
      })
      .catch((error) => toast.error(error.errorMessage))
      .finally(() => dispatch({ type: PATIENTS_INFO_LOADING, data: false }));
  };
};

//patient Inner Export

export const patientVisitInfoExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/patientVisitInfo`,
      data
    )
      .then((response) => {
        if (response.data) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          return callback(response.data);
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const saveMemberDropVal = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/saveMemberConfigFile`,
      data,
      token
    ).then((response) => {
      dispatch({ type: "ISLOADING", data: false });
      // toast.dismiss();
      if (response.statusCode === 200) {
        dispatch({ type: "ISLOADING", data: false });
        toast.success(response.successMessage);
        return callback && callback(response);
      } else if (response.status === 404) {
        dispatch({ type: "ISLOADING", data: false });
        toast.error(response.error);
        // return callback(response);
      } else {
        //Error message 500
        toast.error(response.error);
      }
    });
  };
};

export const getMNRExist = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/PatientMRN/${data}`
    )
      .then((response) => {
        callback && callback(response);
        dispatch({ type: "ISLOADING", data: false });
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const savePatient = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/addPatient`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const savePatientMessageUuid = (uuid, count, editPatient = true) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/addPatient/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else if (response.statusCode === 500) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage || response.error);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const getEditPatientData = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "IS_ADDPATIENT_LOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/editPatientDetails/${data}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response);
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
        } else if (response.statusCode === 500) {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
        }
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: "IS_ADDPATIENT_LOADING", data: false }));
  };
};

export const deletePatient = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "IS_ADDPATIENT_LOADING", data: true });
    return ApiClient.delete(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/deletePatient/${data.patientId}/${data.modifiedBy}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
      });
  };
};

export const deletePatientMessageUUID = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: "IS_ADDPATIENT_LOADING", data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/deletePatient/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
          toast.success("Patient terminated successfully");
        } else if (response.statusCode === 102) {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: true });
        } else {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
          toast.error(response.errorMessage);
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: "IS_ADDPATIENT_LOADING", data: false });
        }
      });
  };
};

export const addVisitInfo = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/addPatientVisits`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response;
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return {};
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      });
  };
};

export const addVisitMessageUUID = (uuid, count) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/patientVisits/messageUUID/${uuid}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.success(response.successMessage);
        } else if (response.statusCode === 102) {
          dispatch({ type: GLOBAL_LOADING, data: true });
        } else if (response.statusCode === 500) {
          dispatch({ type: GLOBAL_LOADING, data: false });
          toast.error(response.errorMessage);
        } else {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
        return response;
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({ type: GLOBAL_LOADING, data: false });
      })
      .finally(() => {
        if (count <= 1) {
          dispatch({ type: GLOBAL_LOADING, data: false });
        }
      });
  };
};

export const fetchSlidingScaleValues = (ceIdForSlicdingScale) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/slidingScale/${ceIdForSlicdingScale}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getVisitDateExist = (payload, callback) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/patient/visitDateExistOrNot`,
      payload
    )
      .then((response) => {
        callback && callback(response);
      })
      .catch((error) => toast.error(error))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const fetchMemberConfigFile = (ceId, loading = true) => {
  return (dispatch) => {
    loading && dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/getMemberConfigFile/${ceId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(
        () => loading && dispatch({ type: GLOBAL_LOADING, data: false })
      );
  };
};
