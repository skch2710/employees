import { toast } from "react-toastify";
import ApiClient from "../../../../../api-client";
import { GLOBAL_LOADING } from "../../../../constants";
import {
  PORT,
  apiUrlUser,
  userService,
  configService,
} from "../../../../../environment";
import { checkResponse } from "../../../../../utils/helper";
import {
  CE_ADMIN_FEES_LIST_LOADING,
  CE_FREQUENCY_LOADING,
  SET_CE_ADMIN_FEES_LIST,
  SET_CE_FREQUENCY,
  SET_BILLING_CONTACT_LIST,
  BILLING_CONTACTS_LOADING,
} from "../../../../reducers/ConfigOverview/constants";

export const getBillingFeeContacts = (payload, { callback } = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: BILLING_CONTACTS_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${userService}/api/v1/user/billContactInformation`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_BILLING_CONTACT_LIST, data: response.data });
          callback && callback(response.data);
          return response.data;
        } else {
          !payload.export &&
            dispatch({
              type: SET_BILLING_CONTACT_LIST,
              data: response.data || {},
            });
          callback && callback(response.data);
          return {};
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: BILLING_CONTACTS_LOADING, data: false });
        return {};
      });
  };
};

export const getCeAdminBillingFees = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export &&
      dispatch({ type: CE_ADMIN_FEES_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/search`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_CE_ADMIN_FEES_LIST, data: response.data });
          return response.data;
        } else {
          !payload.export &&
            dispatch({ type: SET_CE_ADMIN_FEES_LIST, data: response.data });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: CE_ADMIN_FEES_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const saveCeAdminFees = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/saveCEAdminFee`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return true;
        } else if (response.statusCode === 404) {
          toast.error(response.errorMessage);
          return false;
        }
      })
      .catch((error) => {
        toast.error(error.message);
        return false;
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return false;
      });
  };
};

export const editCeAdminFee = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.put(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/editCEAdminFee`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return true;
        } else return false;
      })
      .catch((error) => {
        toast.error(error.message);
        return false;
      })
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return false;
      });
  };
};

export const fetchCeFrequency = (ceId, { disableLoader = false } = {}) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader && dispatch({ type: CE_FREQUENCY_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/ceAdminFeeFreq/${ceId}`
    )
      .then((response) => {
        checkResponse(response);
        dispatch({ type: SET_CE_FREQUENCY, data: response.data || {} });
        return response.data;
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader && dispatch({ type: CE_FREQUENCY_LOADING, data: false });
        return {};
      });
  };
};

export const editCeAdminBillingAndFees = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.put(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/updateCeAdminFeeFreq`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          toast.success(response.successMessage);
          return true;
        }
        return false;
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const saveCeAdminBillingAndFees = (payload) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/saveCeAdminFeeFreq`,
      payload
    )
      .then((response) => {
        if (checkResponse(response)) {
          toast.success(response.successMessage);
          return true;
        }
        return false;
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getAdminFeesAndPharmacies = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/billingfees/adminFeesForPharmacy/${payload.ceId}/${payload.feeId}`
    )
      .then((response) => {
        if (response) {
          return response.data;
        }
        return [];
      })
      .catch((error) => {
        toast.error(error.message);
        return [];
      })
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};
