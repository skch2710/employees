import { GLOBAL_LOADING } from "../../constants";

const initialState = { general: {}, isActive: "" };

export const general = (state = initialState, action) => {
  switch (action.type) {
    case "validateUUID":
      return { ...state.general, ...action.data };
    default:
      return state;
  }
};

export const globalLoader = (state = { loading: false }, action) => {
  switch (action.type) {
    case GLOBAL_LOADING:
      return { loading: action.data };
    default:
      return state;
  }
};
