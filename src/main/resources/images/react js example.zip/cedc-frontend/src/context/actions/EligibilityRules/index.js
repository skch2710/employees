import { toast } from "react-toastify";
import ApiClient from "../../../api-client";
import { PORT, apiUrlUser, configService } from "../../../environment";
import { GLOBAL_LOADING } from "../../constants";
import {
  ELIGIBILITY_CONFIG_LOADING,
  SET_ELIGIBILITY_CONFIG,
} from "../../reducers/ConfigOverview/constants";

export const getEligibilityRulesLookup = () => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/getEligibilityRulesPlusLKP`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          return response.data;
        } else {
          return [];
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};

export const getEligibilityRuleSets = (
  ceId = "",
  { disableLoader = false, callback } = {}
) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader &&
      dispatch({ type: ELIGIBILITY_CONFIG_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/getEligibilityRulesPlus/${ceId}`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({
            type: SET_ELIGIBILITY_CONFIG,
            data: response.data || [],
          });
          callback && callback(response.data);
          return response.data;
        } else {
          callback && callback(response.data);
          dispatch({
            type: SET_ELIGIBILITY_CONFIG,
            data: response.data || [],
          });
          return [];
        }
      })
      .catch((error) => {
        toast.error(error.message);
        dispatch({
          type: SET_ELIGIBILITY_CONFIG,
          data: [],
        });
        return [];
      })
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader &&
          dispatch({ type: ELIGIBILITY_CONFIG_LOADING, data: false });
        return [];
      });
  };
};

export const saveEligibilityRulesList = (data) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/saveEligibilityRulesPlus`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          toast.success(response.successMessage);
          return response;
        } else {
          toast.error(response.errorMessage);
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => dispatch({ type: GLOBAL_LOADING, data: false }));
  };
};
