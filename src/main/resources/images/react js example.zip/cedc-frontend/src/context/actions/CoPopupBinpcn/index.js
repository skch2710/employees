import ApiClient from "../../../api-client";
import { toast } from "react-toastify";
import { PORT, apiUrlUser, backendService } from "../../../environment";
import "react-toastify/dist/ReactToastify.css";

export const Cobinpcndata = (data, popup = true) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/config-service/api/v1/binPcnConfigDetails`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "Cobinpcn_data", data: response.data });
        if (popup) {
          toast.success(response.successMessage);
        }
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "Cobinpcn_data", data: response.data });
        dispatch({ type: "ISLOADING", data: false });

        if (popup) {
          toast.error(response.errorMessage);
        }
        // return callback(response);
      } else {
        dispatch({ type: "Cobinpcn_data", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        //Error message 500
        toast.error(response.errorMessage);
      }
    });
  };
};

export const Cobinpcndatatoggleoff = (data, popup = true) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/config-service/api/v1/phCEBINBlocksDetails`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "Cobinpcndata_toggleoff", data: response.data });
        if (popup) {
          // toast.success(response.successMessage);
        }
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "Cobinpcndata_toggleoff", data: response.data });
        dispatch({ type: "ISLOADING", data: false });

        if (popup) {
          // toast.error(response.errorMessage);
        }
        // return callback(response);
      } else {
        dispatch({ type: "Cobinpcndata_toggleoff", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        //Error message 500
        toast.error(response.errorMessage);
      }
    });
  };
};

export const BinpcnmainExport = (data, popup = true) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/config-service/api/v1/binPcnConfigDetails`,
      data
    ).then((response) => {
      if (response.statusCode === 200) {
        dispatch({ type: "BinpcnmainExport_data", data: response.data });
        if (popup) {
          toast.success(response.successMessage);
        }
        dispatch({ type: "ISLOADING", data: false });
      } else if (response.statusCode === 404) {
        dispatch({ type: "Cobinpcn_data", data: response.data });
        dispatch({ type: "ISLOADING", data: false });

        if (popup) {
          toast.error(response.errorMessage);
        }
        // return callback(response);
      } else {
        dispatch({ type: "Cobinpcn_data", data: response.data });
        dispatch({ type: "ISLOADING", data: false });
        //Error message 500
        toast.error(response.errorMessage);
      }
    });
  };
};