import { toast } from "react-toastify";
import ApiClient, { axiosInstance } from "../../../api-client";
import { apiUrlUser, PORT, configService } from "../../../environment";
import "react-toastify/dist/ReactToastify.css";
import { GLOBAL_LOADING } from "../../constants";
import {
  PHARMACIES_LIST_LOADING,
  PH_ADMIN_FEES_LOADING,
  PH_DISPENSING_FEES_LOADING,
  PH_ELIGIBILITY_LOADING,
  PH_ORDERING_LOADING,
  SET_PHARMACIES_LIST,
  SET_PH_ADMIN_FEES_LIST,
  SET_PH_DISPENSING_FEES_LIST,
  SET_PH_ELIGIBILITY_DETAILS,
  SET_PH_ORDERING_DETAILS,
} from "../../reducers/Pharmacies/constants";
import { checkResponse } from "../../../utils/helper";
import moment from "moment";

export const getPharmaciesMainModule = (
  data,
  popup = true,
  value = false,
  setLoader
) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/search`,
      data
    )
      .then((response) => {
        if (response.statusCode === 200) {
          dispatch({ type: "GET_PHARMACY_LIST", data: response.data });
          if (popup) {
            toast.success(response.successMessage);
          }
          value && setLoader(false);
          dispatch({ type: "ISLOADING", data: false });
        } else if (response.statusCode === 404) {
          dispatch({ type: "GET_PHARMACY_LIST", data: response.data });
          if (popup) {
            toast.error(response.errorMessage);
          }
          value && setLoader(false);
          dispatch({ type: "ISLOADING", data: false });
        } else {
          dispatch({ type: "GET_PHARMACY_LIST", data: response.data });
          toast.error(response.errorMessage);
          value && setLoader(false);
          dispatch({ type: "ISLOADING", data: false });
        }
      })
      .catch((error) => {
        toast.error(error);
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getPharmaciesexport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/pharmaciesSearch`,
      data
    )
      .then((response) => {
        if (response.data) {
          dispatch({ type: "ISLOADING", data: false });
          return callback(response.data);
        } else if (response.statusCode === 404) {
          toast.error(response.errorMessage);
          dispatch({ type: "ISLOADING", data: false });
        } else {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getPharmaciesMainExport = (data, callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/search`,
      data
    )
      .then((response) => {
        if (response.data) {
          dispatch({ type: "ISLOADING", data: false });
          return callback(response.data);
        } else if (response.statusCode === 404) {
          toast.error(response.errorMessage);
          dispatch({ type: "ISLOADING", data: false });
        } else {
          callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const getPharamacyConfigStatus = (callback) => {
  return (dispatch) => {
    dispatch({ type: "ISLOADING", data: true });
    ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/PharmacyConfigurationStatus`
    )
      .then((response) => {
        if (response.statusCode === 200) {
          callback && callback(response.data);
        } else {
          toast.error(response.errorMessage);
          callback && callback(response.data);
        }
      })
      .catch((error) => {
        toast.error(error);
        callback && callback([]);
      })
      .finally(() => dispatch({ type: "ISLOADING", data: false }));
  };
};

export const fetchPharmaciesTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: PHARMACIES_LIST_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/search`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_PHARMACIES_LIST, data: response.data });
          return response.data;
        } else {
          !payload.export &&
            dispatch({ type: SET_PHARMACIES_LIST, data: response.data });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: PHARMACIES_LIST_LOADING, data: false });
        return {};
      });
  };
};

export const fetchSingleCePharmaciesTableData = (payload = {}) => {
  return () => {
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/search`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          return response.data;
        } else {
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        return {};
      });
  };
};

export const fetchPhAdminFeesTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export && dispatch({ type: PH_ADMIN_FEES_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phAdminFeesDetails`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({ type: SET_PH_ADMIN_FEES_LIST, data: response.data });
          return response.data;
        } else {
          !payload.export &&
            dispatch({ type: SET_PH_ADMIN_FEES_LIST, data: response.data });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: PH_ADMIN_FEES_LOADING, data: false });
        return {};
      });
  };
};

export const fetchPhDispensingFeesTableData = (payload = {}) => {
  return (dispatch) => {
    payload.export && dispatch({ type: GLOBAL_LOADING, data: true });
    !payload.export &&
      dispatch({ type: PH_DISPENSING_FEES_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phDispensingAddedFeesDetails`,
      payload
    )
      .then((response) => {
        if (response.statusCode === 200 || response.statusCode === 404) {
          !payload.export &&
            dispatch({
              type: SET_PH_DISPENSING_FEES_LIST,
              data: response.data,
            });
          return response.data;
        } else {
          !payload.export &&
            dispatch({
              type: SET_PH_DISPENSING_FEES_LIST,
              data: response.data,
            });
          return {};
        }
      })
      .catch((error) => {
        toast.error(error.message);
      })
      .finally(() => {
        payload.export && dispatch({ type: GLOBAL_LOADING, data: false });
        !payload.export &&
          dispatch({ type: PH_DISPENSING_FEES_LOADING, data: false });
        return {};
      });
  };
};

export const getCeListOnPhGroupId = (payload = {}) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.post(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacyGroupDropdown`,
      payload
    )
      .then((response) => {
        return response.data;
      })
      .catch((error) => toast.error(error))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return [];
      });
  };
};

export const getCeListAndPhChainListOnPhId = (phId) => {
  return (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/pharmacy/pharmacyDropdown/${phId}`
    )
      .then((response) => {
        return response.data;
      })
      .catch((error) => toast.error(error))
      .finally(() => {
        dispatch({ type: GLOBAL_LOADING, data: false });
        return {};
      });
  };
};

export const fetchPhEligibilityDetails = (
  clientId,
  { disableLoader = false, callback } = {}
) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader && dispatch({ type: PH_ELIGIBILITY_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phEligibilityDetails/${clientId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          dispatch({ type: SET_PH_ELIGIBILITY_DETAILS, data: response.data });
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader &&
          dispatch({ type: PH_ELIGIBILITY_LOADING, data: false });
        return {};
      });
  };
};

export const phGroupOrderingAndReplenishDetails = (
  clientId,
  { disableLoader = false, callback } = {}
) => {
  return (dispatch) => {
    !disableLoader && dispatch({ type: GLOBAL_LOADING, data: true });
    !disableLoader && dispatch({ type: PH_ORDERING_LOADING, data: true });
    return ApiClient.get(
      `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/phGroupOrderAndReplenishDetails/${clientId}`
    )
      .then((response) => {
        if (checkResponse(response)) {
          dispatch({ type: SET_PH_ORDERING_DETAILS, data: response.data });
          callback && callback(response.data);
          return response.data;
        }
      })
      .catch((error) => toast.error(error.message))
      .finally(() => {
        !disableLoader && dispatch({ type: GLOBAL_LOADING, data: false });
        !disableLoader && dispatch({ type: PH_ORDERING_LOADING, data: false });
        return {};
      });
  };
};

export const exportPharmacyConfigDataToPdf = (
  clientId,
  phId,
  isInternalUser
) => {
  return async (dispatch) => {
    dispatch({ type: GLOBAL_LOADING, data: true });
    try {
      try {
        axiosInstance.defaults.responseType = "blob";
        const response = await ApiClient.get(
          `${apiUrlUser}${PORT}/${configService}/api/v1/PharmacyConfig/getPHTable/${clientId}/${phId}/${isInternalUser}`
        );

        // access blob file from api response and generate blob url
        const url = URL.createObjectURL(new Blob([response]));

        // create a link element and pass blob url to download the blob file received
        const a = document.createElement("a");
        a.style.display = "none";
        document.body.appendChild(a);
        a.href = url;
        a.download = `Pharmacy Configuration ${clientId}-${phId} ${moment(
          new Date()
        ).format("YYYY-MM-DD hh:mm:ss")}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
      } catch (error) {
        toast.error(error.message);
      }
    } finally {
      axiosInstance.defaults.responseType = undefined;
      dispatch({ type: GLOBAL_LOADING, data: false });
    }
  };
};
