const initialgetbasicdetailsco = {  records: [],
    count: 0,
    isActive: '',loading:false}
  
  

  
  export const Cebasic_details = (state = initialgetbasicdetailsco, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "CoCebasic_details":
       return { ...state.Cebasic_details, records: action.data};  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetbasicdetailsco;
       default:
        return state;
    }
  };
  
  export const Cebasic_detailsmessageuuid = (state = initialgetbasicdetailsco, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "Cobasicdetails_msguuid":
       return { ...state.Cebasic_detailsmessageuuid, records: action.data};  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetbasicdetailsco;
       default:
        return state;
    }
  };
  

  export const ce_states_list = (state = initialgetbasicdetailsco, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "states_list":
       return { ...state.ce_states_list, records: action.data};  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetbasicdetailsco;
       default:
        return state;
    }
  };
  
  export const CETypedropdownvalues = (state = initialgetbasicdetailsco, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "CE_Type_dropdownlist":
       return { ...state.CETypedropdownvalues, records: action.data};  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetbasicdetailsco;
       default:
        return state;
    }
  };
  
  export const CecodeExist = (state = initialgetbasicdetailsco, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "get_CecodeExist":
       return { ...state.CecodeExist, records: action.data};  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetbasicdetailsco;
       default:
        return state;
    }
  };
  
 
  export const Primary_Contact_details = (state = initialgetbasicdetailsco, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "Primary_Contactdetails":
       return { ...state.Primary_Contact_details, records: action.data};  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetbasicdetailsco;
       default:
        return state;
    }
  };