const initialgetBinPcn = {  records: [],
    count: 0,
    isActive: '',loading:false}
  
    
  export const cobinpcngriddata = (state = initialgetBinPcn, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "Cobinpcn_data":
       return { ...state.cobinpcngriddata, records: action.data, count: action.data.totalElements  };  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetBinPcn;
       default:
        return state;
    }
  };

  export const cobinpcntoggleoffdata = (state = initialgetBinPcn, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "Cobinpcndata_toggleoff":
       return { ...state.cobinpcntoggleoffdata, records: action.data, count: action.data.totalElements  };  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetBinPcn;
       default:
        return state;
    }
  };
  

  export const ExportBinPcnmain = (state = initialgetBinPcn, action) => {
    switch (action.type) {
      case "ISLOADING":
        return { ...state, loading: action.data }
        case "ADD_USER":
          return { ...state };
      case "BinpcnmainExport_data":
       return { ...state.ExportBinPcnmain, records: action.data, count: action.data.totalElements  };  
      //  case "Providers_Export":
      //   return { ...state.providersalldata, records: action.data, count: action.data.totalElements  };  
      case "LOGOUT":
      return initialgetBinPcn;
       default:
        return state;
    }
  };
  