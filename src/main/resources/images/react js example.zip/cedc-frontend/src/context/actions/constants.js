export const DEFAULT_ERROR_TOAST_MSG = "Something went wrong.";
