import axios from "axios";
import jwt_decode from "jwt-decode";
import moment from "moment";
import { toast } from "react-toastify";
import { BASIC_USERNAME, BASIC_PASSWORD } from "../utils/constants";

const baseURL = process.env.REACT_APP_NEW_API;

const axiosInstance = axios.create({
  baseURL,
});

axiosInstance.interceptors.request.use(async (req) => {
  if (req.url.includes("/user-service/api/v1/login/")) return req;
  const authTokens = localStorage.getItem("Accesstoken");
  if (
    !authTokens ||
    req.url.includes("backend-service") ||
    req.url.includes("auth-service")
  )
    return req;
  req.headers["Authorization"] = "Bearer " + authTokens;
  const user = jwt_decode(authTokens);
  const isExpired = moment.unix(user.exp).diff(moment()) < 1;

  if (!isExpired) return req;
  const string = `${BASIC_USERNAME}:${BASIC_PASSWORD}`;
  const authHeader = `Basic ${Buffer.from(string).toString("base64")}`;
  const headers = {
    Authorization: authHeader,
  };
  const refreshTokens = localStorage.getItem("Refreshtoken");
  return await axios
    .post(
      `${baseURL}/auth-service/oauth/token?grant_type=refresh_token&refresh_token=${refreshTokens}`,
      {},
      { headers: headers }
    )
    .then((res) => {
      localStorage.setItem("Accesstoken", res.data.access_token);
      localStorage.setItem("Refreshtoken", res.data.refresh_token);
      req.headers.Authorization = `Bearer ${res.data.access_token}`;
      return req;
    })
    .catch(() => {
      toast.error("Your session has expired, Please login.");
      localStorage.removeItem("Accesstoken");
      localStorage.removeItem("Refreshtoken");
      localStorage.removeItem("sessionslogindata");
      window.location = "/";
    });
});

export default axiosInstance;
