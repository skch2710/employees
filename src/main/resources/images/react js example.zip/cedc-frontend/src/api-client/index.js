/*
 * @file: index.js
 * @description: It Contain rest functions for api call .
 * @author: Dixit
 */
import querystring from "querystring";
import { toast } from "react-toastify";
import axiosInstance from "./axiosInstance";

toast.configure();
var config = {
  headers: {
    "Content-Type": "application/json",
  },
};

var logoutErrFlag = false;
var langHeaders = () => {
  return { headers: { ...config.headers } };
};

const logout = (error, dispatch) => {
  logoutErrFlag = true;
  if (
    dispatch &&
    error.response.data &&
    error.response.data.statusCode === 403
  ) {
    dispatch({ type: "SET_ACTIVE_MAIN_MENU", data: false });
    dispatch({ type: "SET_ACTIVE_MENU_TITLE", data: "" });
    dispatch({ type: "LOGOUT", data: {} });
  }
};
class ApiClient {
  static post(url, params, token = null, dispatch = null) {
    return new Promise((fulfill, reject) => {
      axiosInstance
        .post(url, JSON.stringify(params), langHeaders())
        .then(function (response) {
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response) {
            if (error.response.data.statusCode === 500) {
              reject(error);
            } else if (error.response.data.statusCode === 403) {
              logout(error, dispatch);
              fulfill(error.response.data);
            } else fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  static put(url, params, token = null, dispatch = null) {
    return new Promise(function (fulfill, reject) {
      axiosInstance
        .put(url, JSON.stringify(params), langHeaders())
        .then(function (response) {
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  static get(url, params, token = null, dispatch = null) {
    let query = querystring.stringify(params);
    url = query ? `${url}?${query}` : url;
    return new Promise(function (fulfill, reject) {
      axiosInstance
        .get(url, langHeaders())
        .then(function (response) {
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response) {
            if (error.response.data.statusCode === 500) {
              reject(error);
            } else if (error.response.data.statusCode === 403) {
              logout(error, dispatch);
              fulfill(error.response.data);
            } else fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  static fetch(url, params, token = null, dispatch = null) {
    let query = querystring.stringify(params);
    url = query ? `${url}?${query}` : url;
    return new Promise(function (fulfill, reject) {
      axiosInstance
        .get(url, langHeaders())
        .then(function (response) {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  static patch(url, params, token = null, dispatch = null) {
    return new Promise(function (fulfill, reject) {
      axiosInstance
        .patch(url, JSON.stringify(params), langHeaders())
        .then(function (response) {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  static delete(url, token = null, dispatch = null) {
    // if (token) setAuthorizationToken(axios, token);
    return new Promise(function (fulfill, reject) {
      axiosInstance
        .delete(url, langHeaders())
        .then(function (response) {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }
  /*************** Form-Data Method without file for Create ***********/
  static _postFormData(url, params, { setProgress, dispatch } = {}) {
    // if (token) setAuthorizationToken(axios, token);
    return new Promise(function (fulfill, reject) {
      axiosInstance
        .post(url, params, {
          ...{ headers: { "Content-Type": "multipart/form-data" } },
          onUploadProgress: (progressEvent) => {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setProgress && setProgress(percentCompleted);
          },
        })
        .then(function (response) {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  /*************** Form-Data Method for Update ***********/
  static _putFormData(url, params, token = null, dispatch = null) {
    // setAuthorizationToken(axios, token);
    return new Promise(function (fulfill, reject) {
      // var body = new FormData();
      // body.append("file", params);
      axiosInstance
        .put(url, params, {
          ...langHeaders(),
          ...{
            headers: {
              "Content-Type": "multipart/form-data",
              slug: localStorage.getItem("SLUG")
                ? localStorage.getItem("SLUG")
                : "",
            },
          },
        })

        .then(function (response) {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch(function (error) {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  /*************** Form-Data post with file Method ***********/
  static postFormData(url, body, token = null, dispatch = null) {
    // setAuthorizationToken(axios, token);
    return new Promise((fulfill, reject) => {
      axiosInstance
        .post(url, body, {
          ...langHeaders(),
          ...{
            headers: {
              "Content-Type": "multipart/form-data",
              slug: localStorage.getItem("SLUG")
                ? localStorage.getItem("SLUG")
                : "",
            },
          },
        })

        .then((response) => {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch((error) => {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }

  /*************** Form-Data update with file Method ***********/
  static putFormData(url, body, token = null, dispatch = null) {
    // setAuthorizationToken(axios, token);
    return new Promise((fulfill, reject) => {
      axiosInstance
        .put(url, body, {
          ...langHeaders(),
          ...{
            headers: {
              "Content-Type": "multipart/form-data",
              slug: localStorage.getItem("SLUG")
                ? localStorage.getItem("SLUG")
                : "",
            },
          },
        })
        .then((response) => {
          toast.dismiss();
          fulfill(response.data);
        })
        .catch((error) => {
          if (error && error.response && !logoutErrFlag) {
            logout(error, dispatch);
            fulfill(error.response.data);
          } else {
            reject(error);
          }
        });
    });
  }
}

export default ApiClient;
export { axiosInstance };
